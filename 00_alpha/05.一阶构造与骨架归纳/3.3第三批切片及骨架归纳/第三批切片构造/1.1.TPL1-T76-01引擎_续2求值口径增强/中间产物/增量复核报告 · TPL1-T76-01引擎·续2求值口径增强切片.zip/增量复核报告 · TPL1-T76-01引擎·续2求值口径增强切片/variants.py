#!/usr/bin/env python3
"""变异目录：外审附录B之44例有效变异 ＋ E-1通道 ＋ 五通道针对性重放 ＋ 复核侧自增例。"""
from replay import *

V = []


def add(vid, desc, mutate, pipeline=PIPE_FULL):
    V.append((vid, desc, mutate, pipeline))


# ---------------- M01–M19 单侧·engine ----------------
add("M01", "d1中q符号翻转 (r−q)→(r+q)",
    lambda R: patch(R, ENG, "(r - q + 0.5 * sig * sig)", "(r + q + 0.5 * sig * sig)"))
add("M02", "call delta去 e^{-qT}",
    lambda R: patch(R, ENG, "        delta = disc_q * _norm_cdf(d1)\n", "        delta = _norm_cdf(d1)\n"))
add("M03", "call value首项去 disc_q",
    lambda R: patch(R, ENG, "value = S * disc_q * _norm_cdf(d1) - K * disc_r * _norm_cdf(d2)",
                    "value = S * _norm_cdf(d1) - K * disc_r * _norm_cdf(d2)"))
add("M04", "call theta去 +qSe^{-qT}N(d1)",
    lambda R: patch(R, ENG, "                 + q * S * disc_q * _norm_cdf(d1))",
                    "                 + 0.0)"))
add("M05", "gamma去 disc_q",
    lambda R: patch(R, ENG, "gamma = disc_q * nd1 / (S * sig * sqrtT)", "gamma = nd1 / (S * sig * sqrtT)"))
add("M06", "vega去 disc_q",
    lambda R: patch(R, ENG, "vega = S * disc_q * nd1 * sqrtT", "vega = S * nd1 * sqrtT"))
add("M07", "call rho多乘 disc_q",
    lambda R: patch(R, ENG, "rho = K * T * disc_r * _norm_cdf(d2)", "rho = K * T * disc_r * disc_q * _norm_cdf(d2)"))
add("M08", "忽略声明q（q≡0，字段仍读）",
    lambda R: patch(R, ENG, 'q = float(lot["dividend_yield"])', 'q = float(lot["dividend_yield"]) * 0.0'))
add("M09", "engine分母365→360",
    lambda R: patch(R, ENG, "DAY_COUNT_DENOMINATOR = 365", "DAY_COUNT_DENOMINATOR = 360"))
add("M10", "美式桩改走无q路径",
    lambda R: patch(R, ENG, "    return _eval_bs_dividend_yield(lot)\n",
                    "    return _eval_bs_dividend_yield(dict(lot, dividend_yield=0.0))\n"))
add("M11", "engine: european回标 dividend_carry",
    lambda R: patch(R, ENG, '"european_option":  ("day_count_convention",),',
                    '"european_option":  ("day_count_convention", "dividend_carry"),'))
add("M12", "engine: european升标 closed_on_stated_face",
    lambda R: patch(R, ENG, '"european_option":  "computed_with_open_dimensions",',
                    '"european_option":  "closed_on_stated_face",'))
add("M13", "route_id回退旧名",
    lambda R: patch(R, ENG, '"european_option":  "bs_dividend_yield_closed_form",   # 续2改名',
                    '"european_option":  "bs_no_dividend_closed_form",   # 续2改名'))
add("M14", "side_sign short −1→+1",
    lambda R: patch(R, ENG, 'if side == "short":\n        return -1', 'if side == "short":\n        return 1'))
add("M15", "缩放式丢 multiplier",
    lambda R: patch(R, ENG, 'scale = int(lot["multiplier"]) * int(lot["quantity"]) * _side_sign(lot["side"])',
                    'scale = int(lot["quantity"]) * _side_sign(lot["side"])'))
add("M16", "put value项序反号",
    lambda R: patch(R, ENG, "value = K * disc_r * _norm_cdf(-d2) - S * disc_q * _norm_cdf(-d1)",
                    "value = S * disc_q * _norm_cdf(-d1) - K * disc_r * _norm_cdf(-d2)"))
add("M17", "dte off-by-one",
    lambda R: patch(R, ENG, "return _ord(expiry) - _ord(valuation_date)",
                    "return _ord(expiry) - _ord(valuation_date) + 1"))
add("M18", "期货桩引入持有成本×1.0001",
    lambda R: patch(R, ENG, "不构成'期货＝现货'之语义主张。\"\"\"\n    return {\n        \"value\": float(lot[\"spot\"]),",
                    "不构成'期货＝现货'之语义主张。\"\"\"\n    return {\n        \"value\": float(lot[\"spot\"]) * 1.0001,"))
add("M19", "线性路由delta 1.0→0.999",
    lambda R: patch(R, ENG, "见撞墙清单 TPL1-T7601-01。\"\"\"\n    return {\n        \"value\": float(lot[\"spot\"]),\n        \"delta\": 1.0,",
                    "见撞墙清单 TPL1-T7601-01。\"\"\"\n    return {\n        \"value\": float(lot[\"spot\"]),\n        \"delta\": 0.999,"))

# ---------------- M20–M23 单侧·schema ----------------
add("M20", "schema ROUTE_DECLARATION回标 dividend_carry",
    lambda R: patch(R, SCH, "european_option | bs_dividend_yield_closed_form | computed_with_open_dimensions | day_count_convention",
                    "european_option | bs_dividend_yield_closed_form | computed_with_open_dimensions | day_count_convention,dividend_carry"),
    PIPE_ONLY)
add("M21", "schema CONVENTION分母365→360",
    lambda R: patch(R, SCH, "day_count_denominator | 365", "day_count_denominator | 360"), PIPE_ONLY)
add("M22", "schema §2消费字段集声明删 valuation_date",
    lambda R: patch(R, SCH, "`quantity` / `valuation_date` / `dividend_yield`", "`quantity` / `dividend_yield`"),
    PIPE_ONLY)
add("M23", "schema CONVENTION删 dividend_yield_field行",
    lambda R: patch(R, SCH, "dividend_yield_field | dividend_yield\n", ""), PIPE_ONLY)

# ---------------- C01–C08 协同 ----------------
def _c01(R):
    patch(R, ENG, 'q = float(lot["dividend_yield"])', 'q = float(lot["dividend_yield"]) * 0.0')
    patch(R, IND, 'q = lot["dividend_yield"]', 'q = lot["dividend_yield"] * 0.0')
add("C01", "两侧同时忽略q", _c01)

def _c02(R):
    patch(R, ENG, "(r - q + 0.5 * sig * sig)", "(r + q + 0.5 * sig * sig)")
    patch(R, IND, "(r - q + sig * sig / 2)", "(r + q + sig * sig / 2)")
add("C02", "两侧d1中q符号同翻", _c02)

def _c03(R):
    patch(R, ENG, "value = S * disc_q * _norm_cdf(d1) - K * disc_r * _norm_cdf(d2)",
          "value = S * _norm_cdf(d1) - K * disc_r * disc_q * _norm_cdf(d2)")
    patch(R, IND, "return S * exp(-q * T) * ncdf(d1) - K * exp(-r * T) * ncdf(d2)",
          "return S * ncdf(d1) - K * exp(-r * T) * exp(-q * T) * ncdf(d2)")
add("C03", "两侧 e^{-qT} 误施于K", _c03)

def _c04(R):
    patch(R, ENG, "DAY_COUNT_DENOMINATOR = 365", "DAY_COUNT_DENOMINATOR = 360")
    patch(R, IND, 'T = mpf(_dte(lot["expiry"], valuation_date)) / 365',
          'T = mpf(_dte(lot["expiry"], valuation_date)) / 360')
    patch(R, SCH, "day_count_denominator | 365", "day_count_denominator | 360")
add("C04", "四处同改分母365→360（engine＋indep＋schema）", _c04)

def _c05(R):
    patch(R, ENG, "        theta = (-(S * disc_q * nd1 * sig) / (2.0 * sqrtT)\n                 - r * K * disc_r * _norm_cdf(d2)",
          "        theta = ((S * disc_q * nd1 * sig) / (2.0 * sqrtT)\n                 + r * K * disc_r * _norm_cdf(d2)")
    patch(R, ENG, "        theta = (-(S * disc_q * nd1 * sig) / (2.0 * sqrtT)\n                 + r * K * disc_r * _norm_cdf(-d2)",
          "        theta = ((S * disc_q * nd1 * sig) / (2.0 * sqrtT)\n                 - r * K * disc_r * _norm_cdf(-d2)")
    patch(R, ENG, "                 + q * S * disc_q * _norm_cdf(d1))", "                 - q * S * disc_q * _norm_cdf(d1))")
    patch(R, ENG, "                 - q * S * disc_q * _norm_cdf(-d1))", "                 + q * S * disc_q * _norm_cdf(-d1))")
    patch(R, IND, "theta = -diff(lambda x: _bs_value(S, K, r, sig, x, cp, q), T)",
          "theta = diff(lambda x: _bs_value(S, K, r, sig, x, cp, q), T)")
add("C05", "两侧theta符号约定同翻", _c05)

def _c06(R):
    patch(R, ENG, "vega = S * disc_q * nd1 * sqrtT", "vega = S * disc_q * nd1 * sqrtT / 100.0")
    patch(R, IND, "vega = diff(lambda x: _bs_value(S, K, r, x, T, cp, q), mpf(str(sig)))",
          "vega = diff(lambda x: _bs_value(S, K, r, x, T, cp, q), mpf(str(sig))) / 100")
add("C06", "两侧vega同改per 1%", _c06)

def _c07(R):
    patch(R, ENG, '"european_option":  ("day_count_convention",),',
          '"european_option":  ("day_count_convention", "dividend_carry"),')
    patch(R, SCH, "european_option | bs_dividend_yield_closed_form | computed_with_open_dimensions | day_count_convention",
          "european_option | bs_dividend_yield_closed_form | computed_with_open_dimensions | day_count_convention,dividend_carry")
add("C07", "engine＋schema同步回标 dividend_carry", _c07)

def _c08(R):
    patch(R, ENG, '"european_option":  "computed_with_open_dimensions",', '"european_option":  "closed_on_stated_face",')
    patch(R, SCH, "european_option | bs_dividend_yield_closed_form | computed_with_open_dimensions | day_count_convention",
          "european_option | bs_dividend_yield_closed_form | closed_on_stated_face | day_count_convention")
add("C08", "engine＋schema同步升标闭合态", _c08)

# ---------------- S01–S07 形态封闭·harness ----------------
add("S01", "harness删记录键 computability_status",
    lambda R: patch(R, HAR, '"route_table": {ic: {"route_id": engine.ROUTE_TABLE[ic],\n                             "computability_status": engine.COMPUTABILITY[ic],',
                    '"route_table": {ic: {"route_id": engine.ROUTE_TABLE[ic],'))
add("S02", "harness: time_shift容器静默丢一笔",
    lambda R: patch(R, HAR, '"time_shift_revaluation": tsh,', '"time_shift_revaluation": tsh[:-1],'))
add("S03", "harness: 分量键改名 delta→Delta",
    lambda R: patch(R, ENG, 'GREEK_KEYS = ("delta", "gamma", "vega", "theta", "rho")',
                    'GREEK_KEYS = ("Delta", "gamma", "vega", "theta", "rho")'))
add("S04", "harness: 新增未声明分量键 epsilon",
    lambda R: patch(R, ENG, '    per_lot = {k: per_unit[k] * scale for k in ("value",) + GREEK_KEYS}',
                    '    per_unit["epsilon"] = 0.0\n    per_lot = {k: per_unit[k] * scale for k in ("value",) + GREEK_KEYS}'))
add("S05", "harness: 新增未声明顶层键",
    lambda R: patch(R, HAR, '        "base_valuation": base,', '        "_shadow": 1,\n        "base_valuation": base,'))
add("S06", "harness: route_table静默收窄至五品种",
    lambda R: patch(R, HAR, "for ic in engine.INSTRUMENT_CLASSES}", "for ic in engine.INSTRUMENT_CLASSES[:5]}"))
add("S07", "harness: 丢弃 _data_source 人造标记",
    lambda R: patch(R, HAR, '"_data_source": data["_data_source"],', '"_data_source": "",'))

# ---------------- N01–N04 形态封闭·产物侧（不重跑生产者，允许重钉provenance） ----------------
def _del_key(d):
    for rec in d["base_valuation"]:
        rec.pop("computability_status", None)
add("N01", "产物侧删记录键 computability_status", lambda R: jpatch(R, OUT, _del_key), PIPE_PROV)

def _rename(d):
    for rec in d["base_valuation"]:
        rec["per_unit"]["Delta"] = rec["per_unit"].pop("delta")
add("N02", "产物侧分量键改名", lambda R: jpatch(R, OUT, _rename), PIPE_PROV)

def _drop(d):
    d["time_shift_revaluation"] = d["time_shift_revaluation"][:-1]
add("N03", "产物侧 time_shift丢一笔", lambda R: jpatch(R, OUT, _drop), PIPE_PROV)

def _route(d):
    for ic in d["route_table"]:
        d["route_table"][ic]["unstated_dimensions_hit"] = []
add("N04", "产物侧 route_table值层集体改标", lambda R: jpatch(R, OUT, _route), PIPE_PROV)

# ---------------- Q01 四处协同改名 ----------------
def _q01(R):
    patch(R, ENG, 'q = float(lot["dividend_yield"])', 'q = float(lot["div_yld"])')
    patch(R, ENG, '    "dividend_yield",     # 续2新增', '    "div_yld",     # 续2新增')
    patch(R, IND, 'q = lot["dividend_yield"]', 'q = lot["div_yld"]')
    patch(R, SCH, "dividend_yield_field | dividend_yield", "dividend_yield_field | div_yld")
    p = os.path.join(R, "entity/input_data.json")
    s = open(p, encoding="utf-8").read().replace('"dividend_yield"', '"div_yld"')
    open(p, "w", encoding="utf-8").write(s)
add("Q01", "q承接位改名 div_yld（engine＋indep＋schema＋input四处）", _q01)

# ---------------- B01 外置件通道 ----------------
def _b01(R):
    # q=0分支偏离底版（仅在q==0时引入1e-16量级偏离），并同步改写未钉指纹之baseline
    patch(R, ENG, "    gamma = disc_q * nd1 / (S * sig * sqrtT)",
          "    gamma = disc_q * nd1 / (S * sig * sqrtT) * (1.0 + (1e-16 if q == 0.0 else 0.0))")
    p = os.path.join(R, BASE)
    d = json.load(open(p, encoding="utf-8"))
    def walk(o):
        if isinstance(o, dict):
            for k, v in o.items():
                if k == "gamma" and isinstance(v, (int, float)):
                    o[k] = v * (1.0 + 1e-16)
                else:
                    walk(v)
        elif isinstance(o, list):
            for x in o:
                walk(x)
    walk(d)
    with open(p, "w", encoding="utf-8") as fh:
        json.dump(d, fh, ensure_ascii=False, indent=2); fh.write("\n")
add("B01", "q=0分支偏离底版＋改写baseline外置件", _b01)

# ---------------- E-1 通道级：注入后不重跑 ----------------
def _e1(R):
    patch(R, ENG, "(r - q + 0.5 * sig * sig)", "(r + q + 0.5 * sig * sig)")
    patch(R, ENG, "gamma = disc_q * nd1 / (S * sig * sqrtT)", "gamma = 1.5 * nd1 / (S * sig * sqrtT)")
add("E-1", "engine注入两处实质变异后完全不重跑（外审原形态）", _e1, PIPE_ONLY)

# ---------------- 复核侧自增（§四B-4授权） ----------------
def _e1p(R):
    _e1(R)
add("E-1'", "同E-1，但攻击者重跑 build_provenance.py 后再跑断言（新鲜度钉定件自身未双钉）", _e1p, PIPE_PROV)

def _x01(R):
    patch(R, ENG, '"futures":          ("futures_settlement_form", "dividend_carry"),',
          '"futures":          ("futures_settlement_form",),')
    patch(R, SCH, "futures | linear_underlying_futures_stub | placeholder_stub | futures_settlement_form,dividend_carry",
          "futures | linear_underlying_futures_stub | placeholder_stub | futures_settlement_form")
add("X01", "【A11反向】futures路由不消费q而协同去标 dividend_carry（伪闭合宣称）", _x01)

def _x02(R):
    patch(R, ENG, '"futures":          ("futures_settlement_form", "dividend_carry"),', '"futures":          (),')
    patch(R, ENG, '"futures":          "placeholder_stub",', '"futures":          "closed_on_stated_face",')
    patch(R, SCH, "futures | linear_underlying_futures_stub | placeholder_stub | futures_settlement_form,dividend_carry",
          "futures | linear_underlying_futures_stub | closed_on_stated_face |")
add("X02", "【A12反向】futures协同升标闭合态＋同步清空命中维度", _x02)

def _x03(R):
    p = os.path.join(R, PROV)
    d = json.load(open(p, encoding="utf-8"))
    d["engine_py_sha256"] = "0" * 64
    with open(p, "w", encoding="utf-8") as fh:
        json.dump(d, fh, ensure_ascii=False, indent=2); fh.write("\n")
add("X03", "【F-5反向】直接改写 build_provenance.json 钉定值（该件未纳入§8.1双钉）", lambda R: _x03(R), PIPE_ONLY)

def _x04(R):
    patch(R, ENG, "(r - q + 0.5 * sig * sig)", "(r + q + 0.5 * sig * sig)")
add("X04", "【乙-4实质面】engine注入q面变异并按完整流水线重跑（计算面断言是否承担击落）", _x04)

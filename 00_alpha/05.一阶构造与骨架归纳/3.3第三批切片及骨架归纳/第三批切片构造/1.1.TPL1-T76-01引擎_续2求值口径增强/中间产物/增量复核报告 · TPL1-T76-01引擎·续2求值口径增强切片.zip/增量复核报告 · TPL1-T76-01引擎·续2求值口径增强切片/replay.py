#!/usr/bin/env python3
"""增量复核 · B-4 重放驱动（逐例落盘实跑）

攻击者模型（较外审更严）：除显式声明之"不重跑"通道外，一律按交付件所载完整流水线
重跑（harness → independent_recompute → regression_check → build_provenance → assert_check）。
即：攻击者被允许重跑 build_provenance.py 重新钉定——A10 因而不构成"免费击落"，
击落须由实质判据承担。
"""
import os, re, shutil, subprocess, sys, json

SRC = "/home/claude/rev/v11/TPL1-T76-01引擎_续2求值口径增强_交付包_v1_1_candidate_20260802"
RUN = "/home/claude/rev/run"

ENG = "entity/engine.py"
HAR = "entity/harness.py"
SCH = "entity/input_schema.md"
IND = "verify/independent_recompute.py"
OUT = "entity/harness_output.json"
IEX = "verify/independent_expected.json"
RQ0 = "verify/regression_q0_output.json"
PROV = "verify/build_provenance.json"
BASE = "verify/baseline_v1_1_reference.json"


def patch(root, rel, old, new, n=1):
    p = os.path.join(root, rel)
    s = open(p, encoding="utf-8").read()
    c = s.count(old)
    assert c == n, "patch锚定失败 %s: 期望%d处 实得%d处 :: %r" % (rel, n, c, old[:70])
    open(p, "w", encoding="utf-8").write(s.replace(old, new))


def jpatch(root, rel, fn):
    p = os.path.join(root, rel)
    d = json.load(open(p, encoding="utf-8"))
    fn(d)
    with open(p, "w", encoding="utf-8") as fh:
        json.dump(d, fh, ensure_ascii=False, indent=2); fh.write("\n")


def run(root, script, cwd_rel):
    r = subprocess.run([sys.executable, script], cwd=os.path.join(root, cwd_rel),
                       capture_output=True, text=True, timeout=600)
    return r.returncode, r.stdout + r.stderr


PIPE_FULL = [("harness.py", "entity"), ("independent_recompute.py", "verify"),
             ("regression_check.py", "verify"), ("build_provenance.py", "verify"),
             ("assert_check.py", "verify")]
PIPE_PROV = [("build_provenance.py", "verify"), ("assert_check.py", "verify")]
PIPE_ONLY = [("assert_check.py", "verify")]


def first_fail(out):
    fails = re.findall(r"^FAIL\s+(.{0,60})", out, re.M)
    if fails:
        return [f.strip().split("：")[0].split("（")[0].strip() for f in fails][:3]
    return None


def execute(vid, desc, mutate, pipeline):
    if os.path.exists(RUN):
        shutil.rmtree(RUN)
    shutil.copytree(SRC, RUN)
    try:
        mutate(RUN)
    except AssertionError as e:
        return dict(id=vid, desc=desc, result="ANCHOR_FAIL", detail=str(e))
    killed, detail = False, ""
    for script, cwd in pipeline:
        rc, out = run(RUN, script, cwd)
        if rc != 0:
            killed = True
            ff = first_fail(out)
            if ff:
                detail = "%s → 断言 %s" % (script, "；".join(ff))
            else:
                tail = [l for l in out.strip().split("\n") if l.strip()][-1:]
                detail = "%s → 异常终止：%s" % (script, (tail[0][:90] if tail else "rc=%d" % rc))
            break
    if not killed:
        detail = "全流水线绿灯，exit=0"
    return dict(id=vid, desc=desc, result="击落" if killed else "逃逸", detail=detail)

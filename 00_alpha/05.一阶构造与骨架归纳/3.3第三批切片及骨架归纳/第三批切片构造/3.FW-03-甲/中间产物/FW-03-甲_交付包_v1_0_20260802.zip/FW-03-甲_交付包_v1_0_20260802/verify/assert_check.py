"""
FW-03-甲 · D段断言脚本

判据基线程序化解析自 entity/input_schema.md §3 口径声明块（yaml键值），
不硬编码重复声明值（除防御性默认外）。任一断言不符即非零退出码终止（28-B(ii)）。
日志开跑即清、逐断言即时写出（沿用M1 Q-6订正纪律）。
"""

import json
import re
import hashlib
import sys
import datetime

LOG_LINES = []
FAIL_COUNT = 0
PASS_COUNT = 0


def log(msg):
    LOG_LINES.append(msg)
    print(msg)


def check(name, cond, detail=""):
    global FAIL_COUNT, PASS_COUNT
    if cond:
        PASS_COUNT += 1
        log("PASS %-6s %s" % (name, detail))
    else:
        FAIL_COUNT += 1
        log("FAIL %-6s %s" % (name, detail))


def _sha256(path):
    with open(path, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()


def _dte_days(expiry, valuation_date):
    def _ord(d):
        y, m, dd = (int(t) for t in d.split("-"))
        if m <= 2:
            y -= 1
            m += 12
        return (365 * y + y // 4 - y // 100 + y // 400
                + (153 * (m - 3) + 2) // 5 + dd)
    return _ord(expiry) - _ord(valuation_date)


def parse_schema_declarations(schema_text):
    """从input_schema.md §3 yaml声明块解析键值（简单行级解析，勿依赖yaml库，
    保持verify包自足、零包外路径依赖）。"""
    m = re.search(r"```yaml\n(.*?)\n```", schema_text, re.S)
    if not m:
        raise AssertionError("input_schema.md §3口径声明块未找到（```yaml fenced block）")
    decls = {}
    for line in m.group(1).splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        k, v = line.split(":", 1)
        decls[k.strip()] = v.strip()
    return decls


def main():
    log("=== FW-03-甲 assert_check 开跑 %s ===" % datetime.datetime.now().isoformat())

    with open("../entity/input_schema.md", "r", encoding="utf-8") as f:
        schema_text = f.read()
    decls = parse_schema_declarations(schema_text)

    with open("../entity/input_data.json", "r", encoding="utf-8") as f:
        input_data = json.load(f)
    with open("../entity/harness_output.json", "r", encoding="utf-8") as f:
        harness = json.load(f)
    with open("independent_expected.json", "r", encoding="utf-8") as f:
        indep = json.load(f)
    with open("build_provenance.json", "r", encoding="utf-8") as f:
        provenance = json.load(f)
    with open("../entity/engine.py", "r", encoding="utf-8") as f:
        engine_src = f.read()

    # --- A1 目录结构判据（24-A7 O1）---
    import os
    check("A1a", os.path.isdir("../entity"), "entity/目录在场")
    check("A1b", os.path.isdir("."), "verify/目录在场（当前即verify/）")

    # --- A2 人造input声明（A段字面层，裁决1）---
    check("A2", input_data.get("_data_source") == "synthetic_hand_constructed",
          "input_data._data_source声明核验")
    check("A2b", harness.get("_data_source") == "synthetic_hand_constructed",
          "harness_output承接声明核验")

    # --- A3 符号一致性（主判据，零容差，逐格点）---
    state_seq = harness["state_sequence"]
    indep_by_t = {r["t"]: r for r in indep["records"]}
    sign_mismatches = []
    for rec in state_seq:
        t = rec["t"]
        ind = indep_by_t.get(t)
        if ind is None:
            sign_mismatches.append((t, "independent_expected缺该t记录"))
            continue
        if rec["sign"] != ind["independent_sign"]:
            sign_mismatches.append((t, "engine_sign=%r independent_sign=%r"
                                     % (rec["sign"], ind["independent_sign"])))
    check("A3", len(sign_mismatches) == 0,
          "符号逐格点一致性：%d/%d 不符 %s" % (
              len(sign_mismatches), len(state_seq),
              sign_mismatches[:3] if sign_mismatches else ""))

    # --- A4 量级容差（辅助诊断，声明值解析自independent_expected.json/schema）---
    tol_rel = float(decls["MAGNITUDE_TOLERANCE_REL_DECLARED"])
    tol_rel_from_indep = indep["magnitude_tolerance_rel"]
    check("A4a", abs(tol_rel - tol_rel_from_indep) < 1e-15,
          "schema声明容差(%s)与独立复算文件声明容差(%s)一致"
          % (tol_rel, tol_rel_from_indep))
    mag_violations = []
    for rec in state_seq:
        t = rec["t"]
        ind = indep_by_t[t]
        true_d2 = ind["independent_second_derivative_gamma"]
        eng_d2 = rec["second_derivative_gamma"]
        if abs(true_d2) > 1e-8:
            rel_err = abs(eng_d2 - true_d2) / abs(true_d2)
            if rel_err > tol_rel:
                mag_violations.append((t, rel_err))
    check("A4b", len(mag_violations) == 0,
          "量级容差界内：%d 超界 %s" % (len(mag_violations), mag_violations[:3]))

    # --- A5 过零检测正确性（独立重新计算，不调用engine.detect_zero_crossings）---
    def independent_crossings(records_sorted_by_t):
        crossings = []
        prev_sign = None
        prev_t = None
        for r in sorted(records_sorted_by_t, key=lambda x: x["t"]):
            s = r["independent_sign"]
            if s == 0:
                continue
            if prev_sign is not None and s != prev_sign:
                crossings.append((prev_t, r["t"], prev_sign, s))
            prev_sign = s
            prev_t = r["t"]
        return crossings

    expected_crossings = independent_crossings(indep["records"])
    engine_crossings = [(c["from_t"], c["to_t"], c["from_sign"], c["to_sign"])
                        for c in harness["zero_crossings"]]
    check("A5", expected_crossings == engine_crossings,
          "过零事件独立核对：期望%d项，实得%d项 %s" % (
              len(expected_crossings), len(engine_crossings),
              "" if expected_crossings == engine_crossings
              else (expected_crossings, engine_crossings)))

    # --- A6 恒正核验正确性（独立计算） ---
    expected_all_positive = all(r["independent_sign"] > 0 for r in indep["records"])
    expected_violation_ts = [r["t"] for r in indep["records"] if not r["independent_sign"] > 0]
    check("A6a", harness["always_positive_check"]["all_positive"] == expected_all_positive,
          "all_positive独立核对：期望%r 实得%r" % (
              expected_all_positive, harness["always_positive_check"]["all_positive"]))
    check("A6b", harness["always_positive_check"]["violation_ts"] == expected_violation_ts,
          "violation_ts独立核对：期望%d项 实得%d项" % (
              len(expected_violation_ts),
              len(harness["always_positive_check"]["violation_ts"])))

    # --- A7 输出形态封闭（39-B2，第三批起施工侧判据）---
    declared_top_keys = {"_data_source", "position", "bump_config", "state_sequence",
                          "zero_crossings", "always_positive_check", "summary"}
    check("A7a", set(harness.keys()) == declared_top_keys,
          "harness_output顶层键封闭：多余%s 缺失%s" % (
              set(harness.keys()) - declared_top_keys,
              declared_top_keys - set(harness.keys())))
    declared_step_keys = {"spot", "valuation_date", "bump_h", "gamma_minus", "gamma_mid",
                           "gamma_plus", "second_derivative_gamma", "sign", "t"}
    step_key_violations = [rec for rec in state_seq if set(rec.keys()) != declared_step_keys]
    check("A7b", len(step_key_violations) == 0,
          "state_sequence单条记录键封闭：%d 条不符" % len(step_key_violations))

    # --- A8 声明-实现一致性（F-4）---
    check("A8a", decls["BUMP_MODE_DECLARED"] == input_data["bump_config"]["bump_mode"],
          "bump_mode声明与实现一致：%s" % decls["BUMP_MODE_DECLARED"])
    check("A8b", abs(float(decls["BUMP_RATIO_DECLARED"])
                     - input_data["bump_config"]["bump_ratio"]) < 1e-15,
          "bump_ratio声明与实现一致：%s" % decls["BUMP_RATIO_DECLARED"])
    m = re.search(r"^SIGN_EPSILON\s*=\s*([0-9.eE+-]+)", engine_src, re.M)
    check("A8c", m is not None and abs(float(m.group(1))
                     - float(decls["SIGN_EPSILON_DECLARED"])) < 1e-30,
          "SIGN_EPSILON声明(%s)与engine.py源码实现(%s)一致"
          % (decls["SIGN_EPSILON_DECLARED"], m.group(1) if m else "未找到"))
    check("A8d", decls["AGGREGATION_LEVEL_DECLARED"] == "per_lot",
          "聚合层级声明字面核验")

    # --- A9 参数声明域检查 ---
    pos = input_data["position"]
    check("A9a", pos["option_type"] == "put", "option_type=put（本根声明域）")
    check("A9b", pos["instrument_class"] == "european_option", "instrument_class声明域")
    check("A9c", pos["side"] in ("long", "short"), "side枚举域")
    check("A9d", int(pos["multiplier"]) > 0 and int(pos["quantity"]) > 0,
          "multiplier/quantity正整数")
    dte_violations = [s for s in input_data["scenario"]
                      if _dte_days(pos["expiry"], s["valuation_date"]) <= 0]
    check("A9e", len(dte_violations) == 0,
          "全程dte>0（未落入未言明维度分支）：%d 步违反" % len(dte_violations))

    # --- A10 产物新鲜度机制（仿M1同名A10，D-4/E-1同型）---
    fresh_violations = []
    for relpath, pinned_hash in provenance["fingerprints"].items():
        actual_path = ("../" + relpath) if relpath.startswith("entity/") else relpath.split("/", 1)[1]
        cur = _sha256(actual_path)
        if cur != pinned_hash:
            fresh_violations.append((relpath, pinned_hash[:12], cur[:12]))
    check("A10", len(fresh_violations) == 0,
          "产物新鲜度核对：%d 项不符 %s" % (len(fresh_violations), fresh_violations))

    # --- 汇总 ---
    log("=== 汇总：PASS=%d FAIL=%d ===" % (PASS_COUNT, FAIL_COUNT))
    with open("assert_check_log.txt", "w", encoding="utf-8") as f:
        f.write("\n".join(LOG_LINES) + "\n")

    if FAIL_COUNT > 0:
        sys.exit(1)
    sys.exit(0)


if __name__ == "__main__":
    main()

"""
FW-03-甲 · 产物新鲜度钉定件生成脚本（仿TPL1-T76-01引擎续2 D-4/E-1同型机制）

须于 harness.py（entity/）与 independent_recompute.py（verify/）全部产出之后
运行，一次性钉定"源码-产物"对应关系之SHA256。assert_check.py之新鲜度断言
重算当前哈希与钉定值逐一对表——若被测实现（engine.py）遭源码级变异但未
重跑harness.py，此机制将检出"声明产物"与"当前源码"之不一致（乙-4/F-9
被测侧注入检出通道）。
"""

import hashlib
import json


def _sha256(path):
    with open(path, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()


PINNED_PAIRS = [
    ("entity/engine.py", "entity/harness_output.json"),
    ("entity/input_data.json", "entity/harness_output.json"),
    ("verify/independent_recompute.py", "verify/independent_expected.json"),
    ("entity/input_data.json", "verify/independent_expected.json"),
]

ALL_FILES = sorted({p for pair in PINNED_PAIRS for p in pair})


def main():
    fingerprints = {f: _sha256("../" + f if not f.startswith("verify/") else f.replace("verify/", "")) for f in ALL_FILES}
    # 路径统一：本脚本运行于 verify/ 目录，entity/*相对上级，verify/*为当前目录同级文件
    fingerprints = {}
    for f in ALL_FILES:
        if f.startswith("entity/"):
            path = "../" + f
        else:
            path = f.split("/", 1)[1]
        fingerprints[f] = _sha256(path)

    out = {
        "_purpose": "D-4/E-1同型机制：源码-产物SHA256钉定，供assert_check.py新鲜度断言核对",
        "pinned_pairs": [{"source": s, "product": p} for s, p in PINNED_PAIRS],
        "fingerprints": fingerprints,
    }
    with open("build_provenance.json", "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)
    print("产物新鲜度钉定完成：%d 项文件指纹" % len(fingerprints))


if __name__ == "__main__":
    main()

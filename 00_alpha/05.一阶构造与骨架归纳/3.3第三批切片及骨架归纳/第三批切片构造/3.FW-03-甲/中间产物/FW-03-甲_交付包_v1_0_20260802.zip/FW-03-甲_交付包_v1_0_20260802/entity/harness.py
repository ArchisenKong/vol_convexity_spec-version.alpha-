"""
FW-03-甲 · 一次性 harness（B段）

真跑出数、不建常设pipeline：单次执行，喂入entity/input_data.json，驱动
engine.py三项计算（逐步二阶导→过零检测→恒正核验），捕获全部中间与终态量，
落盘entity/harness_output.json。

情景重估口径：本根不存在"时点推移"额外接口——scenario本身已含逐步
valuation_date与spot（人造input层面的时间序列声明），harness不做任何
二次冲击构造，纯粹逐步喂入。
"""

import json
import engine


def main():
    with open("input_data.json", "r", encoding="utf-8") as f:
        doc = json.load(f)

    position = doc["position"]
    bump_config = doc["bump_config"]
    scenario = doc["scenario"]

    state_sequence = engine.compute_state_sequence(position, bump_config, scenario)
    crossings = engine.detect_zero_crossings(state_sequence)
    positive_check = engine.check_always_positive(state_sequence)

    output = {
        "_data_source": "synthetic_hand_constructed",
        "position": position,
        "bump_config": bump_config,
        "state_sequence": state_sequence,
        "zero_crossings": crossings,
        "always_positive_check": positive_check,
        "summary": {
            "n_steps": len(state_sequence),
            "n_crossings": len(crossings),
            "sign_at_start": state_sequence[0]["sign"],
            "sign_at_end": state_sequence[-1]["sign"],
        },
    }

    with open("harness_output.json", "w", encoding="utf-8") as f:
        json.dump(output, f, ensure_ascii=False, indent=2)

    print("harness完成：steps=%d crossings=%d" % (
        output["summary"]["n_steps"], output["summary"]["n_crossings"]))


if __name__ == "__main__":
    main()

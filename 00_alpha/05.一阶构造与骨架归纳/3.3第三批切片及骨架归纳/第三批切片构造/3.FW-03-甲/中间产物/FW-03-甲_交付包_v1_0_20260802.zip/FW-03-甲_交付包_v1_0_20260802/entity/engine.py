"""
FW-03-甲 引擎 · 一阶实体本体（被测对象）

对象＝Gamma二阶导状态量：OTM put头寸之Gamma对现货二阶导数（"Gamma的Gamma"）
符号序列＋过零检测＋恒正核验。

判据锚（Q4判据，任务5_Step2增量产出v1.0 §1 FW-03行，裁决51已裁态，逐字转抄）：
"甲＝可算部分＝'OTM put之Gamma极值/二阶导过零'状态量与'二阶导恒正'不变量
（喂持仓+行情时序，出二阶导符号序列，判据＝过零检测与恒正核验）。"

"二阶导"指代对象裁定锚（本根裁定登记#1，呈KD追认，非本会话新造读法——
既有KD裁定原文转抄）：
  - 思想层宪法v1.0 宪-CV-06："保持Gamma的二阶导与Vomma等高阶响应持续为正"，
    源文引 未来不可测_但我们有办法.md 行30-32："对于Gamma的二阶导...做多四阶矩"；
    QQQAI杠铃结构交流 行887："做的是Gamma的Gamma的功夫"。
  - 二阶导＝∂²Gamma/∂S²（Gamma以现货S为自变量，自身作为基函数再求两次导，
    即"Gamma的Gamma"）；求导变量＝现货价S；非对Gamma之价格∂V/∂S一阶导（Speed），
    非跨变量混合导（时间-现货）。
  - 源文"OTM put之Gamma最大即二阶导为0"之字面松弛：数值上严格Gamma峰值处
    （dGamma/dS=0）与∂²Gamma/∂S²=0（拐点）一般非同一点；本根按Q4判据字面
    （"二阶导符号序列"+"过零检测"）实现，不代入"必须等于Gamma严格峰值"之
    额外断言——过零点＝拐点本身，是否恰与"最大"重合不在甲核验范围（甲仅出
    状态量，不裁决/不生成动作，乙域）。

M1直调路径声明（本根裁定登记#2，呈KD追认）：本模块之Gamma供给＝TPL1-T76-01
引擎（续2求值口径增强 v1.2）evaluate_lot()函数原文逐字内嵌（见下方
"── M1直调：verbatim embed ──"分区），非独立重导BSM公式（避免对M1已收口
产物之越权平行重造，先例同型＝T3-22/T3-17"避免平行重造"处置原则，唯本根
因需多点bump求二阶导、无法采用T3-22"声明值接收"形态，改采M1直调路径）。
源文件＝TPL1-T76-01引擎_续2求值口径增强_交付包_v1_2_20260802/entity/engine.py
SHA256＝e31fbcfeacebeb196f7e1d63f41089e7e0a7deb3cc9a9a8b44941af31e194e99
（逐位核验，见本包装载核证记录）。仅摘取european_option路由（本根position恒为
put/long/european_option，其余路由不消费，不嵌入以保持自足最小面）。
嵌入部分零改动（含注释），FW-03专属逻辑另起分区，两者不交叉修改。

仪表身份标注（对照表§3随行义务③+§5.4，24-E3形态）：本根消费之per_lot gamma
读数为M1引擎之仪表读数，非定价真理源；二阶导数由该读数有限差分导出，同一
仪表身份随行，不因求导运算而升格为真理判定。
"""

import math

# ═══════════════════ M1直调：verbatim embed（零改动） ═══════════════════
# 逐字摘自 TPL1-T76-01引擎_续2求值口径增强_交付包_v1_2_20260802/entity/engine.py
# （仅保留 european_option 路由链路所需片段：常量/基础数值原语/BS-q闭式解/
#  evaluate_lot 本体）。SHA256见上方模块docstring。

GREEK_KEYS = ("delta", "gamma", "vega", "theta", "rho")
DAY_COUNT_DENOMINATOR = 365


def _norm_cdf(x):
    """标准正态 CDF；erf 入口。"""
    return 0.5 * (1.0 + math.erf(x / math.sqrt(2.0)))


def _norm_pdf(x):
    return math.exp(-0.5 * x * x) / math.sqrt(2.0 * math.pi)


def _side_sign(side):
    if side == "long":
        return 1
    if side == "short":
        return -1
    raise ValueError("side 越出已言明值域 enum{long,short}: %r" % (side,))


def _dte_days(expiry, valuation_date):
    """dte = (expiry - valuation_date).days，整数天（T-76 §3 已言明口径）。
    不引入日历库：两日期以 yyyy-mm-dd 给出，按公历序日差计算。"""
    def _ord(d):
        y, m, dd = (int(t) for t in d.split("-"))
        if m <= 2:
            y -= 1
            m += 12
        return (365 * y + y // 4 - y // 100 + y // 400
                + (153 * (m - 3) + 2) // 5 + dd)
    return _ord(expiry) - _ord(valuation_date)


def _eval_bs_dividend_yield(lot):
    """欧式期权路由：含连续股息收益率 q 之 Black-Scholes-Merton 闭式解。
    （M1 契约六条①②③④⑤⑥随原文携带，逐字未改，参M1 entity/engine.py全文）"""
    S = float(lot["spot"])
    K = float(lot["strike"])
    r = float(lot["risk_free_rate"])
    sig = float(lot["implied_vol"])
    q = float(lot["dividend_yield"])
    dte = _dte_days(lot["expiry"], lot["valuation_date"])
    if dte <= 0:
        raise ValueError("dte<=0 落在本分支已言明面之外（到期/已到期形态未言明）")
    T = dte / DAY_COUNT_DENOMINATOR

    sqrtT = math.sqrt(T)
    d1 = (math.log(S / K) + (r - q + 0.5 * sig * sig) * T) / (sig * sqrtT)
    d2 = d1 - sig * sqrtT
    disc_r = math.exp(-r * T)
    disc_q = math.exp(-q * T)
    nd1 = _norm_pdf(d1)

    if lot["option_type"] == "call":
        value = S * disc_q * _norm_cdf(d1) - K * disc_r * _norm_cdf(d2)
        delta = disc_q * _norm_cdf(d1)
        theta = (-(S * disc_q * nd1 * sig) / (2.0 * sqrtT)
                 - r * K * disc_r * _norm_cdf(d2)
                 + q * S * disc_q * _norm_cdf(d1))
        rho = K * T * disc_r * _norm_cdf(d2)
    elif lot["option_type"] == "put":
        value = K * disc_r * _norm_cdf(-d2) - S * disc_q * _norm_cdf(-d1)
        delta = disc_q * (_norm_cdf(d1) - 1.0)
        theta = (-(S * disc_q * nd1 * sig) / (2.0 * sqrtT)
                 + r * K * disc_r * _norm_cdf(-d2)
                 - q * S * disc_q * _norm_cdf(-d1))
        rho = -K * T * disc_r * _norm_cdf(-d2)
    else:
        raise ValueError("option_type 越出已言明值域 enum{call,put}: %r"
                         % (lot["option_type"],))

    gamma = disc_q * nd1 / (S * sig * sqrtT)
    vega = S * disc_q * nd1 * sqrtT
    return {"value": value, "delta": delta, "gamma": gamma,
            "vega": vega, "theta": theta, "rho": rho}


def evaluate_lot(lot):
    """M1引擎入口（本根仅路由european_option，逐字沿用）。"""
    if lot["instrument_class"] != "european_option":
        raise ValueError(
            "FW-03-甲内嵌子集仅承接 european_option 路由，收到: %r"
            % (lot["instrument_class"],))
    per_unit = _eval_bs_dividend_yield(lot)
    scale = int(lot["multiplier"]) * int(lot["quantity"]) * _side_sign(lot["side"])
    per_lot = {k: per_unit[k] * scale for k in ("value",) + GREEK_KEYS}
    return {
        "lot_id": lot["lot_id"],
        "instrument_class": lot["instrument_class"],
        "route_id": "bs_dividend_yield_closed_form",
        "per_unit": per_unit,
        "per_lot": per_lot,
    }

# ═══════════════════ M1直调 embed 结束 ═══════════════════════════════════


# ═══════════════════ FW-03-甲 专属逻辑（本根新增） ═══════════════════════

SIGN_EPSILON = 1e-12
# 符号分类容差（本根裁定登记#3，呈KD追认）：|二阶导|<SIGN_EPSILON 时判0
# （未分类/边界），非裁决13/19容差子口径（该口径用于独立复算路径比对，
# 见verify/independent_recompute.py与assert_check.py，两容差用途不同，
# 分开声明不混用）。SIGN_EPSILON取值理由：仅防护literal浮点零，观测量级
# （本情景d²Gamma/dS²实测∈[1e-4,1e-1]量级）远高于该阈值，不影响任何实际
# 分类结果，纯防御性声明。


def _bump_h(spot, bump_config):
    """按bump_config声明模式计算bump步长（本根裁定登记#4，呈KD追认）：
    relative模式＝h=spot*bump_ratio（比例bump，跨价格水平量纲一致）；
    absolute模式＝h=abs_h（常数步长）。本情景采用relative，bump_ratio=0.001。"""
    mode = bump_config["bump_mode"]
    if mode == "relative":
        return spot * bump_config["bump_ratio"]
    if mode == "absolute":
        return bump_config["abs_h"]
    raise ValueError("bump_mode 越出已声明值域 enum{relative,absolute}: %r" % (mode,))


def bump_and_second_derivative(position, spot_center, valuation_date, bump_config):
    """单一时间快照之核心计算（纯函数，无副作用）：
    固定valuation_date（即固定τ），仅沿现货S方向bump三点，中心差分二阶导。
    d²Gamma/dS² ≈ [Gamma(S+h) - 2·Gamma(S) + Gamma(S-h)] / h²
    （聚合层级＝per-lot，声明理由见input_schema §口径声明#2：源文/Q4判据均以
    "头寸Gamma"为单位，非跨头寸聚合；side=long时scale>0，per_lot与per_unit
    二阶导同号，此情景下二者符号等价——如side=short，scale<0，符号将整体
    翻转，此为per_lot口径之应有行为，非缺陷）。"""
    h = _bump_h(spot_center, bump_config)

    def _lot(spot):
        lot = dict(position)
        lot["spot"] = spot
        lot["valuation_date"] = valuation_date
        return lot

    g_plus = evaluate_lot(_lot(spot_center + h))["per_lot"]["gamma"]
    g_mid = evaluate_lot(_lot(spot_center))["per_lot"]["gamma"]
    g_minus = evaluate_lot(_lot(spot_center - h))["per_lot"]["gamma"]

    d2 = (g_plus - 2.0 * g_mid + g_minus) / (h * h)
    if d2 > SIGN_EPSILON:
        sign = 1
    elif d2 < -SIGN_EPSILON:
        sign = -1
    else:
        sign = 0

    return {
        "spot": spot_center,
        "valuation_date": valuation_date,
        "bump_h": h,
        "gamma_minus": g_minus,
        "gamma_mid": g_mid,
        "gamma_plus": g_plus,
        "second_derivative_gamma": d2,
        "sign": sign,
    }


def compute_state_sequence(position, bump_config, scenario):
    """喂〔持仓+行情时序〕出〔二阶导符号序列〕（Q4判据字面产出）。
    scenario＝[{"t":int,"valuation_date":str,"spot":float}, ...]，
    每步独立调用bump_and_second_derivative，零跨步状态依赖（纯函数序列）。"""
    seq = []
    for step in scenario:
        rec = bump_and_second_derivative(
            position, step["spot"], step["valuation_date"], bump_config)
        rec["t"] = step["t"]
        seq.append(rec)
    return seq


def detect_zero_crossings(state_sequence):
    """过零检测（Q4判据"判据＝过零检测"字面产出）：相邻步符号翻转事件清单
    （sign 0视为"未分类"、不参与翻转判定传递，取上一非零符号延续比较——
    本情景SIGN_EPSILON防御性极小，实测数据不触发0分类，此分支为完备性声明）。"""
    crossings = []
    prev_sign = None
    prev_t = None
    for rec in state_sequence:
        s = rec["sign"]
        if s == 0:
            continue
        if prev_sign is not None and s != prev_sign:
            crossings.append({
                "from_t": prev_t, "to_t": rec["t"],
                "from_sign": prev_sign, "to_sign": s,
                "from_spot": None, "to_spot": rec["spot"],
            })
        prev_sign = s
        prev_t = rec["t"]
    return crossings


def check_always_positive(state_sequence):
    """恒正核验（Q4判据"判据＝...恒正核验"字面产出）：诊断量，非强制量——
    甲仅核验/报告当前序列是否满足"二阶导恒正"不变量，不裁决、不生成使其
    恒正的动作（该动作属FW-03-乙，roll编排域，本根不越界）。"""
    per_step = [{"t": rec["t"], "positive": rec["sign"] > 0} for rec in state_sequence]
    all_positive = all(r["positive"] for r in per_step)
    violation_ts = [r["t"] for r in per_step if not r["positive"]]
    return {
        "per_step": per_step,
        "all_positive": all_positive,
        "violation_step_count": len(violation_ts),
        "violation_ts": violation_ts,
    }

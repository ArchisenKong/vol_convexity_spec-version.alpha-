"""
FW-03-甲 · 独立复算路径（verify/）

计算核心分叉（F-2，非取字段/循环外壳分叉）：
被测侧（entity/engine.py）＝闭式Gamma公式（解析）＋3点低阶中心差分
（bump_ratio=0.001）间接得二阶导。
独立侧（本脚本）＝对期权价值函数V(S)本身，用mpmath高精度（dps=50）原生
4阶数值微分（mpmath.diff(f, S, n=4)）直接取得d⁴V/dS⁴（＝d²Gamma/dS²，
按微积分求导阶数可交换性），零解析Gamma公式、零复用被测侧之差分步长
与差分格式。两侧连"是否由闭式Gamma公式出发"与"差分阶数/步长选择"两层
均不共享，符合F-2独立分叉要求。

数据源独立：只读entity/input_data.json（position原始参数），不触碰被测侧
任何产物（harness_output.json/engine.py均不读取）。

容差性质声明（本根裁定登记#5，呈KD追认，偏离标准两子口径需如实声明）：
被测侧之"二阶导"本身即为声明的离散近似量（bump_ratio=0.001之3点差分），
非对真实连续二阶导之精确解析复刻——與裁决13/19(a)/(b)框架预设情形不同
（该框架服务于"同一精确数学量之两条独立路径"比对，如M1五希腊闭式解
vs 数值微分，两者对真值均无固有偏置）。本根被测量本身即含O(h²)量级
截断偏置（h≈spot*0.001），故独立复算之比对面须区分两条判据：
  ①符号一致性（主判据，零容差——两侧符号在全部格点必须逐一相等，
    Q4判据"过零检测"之字面要求）；
  ②量级偏离界（辅助诊断，非0容差——相对误差须落在声明界内，
    界值取0.01（相对），依经验实测被测法最大相对误差约8e-4量级、
    留一个数量级安全边际；若突破该界，指向被测法本身之实现缺陷
    而非离散化固有偏置，须裁定为不合格）。
"""

import json
import mpmath

mpmath.mp.dps = 50

MAGNITUDE_TOLERANCE_REL = 0.01  # 见docstring容差性质声明②


def _dte_days(expiry, valuation_date):
    def _ord(d):
        y, m, dd = (int(t) for t in d.split("-"))
        if m <= 2:
            y -= 1
            m += 12
        return (365 * y + y // 4 - y // 100 + y // 400
                + (153 * (m - 3) + 2) // 5 + dd)
    return _ord(expiry) - _ord(valuation_date)


def _V_put_mp(S, K, r, q, sig, T):
    """欧式put之BS-q闭式价值（mpmath高精度），仅用于4阶数值微分入口，
    本脚本不从该式解析导出Gamma——直接对V做4阶数值微分。"""
    S = mpmath.mpf(S); K = mpmath.mpf(K); r = mpmath.mpf(r)
    q = mpmath.mpf(q); sig = mpmath.mpf(sig); T = mpmath.mpf(T)
    sqrtT = mpmath.sqrt(T)
    d1 = (mpmath.log(S / K) + (r - q + mpmath.mpf("0.5") * sig * sig) * T) / (sig * sqrtT)
    d2 = d1 - sig * sqrtT
    return K * mpmath.e ** (-r * T) * mpmath.ncdf(-d2) - S * mpmath.e ** (-q * T) * mpmath.ncdf(-d1)


def independent_second_derivative(position, spot, valuation_date):
    """d⁴V/dS⁴（per_lot，含scale）＝独立路径下之d²Gamma/dS²真值。"""
    K = position["strike"]; r = position["risk_free_rate"]
    sig = position["implied_vol"]; q = position["dividend_yield"]
    expiry = position["expiry"]
    scale = (int(position["multiplier"]) * int(position["quantity"])
             * (1 if position["side"] == "long" else -1))
    dte = _dte_days(expiry, valuation_date)
    T = dte / 365.0

    f = lambda s: _V_put_mp(s, K, r, q, sig, T)
    d4 = mpmath.diff(f, mpmath.mpf(spot), n=4)
    return float(d4) * scale


def main():
    with open("../entity/input_data.json", "r", encoding="utf-8") as fh:
        doc = json.load(fh)
    position = doc["position"]
    scenario = doc["scenario"]

    records = []
    for step in scenario:
        S = step["spot"]; vd = step["valuation_date"]; t = step["t"]
        true_d2 = independent_second_derivative(position, S, vd)
        sign = 1 if true_d2 > 1e-12 else (-1 if true_d2 < -1e-12 else 0)
        records.append({
            "t": t, "spot": S, "valuation_date": vd,
            "independent_second_derivative_gamma": true_d2,
            "independent_sign": sign,
        })

    out = {
        "_method": "mpmath dps=50, d^4V/dS^4 native numerical differentiation, "
                   "zero closed-form Gamma reuse, zero shared bump/step with engine.py",
        "magnitude_tolerance_rel": MAGNITUDE_TOLERANCE_REL,
        "records": records,
    }
    with open("independent_expected.json", "w", encoding="utf-8") as fh:
        json.dump(out, fh, ensure_ascii=False, indent=2)
    print("独立复算完成：%d 条记录" % len(records))


if __name__ == "__main__":
    main()

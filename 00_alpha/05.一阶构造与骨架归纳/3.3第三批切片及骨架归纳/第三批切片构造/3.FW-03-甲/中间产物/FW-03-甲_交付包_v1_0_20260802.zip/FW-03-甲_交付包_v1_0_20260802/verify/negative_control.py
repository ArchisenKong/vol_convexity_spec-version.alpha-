"""
FW-03-甲 · 负向对照自查（构造侧留痕，非G4外审重放，非合格判定依据本身）

三类被测侧注入变异（乙-4）：
  案例1：声明-实现不一致注入（engine.py内SIGN_EPSILON改值，schema声明不变）
        —— 期望击落断言：A8c
  案例2：源码级变异+不重跑下游产物（仿M1 D-2/D-4同型攻击模式）
        —— 期望击落断言：A10（产物新鲜度机制；数值比对本身不会发现，
           因harness_output.json仍是变异前的旧产物）
  案例3：源码级变异+全链重跑（真实计算逻辑bug，非新鲜度可捕获——
        产物已随变异重新生成，新鲜度钉定也重新做过）
        —— 期望击落断言：计算面断言（A3符号一致性 或 A4量级容差），
           F-9"被测侧注入案例集须含≥1例经计算面断言击落之变异"由本案例满足

全部案例结束后，精确复原entity/engine.py与全部产物至变异前状态（SHA256核验
复原后逐字节一致），复原后assert_check.py须回到基线clean跑（44/44…本包为
22/22 PASS，exit=0）。
"""

import hashlib
import shutil
import subprocess
import sys
import os

RESULTS = []


def _sha256(path):
    with open(path, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()


def _run_assert_check():
    r = subprocess.run([sys.executable, "assert_check.py"],
                        capture_output=True, text=True, cwd=".")
    return r.returncode, r.stdout


def _run(cmd, cwd="."):
    r = subprocess.run([sys.executable] + cmd, capture_output=True, text=True, cwd=cwd)
    return r.returncode, r.stdout, r.stderr


def case_1_declaration_mismatch():
    """案例1：engine.py内SIGN_EPSILON由1e-12改为1e-6，schema声明维持1e-12不变。"""
    path = "../entity/engine.py"
    backup = path + ".bak1"
    shutil.copy(path, backup)
    with open(path, "r", encoding="utf-8") as f:
        src = f.read()
    mutated = src.replace("SIGN_EPSILON = 1e-12", "SIGN_EPSILON = 1e-6", 1)
    assert mutated != src, "替换未生效，源码内未找到目标行"
    with open(path, "w", encoding="utf-8") as f:
        f.write(mutated)

    code, out = _run_assert_check()
    caught = (code != 0) and ("FAIL A8c" in out)
    RESULTS.append(("案例1_声明实现不一致", caught, "exit=%d, A8c%s" % (
        code, " FAIL在场" if "FAIL A8c" in out else " 未见FAIL A8c")))

    shutil.copy(backup, path)
    os.remove(backup)
    restored_ok = _sha256(path) == _sha256_of_original_engine
    RESULTS.append(("案例1_engine.py复原核验", restored_ok, "SHA256复原比对"))


def case_2_mutate_no_rerun():
    """案例2：engine.py核心公式变异（分母h*h改为h），但不重跑harness.py，
    模拟'被测侧源码已变、声明产物未随之更新'攻击——新鲜度机制应捕获。"""
    path = "../entity/engine.py"
    backup = path + ".bak2"
    shutil.copy(path, backup)
    with open(path, "r", encoding="utf-8") as f:
        src = f.read()
    target = "d2 = (g_plus - 2.0 * g_mid + g_minus) / (h * h)"
    mutated = src.replace(target, "d2 = (g_plus - 2.0 * g_mid + g_minus) / (h)")
    assert mutated != src, "替换未生效"
    with open(path, "w", encoding="utf-8") as f:
        f.write(mutated)
    # 刻意不重跑 entity/harness.py —— harness_output.json 保持变异前旧产物

    code, out = _run_assert_check()
    caught = (code != 0) and ("FAIL A10" in out)
    RESULTS.append(("案例2_源码变异不重跑_新鲜度捕获", caught, "exit=%d, A10%s" % (
        code, " FAIL在场" if "FAIL A10" in out else " 未见FAIL A10")))

    shutil.copy(backup, path)
    os.remove(backup)
    restored_ok = _sha256(path) == _sha256_of_original_engine
    RESULTS.append(("案例2_engine.py复原核验", restored_ok, "SHA256复原比对"))


def case_3_mutate_full_rerun():
    """案例3：同案例2之公式变异，但全链重跑（entity/harness.py +
    verify/build_provenance.py），使新鲜度钉定同步刷新、不再报警——
    唯一能捕获此逻辑bug的通道＝计算面断言（A3/A4），验证F-9"计算面断言击落"要求。"""
    engine_path = "../entity/engine.py"
    engine_backup = engine_path + ".bak3"
    harness_out_path = "../entity/harness_output.json"
    harness_out_backup = harness_out_path + ".bak3"
    provenance_path = "build_provenance.json"
    provenance_backup = provenance_path + ".bak3"

    shutil.copy(engine_path, engine_backup)
    shutil.copy(harness_out_path, harness_out_backup)
    shutil.copy(provenance_path, provenance_backup)

    with open(engine_path, "r", encoding="utf-8") as f:
        src = f.read()
    target = "d2 = (g_plus - 2.0 * g_mid + g_minus) / (h * h)"
    mutated = src.replace(target, "d2 = (g_plus - 2.0 * g_mid + g_minus) / (h)")
    assert mutated != src, "替换未生效"
    with open(engine_path, "w", encoding="utf-8") as f:
        f.write(mutated)

    # 全链重跑：harness -> build_provenance（独立复算文件不受engine变异影响，不重跑）
    c1, o1, e1 = _run(["harness.py"], cwd="../entity")
    c2, o2, e2 = _run(["build_provenance.py"], cwd=".")

    code, out = _run_assert_check()
    computational_fail = ("FAIL A3" in out) or ("FAIL A4" in out)
    fresh_fail = "FAIL A10" in out
    caught = (code != 0) and computational_fail
    RESULTS.append(("案例3_源码变异全链重跑_计算面断言捕获", caught,
                     "exit=%d, A3/A4命中=%s, A10命中=%s(应为False，新鲜度已随重跑更新不应报警)"
                     % (code, computational_fail, fresh_fail)))

    shutil.copy(engine_backup, engine_path)
    shutil.copy(harness_out_backup, harness_out_path)
    shutil.copy(provenance_backup, provenance_path)
    for b in (engine_backup, harness_out_backup, provenance_backup):
        os.remove(b)

    restored_engine_ok = _sha256(engine_path) == _sha256_of_original_engine
    restored_harness_ok = _sha256(harness_out_path) == _sha256_of_original_harness_out
    restored_prov_ok = _sha256(provenance_path) == _sha256_of_original_provenance
    RESULTS.append(("案例3_三件复原核验", restored_engine_ok and restored_harness_ok and restored_prov_ok,
                     "engine=%s harness_output=%s build_provenance=%s"
                     % (restored_engine_ok, restored_harness_ok, restored_prov_ok)))


def main():
    global _sha256_of_original_engine, _sha256_of_original_harness_out, _sha256_of_original_provenance
    _sha256_of_original_engine = _sha256("../entity/engine.py")
    _sha256_of_original_harness_out = _sha256("../entity/harness_output.json")
    _sha256_of_original_provenance = _sha256("build_provenance.json")

    print("=== 基线核验：变异前 assert_check.py 应clean跑 ===")
    code0, out0 = _run_assert_check()
    RESULTS.append(("基线_变异前clean跑", code0 == 0, "exit=%d" % code0))

    case_1_declaration_mismatch()
    case_2_mutate_no_rerun()
    case_3_mutate_full_rerun()

    print("\n=== 复原后终态核验：assert_check.py 应回到基线clean跑 ===")
    code_final, out_final = _run_assert_check()
    RESULTS.append(("终态_复原后clean跑", code_final == 0, "exit=%d" % code_final))

    print("\n=== 负向对照汇总 ===")
    n_pass = 0
    for name, ok, detail in RESULTS:
        status = "PASS" if ok else "FAIL"
        if ok:
            n_pass += 1
        print("%s  %-40s  %s" % (status, name, detail))
    print("总计 %d/%d 项通过" % (n_pass, len(RESULTS)))

    with open("negative_control_log.txt", "w", encoding="utf-8") as f:
        for name, ok, detail in RESULTS:
            f.write("%s  %s  %s\n" % ("PASS" if ok else "FAIL", name, detail))
        f.write("总计 %d/%d 项通过\n" % (n_pass, len(RESULTS)))

    if n_pass != len(RESULTS):
        sys.exit(1)
    sys.exit(0)


if __name__ == "__main__":
    main()

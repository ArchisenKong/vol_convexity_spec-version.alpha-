#!/usr/bin/env python3
"""
GL-06 · verify/assert_check.py · v1.1（裁决60乙类修复）

合格断言脚本（任务6模板三D段）。v1.1修复对应外审缺陷：
  D-2  f4_strict_declaration_check：严格解析schema §10 F4机读声明块，零OR兜底；
       并断言宪-ST-06口径界定段三锚短语在场（删除/改写该段即失败）。
  D-3  source_anchor_check：28-B(i)源文程序化解析——定位源文行231，断言其含判据原句，
       且schema转抄与源文一致（57 Q-9指针核证；源文不在可及面＝装载缺陷，FAIL不SKIP）。
  D-4  崩溃安全日志：运行起点先写in-progress戳，异常路径经except写FAIL日志后exit 2；
       失败/崩溃运行不残留上一轮成功日志。
  D-5  W-8(b)关键字前哨以re.search消费scan_patterns.json之正则模式（修死条款）。
  D-6/D-7  f8_provenance_exact_reconstruction：自当前文件系统独立重构全份钉定内容
       （含全部非指纹字段）并与build_provenance.json逐字段比对（X19闭合）；
       并重跑pin-verify gate（当前代码重算vs存量产物语义，X18双保险）。
  D-8/39-B2  output_form_closure：harness_output顶层键集与逐行键集对声明集封闭，
       未声明键/层出现即失败。
  O-6  F-5/F-6由无条件record(True)改为实检：F-5数据件枚举封闭（多出未声明数据件即失败）；
       F-6源域声明在场性检查。

钉表顺序留痕（F-10，三处一致之一）：entity/ledger_input.json（钉表）先于两条计算路径
首次执行写定；本脚本比对晚于两路径真跑。
任一断言失败 => 非零退出码，输出指名实际失败断言（W-9(3)）。
"""
import hashlib
import importlib.util
import json
import os
import re
import sys

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # GL-06/
LOG_PATH = os.path.join(BASE, "verify", "assert_check_log.txt")

failures = []
passes = []

# ---- 声明集（封闭断言之基准，写死于此＝声明面；与schema §2/§10同义） ----
DECLARED_TOP_KEYS = {"object_id", "_data_source", "slots_echo", "results", "falsification_trigger_flags"}
DECLARED_ROW_KEYS_EVAL = {"t", "evaluated", "theta_income_cents", "window_days",
                          "window_sum_protection_cost_tv_cents", "lhs_cross_mult",
                          "rhs_cross_mult", "ratio_meets_threshold"}
DECLARED_ROW_KEYS_NONEVAL = {"t", "evaluated", "reason"}
DECLARED_DATA_FILES = {"entity/ledger_input.json", "entity/harness_output.json",
                       "verify/independent_expected.json", "verify/build_provenance.json",
                       "verify/comparison_table.tsv", "verify/scan_patterns.json"}
SOURCE_QUOTE = "我通常要求卖期权侧的 Theta 收入要大致两倍于日均保护成本的时间价值"
ST06_ANCHOR_PHRASES = ["时间价值现金流", "extrinsic premium", "非瞬时"]
PROV_EXCLUDED = {"verify/build_provenance.json", "verify/assert_check_log.txt",
                 "verify/negative_control_log.txt"}


def record(ok, label, detail=""):
    (passes if ok else failures).append(
        f"[{'PASS' if ok else 'FAIL'}] {label}" + (f" ({detail})" if detail else ""))


def strip_comments_and_docstrings(src: str) -> str:
    src = re.sub(r'"""[\s\S]*?"""', "", src)
    src = re.sub(r"'''[\s\S]*?'''", "", src)
    lines = []
    for line in src.splitlines():
        idx = line.find("#")
        if idx >= 0:
            line = line[:idx]
        lines.append(line)
    return "\n".join(lines)


def load_json(rel):
    with open(os.path.join(BASE, rel), encoding="utf-8") as f:
        return json.load(f)


def sha256_of(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        h.update(f.read())
    return h.hexdigest()


# ---------------- step0 ----------------

def step0_i_input_synthetic():
    ledger = load_json("entity/ledger_input.json")
    ok = ledger.get("_data_source") == "synthetic_hand_constructed"
    record(ok, "step0(i)_input_synthetic", f"_data_source={ledger.get('_data_source')}")
    return ok


def step0_ii_no_data_source_static_scan():
    patterns = load_json("verify/scan_patterns.json")
    scan_set = patterns["scan_object_set"]
    forbidden_imports = [re.compile(p, re.MULTILINE) for p in patterns["forbidden_import_patterns"]]
    # D-5修复：关键字模式同样以正则消费（模式表内即正则写法，此前以字面in消费致两条恒不命中）
    forbidden_keywords = [re.compile(p) for p in patterns["forbidden_keyword_patterns"]]

    all_clean = True
    hit_detail = []
    for rel in scan_set:
        with open(os.path.join(BASE, rel), encoding="utf-8") as f:
            raw = f.read()
        stripped = strip_comments_and_docstrings(raw)
        for pat in forbidden_imports:
            if pat.search(stripped):
                all_clean = False
                hit_detail.append(f"{rel}: forbidden import '{pat.pattern}'")
        for pat in forbidden_keywords:
            if pat.search(stripped):
                all_clean = False
                hit_detail.append(f"{rel}: forbidden keyword /{pat.pattern}/")
    record(all_clean, "step0(ii)_no_data_source_static_scan",
           "; ".join(hit_detail) if hit_detail else f"{len(scan_set)} files scanned (regex-consumed), clean")
    return all_clean


def step0_iii_independent_recompute_no_harness_reuse():
    with open(os.path.join(BASE, "verify", "independent_recompute.py"), encoding="utf-8") as f:
        src = f.read()
    stripped = strip_comments_and_docstrings(src)
    forbidden_tokens = ["harness_output", "import harness", "from entity.harness", "from entity import harness"]
    raw_hit = [t for t in forbidden_tokens if t in src]
    stripped_hit = [t for t in forbidden_tokens if t in stripped]
    ok = len(stripped_hit) == 0
    detail = f"stripped_hit={stripped_hit}"
    if raw_hit and not stripped_hit:
        detail += f"; 剥离前命中(留痕,非判定)={raw_hit}"
    record(ok, "step0(iii)_independent_recompute_no_harness_reuse", detail)
    return ok


# ---------------- 源文锚（D-3） ----------------

def _parse_f4_block(schema_text):
    m = re.search(r"<!--\s*F4_DECLARATIONS\s*(.*?)-->", schema_text, re.S)
    if not m:
        return None
    decl = {}
    for line in m.group(1).splitlines():
        line = line.strip()
        if ":" in line:
            k, v = line.split(":", 1)
            decl[k.strip()] = v.strip()
    return decl


def source_anchor_check():
    with open(os.path.join(BASE, "entity", "input_schema.md"), encoding="utf-8") as f:
        schema_text = f.read()
    decl = _parse_f4_block(schema_text)
    if decl is None or "source_anchor_file" not in decl or "source_anchor_line" not in decl:
        record(False, "source_anchor_check", "schema F4块缺source_anchor_*键")
        return False
    fname = decl["source_anchor_file"]
    lineno = int(decl["source_anchor_line"])
    candidates = [os.path.join(os.environ.get("GL06_SOURCE_DIR", ""), fname),
                  os.path.join("/mnt/project", fname),
                  os.path.join(BASE, "..", fname)]
    src_path = next((p for p in candidates if p and os.path.isfile(p)), None)
    if src_path is None:
        record(False, "source_anchor_check",
               f"源文{fname}不在可及面（C4③装载义务缺件，FAIL不SKIP）")
        return False
    with open(src_path, encoding="utf-8") as f:
        lines = f.read().splitlines()
    line_ok = len(lines) >= lineno and (SOURCE_QUOTE in lines[lineno - 1])
    schema_ok = SOURCE_QUOTE in schema_text
    ok = line_ok and schema_ok
    record(ok, "source_anchor_check",
           f"file={os.path.basename(src_path)} line{lineno}_contains_quote={line_ok} schema_quotes_source={schema_ok}")
    return ok


# ---------------- 数值面（存量保留） ----------------

def numeric_compare_ratio_meets_threshold(harness_out, indep_out):
    h_by_t = {r["t"]: r for r in harness_out["results"]}
    i_by_t = {r["t"]: r for r in indep_out["results"]}
    mismatches = []
    if set(h_by_t.keys()) != set(i_by_t.keys()):
        mismatches.append(f"period set mismatch: harness={sorted(h_by_t)} indep={sorted(i_by_t)}")
    for t in sorted(set(h_by_t) & set(i_by_t)):
        h, i = h_by_t[t], i_by_t[t]
        if h["evaluated"] != i["evaluated"]:
            mismatches.append(f"t={t}: evaluated mismatch")
            continue
        if not h["evaluated"]:
            continue
        if h["ratio_meets_threshold"] != i["ratio_meets_threshold"]:
            mismatches.append(f"t={t}: ratio_meets_threshold mismatch harness={h['ratio_meets_threshold']} indep={i['ratio_meets_threshold']}")
        if h["window_sum_protection_cost_tv_cents"] != i["window_sum_protection_cost_tv_cents"]:
            mismatches.append(f"t={t}: window_sum mismatch")
    ok = len(mismatches) == 0
    record(ok, "numeric_compare_ratio_meets_threshold_bit_exact",
           "; ".join(mismatches) if mismatches else f"{len(h_by_t)} periods cross-checked, all bit-exact match")
    return ok


def window_exclusion_correctness(ledger, harness_out, indep_out):
    W = ledger["slots"]["averaging_window_days"]["value"]
    expected_excluded = set(range(1, W))
    h_excluded = set(r["t"] for r in harness_out["results"] if not r["evaluated"])
    i_excluded = set(r["t"] for r in indep_out["results"] if not r["evaluated"])
    ok = (h_excluded == expected_excluded == i_excluded)
    record(ok, "window_exclusion_correctness",
           f"expected={sorted(expected_excluded)} harness={sorted(h_excluded)} indep={sorted(i_excluded)}")
    return ok


def boundary_ge_semantics(harness_out):
    h_by_t = {r["t"]: r for r in harness_out["results"]}
    checks = []
    for t in (5, 10):
        r = h_by_t[t]
        checks.append((t, r["lhs_cross_mult"] == r["rhs_cross_mult"], r["ratio_meets_threshold"]))
    ok = all(b and m for (_, b, m) in checks)
    record(ok, "boundary_ge_not_gt_semantics", f"t=5,10 boundary-equal-and-pass: {checks}")
    return ok


# ---------------- F-4严格（D-2） ----------------

def f4_strict_declaration_check():
    with open(os.path.join(BASE, "entity", "input_schema.md"), encoding="utf-8") as f:
        schema_text = f.read()
    decl = _parse_f4_block(schema_text)
    if decl is None:
        record(False, "f4_strict_declaration_check", "schema缺F4_DECLARATIONS机读块")
        return False
    ledger = load_json("entity/ledger_input.json")
    checks = []
    checks.append(("numerator", str(ledger["slots"]["ratio_threshold"]["numerator"]) == decl.get("ratio_threshold_numerator")))
    checks.append(("denominator", str(ledger["slots"]["ratio_threshold"]["denominator"]) == decl.get("ratio_threshold_denominator")))
    checks.append(("window", str(ledger["slots"]["averaging_window_days"]["value"]) == decl.get("averaging_window_days")))
    checks.append(("st06_marker_key", decl.get("st06_scope_marker") == "extrinsic_premium_not_instantaneous_dVdt"))
    for ph in ST06_ANCHOR_PHRASES:
        checks.append((f"st06_phrase[{ph}]", ph in schema_text))
    ok = all(v for _, v in checks)
    record(ok, "f4_strict_declaration_check",
           "; ".join(f"{k}={'OK' if v else 'MISMATCH'}" for k, v in checks))
    return ok


# ---------------- F-8重构核证（D-6/D-7） ----------------

def f8_provenance_exact_reconstruction():
    prov_path = os.path.join(BASE, "verify", "build_provenance.json")
    with open(prov_path, encoding="utf-8") as f:
        prov = json.load(f)
    spec = importlib.util.spec_from_file_location("gl06_bp", os.path.join(BASE, "verify", "build_provenance.py"))
    bp = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(bp)
    expected_fp = {rel: sha256_of(os.path.join(BASE, rel)) for rel in bp.enumerate_tracked()}
    expected = {
        "object_id": "GL-06",
        "pin_sequence_note": bp.PIN_SEQUENCE_NOTE,
        "pin_verify_gate": "passed_current_code_reproduces_stored_semantic_output",
        "excluded_with_reasons": {
            "verify/build_provenance.json": "self; integrity via assert_check exact reconstruction",
            "verify/assert_check_log.txt": "post-pin stage output",
            "verify/negative_control_log.txt": "post-pin stage output",
        },
        "fingerprints": expected_fp,
    }
    ok_struct = (prov == expected)
    ok_gate = bp.pin_verify_gate()
    detail = []
    if not ok_struct:
        diff_keys = [k for k in set(prov) | set(expected) if prov.get(k) != expected.get(k)]
        if "fingerprints" in diff_keys:
            fp = prov.get("fingerprints", {})
            fdiff = [k for k in set(fp) | set(expected_fp) if fp.get(k) != expected_fp.get(k)]
            detail.append(f"fingerprint_diff={fdiff[:6]}")
        detail.append(f"field_diff={[k for k in diff_keys if k != 'fingerprints']}")
    detail.append(f"pin_verify_gate_rerun={'OK' if ok_gate else 'FAIL'}")
    ok = ok_struct and ok_gate
    record(ok, "f8_provenance_exact_reconstruction", "; ".join(detail) if detail else
           f"{len(expected_fp)} files, full-field match, gate rerun OK")
    return ok


# ---------------- 输出形态封闭（D-8/39-B2） ----------------

def output_form_closure(harness_out):
    problems = []
    top = set(harness_out.keys())
    if top != DECLARED_TOP_KEYS:
        problems.append(f"top: extra={sorted(top - DECLARED_TOP_KEYS)} missing={sorted(DECLARED_TOP_KEYS - top)}")
    for r in harness_out["results"]:
        keys = set(r.keys())
        declared = DECLARED_ROW_KEYS_EVAL if r.get("evaluated") else DECLARED_ROW_KEYS_NONEVAL
        if keys != declared:
            problems.append(f"t={r.get('t')}: extra={sorted(keys - declared)} missing={sorted(declared - keys)}")
    ok = len(problems) == 0
    record(ok, "output_form_closure_undeclared_keys", "; ".join(problems) if problems else
           "top-level与逐行键集对声明集封闭")
    return ok


# ---------------- F-5/F-6实检（O-6） ----------------

def f5_data_file_enumeration_closure():
    discovered = set()
    for root, dirs, files in os.walk(BASE):
        dirs[:] = [d for d in dirs if d != "__pycache__"]
        for fn in files:
            if fn.endswith((".json", ".tsv", ".csv")):
                rel = os.path.relpath(os.path.join(root, fn), BASE).replace(os.sep, "/")
                discovered.add(rel)
    extra = discovered - DECLARED_DATA_FILES
    missing = DECLARED_DATA_FILES - discovered
    ok = not extra and not missing
    record(ok, "f5_data_file_enumeration_closure",
           f"extra={sorted(extra)} missing={sorted(missing)}" if not ok else
           f"{len(discovered)} data files, closed vs declared set")
    return ok


def f6_source_domain_declaration_present():
    with open(os.path.join(BASE, "entity", "input_schema.md"), encoding="utf-8") as f:
        schema_text = f.read()
    ok = ("八份" in schema_text) and ("行231" in schema_text)
    record(ok, "f6_source_domain_declaration_present",
           f"eight-docs-domain-declared={'八份' in schema_text} line-anchor-declared={'行231' in schema_text}")
    return ok


def falsification_trigger_flags_empty(harness_out):
    ok = harness_out.get("falsification_trigger_flags", None) == []
    record(ok, "falsification_trigger_flags_empty_per_step3_no_C6",
           f"flags={harness_out.get('falsification_trigger_flags')}")
    return ok


# ---------------- 日志（D-4崩溃安全） ----------------

def write_log(verdict_line):
    with open(LOG_PATH, "w", encoding="utf-8") as f:
        f.write("GL-06 assert_check log (v1.1)\n")
        f.write("=" * 60 + "\n")
        for line in passes:
            f.write(line + "\n")
        for line in failures:
            f.write(line + "\n")
        f.write("=" * 60 + "\n")
        f.write(f"TOTAL: {len(passes)} passed, {len(failures)} failed\n")
        f.write(verdict_line + "\n")


def stamp_in_progress():
    with open(LOG_PATH, "w", encoding="utf-8") as f:
        f.write("GL-06 assert_check log (v1.1)\n")
        f.write("RUN IN PROGRESS - NO VERDICT (若本行残留，说明运行未正常收尾)\n")


def main():
    stamp_in_progress()
    ledger = load_json("entity/ledger_input.json")

    ok0i = step0_i_input_synthetic()
    ok0ii = step0_ii_no_data_source_static_scan()
    ok0iii = step0_iii_independent_recompute_no_harness_reuse()
    ok_anchor = source_anchor_check()

    if not (ok0i and ok0ii and ok0iii and ok_anchor):
        write_log("RESULT: FAIL (step0前置合规/源文锚未通过，未进入数值比对)")
        print(f"\n{'='*60}\nRESULT: FAIL (step0/源文锚未通过)\n{'='*60}")
        sys.exit(1)

    harness_out = load_json("entity/harness_output.json")
    indep_out = load_json("verify/independent_expected.json")

    results = [
        numeric_compare_ratio_meets_threshold(harness_out, indep_out),
        window_exclusion_correctness(ledger, harness_out, indep_out),
        boundary_ge_semantics(harness_out),
        f4_strict_declaration_check(),
        f8_provenance_exact_reconstruction(),
        output_form_closure(harness_out),
        f5_data_file_enumeration_closure(),
        f6_source_domain_declaration_present(),
        falsification_trigger_flags_empty(harness_out),
    ]
    all_ok = all(results)
    write_log(f"RESULT: {'PASS' if all_ok else 'FAIL'}")
    print(f"\n{'='*60}\nRESULT: {'PASS' if all_ok else 'FAIL'}\n{'='*60}")
    sys.exit(0 if all_ok else 1)


if __name__ == "__main__":
    try:
        main()
    except SystemExit:
        raise
    except Exception as e:  # D-4：崩溃路径不残留成功日志
        failures.append(f"[FAIL] uncaught_exception ({type(e).__name__}: {e})")
        write_log("RESULT: FAIL (uncaught exception - crashed run)")
        print(f"\n{'='*60}\nRESULT: FAIL (crash: {e})\n{'='*60}")
        sys.exit(2)

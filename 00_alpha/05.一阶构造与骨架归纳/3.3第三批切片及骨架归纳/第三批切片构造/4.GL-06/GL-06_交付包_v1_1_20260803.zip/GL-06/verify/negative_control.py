#!/usr/bin/env python3
"""
GL-06 · verify/negative_control.py · v1.1（裁决60乙类修复）

被测侧注入变异（乙-4）。v1.1修复内容（对应外审D-8与观察O-4）：
1. 全部案例改经断言栈实跑击落（在隔离副本树上以subprocess运行verify/assert_check.py，
   以退出码与日志指名断言为击落证据），不再由本脚本自建比对（O-4闭合）。
2. 新增输出形态封闭类注入案例（D-8/39-B2）。
3. 保留计算面击落例（F-9）与X18型钉定门拒绝例。

案例：
  NC-1（原M-GL06-01强化）：harness比较算子>=误写为>，全链重跑（harness→provenance→assert），
       预期assert_check exit=1且击落断言含numeric/boundary计算面断言（F-9计算面击落例）。
  NC-2（新增，D-8）：向harness_output注入未声明顶层键＋未声明行键（不改代码），重钉后跑assert，
       预期exit=1且击落断言＝output_form_closure_undeclared_keys（输出形态封闭类注入在场）。
  NC-3（X18型）：改harness实现（权重变异）后直接重钉不重跑产物，预期build_provenance.py
       pin-verify gate拒绝钉定（exit=3）——"改代码＋重钉＋不重跑"通道在钉定环节击落。

隔离纪律：每案例在/tmp全新副本树上执行，原交付树零触碰（无需复原步骤）；
失败输出指名实际失败断言（W-9(3)）。
"""
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LOG_PATH = os.path.join(BASE, "verify", "negative_control_log.txt")

lines_out = []
ok_all = True


def log(s):
    lines_out.append(s)
    print(s)


def fresh_copy():
    d = tempfile.mkdtemp(prefix="gl06_nc_")
    dst = os.path.join(d, "GL-06")
    shutil.copytree(BASE, dst, ignore=shutil.ignore_patterns("__pycache__"))
    return dst


def run(cmd, cwd):
    p = subprocess.run([sys.executable] + cmd, cwd=cwd, capture_output=True, text=True)
    return p.returncode


def read_log(tree):
    p = os.path.join(tree, "verify", "assert_check_log.txt")
    return open(p, encoding="utf-8").read() if os.path.isfile(p) else ""


def case_nc1():
    global ok_all
    tree = fresh_copy()
    hp = os.path.join(tree, "entity", "harness.py")
    src = open(hp, encoding="utf-8").read()
    mutated = src.replace("lhs >= rhs", "lhs > rhs")
    assert mutated != src, "NC-1注入点未命中"
    open(hp, "w", encoding="utf-8").write(mutated)
    rc_h = run([os.path.join("entity", "harness.py")], tree)
    rc_p = run([os.path.join("verify", "build_provenance.py")], tree)
    rc_a = run([os.path.join("verify", "assert_check.py")], tree)
    logtxt = read_log(tree)
    killed_by = [m for m in ("numeric_compare_ratio_meets_threshold_bit_exact",
                             "boundary_ge_not_gt_semantics") if f"[FAIL] {m}" in logtxt]
    ok = (rc_h == 0 and rc_p == 0 and rc_a == 1 and len(killed_by) >= 1)
    ok_all = ok_all and ok
    log(f"[NC-1] {'PASS' if ok else 'FAIL'} 比较算子>=→>全链重跑：harness={rc_h} pin={rc_p} "
        f"assert_exit={rc_a} 计算面击落断言={killed_by}（F-9计算面击落例，经断言栈实跑）")


def case_nc2():
    global ok_all
    tree = fresh_copy()
    op = os.path.join(tree, "entity", "harness_output.json")
    h = json.load(open(op, encoding="utf-8"))
    h["_undeclared_top_level_key"] = "injected"
    for r in h["results"]:
        if r.get("evaluated"):
            r["undeclared_row_key"] = 42
            break
    json.dump(h, open(op, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
    rc_p = run([os.path.join("verify", "build_provenance.py")], tree)  # 语义门只核语义字段，应放行
    rc_a = run([os.path.join("verify", "assert_check.py")], tree)
    logtxt = read_log(tree)
    killed = "[FAIL] output_form_closure_undeclared_keys" in logtxt
    ok = (rc_p == 0 and rc_a == 1 and killed)
    ok_all = ok_all and ok
    log(f"[NC-2] {'PASS' if ok else 'FAIL'} 未声明键/层注入（顶层+行级）重钉后实跑：pin={rc_p} "
        f"assert_exit={rc_a} 击落断言=output_form_closure_undeclared_keys命中={killed}（38-2锚点一/39-B2在场）")


def case_nc3():
    global ok_all
    tree = fresh_copy()
    hp = os.path.join(tree, "entity", "harness.py")
    src = open(hp, encoding="utf-8").read()
    mutated = src.replace("income_t * W * thr_den", "income_t * thr_den")
    assert mutated != src, "NC-3注入点未命中"
    open(hp, "w", encoding="utf-8").write(mutated)
    rc_p = run([os.path.join("verify", "build_provenance.py")], tree)  # 不重跑harness，直接重钉
    ok = (rc_p == 3)
    ok_all = ok_all and ok
    log(f"[NC-3] {'PASS' if ok else 'FAIL'} 改代码+重钉+不重跑产物（X18型）：pin_exit={rc_p}"
        f"（预期3＝pin-verify gate拒绝钉定，D-7通道在钉定环节击落）")


def main():
    log("GL-06 negative_control log (v1.1) — 全案例经隔离副本树+断言栈实跑")
    log("=" * 60)
    # 基线：原树clean跑（不落盘写原树日志——在副本树跑基线，避免污染主树assert日志时序）
    tree = fresh_copy()
    rc_base = run([os.path.join("verify", "assert_check.py")], tree)
    ok_base = (rc_base == 0)
    global ok_all
    ok_all = ok_all and ok_base
    log(f"[BASE] {'PASS' if ok_base else 'FAIL'} 未注入基线（副本树实跑）：assert_exit={rc_base}（预期0）")
    case_nc1()
    case_nc2()
    case_nc3()
    log("=" * 60)
    verdict = "ALL NEGATIVE-CONTROL CASES PASS" if ok_all else "NEGATIVE-CONTROL FAILURE"
    log(f"RESULT: {verdict}")
    with open(LOG_PATH, "w", encoding="utf-8") as f:
        f.write("\n".join(lines_out) + "\n")
    sys.exit(0 if ok_all else 1)


if __name__ == "__main__":
    main()

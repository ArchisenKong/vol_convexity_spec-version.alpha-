#!/usr/bin/env python3
"""
GL-06 · verify/independent_recompute.py

独立复算路径（D段②"实现路径独立"硬要求；F-2判别据＝改写后是否仍共享同一失效模式）：
- 技术路径①：窗口和改用前缀和(prefix sum)推导，非entity/harness.py之直接切片求和——
  若harness窗口边界索引存在off-by-one类缺陷，前缀和实现不会因共享同一推导路径而复现同一缺陷。
- 技术路径②：比值判定改用Python fractions.Fraction精确有理数除法+比较，非harness之
  cross-multiplication整数比较——两种数值判定技术路径独立。
- 独立性硬约束（F-8同型禁令）：本脚本自clean人造input（ledger_input.json）独立推导期望值，
  不读取entity/harness_output.json或任何harness中间产物/本脚本自身既往产物。
"""
import json
import os
from fractions import Fraction

LEDGER_PATH = os.path.join(os.path.dirname(__file__), "..", "entity", "ledger_input.json")
OUTPUT_PATH = os.path.join(os.path.dirname(__file__), "independent_expected.json")


def load_ledger(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def build_prefix_sums(values_by_t, ts_sorted):
    """前缀和：prefix[t] = sum(values[1..t])。O(1)窗口和推导，技术路径与harness直接切片求和不同。"""
    prefix = {}
    running = 0
    for t in ts_sorted:
        running += values_by_t[t]
        prefix[t] = running
    return prefix


def window_sum_via_prefix(prefix, t, W):
    upper = prefix[t]
    lower_t = t - W
    lower = prefix.get(lower_t, 0)
    return upper - lower


def compute_independent(ledger):
    W = ledger["slots"]["averaging_window_days"]["value"]
    thr = Fraction(
        ledger["slots"]["ratio_threshold"]["numerator"],
        ledger["slots"]["ratio_threshold"]["denominator"]
    )
    periods = ledger["periods"]
    cost_by_t = {p["t"]: p["protection_cost_tv_cents"] for p in periods}
    income_by_t = {p["t"]: p["theta_income_cents"] for p in periods}
    ts_sorted = sorted(cost_by_t.keys())
    cost_prefix = build_prefix_sums(cost_by_t, ts_sorted)

    results = []
    for t in ts_sorted:
        if t < W:
            results.append({"t": t, "evaluated": False})
            continue

        window_sum_cost = window_sum_via_prefix(cost_prefix, t, W)
        avg_cost = Fraction(window_sum_cost, W)
        ratio = Fraction(income_by_t[t], 1) / avg_cost
        meets = ratio >= thr

        results.append({
            "t": t,
            "evaluated": True,
            "window_sum_protection_cost_tv_cents": window_sum_cost,
            "avg_protection_cost_tv_cents_fraction": [avg_cost.numerator, avg_cost.denominator],
            "ratio_fraction": [ratio.numerator, ratio.denominator],
            "ratio_meets_threshold": meets
        })
    return results


def main():
    ledger = load_ledger(LEDGER_PATH)
    results = compute_independent(ledger)
    with open(OUTPUT_PATH, "w", encoding="utf-8") as f:
        json.dump({"object_id": "GL-06", "results": results}, f, ensure_ascii=False, indent=2)
    print(f"[independent_recompute] wrote {OUTPUT_PATH}: {len(results)} periods")


if __name__ == "__main__":
    main()

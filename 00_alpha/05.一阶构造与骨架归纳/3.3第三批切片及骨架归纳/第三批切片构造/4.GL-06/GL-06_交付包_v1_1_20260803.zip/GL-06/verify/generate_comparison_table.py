#!/usr/bin/env python3
"""
GL-06 · verify/generate_comparison_table.py

程序化产出比对表（W-13(14)：凡进入合格判定叙述链的表格类制品须由随verify/交付的脚本程序化产出，
不得手工誊写）。本脚本读取entity/harness_output.json与verify/independent_expected.json，
逐期比对，输出verify/comparison_table.tsv。
"""
import json
import os

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUTPUT_PATH = os.path.join(BASE, "verify", "comparison_table.tsv")


def load_json(rel):
    with open(os.path.join(BASE, rel), encoding="utf-8") as f:
        return json.load(f)


def main():
    harness_out = load_json("entity/harness_output.json")
    indep_out = load_json("verify/independent_expected.json")
    h_by_t = {r["t"]: r for r in harness_out["results"]}
    i_by_t = {r["t"]: r for r in indep_out["results"]}

    lines = ["t\tevaluated\ttheta_income_cents\twindow_sum_cost\tharness_ratio_meets\tindep_ratio_meets\tmatch"]
    for t in sorted(h_by_t.keys()):
        h, i = h_by_t[t], i_by_t[t]
        if not h["evaluated"]:
            lines.append(f"{t}\tFalse\t-\t-\t-\t-\t-")
            continue
        match = h["ratio_meets_threshold"] == i["ratio_meets_threshold"]
        lines.append(
            f"{t}\tTrue\t{h['theta_income_cents']}\t{h['window_sum_protection_cost_tv_cents']}\t"
            f"{h['ratio_meets_threshold']}\t{i['ratio_meets_threshold']}\t{match}"
        )

    with open(OUTPUT_PATH, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    print(f"[generate_comparison_table] wrote {OUTPUT_PATH}: {len(lines)-1} rows")


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""
GL-06 · verify/build_provenance.py · v1.1（裁决60乙类修复）

新鲜度/来源钉定件生成脚本（F-8）。v1.1修复内容（对应外审D-6/D-7）：
1. 钉定射程扩至全部代码件＋全部数据/产物件（除本钉定件自身与两份运行日志外全包域）；
   本钉定件自身（build_provenance.json）之完整性由 verify/assert_check.py
   `f8_provenance_exact_reconstruction` 以"自当前文件系统独立重构全份钉定内容并逐字段比对"
   方式核证——非自哈希（数学上不可能），而是可重构性核证：任何字段被篡改（含非指纹字段）
   均因与重构结果不符而被击落（X19通道闭合）。
2. 钉前验证门（pin-verify gate，D-7/X18通道闭合）：本脚本在写钉定件之前，以当前
   entity/harness.py 代码在进程内重算全部语义结果，与 entity/harness_output.json 存量
   语义字段逐项比对；不符则拒绝钉定并以非零退出码终止——"改代码＋重钉＋不重跑产物"
   之攻击在钉定环节即被拒绝。残余面（如实声明）：语义等价之代码改写不改变输出，
   门无从区分，属计算面无害类。
3. 本脚本不读取自身既往产物（每次运行对当前文件系统状态全量重算，非累积追加）。
"""
import hashlib
import importlib.util
import json
import os
import sys

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # GL-06/
OUTPUT_PATH = os.path.join(BASE, "verify", "build_provenance.json")

# 钉定射程＝全包域，排除项最小化且逐项给理由：
#   verify/build_provenance.json —— 本钉定件自身（由assert_check重构核证，见docstring第1条）
#   verify/assert_check_log.txt / verify/negative_control_log.txt —— 钉定之后阶段产出的运行日志
EXCLUDED = {
    "verify/build_provenance.json",
    "verify/assert_check_log.txt",
    "verify/negative_control_log.txt",
}

PIN_SEQUENCE_NOTE = (
    "本次钉定发生于harness.py与independent_recompute.py均已真跑产出数值文件之后、"
    "assert_check.py执行之前；钉定对象=全包域当前内容（排除项见schema与本脚本EXCLUDED，"
    "排除理由逐项声明）；钉定前已执行pin-verify gate（当前代码在进程内重算与存量产物语义比对）。"
)


def enumerate_tracked():
    """钉定域＝entity/＋verify/交付射程（W-9(1)口径）；切片记录/撞墙清单为记录文书，
    在裁决台收口流程中后于钉定环节定稿，不入本钉定域（其完整性由外审侧指纹对照承载）。"""
    tracked = []
    for sub in ("entity", "verify"):
        for root, dirs, files in os.walk(os.path.join(BASE, sub)):
            dirs[:] = [d for d in dirs if d != "__pycache__"]
            for fn in files:
                rel = os.path.relpath(os.path.join(root, fn), BASE).replace(os.sep, "/")
                if rel in EXCLUDED:
                    continue
                tracked.append(rel)
    return sorted(tracked)


def sha256_of(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        h.update(f.read())
    return h.hexdigest()


def semantic_fields(result_row):
    """pin-verify gate比对之语义字段子集（键封闭性归assert_check职责，门只核语义值）。"""
    if not result_row.get("evaluated"):
        return {"t": result_row.get("t"), "evaluated": False, "reason": result_row.get("reason")}
    keys = ("t", "evaluated", "theta_income_cents", "window_days",
            "window_sum_protection_cost_tv_cents", "lhs_cross_mult", "rhs_cross_mult",
            "ratio_meets_threshold")
    return {k: result_row.get(k) for k in keys}


def pin_verify_gate():
    spec = importlib.util.spec_from_file_location("gl06_harness", os.path.join(BASE, "entity", "harness.py"))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    ledger = mod.load_ledger(os.path.join(BASE, "entity", "ledger_input.json"))
    fresh_rows = mod.compute_gl06(ledger)  # 返回results行list（harness.main()负责外层包装）
    with open(os.path.join(BASE, "entity", "harness_output.json"), encoding="utf-8") as f:
        stored = json.load(f)
    fresh_sem = [semantic_fields(r) for r in fresh_rows]
    stored_sem = [semantic_fields(r) for r in stored["results"]]
    return fresh_sem == stored_sem


def main():
    if not pin_verify_gate():
        print("[build_provenance] PIN REFUSED: 当前harness代码重算结果与存量harness_output.json语义不符"
              "（改代码未重跑产物？）。不写钉定件。")
        sys.exit(3)

    fingerprints = {rel: sha256_of(os.path.join(BASE, rel)) for rel in enumerate_tracked()}
    output = {
        "object_id": "GL-06",
        "pin_sequence_note": PIN_SEQUENCE_NOTE,
        "pin_verify_gate": "passed_current_code_reproduces_stored_semantic_output",
        "excluded_with_reasons": {
            "verify/build_provenance.json": "self; integrity via assert_check exact reconstruction",
            "verify/assert_check_log.txt": "post-pin stage output",
            "verify/negative_control_log.txt": "post-pin stage output",
        },
        "fingerprints": fingerprints,
    }
    with open(OUTPUT_PATH, "w", encoding="utf-8") as f:
        json.dump(output, f, ensure_ascii=False, indent=2)
    print(f"[build_provenance] wrote {OUTPUT_PATH}: {len(fingerprints)} files fingerprinted (gate passed)")


if __name__ == "__main__":
    main()

# 三方比对表（钉表 / harness 实跑 / 独立复算）· 脚本程序化产出（W-13(14)）

| 序列 | 类 | 钉定 verdict | 钉定违规码 | 三方 |
|---|---|---|---|---|
| N01 | negative | illegal | V03 | 一致 |
| N02 | negative | illegal | V05 | 一致 |
| N03 | negative | illegal | V08 | 一致 |
| N04 | negative | illegal | V12 | 一致 |
| N05 | negative | illegal | V07 | 一致 |
| N06 | negative | illegal | V04 | 不一致 |
| N07 | negative | illegal | V09 | 一致 |
| N08 | negative | illegal | V10 | 一致 |
| N09 | negative | illegal | V11 | 一致 |
| N10 | negative | illegal | V13 | 一致 |
| N11 | negative | illegal | V14 | 一致 |
| N12 | negative | illegal | V06 | 一致 |
| N13 | negative | illegal | V01 | 一致 |
| N14 | negative | illegal | V02 | 一致 |
| N15 | negative | illegal | V08 | 一致 |
| P1 | positive | legal | — | 一致 |
| P2 | positive | legal | — | 一致 |
| P3 | positive | legal | — | 一致 |
| P4 | positive | legal | — | 一致 |
| P5 | positive | legal | — | 一致 |

三方一致数＝19/20

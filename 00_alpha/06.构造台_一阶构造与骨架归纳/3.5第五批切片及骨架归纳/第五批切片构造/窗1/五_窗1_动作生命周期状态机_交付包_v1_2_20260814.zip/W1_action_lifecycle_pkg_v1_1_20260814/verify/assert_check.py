# -*- coding: utf-8 -*-
"""
断言栈 · 窗1 动作生命周期状态机（模板三 D 段）

【钉表构造顺序留痕（F-10 最低形态：文字声明三处一致，本处为第二处）】
  期望值钉表 entity/expected_pin_table.json 与人造 input 同轮提交，**先于 harness 首次实跑**。
  另两处＝ entity/input_schema.md §7、本根切片记录。可程序化时序证据非强制（F-10）。

【判据可检层次声明（F-3）】
  每条断言在 ASSERTIONS 表内显式标注 layer ∈ {字面层, 语义层-机械前哨}。
  标「语义层-机械前哨」者：机械检出仅作假阴性通道，权威证伪面＝人读审计。

【判据面纯净性自扫描射程声明（DOC-35③ 转-5）】
  本脚本自扫描射程＝**字面层**（文本/键集/指纹/数值面之机械比对）；
  语义适当性（L2）不在本脚本射程，归外审与KD。

【退出码】任一断言失败即以非零退出码终止（W-13(2)）；失败归因按实际失败断言输出，不写死单一原因（W-9(3)）。
"""
import sys

sys.dont_write_bytecode = True

import ast
import io
import json
import os
import re
import tokenize

_HERE = os.path.dirname(os.path.abspath(__file__))
_PKG = os.path.dirname(_HERE)
sys.path.insert(0, _HERE)
sys.path.insert(0, os.path.join(_PKG, "entity"))

import build_provenance as PROV                     # noqa: E402
import independent_recompute as IR                  # noqa: E402

SCHEMA = os.path.join(_PKG, "entity", "input_schema.md")
DECL_JSON = os.path.join(_PKG, "entity", "lifecycle_declaration.json")
INPUT_JSON = os.path.join(_PKG, "entity", "synthetic_input.json")
PIN_JSON = os.path.join(_PKG, "entity", "expected_pin_table.json")
RUN_JSON = os.path.join(_PKG, "entity", "outputs", "run_output.json")
LOG_DIR = os.path.join(_HERE, "logs")

IMPL_SOURCES = [os.path.join(_PKG, "entity", "state_machine.py"),
                os.path.join(_HERE, "independent_recompute.py")]

# ---- F-1 检测器自排除条款：排除清单非空且**仅含检测器自身条目** ----
SCAN_EXCLUDED = {"verify/assert_check.py"}

FORBIDDEN_LIBS = ("requests", "urllib", "socket", "yfinance", "ibapi",
                  "ib_insync", "pandas_datareader")
FORBIDDEN_REGEX = [
    r"^\s*import\s+(?:%s)\b" % "|".join(FORBIDDEN_LIBS),
    r"^\s*from\s+(?:%s)\b" % "|".join(FORBIDDEN_LIBS),
]
FORBIDDEN_KEYWORDS = ["IBKR", "QuantConnect", "http" + "://", "http" + "s://",
                      "urlopen", "requests" + ".", "socket" + ".",
                      "importlib", "__" + "import__", "b64" + "decode"]

SOURCE_ROOTS = [r for r in
                (os.environ.get("W1_SOURCE_ROOTS", "").split(os.pathsep)
                 + ["/mnt/project", "/mnt/user-data/uploads"]) if r]

# 源文锚（F-18 L2 完整性维 ①：行号指针可解析且字面在场）
SOURCE_ANCHORS = [
    ("2_波动率凸性策略可复用方法论文档集_12篇_T0_frozen_clean_20260615.md", 66, "candidate action"),
    ("2_波动率凸性策略可复用方法论文档集_12篇_T0_frozen_clean_20260615.md", 67, "approved action"),
    ("2_波动率凸性策略可复用方法论文档集_12篇_T0_frozen_clean_20260615.md", 71, "identity drift declaration"),
    ("1_可复用方法论主题树_T0_frozen_clean_20260615.md", 1011, "状态转移"),
    ("1_可复用方法论主题树_T0_frozen_clean_20260615.md", 1017, "合法动作必须保证"),
    ("1_可复用方法论主题树_T0_frozen_clean_20260615.md", 1024, "对象身份未漂移"),
    ("1_可复用方法论主题树_T0_frozen_clean_20260615.md", 1027, "parameter_slot_candidate"),
    ("1_可复用方法论主题树_T0_frozen_clean_20260615.md", 1029, "object identity audit"),
    ("思想层宪法_v1_0_20260724.md", 471, "人工持有最终执行确认权"),
    ("思想层宪法_v1_0_20260724.md", 475, "研究/回测环节"),
]

TASKPACK = "第五批窗1任务包_v1_0_20260814.md"


# ------------------------------------------------------------------ 工具
def read(path, mode="r"):
    if mode == "rb":
        with open(path, "rb") as fh:
            return fh.read()
    with open(path, "r", encoding="utf-8") as fh:
        return fh.read()


def pkg_files():
    return PROV.iter_package_files(_PKG)


def find_doc(name):
    for root in SOURCE_ROOTS:
        p = os.path.join(root, name)
        if os.path.isfile(p):
            return p
    return None


def strip_comments_and_docstrings(src):
    """剥离注释与 docstring 后返回文本（W-8 判定基面；剥离前命中仅作留痕）。"""
    out_lines = src.split("\n")
    try:
        tree = ast.parse(src)
    except SyntaxError:
        tree = None
    blank = set()
    if tree is not None:
        for node in ast.walk(tree):
            if isinstance(node, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef,
                                 ast.ClassDef)):
                body = getattr(node, "body", [])
                if body and isinstance(body[0], ast.Expr) and \
                        isinstance(body[0].value, ast.Constant) and \
                        isinstance(body[0].value.value, str):
                    s = body[0].lineno
                    e = getattr(body[0], "end_lineno", s)
                    for ln in range(s, e + 1):
                        blank.add(ln)
    for ln in blank:
        if 1 <= ln <= len(out_lines):
            out_lines[ln - 1] = ""
    txt = "\n".join(out_lines)
    try:
        res = []
        for tok in tokenize.generate_tokens(io.StringIO(txt).readline):
            if tok.type == tokenize.COMMENT:
                continue
            res.append(tok)
        txt = tokenize.untokenize(res)
    except Exception:
        txt = "\n".join(l.split("#")[0] if l.strip().startswith("#") else l
                        for l in txt.split("\n"))
    return txt


def scan_text_for_forbidden(text):
    hits = []
    for ln_no, ln in enumerate(text.split("\n"), 1):
        for rx in FORBIDDEN_REGEX:
            if re.search(rx, ln):
                hits.append((ln_no, rx))
        for kw in FORBIDDEN_KEYWORDS:
            if kw in ln:
                hits.append((ln_no, kw))
    return hits


# ------------------------------------------------------------------ 载入
D = json.loads(read(DECL_JSON))
D_EMBED = IR.parse_embedded_declaration(SCHEMA)
INP = json.loads(read(INPUT_JSON))
PIN = json.loads(read(PIN_JSON))
RUN = json.loads(read(RUN_JSON))
REC = IR.recompute_all()
SCHEMA_TXT = read(SCHEMA)
IMPL_TXT = "\n".join(read(p) for p in IMPL_SOURCES)
# 判定基面＝剥离注释/docstring 后之实现体（W-8 同口径；防声明性提及被误判为消费）
IMPL_BODY = "\n".join(strip_comments_and_docstrings(read(p)) for p in IMPL_SOURCES)


def norm(res):
    return (res["verdict"],
            [(v["code"], v["locus"]["t"], v["locus"]["event_type"], v["locus"]["key"])
             for v in res["violations"]])


RUN_MAP = {r["sequence_id"]: r for r in RUN["results"]}
REC_MAP = {r["sequence_id"]: r for r in REC["results"]}
PIN_MAP = {r["sequence_id"]: r for r in PIN["expected"]}
SEQ_MAP = {s["sequence_id"]: s for s in INP["sequences"]}


def codes_of(sid):
    return {v["code"] for v in RUN_MAP[sid]["violations"]}


# ------------------------------------------------------------------ 断言
def a01_synthetic_declared():
    ok = INP.get("_data_source") == "synthetic_hand_constructed"
    decl = INP.get("_zero_data_source_declaration", "")
    ok = ok and "零数据源" in decl and "裁决1" in decl
    ok = ok and RUN.get("_input_data_source") == "synthetic_hand_constructed"
    return ok, "input _data_source=%s；run_output 回显=%s" % (
        INP.get("_data_source"), RUN.get("_input_data_source"))


def a02_static_scan():
    files = pkg_files()
    scanned, hits = [], {}
    for rel in files:
        if rel in SCAN_EXCLUDED:
            continue
        full = os.path.join(_PKG, rel)
        txt = read(full)
        if rel.endswith(".py"):
            txt = strip_comments_and_docstrings(txt)
        h = scan_text_for_forbidden(txt)
        scanned.append(rel)
        if h:
            hits[rel] = h
    detail = ("扫描面=全包域%d件，实扫%d件，排除清单=%s（仅检测器自身，%d条）；命中=%s"
              % (len(files), len(scanned), sorted(SCAN_EXCLUDED), len(SCAN_EXCLUDED), hits or "无"))
    return (not hits) and len(SCAN_EXCLUDED) == 1, detail


def a03_recompute_isolation():
    raw = read(IMPL_SOURCES[1])
    body = strip_comments_and_docstrings(raw)
    banned = ["import state_machine", "from state_machine", "import harness",
              "from harness", "outputs/run_output"]
    bad = [t for t in banned if t in body]
    reads_self = bool(re.search(r"open\([^)]*independent_recompute_output[^)]*\)\s*as[^:]*:\s*\n\s*json\.load", body))
    ok = (not bad) and (not reads_self)
    return ok, "剥离注释后禁用符号命中=%s；自读既往产物=%s；声明面来源=%s" % (
        bad or "无", reads_self, REC.get("_declaration_source"))


def a04_verdict_bitexact():
    bad = [sid for sid in PIN_MAP
           if RUN_MAP[sid]["verdict"] != REC_MAP[sid]["verdict"]]
    return not bad, "20条 verdict 逐条比对，差异=%s（子口径(a)=0 bit-exact）" % (bad or "无")


def a05_violations_bitexact():
    bad = [sid for sid in PIN_MAP if norm(RUN_MAP[sid]) != norm(REC_MAP[sid])]
    return not bad, "violations 逐项(code,t,event_type,key)比对，差异=%s" % (bad or "无")


def a06_three_way_table():
    rows, bad = [], []
    for sid in sorted(PIN_MAP):
        p, r, c = norm(PIN_MAP[sid]), norm(RUN_MAP[sid]), norm(REC_MAP[sid])
        agree = (p == r == c)
        if not agree:
            bad.append(sid)
        rows.append((sid, SEQ_MAP[sid]["class"], p[0],
                     ",".join(x[0] for x in p[1]) or "—",
                     "一致" if agree else "不一致"))
    lines = ["# 三方比对表（钉表 / harness 实跑 / 独立复算）· 脚本程序化产出（W-13(14)）", "",
             "| 序列 | 类 | 钉定 verdict | 钉定违规码 | 三方 |", "|---|---|---|---|---|"]
    lines += ["| %s | %s | %s | %s | %s |" % r for r in rows]
    lines += ["", "三方一致数＝%d/%d" % (len(rows) - len(bad), len(rows))]
    with open(os.path.join(LOG_DIR, "comparison_table.md"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n")
    return not bad, "三方逐值一致 %d/%d；不一致=%s" % (len(rows) - len(bad), len(rows), bad or "无")


def a07_approved_single_entry():
    entries = [t for t in D["allowed_transitions"] if t["to"] == "approved"]
    ok = len(entries) == 1 and entries[0]["guard_decision"] == "approval" \
        and entries[0]["from"] == "candidate"
    killed = codes_of("N14") == {"V02"}
    return ok and killed, "approved 入口数=%d guard=%s；N14 击落码=%s" % (
        len(entries), entries[0]["guard_decision"] if entries else None, codes_of("N14"))


def a08_executed_and_postcheck():
    t_exec = [t for t in D["allowed_transitions"] if t["to"] == "executed"]
    ok = len(t_exec) == 1 and t_exec[0]["from"] == "approved"
    ok = ok and D["mandatory_terminal_for_executed"] == "post_action_checked"
    return ok and codes_of("N01") == {"V03"} and codes_of("N06") == {"V04"}, \
        "executed 入口=%s；N01=%s；N06=%s" % (
            [t["from"] for t in t_exec], codes_of("N01"), codes_of("N06"))


def a09_t13_domain_completeness():
    """O-2：五值域 vs 源文 00A 行71 逐值在场（双向）。"""
    path = find_doc(SOURCE_ANCHORS[2][0])
    if path is None:
        return False, "源文不可及（必装件缺位）：%s" % SOURCE_ANCHORS[2][0]
    line = read(path).split("\n")[70]
    dom = D["governance_decision_domain"]
    tokens = {"approval": "approval", "block": "block",
              "manual_review": "manual review", "rollback": "rollback",
              "identity_drift_declaration": "identity drift declaration"}
    missing = [k for k in dom if tokens[k] not in line]
    extra_in_line = [t for k, t in tokens.items() if k not in dom]
    ok = (not missing) and (not extra_in_line) and len(dom) == 5
    return ok and codes_of("N10") == {"V13"}, \
        "五值域 vs 行71 双向对表：缺=%s 多=%s；越域击落 N10=%s" % (
            missing or "无", extra_in_line or "无", codes_of("N10"))


def a10_execution_confirmation():
    spec = D["execution_confirmation_requirement"]
    ok = spec["required_when_channel"] == "live_execution" \
        and spec["required_field"] == "human_execution_confirmation_ref" \
        and set(spec["channel_domain"]) == {"live_execution", "research_runtime"}
    live_kill = codes_of("N12") == {"V06"}
    research_exempt = RUN_MAP["P5"]["verdict"] == "legal"
    # 保守缺省实证：未知通道不得取得豁免
    from state_machine import ActionLifecycleMachine
    probe = json.loads(json.dumps(SEQ_MAP["P5"]))
    for ev in probe["events"]:
        if ev["type"] == "execution":
            ev["execution_channel"] = "undeclared_channel"
    m = ActionLifecycleMachine(D, INP["_synthetic_test_values"]["verification_period"],
                              INP["reset_target_sets"][INP["active_reset_target_set"]])
    conservative = "V06" in {v["code"] for v in m.run(probe)["violations"]}
    return ok and live_kill and research_exempt and conservative, \
        "live 击落 N12=%s；research 豁免 P5=%s；未知通道保守缺省命中 V06=%s" % (
            codes_of("N12"), RUN_MAP["P5"]["verdict"], conservative)


def a11_forced_liquidation():
    ext = D["external_override"]
    ok = ext["mandatory_consequence"]["event"] == "object_identity_audit" \
        and ext["not_an_authorization_source"] is True \
        and "自动交易授权" in ext["not_an_authorization_source_note"]
    return ok and codes_of("N05") == {"V07"} and RUN_MAP["P3"]["verdict"] == "legal", \
        "强平非授权来源声明=在场；N05 击落=%s；P3 正例=%s" % (
            codes_of("N05"), RUN_MAP["P3"]["verdict"])


def a12_no_action_audit():
    ok = codes_of("N03") == {"V08"} and RUN_MAP["P2"]["verdict"] == "legal"
    period = INP["_synthetic_test_values"]["verification_period"]
    ok = ok and RUN["_verification_period_used"] == period
    return ok, "N03 击落=%s；纯静默 P2=%s；周期实测值回显=%s" % (
        codes_of("N03"), RUN_MAP["P2"]["verdict"], RUN["_verification_period_used"])


def a13_rebasing_no_bypass():
    return codes_of("N07") == {"V09"} and RUN_MAP["P4"]["verdict"] == "legal", \
        "N07 击落=%s；P4 全链正例=%s" % (codes_of("N07"), RUN_MAP["P4"]["verdict"])


def a14_reset_completeness():
    spec = D["rebasing_semantics"]["reset_on_effect"]
    ok = spec["target_cardinality"] == 4 and spec["partial_reset_is_violation"] is True
    ok = ok and len(INP["reset_target_sets"][INP["active_reset_target_set"]]) == 4
    return ok and codes_of("N08") == {"V10"}, \
        "声明基数=%s；实集基数=%s；N08 击落=%s" % (
            spec["target_cardinality"],
            len(INP["reset_target_sets"][INP["active_reset_target_set"]]),
            codes_of("N08"))


def a15_uncalibrated_tristate():
    ok = D["rebasing_semantics"]["uncalibrated_judgment_state"] == "indeterminate"
    ok = ok and "indeterminate" in D["judgment_verdict_domain"]
    return ok and codes_of("N09") == {"V11"}, \
        "未标定态要求 verdict=%s；N09 击落=%s" % (
            D["rebasing_semantics"]["uncalibrated_judgment_state"], codes_of("N09"))


def a16_required_refs():
    refs = D["action_record_required_refs"]
    ok = len(refs) == 5 and set(refs) == {
        "pre_state_legality_ref", "candidate_ref", "decision_ref",
        "post_state_legality_ref", "identity_verification_ref"}
    src = D["action_record_required_refs_source"]
    ok = ok and "1020-1024" in src
    return ok and codes_of("N02") == {"V05"}, \
        "五 ref 集=%d项；源文投影指针=%s；N02 击落=%s" % (len(refs), "在场" if ok else "缺", codes_of("N02"))


def a17_a9_seventh_dim():
    key = D["position_ref_coordinate_key"]
    ok = key["field"] == "instrument_type" and key["domain"] == ["linear", "option"]
    ok = ok and "同名同值域" in key["reference_form"]
    used = set()
    for s in INP["sequences"]:
        for ev in s["events"]:
            pr = ev.get("position_ref") or {}
            if pr.get("instrument_type"):
                used.add(pr["instrument_type"])
    in_domain = used - {"future"}
    ok = ok and in_domain <= set(key["domain"])
    return ok and codes_of("N11") == {"V14"}, \
        "字段名=%s 值域=%s；input 实用值=%s；N11 越域击落=%s" % (
            key["field"], key["domain"], sorted(used), codes_of("N11"))


def a18_slots_zero_value():
    slots = D["parameter_slots"]
    ok = all(s["form"] == "parameter_slot_candidate" and s["value"] is None for s in slots)
    binding = INP["slot_symbol_binding"]
    ok = ok and all(binding[s["slot_symbol"]]["authoritative_value"] is None for s in slots)
    ok = ok and binding["recalibration_window_length"]["synthetic_test_value"] is None
    isolated = "_synthetic_test_values" in INP and \
        INP["_synthetic_test_values"]["verification_period"] == 5
    zero_consume = "recalibration_window_length" not in IMPL_BODY
    return ok and isolated and zero_consume, \
        "槽位%d枚权威值全 null；人造测试值隔离=%s；重标窗口期阶段A零消费=%s" % (
            len(slots), isolated, zero_consume)


def a19_declaration_role_table():
    """F-4／F-17转-3：声明面键角色三分之双向对表（检多不止检缺）。"""
    roles = D["_key_roles"]
    nonmeta = {k for k in D if not k.startswith("_")}
    miss = sorted(nonmeta - set(roles))
    extra = sorted(set(roles) - nonmeta)
    self_src = read(os.path.abspath(__file__))
    bad = []
    for k, role in roles.items():
        pat = '"%s"' % k
        if role == "impl" and pat not in IMPL_BODY:
            bad.append((k, "impl 未被实现侧解析"))
        if role == "assert" and pat not in self_src:
            bad.append((k, "assert 未被断言侧解析"))
        if role == "registry" and k not in SCHEMA_TXT:
            bad.append((k, "registry 未在 schema 成文"))
    ok = (not miss) and (not extra) and (not bad)
    return ok, "非meta键=%d 角色表=%d 缺=%s 多=%s 落空=%s" % (
        len(nonmeta), len(roles), miss or "无", extra or "无", bad or "无")


def a20_reading_agnostic():
    """C10条2 机制对同族值集成员身份不敏感之实证（支撑 TPL2-W1-02 呈KD）。"""
    from harness import run_all
    alt = run_all(reset_set_key="reading_ii")
    a = {r["sequence_id"]: norm(r) for r in RUN["results"]}
    b = {r["sequence_id"]: norm(r) for r in alt["results"]}
    # reading_ii 下，input 内实际写入的 reset_targets 为 reading_i 成员，
    # 故 P4/N09 之完整重置将变为「集合不等」→ 机制仍然按声明集判定：
    diff = sorted(k for k in a if a[k] != b[k])
    mechanism_reacts = set(diff) >= {"P4", "N09"}
    return mechanism_reacts, ("换用 reading_ii 声明集后判定变化序列=%s；"
                              "证机制以**声明集**为准而非以成员字面为准（读法无关性）" % diff)


def a21_output_closure():
    form = D["output_form"]
    top = set(RUN.keys())
    declared_top = {"_produced_by", "_input_data_source", "_verification_period_used",
                    "_reset_target_set_used", "_reset_targets_used",
                    "_declaration_version_used", "_sequence_count", "results"}
    ok = top == declared_top
    for r in RUN["results"]:
        if set(r.keys()) != set(form["per_sequence"]):
            ok = False
        for v in r["violations"]:
            if set(v.keys()) != set(form["violation_item_fields"]):
                ok = False
            if set(v["locus"].keys()) != {"t", "event_type", "key"}:
                ok = False
    # 违规码封闭：实产码 ⊆ 声明码
    declared_codes = {c["code"] for c in D["violation_codes"]}
    produced = {v["code"] for r in RUN["results"] for v in r["violations"]}
    ok = ok and produced <= declared_codes
    # locus 规则对表
    lr = D["locus_rule"]
    bad_locus = []
    for r in RUN["results"]:
        for v in r["violations"]:
            rule = lr.get(v["code"], "")
            if v["code"] not in ("V08",) and not rule.startswith(v["locus"]["event_type"]):
                bad_locus.append((r["sequence_id"], v["code"]))
    ok = ok and not bad_locus
    return ok, "顶层键集封闭=%s；实产码%d/声明码%d；locus 规则不符=%s" % (
        top == declared_top, len(produced), len(declared_codes), bad_locus or "无")


def a22_negative_statement_crosstable():
    path = find_doc(TASKPACK)
    if path is None:
        return False, "任务包不可及（W-19① 可及面义务未满足）：%s" % TASKPACK
    lines = read(path).split("\n")
    s = [i for i, l in enumerate(lines) if l.startswith("## §4")][0]
    e = [i for i, l in enumerate(lines) if l.startswith("## §5")][0]
    keys = []
    for l in lines[s:e]:
        m = re.match(r"^- \*\*(.+?)\*\*", l.strip())
        if m:
            keys.append(m.group(1))
    tbl = SCHEMA_TXT.split("### 9.1")[1].split("\n---\n")[0]
    miss = [k for k in keys if ("| %s |" % k) not in tbl]
    rows = re.findall(r"^\| (.+?) \| ", tbl, re.M)
    rows = [r for r in rows if r not in ("任务包 §4 条目",) and not set(r) <= set("-")]
    extra = [r for r in rows if r not in keys]
    return (not miss) and (not extra), \
        "任务包§4条目=%d；§9.1 覆盖缺=%s 多=%s" % (len(keys), miss or "无", extra or "无")


def a23_l2_completeness():
    """F-18 四项。"""
    detail = []
    ok = True
    # ① 源文行号指针可解析且字面在场
    bad = []
    for fname, ln, token in SOURCE_ANCHORS:
        p = find_doc(fname)
        if p is None:
            bad.append((fname, ln, "文件不可及"))
            continue
        lines = read(p).split("\n")
        if ln > len(lines) or token not in lines[ln - 1]:
            bad.append((fname, ln, token))
    ok = ok and not bad
    detail.append("①源文锚 %d/%d 命中，缺=%s" % (len(SOURCE_ANCHORS) - len(bad),
                                              len(SOURCE_ANCHORS), bad or "无"))
    # ② 三分归属逐条回引受控文本条款号
    sec = SCHEMA_TXT.split("## §10")[1].split("## §11")[0]
    rows = re.findall(r"^\| (C-\d+) \|", sec, re.M)
    no_ref = [r for r in rows
              if not re.search(r"\| %s \|[^|]*\|[^|]*\|[^|]*§" % re.escape(r), sec)]
    ok = ok and len(rows) >= 15 and not no_ref
    detail.append("②三分条目=%d，缺回引=%s" % (len(rows), no_ref or "无"))
    # ③ 审计表行状态／未审引用标注在场
    has_audit = "已审" in SCHEMA_TXT and "未审引用" in SCHEMA_TXT and "C4④" in SCHEMA_TXT
    ok = ok and has_audit
    detail.append("③审计表状态/未审引用标注=%s" % ("在场" if has_audit else "缺"))
    # ④ 思想层一手材料三件并联（本根不触发之显式声明）
    has_decl = "思想层一手材料三件并联" in SCHEMA_TXT and "不触发" in SCHEMA_TXT
    ok = ok and has_decl
    detail.append("④三件并联适用性声明=%s" % ("在场" if has_decl else "缺"))
    return ok, "；".join(detail)


def a24_double_pin():
    rc = PROV.verify()
    doc = json.loads(read(os.path.join(_HERE, "provenance.json")))
    self_ok = doc["_self_manifest_digest"] == PROV.self_digest(doc["entries"])
    decl_ok = "SHA256" in SCHEMA_TXT and "双钉" in SCHEMA_TXT
    return rc == 0 and self_ok and decl_ok, \
        "指纹双向对表 rc=%d；钉定件自摘要自洽=%s；schema 声明面=%s" % (
            rc, self_ok, "在场" if decl_ok else "缺")


def a25_package_closure():
    files = set(pkg_files())
    sec = SCHEMA_TXT.split("## §13")[1].split("## §14")[0]
    declared = set(re.findall(r"`([^`]+)`", sec))
    declared = {d for d in declared if "/" in d}
    concrete = {d for d in declared if not d.endswith("*")}
    miss = sorted(concrete - files)
    globs = [d for d in declared if d.endswith("*")]
    covered = set(concrete)
    for g in globs:
        pre = g[:-1]
        covered |= {f for f in files if f.startswith(pre)}
    extra = sorted(files - covered)
    return (not miss) and (not extra), \
        "全包域%d件；清单声明缺=%s 多（检多）=%s" % (len(files), miss or "无", extra or "无")


def a26_status_header_scan():
    bad_name = [f for f in pkg_files() if "_candidate_" in f]
    schema_head = SCHEMA_TXT.split("\n")[0:12]
    has_status = any("呈报态" in l for l in schema_head)
    has_identity = any("会话身份" in l for l in schema_head)
    return (not bad_name) and has_status and has_identity, \
        "candidate 文件名=%s；状态头=%s；身份头=%s" % (
            bad_name or "无", has_status, has_identity)


def a27_pin_order_three_places():
    a = "先钉表后跑数" in SCHEMA_TXT
    b = "先于 harness 首次实跑" in read(os.path.abspath(__file__))
    c = "先钉表后跑数" in read(PIN_JSON) or "先于" in read(PIN_JSON)
    return a and b and c, "三处文字声明：schema=%s 断言脚本=%s 钉表件=%s（切片记录为第三处之文书载体）" % (a, b, c)


def a28_echo_from_runtime():
    """F-15⑥：回显字段取自实际执行路径返回值，非同名常量。"""
    from harness import run_all
    live = run_all()
    ok = (live["_verification_period_used"] == RUN["_verification_period_used"]
          and live["_reset_targets_used"] == RUN["_reset_targets_used"]
          and live["_declaration_version_used"] == D["_declaration_version"]
          and live["_sequence_count"] == len(INP["sequences"]))
    same = all(norm(a) == norm(b) for a, b in zip(live["results"], RUN["results"]))
    return ok and same, "重入 run_all 返回值与交付产物逐字段一致=%s；判定逐条一致=%s" % (ok, same)


def a29_purity_self_scan():
    self_src = read(os.path.abspath(__file__))
    scope = "本脚本自扫描射程＝**字面层**" in self_src
    # 判据面不得含对具体判定结论之阈值化断言（本根无数值面）
    numeric = re.findall(r"[<>]=?\s*\d+\.\d+", self_src)
    return scope and not numeric, "射程声明=%s；数值阈值断言=%s" % (
        "在场" if scope else "缺", numeric or "无")


def a30_layer_declared():
    undeclared = [aid for aid, layer, _, _ in ASSERTIONS if layer not in
                  ("字面层", "语义层-机械前哨")]
    return not undeclared, "断言%d条，层次未声明=%s" % (len(ASSERTIONS), undeclared or "无")


def a31_domain_and_set_closure():
    """消费 assert 角色声明键：状态集/终止集/事件类型集/值域/声明值接收项。"""
    detail, ok = [], True
    states = set(D["action_states"])
    used = {t["from"] for t in D["allowed_transitions"]} | \
           {t["to"] for t in D["allowed_transitions"]}
    used.discard("__none__")
    ok = ok and used <= states and states >= used
    detail.append("状态集%d ⊇ 转移表实用%d=%s" % (len(states), len(used), used <= states))

    terms = set(D["terminal_states"])
    outgoing = {t["from"] for t in D["allowed_transitions"]}
    ok = ok and not (terms & outgoing)
    detail.append("终止态无出边=%s" % (not (terms & outgoing)))

    declared_ev = {e["name"] for e in D["event_types"]}
    input_ev = {ev["type"] for s in INP["sequences"] for ev in s["events"]}
    ok = ok and declared_ev == input_ev
    detail.append("事件类型声明%d vs input实用%d 双向=%s" % (
        len(declared_ev), len(input_ev), declared_ev == input_ev))

    trig = set(D["identity_audit_trigger_domain"])
    outc = set(D["identity_audit_outcome_domain"])
    used_t = {ev.get("trigger") for s in INP["sequences"] for ev in s["events"]
              if ev["type"] == "object_identity_audit"}
    used_o = {ev.get("outcome") for s in INP["sequences"] for ev in s["events"]
              if ev["type"] == "object_identity_audit"}
    ok = ok and used_t <= trig and used_o <= outc
    detail.append("identity audit trigger/outcome 值域闭合=%s" % (used_t <= trig and used_o <= outc))

    dvr = D["declared_value_receipt_only"]
    ok = ok and set(dvr) <= set(D["action_record_required_refs"])
    leak = [k for k in dvr if IMPL_BODY.count(k) > 0]
    ok = ok and not leak
    detail.append("声明值接收项%d项仅经必填集核在场；实现侧字面泄漏=%s（C3 乙禁建机械守卫）"
                  % (len(dvr), leak or "无"))
    return ok, "；".join(detail)


ASSERTIONS = [
    ("A01", "字面层", "step0(i) 人造 input 声明在场", a01_synthetic_declared),
    ("A02", "语义层-机械前哨", "step0(ii) 全包域数据源静态扫描（F-1 现行权威扫描集）", a02_static_scan),
    ("A03", "字面层", "step0(iii) 独立复算路径隔离（F-8 独立性封闭）", a03_recompute_isolation),
    ("A04", "字面层", "verdict 逐序列 bit-exact（子口径(a)=0）", a04_verdict_bitexact),
    ("A05", "字面层", "violations 逐项(code,locus三字段) 精确一致（F-17转-4）", a05_violations_bitexact),
    ("A06", "字面层", "钉表/实跑/复算 三方程序化对表（F-15⑧、W-13(14)）", a06_three_way_table),
    ("A07", "字面层", "approved 唯一入口（C2① 边界级）＋N14 击落", a07_approved_single_entry),
    ("A08", "字面层", "executed 仅出自 approved ＋ post-action check 强制（C2①）", a08_executed_and_postcheck),
    ("A09", "字面层", "T-13 五值域 vs 源文行71 双向对表（O-2 完备性）", a09_t13_domain_completeness),
    ("A10", "字面层", "执行确认权引用要件（O-3；含 research 豁免与保守缺省）", a10_execution_confirmation),
    ("A11", "字面层", "强平⇒identity audit 强制（C2④）＋非授权来源声明", a11_forced_liquidation),
    ("A12", "字面层", "no-action 周期审计条件（C2③）", a12_no_action_audit),
    ("A13", "字面层", "换装不得旁路生命周期（C10条1）", a13_rebasing_no_bypass),
    ("A14", "字面层", "换装联动重置完备性（C10条2）", a14_reset_completeness),
    ("A15", "字面层", "未标定态三态输出（C10条3）", a15_uncalibrated_tristate),
    ("A16", "字面层", "动作记录必填五 ref 在场性（C2②）", a16_required_refs),
    ("A17", "字面层", "A9 第七维 instrument_type 同名同值域＋值域封闭", a17_a9_seventh_dim),
    ("A18", "字面层", "槽位零赋值＋人造测试值隔离（C15）", a18_slots_zero_value),
    ("A19", "字面层", "声明面键角色三分双向对表（F-4／F-17转-3）", a19_declaration_role_table),
    ("A20", "字面层", "重置机制以声明集为准之读法无关性实证", a20_reading_agnostic),
    ("A21", "字面层", "输出形态封闭＋违规码封闭＋locus 规则对表", a21_output_closure),
    ("A22", "字面层", "反面陈述段 vs 任务包§4 逐条机械对表（F-13）", a22_negative_statement_crosstable),
    ("A23", "语义层-机械前哨", "F-18 L2 完整性四项", a23_l2_completeness),
    ("A24", "字面层", "F-5／F-8 双钉与指纹双向对表", a24_double_pin),
    ("A25", "字面层", "F-7 包完整性封闭（检多不止检缺）", a25_package_closure),
    ("A26", "字面层", "状态头/身份头扫描（F-15④、乙-9）", a26_status_header_scan),
    ("A27", "字面层", "F-10 钉表构造顺序三处声明一致", a27_pin_order_three_places),
    ("A28", "字面层", "F-15⑥ 回显字段取自实际执行路径返回值", a28_echo_from_runtime),
    ("A29", "字面层", "判据面纯净性自扫描＋射程声明（DOC-35③）", a29_purity_self_scan),
    ("A30", "字面层", "F-3 判据可检层次逐条声明", a30_layer_declared),
    ("A31", "字面层", "声明面域与集合闭合（状态/终止/事件/值域/声明值接收）", a31_domain_and_set_closure),
]


def main():
    if not os.path.isdir(LOG_DIR):
        os.makedirs(LOG_DIR)
    lines = []
    failed = []
    for aid, layer, desc, fn in ASSERTIONS:
        try:
            ok, detail = fn()
        except Exception as exc:  # 异常即失败，归因为该断言
            ok, detail = False, "异常：%r" % (exc,)
        tag = "PASS" if ok else "FAIL"
        lines.append("[%s] %s (%s) %s | %s" % (tag, aid, layer, desc, detail))
        print(lines[-1])
        if not ok:
            failed.append(aid)
    lines.append("")
    lines.append("总计 %d 条；PASS %d；FAIL %d %s"
                 % (len(ASSERTIONS), len(ASSERTIONS) - len(failed), len(failed),
                    failed or ""))
    with open(os.path.join(LOG_DIR, "assert_log.txt"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n")
    print(lines[-1])
    if failed:
        print("[assert_check] 失败断言：%s" % ", ".join(failed))
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())

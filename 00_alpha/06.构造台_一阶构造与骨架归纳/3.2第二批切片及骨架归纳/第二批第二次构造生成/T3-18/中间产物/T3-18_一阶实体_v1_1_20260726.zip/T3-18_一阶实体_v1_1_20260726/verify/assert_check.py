#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
verify/assert_check.py · T3-18 · v1.1 · 20260726 · 模板三D段合格断言（step0 前置 + 数值比对 + 附加断言）

v1.1 修复（裁决31-C缺陷回传，单一修复动作；cp-then-edit 自 v1.0）：
  (b) 新增逐评估点期望三元组静态钉表（EXPECTED_TRIPLES）＋逐点断言 14 项＋点集前置断言 1 项；
      期望值自源文语义人工推导，静态字面量，不取自 harness 输出、不由第三实现路径推算。
  (c) 断言基线解析段由"关键词在场"升为"公式结构可判"：新增
      check_source_formula_structure_vs_impl，自源文行 609 抽取减法项序与符号向量，
      与 harness 实现侧 (符号, 字段) 序列逐位比对（顺序敏感）。
      原 check_source_anchor_line609（关键词在场，锚定槽位/聚合语义）保留不删——"升为"取
      "增补结构判别力"读法，不减损既有覆盖面；若 KD 认取"替换"读法，本项待裁（见修复会话呈报）。
  (a) 之 input 扩充见 entity/ledger_input.json（t=13..17，本文件不涉）。
  断言项数按 KD 裁定"丙"式分列：原 11 项 ＋ 修复新增 16 项 ＝ 27 项。

纪律绑定：
  - 非零退出码（裁决28-B(ii)判据(ii)，裁决30-A溯及本存量包）：任一断言未过，本脚本以非零退出码结束。
  - 断言基线须程序化解析源文（裁决28-B判据(i)，包§1.5既有条款）：本脚本独立读取并正则解析
    3_波动率凸性操作方法论主文档 源文件第609行，不复用 harness 转录/中间量，作为公式结构断言基线。
  - 整体判定归因文案不写死单一失败原因（W-9(3)）：逐条[PASS]/[FAIL]按实际断言结果输出。
  - step0(ii) 静态扫描口径按手册§3.1 W-5/W-8三部分（剥离注释/docstring后判定，W-8(c)）。
"""
import json
import os
import re
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
REPO_ROOT = os.path.dirname(HERE)
ENTITY_DIR = os.path.join(REPO_ROOT, "entity")
SOURCE_DOC = os.path.join(REPO_ROOT, "3_波动率凸性操作方法论主文档_T0_frozen_clean_20260615.md")
HARNESS_PATH = os.path.join(ENTITY_DIR, "harness.py")
HARNESS_OUTPUT = os.path.join(ENTITY_DIR, "harness_output.json")
INDEP_SCRIPT = os.path.join(HERE, "independent_recompute.py")
SCHEMA_PATH = os.path.join(ENTITY_DIR, "input_schema.md")

passes = []
failures = []


def record(name, ok, detail=""):
    (passes if ok else failures).append((name, detail))
    return ok


# ---------- step0(i)：input 确为人造 ----------
def check_step0_i_input_synthetic():
    input_path = os.path.join(ENTITY_DIR, "ledger_input.json")
    with open(input_path, "r", encoding="utf-8") as f:
        data = json.load(f)
    ok = data.get("_data_source") == "synthetic_hand_constructed"
    return record("step0(i)_input_synthetic", ok, f"_data_source={data.get('_data_source')!r}")


# ---------- step0(ii)：harness 全程无数据源接入（静态扫描，手册§3.1 W-5/W-8三部分口径） ----------
FORBIDDEN_IMPORT_RE = re.compile(
    r'^\s*(import\s+(requests|urllib|socket|yfinance|ibapi|ib_insync|pandas_datareader)\b'
    r'|from\s+(requests|urllib|socket|yfinance|ibapi|ib_insync|pandas_datareader)\b)',
    re.MULTILINE,
)
FORBIDDEN_KEYWORD_RE = re.compile(r'IBKR|QuantConnect|http://|https://|urlopen|requests\.|socket\.')


def strip_comments_and_docstrings(src):
    """W-8(c)：判定在剥离注释/docstring后的文本上执行；剥离前命中仅留痕展示，不作否决依据。"""
    no_triple = re.sub(r'("""[\s\S]*?"""|\'\'\'[\s\S]*?\'\'\')', '', src)
    no_comment = re.sub(r'#.*$', '', no_triple, flags=re.MULTILINE)
    return no_comment


def check_step0_ii_no_data_source():
    with open(HARNESS_PATH, "r", encoding="utf-8") as f:
        raw = f.read()
    stripped = strip_comments_and_docstrings(raw)
    import_hits = FORBIDDEN_IMPORT_RE.findall(stripped)
    keyword_hits = FORBIDDEN_KEYWORD_RE.findall(stripped)
    raw_only = []
    if FORBIDDEN_IMPORT_RE.search(raw) and not FORBIDDEN_IMPORT_RE.search(stripped):
        raw_only.append("import(剥离前命中·留痕非否决)")
    if FORBIDDEN_KEYWORD_RE.search(raw) and not FORBIDDEN_KEYWORD_RE.search(stripped):
        raw_only.append("keyword(剥离前命中·留痕非否决)")
    ok = (len(import_hits) == 0) and (len(keyword_hits) == 0)
    detail = f"剥离后import命中={import_hits} 剥离后keyword命中={keyword_hits} 留痕={raw_only}"
    return record("step0(ii)_no_data_source_static_scan", ok, detail)


# ---------- step0(iii)：独立复算不取 harness 中间量/数据源派生量 ----------
def check_step0_iii_independent_path():
    """判定须在剥离注释/docstring后的文本上执行（同W-8(c)口径）——否则本脚本自身文档字符串中
    "不读取 harness_output.json" 的说明性文本会被朴素子串匹配误判为真实读取行为（自查中发现，留痕于
    切片记录"检验通道记录"）。剥离前命中仅作留痕展示，不作否决依据。"""
    with open(INDEP_SCRIPT, "r", encoding="utf-8") as f:
        raw = f.read()
    stripped = strip_comments_and_docstrings(raw)
    imports_harness = bool(re.search(r'^\s*(import\s+harness|from\s+harness)', stripped, re.MULTILINE))
    reads_harness_output = "harness_output.json" in stripped
    raw_only = []
    if ("harness_output.json" in raw) and ("harness_output.json" not in stripped):
        raw_only.append("harness_output.json字样(仅见于剥离前/注释docstring内·留痕非否决)")
    ok = (not imports_harness) and (not reads_harness_output)
    return record(
        "step0(iii)_independent_recompute_no_harness_reuse", ok,
        f"剥离后imports_harness={imports_harness} 剥离后reads_harness_output_json={reads_harness_output} 留痕={raw_only}",
    )


# ---------- 断言基线程序化解析源文（裁决28-B判据(i)） ----------
def check_source_anchor_line609():
    with open(SOURCE_DOC, "r", encoding="utf-8") as f:
        lines = f.readlines()
    line609 = lines[608] if len(lines) >= 609 else ""  # 0-indexed -> 第609行
    required_terms = [
        "funding gap", "short-end premium income", "long-end premium bleed", "roll cost",
        "滚动窗口", "累计", "parameter_slot_candidate",
        "funding_gap_window", "funding_gap_persistence_shape",
    ]
    missing = [t for t in required_terms if t not in line609]
    ok = (len(missing) == 0)
    return record("source_anchor_T3_line609_programmatic_parse", ok,
                   f"missing_terms={missing} line_len={len(line609)}")


# ---------- (c) 断言基线解析段升级：公式结构可判（裁决31-C(c)） ----------
# v1.0 该段仅核验 9 个关键词"在场"，对"实现里的公式是否等于源文的公式"零约束
# （外审 C1：两侧 roll_cost 符号同翻仍全绿）。v1.1 升级为结构可判：
#   ① 自源文行 609「funding gap（…）」括号内容按 U+2212 MINUS SIGN 切分，得减法项序与符号向量；
#      注意：切分字符限 U+2212，不含 "short-end"/"long-end" 内的 U+002D HYPHEN；
#   ② 自 harness.py 之 compute_gap_series 函数体抽取赋值表达式，得实现侧 (符号, 字段) 序列；
#   ③ 逐位比对 符号 与 项序对应关系（顺序敏感），任一不符即 FAIL。
MINUS_SIGN = "\u2212"


def parse_source_formula_symbol_vector(line609):
    """自源文抽取减法项序与符号向量。返回 (terms, signs)。"""
    m = re.search(r'funding gap\s*（([^）]*)）', line609)
    if not m:
        return None, None
    parts = [p.strip() for p in m.group(1).split(MINUS_SIGN)]
    if len(parts) < 2 or any(p == "" for p in parts):
        return None, None
    signs = [1] + [-1] * (len(parts) - 1)
    return parts, signs


def parse_impl_formula_symbol_vector(harness_src):
    """自 harness.compute_gap_series 抽取实现侧 (符号, 字段) 序列。"""
    fm = re.search(r'def\s+compute_gap_series\s*\([^)]*\):(.*?)(?=\ndef\s|\Z)', harness_src, re.S)
    if not fm:
        return None, None
    body = fm.group(1)
    am = re.search(r'^\s*g\s*=\s*(.+)$', body, re.M)
    if not am:
        return None, None
    expr = am.group(1)
    tokens = re.findall(r'([+\-])?\s*p\[\s*"([A-Za-z0-9_]+)"\s*\]', expr)
    if not tokens:
        return None, None
    fields = [t[1] for t in tokens]
    signs = [(-1 if t[0] == "-" else 1) for t in tokens]
    return fields, signs


def _field_stem(field_name):
    """income_cents -> 'income'；roll_cost_cents -> 'roll cost'（供与源文术语作对应核验）"""
    return field_name[:-6].replace("_", " ") if field_name.endswith("_cents") else field_name.replace("_", " ")


def check_source_formula_structure_vs_impl():
    with open(SOURCE_DOC, "r", encoding="utf-8") as f:
        lines = f.readlines()
    line609 = lines[608] if len(lines) >= 609 else ""
    src_terms, src_signs = parse_source_formula_symbol_vector(line609)
    with open(HARNESS_PATH, "r", encoding="utf-8") as f:
        harness_src = f.read()
    impl_fields, impl_signs = parse_impl_formula_symbol_vector(harness_src)

    if src_terms is None or impl_fields is None:
        return record("source_formula_structure_vs_impl_symbol_vector", False,
                       f"解析失败 src_terms={src_terms} impl_fields={impl_fields}"
                       "（解析失败即判不合格，不静默跳过——同变异注入'命中失败即报'口径）")

    arity_ok = (len(src_terms) == len(impl_fields))
    sign_ok = arity_ok and (src_signs == impl_signs)
    # 项序对应：第 i 位实现字段之词干须出现于第 i 位源文术语内（顺序敏感）
    order_ok = arity_ok and all(
        _field_stem(impl_fields[i]).lower() in src_terms[i].lower() for i in range(len(src_terms))
    )
    ok = arity_ok and sign_ok and order_ok
    return record(
        "source_formula_structure_vs_impl_symbol_vector", ok,
        f"源文项序={src_terms} 源文符号向量={src_signs} | 实现字段序={impl_fields} 实现符号向量={impl_signs} "
        f"| arity={arity_ok} signs={sign_ok} order={order_ok}",
    )


# ---------- B：真跑 harness（裁决1"真跑出数"，非纸面推演） ----------
def run_harness():
    result = subprocess.run([sys.executable, HARNESS_PATH], cwd=ENTITY_DIR,
                             capture_output=True, text=True)
    ok = (result.returncode == 0) and os.path.exists(HARNESS_OUTPUT)
    return record("harness_real_run", ok,
                   f"returncode={result.returncode} stdout={result.stdout.strip()!r} stderr={result.stderr[:300]!r}")


# ---------- D段②：独立复算数值比对（子口径(a)=0 bit-exact，全程整数运算） ----------
def run_independent_and_compare():
    result = subprocess.run([sys.executable, INDEP_SCRIPT], cwd=HERE,
                             capture_output=True, text=True)
    if result.returncode != 0:
        return record("independent_recompute_run", False,
                       f"returncode={result.returncode} stderr={result.stderr[:300]!r}")
    record("independent_recompute_run", True, "独立复算脚本真跑成功")

    indep = json.loads(result.stdout)
    with open(HARNESS_OUTPUT, "r", encoding="utf-8") as f:
        harness_out = json.load(f)

    gap_match = (harness_out["gap_series_cents"] == indep["gap_series_cents"])
    record("numeric_compare_gap_series_bit_exact_a0", gap_match,
           f"harness={harness_out['gap_series_cents']} indep={indep['gap_series_cents']}")

    cum_match = (harness_out["cum_gap_cents"] == indep["cum_gap_cents"])
    record("numeric_compare_cum_gap_bit_exact_a0", cum_match,
           f"harness={harness_out['cum_gap_cents']} indep={indep['cum_gap_cents']}")

    shape_match = (harness_out["shape_evaluation"] == indep["shape_evaluation"])
    record("numeric_compare_shape_evaluation_bit_exact_a0", shape_match,
           f"harness={harness_out['shape_evaluation']} indep={indep['shape_evaluation']}")

    return gap_match and cum_match and shape_match


# ---------- D段③附加断言：判据覆盖——三分支齐备（历史不足/触发/未触发） ----------
def check_shape_branch_coverage():
    with open(HARNESS_OUTPUT, "r", encoding="utf-8") as f:
        out = json.load(f)
    shape = out["shape_evaluation"]
    has_none = any(v is None for v in shape.values())
    has_true = any((v is not None and v["destructive_form"] is True) for v in shape.values())
    has_false = any((v is not None and v["destructive_form"] is False) for v in shape.values())
    ok = has_none and has_true and has_false
    return record("branch_coverage_insufficient_history_trigger_nontrigger", ok,
                   f"has_insufficient_history={has_none} has_destructive_true={has_true} has_destructive_false={has_false}")


# ---------- D段③附加断言：实体制品须携带 C-6标记 / P_B引用 / _data_source 字段（包§7强制） ----------
def check_entity_carries_required_annotations():
    with open(SCHEMA_PATH, "r", encoding="utf-8") as f:
        schema_text = f.read()
    has_c6 = "C-6" in schema_text
    has_pb = ("P_B" in schema_text) and ("要件4" in schema_text or "P_B注册记录" in schema_text)
    has_data_source_field = ("_data_source" in schema_text) and ("synthetic_hand_constructed" in schema_text)
    ok = has_c6 and has_pb and has_data_source_field
    return record("entity_carries_C6_PB_reference_and_data_source_field", ok,
                   f"has_C6标记={has_c6} has_P_B要件4引用={has_pb} has_data_source字段声明={has_data_source_field}")


# ---------- (b) 逐评估点期望三元组静态钉表（裁决31-C(b)） ----------
# 独立推导声明（31-C(b)："期望值须自源文语义独立推导，不得取自harness输出"；
#   四-1 D段②路径独立："新增断言之期望值推导路径不得复用harness实现"）：
#   本表为**静态字面量**，非任何运行期计算产物；不 import harness、不读 harness_output.json 生成，
#   亦不由本文件内任何第三实现路径推算——若由第三实现推算，则该实现与 harness/复算共享同一
#   操作化选择时，协同变异仍可同步逃逸（外审 C3/C4/C5/C6 之根因，见裁决31-F）。静态钉表是
#   对"两侧同源设计错误"的唯一有效防线。
#
# 推导链（人工算术，逐步留痕，可离机复核）：
#   ① gap_t = income_t − bleed_t − roll_cost_t（源文行609括号内减法项序）
#      t1..t17 = 20, 5, −10, −25, −40, −50, −55, −55, −50, −40, −25, −10, 75, −140, 35, −30, 85
#   ② cum_gap_t = Σ gap[t−3..t]（源文"滚动窗口内累计"，W = funding_gap_window 桩值 4；首个可算 t=4）
#      t4=−10  t5=−70  t6=−125 t7=−170 t8=−200 t9=−210 t10=−200
#      t11=−170 t12=−125 t13=0  t14=−100 t15=−40 t16=−60 t17=−50
#   ③ 破坏形态（源文"累计gap呈持续性负值且斜率不收敛超过槽位窗口"，本根已裁操作化＝
#      切片记录裁定登记#3／entity/input_schema.md §4③，类三候选、待Phase B证伪）：
#      PN = 窗口{t−2,t−1,t} 之 cum 值全部严格低于 baseline(0)
#      delta = cum[t] − cum[t−2]（persistence 窗口两端点割线，除法经移项消去）
#      SN = delta ≤ slope_threshold(0)；DF = PN ∧ SN；窗口内任一 cum 缺失 → 不可判(None)
#      t6  {−10,−70,−125}   PN=T  delta=−115 SN=T  DF=T
#      t7  {−70,−125,−170}  PN=T  delta=−100 SN=T  DF=T
#      t8  {−125,−170,−200} PN=T  delta=−75  SN=T  DF=T
#      t9  {−170,−200,−210} PN=T  delta=−40  SN=T  DF=T
#      t10 {−200,−210,−200} PN=T  delta=0    SN=T  DF=T   ← delta == slope_threshold 边界
#      t11 {−210,−200,−170} PN=T  delta=40   SN=F  DF=F
#      t12 {−200,−170,−125} PN=T  delta=75   SN=F  DF=F
#      t13 {−170,−125,0}    PN=F  delta=170  SN=F  DF=F   ← cum == baseline 边界（v1.1新增）
#      t14 {−125,0,−100}    PN=F  delta=25   SN=F  DF=F   （v1.1新增）
#      t15 {0,−100,−40}     PN=F  delta=−40  SN=T  DF=F   （v1.1新增）
#      t16 {−100,−40,−60}   PN=T  delta=40   SN=F  DF=F   （v1.1新增）
#      t17 {−40,−60,−50}    PN=T  delta=−10  SN=T  DF=T   （v1.1新增）
#   ④ delta 值本身不入钉表——31-C(b) 字面限 persistent_negative／slope_nonconvergent／
#      destructive_form 三元组，不扩项。
EXPECTED_TRIPLES = {
    4:  None,
    5:  None,
    6:  {"persistent_negative": True,  "slope_nonconvergent": True,  "destructive_form": True},
    7:  {"persistent_negative": True,  "slope_nonconvergent": True,  "destructive_form": True},
    8:  {"persistent_negative": True,  "slope_nonconvergent": True,  "destructive_form": True},
    9:  {"persistent_negative": True,  "slope_nonconvergent": True,  "destructive_form": True},
    10: {"persistent_negative": True,  "slope_nonconvergent": True,  "destructive_form": True},
    11: {"persistent_negative": True,  "slope_nonconvergent": False, "destructive_form": False},
    12: {"persistent_negative": True,  "slope_nonconvergent": False, "destructive_form": False},
    13: {"persistent_negative": False, "slope_nonconvergent": False, "destructive_form": False},
    14: {"persistent_negative": False, "slope_nonconvergent": False, "destructive_form": False},
    15: {"persistent_negative": False, "slope_nonconvergent": True,  "destructive_form": False},
    16: {"persistent_negative": True,  "slope_nonconvergent": False, "destructive_form": False},
    17: {"persistent_negative": True,  "slope_nonconvergent": True,  "destructive_form": True},
}

TRIPLE_KEYS = ("persistent_negative", "slope_nonconvergent", "destructive_form")


def check_expected_evaluation_point_set():
    """(b) 之机械前置：评估点集合须与钉表键集一致（否则"逐评估点"无定义域）。"""
    with open(HARNESS_OUTPUT, "r", encoding="utf-8") as f:
        out = json.load(f)
    actual = sorted(int(k) for k in out["shape_evaluation"].keys())
    expected = sorted(EXPECTED_TRIPLES.keys())
    ok = (actual == expected)
    return record("expected_evaluation_point_set", ok,
                   f"expected={expected} actual={actual}")


def check_expected_triples_per_point():
    """(b) 逐评估点钉住三元组期望值——静态钉表 vs harness 真跑输出。"""
    with open(HARNESS_OUTPUT, "r", encoding="utf-8") as f:
        out = json.load(f)
    shape = out["shape_evaluation"]
    all_ok = True
    for t in sorted(EXPECTED_TRIPLES.keys()):
        exp = EXPECTED_TRIPLES[t]
        act_raw = shape.get(str(t), "<缺失>")
        if exp is None:
            ok = (act_raw is None)
            detail = f"期望=不可判(None) 实际={act_raw!r}"
        elif act_raw is None or act_raw == "<缺失>":
            ok = False
            detail = f"期望={ {k: exp[k] for k in TRIPLE_KEYS} } 实际={act_raw!r}"
        else:
            act = {k: act_raw.get(k) for k in TRIPLE_KEYS}
            ok = all(act[k] == exp[k] for k in TRIPLE_KEYS)
            diff = [k for k in TRIPLE_KEYS if act[k] != exp[k]]
            detail = (f"期望={ {k: exp[k] for k in TRIPLE_KEYS} } 实际={act}"
                      + (f" 不符项={diff}" if diff else ""))
        record(f"expected_triple_t{t:02d}", ok, detail)
        all_ok = all_ok and ok
    return all_ok


def main():
    check_step0_i_input_synthetic()
    check_step0_ii_no_data_source()
    check_step0_iii_independent_path()
    check_source_anchor_line609()
    check_source_formula_structure_vs_impl()

    gate_names = {
        "step0(i)_input_synthetic",
        "step0(ii)_no_data_source_static_scan",
        "step0(iii)_independent_recompute_no_harness_reuse",
        "source_anchor_T3_line609_programmatic_parse",
        "source_formula_structure_vs_impl_symbol_vector",
    }
    gate_failed = any(name in gate_names for name, _ in failures)

    if not gate_failed:
        if run_harness():
            run_independent_and_compare()
            check_shape_branch_coverage()
            check_entity_carries_required_annotations()
            check_expected_evaluation_point_set()
            check_expected_triples_per_point()
        else:
            record("D段跳过_harness未真跑成功", False, "harness执行失败，无法进入数值比对")
    else:
        record("D段跳过_step0前置未过", False,
               "step0前置合规断言/源文锚定未全过，依模板三D段规则直接判不合格，不进入数值比对（裁决1强制）")

    print("=== T3-18 断言执行日志（模板三D段：step0前置 + 独立数值比对 + 附加断言） ===")
    for name, detail in passes:
        print(f"[PASS] {name} :: {detail}")
    for name, detail in failures:
        print(f"[FAIL] {name} :: {detail}")

    total = len(passes) + len(failures)
    v10_names = {
        "step0(i)_input_synthetic", "step0(ii)_no_data_source_static_scan",
        "step0(iii)_independent_recompute_no_harness_reuse",
        "source_anchor_T3_line609_programmatic_parse", "harness_real_run",
        "independent_recompute_run", "numeric_compare_gap_series_bit_exact_a0",
        "numeric_compare_cum_gap_bit_exact_a0", "numeric_compare_shape_evaluation_bit_exact_a0",
        "branch_coverage_insufficient_history_trigger_nontrigger",
        "entity_carries_C6_PB_reference_and_data_source_field",
    }
    executed = [n for n, _ in passes] + [n for n, _ in failures]
    n_v10 = sum(1 for n in executed if n in v10_names)
    n_new = total - n_v10
    print(f"--- 合计 {len(passes)}/{total} 项断言通过 ---")
    print(f"--- 项数分解（KD裁定'丙'式分列）：v1.0原始项 {n_v10} ＋ v1.1修复新增项 {n_new} ＝ {total} ---")

    if failures:
        fail_names = "、".join(name for name, _ in failures)
        print(f"整体判定：不合格（{len(failures)}项未过：{fail_names}——按实际失败断言输出，非写死单一原因）")
        sys.exit(1)
    else:
        print("整体判定：合格（step0前置合规 + 断言基线程序化解析源文 + 源文公式结构vs实现符号向量 "
              "+ D段②独立数值比对bit-exact + D段③附加断言〔分支覆盖／制品标注／逐评估点期望三元组〕 全部通过）")
        sys.exit(0)


if __name__ == "__main__":
    main()

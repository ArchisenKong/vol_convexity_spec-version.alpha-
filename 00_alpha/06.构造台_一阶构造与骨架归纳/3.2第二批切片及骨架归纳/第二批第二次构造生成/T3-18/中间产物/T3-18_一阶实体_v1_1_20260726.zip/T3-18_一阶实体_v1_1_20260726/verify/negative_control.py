#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
verify/negative_control.py · T3-18 · v1.1 · 20260726 · 修复过程核验留痕（负例验证）

【性质声明——先读】
  本脚本＝**构造侧修复过程留痕**（会话开启文本四-2 之 W-9(2) 留痕纪律／五-1 产出要求），
  **不是**外审第三层变异注入、**不是**增量复核、**不构成**任何合格判定。
  合格判定权在增量复核会话（外审侧，重放 M3/M7/C1/C3/C4/C5/C6，判据＝assert_check.py 退出码
  非零为击落）与 KD。本脚本之注入文本与外审侧注入文本可能不同；此处逐例明文列出注入锚点串与
  替换串，供外审侧比对，不主张等价。
  W-9(2) 教训（O2）：凡进入合格判定叙述链的核验，其脚本与输出须随 verify/ 交付，不得仅以文字
  声明——故本脚本与 negative_control_log.txt 随交付。

【方法】
  隔离临时目录整树复制 → 锚点串替换（**命中失败即报注入失败并计为本例不成立，不静默跳过**）
  → 执行 verify/assert_check.py → 记录退出码与首个失败断言名。
  单侧＝仅改 entity/harness.py；协同＝harness 与 verify/independent_recompute.py 同向同改。

【七例来源】外审报告 §1 第三层表中 v1.0 逃逸之七例（M3/M7 单侧；C1/C3/C4/C5/C6 协同）。
"""
import os
import re
import shutil
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
REPO_ROOT = os.path.dirname(HERE)

H = "entity/harness.py"
V = "verify/independent_recompute.py"

# (例号, 类型, 说明, [(相对路径, 锚点串, 替换串), ...])
MUTATIONS = [
    ("M3", "单侧", "持续负值 all→any（harness 侧）", [
        (H, "persistent_negative = all(v < baseline_cents for v in window_vals)",
            "persistent_negative = any(v < baseline_cents for v in window_vals)"),
    ]),
    ("M7", "单侧", "基准比较 <→<=（harness 侧）", [
        (H, "persistent_negative = all(v < baseline_cents for v in window_vals)",
            "persistent_negative = all(v <= baseline_cents for v in window_vals)"),
    ]),
    ("C1", "协同", "两侧 roll_cost 符号同翻（−→+）", [
        (H, 'g = p["income_cents"] - p["bleed_cents"] - p["roll_cost_cents"]',
            'g = p["income_cents"] - p["bleed_cents"] + p["roll_cost_cents"]'),
        (V, 'out.append(pd["income_cents"] - pd["bleed_cents"] - pd["roll_cost_cents"])',
            'out.append(pd["income_cents"] - pd["bleed_cents"] + pd["roll_cost_cents"])'),
    ]),
    ("C3", "协同", "两侧斜率边界 <=→<（等价改写：not(>)→not(>=)）", [
        (H, "slope_nonconvergent = delta <= slope_threshold_cents",
            "slope_nonconvergent = delta < slope_threshold_cents"),
        (V, "slope_nonconvergent = not (delta > slope_threshold)",
            "slope_nonconvergent = not (delta >= slope_threshold)"),
    ]),
    ("C4", "协同", "两侧斜率窗口改取 funding_gap_window(=4)，即 cum[t]−cum[t−3]（原文\"超过槽位窗口\"另一读法）", [
        (H, "delta = cum_gap[t] - cum_gap[window_start]",
            "delta = cum_gap[t] - (cum_gap[t - 3] if (t - 3) in cum_gap else cum_gap[window_start])"),
        (V, "delta = cum_gap[t] - cum_gap[lo]",
            "delta = cum_gap[t] - (cum_gap[t - 3] if (t - 3) in cum_gap else cum_gap[lo])"),
    ]),
    ("C5", "协同", "两侧斜率改单期差分 cum[t]−cum[t−1]", [
        (H, "delta = cum_gap[t] - cum_gap[window_start]",
            "delta = cum_gap[t] - cum_gap[t - 1]"),
        (V, "delta = cum_gap[t] - cum_gap[lo]",
            "delta = cum_gap[t] - cum_gap[t - 1]"),
    ]),
    ("C6", "协同", "两侧持续负值判据显著放宽（all→any／max→min）", [
        (H, "persistent_negative = all(v < baseline_cents for v in window_vals)",
            "persistent_negative = any(v < baseline_cents for v in window_vals)"),
        (V, "persistent_negative = (max(vals) < baseline)",
            "persistent_negative = (min(vals) < baseline)"),
    ]),
]


def first_failure_name(stdout):
    m = re.search(r'^\[FAIL\]\s+(\S+)', stdout, re.M)
    return m.group(1) if m else "—"


def failure_names(stdout):
    return re.findall(r'^\[FAIL\]\s+(\S+)', stdout, re.M)


def run_case(case_id, kind, note, edits):
    with tempfile.TemporaryDirectory() as td:
        dst = os.path.join(td, "tree")
        shutil.copytree(REPO_ROOT, dst)
        # 注入
        for rel, anchor, repl in edits:
            path = os.path.join(dst, rel)
            with open(path, "r", encoding="utf-8") as f:
                src = f.read()
            if src.count(anchor) != 1:
                return {
                    "case": case_id, "kind": kind, "note": note, "exit": None,
                    "status": "注入失败（锚点命中数≠1，不静默跳过）",
                    "detail": f"file={rel} hits={src.count(anchor)}", "fails": [],
                }
            with open(path, "w", encoding="utf-8") as f:
                f.write(src.replace(anchor, repl))
        r = subprocess.run([sys.executable, os.path.join(dst, "verify", "assert_check.py")],
                           capture_output=True, text=True)
        fails = failure_names(r.stdout)
        return {
            "case": case_id, "kind": kind, "note": note, "exit": r.returncode,
            "status": "击落（exit≠0）" if r.returncode != 0 else "逃逸（exit=0）",
            "detail": f"首个失败断言={first_failure_name(r.stdout)}",
            "fails": fails,
        }


def main():
    print("=== T3-18 v1.1 修复过程核验留痕 · 负例验证（构造侧留痕，非外审判定） ===")
    print("判据：assert_check.py 退出码非零＝该变异被击落。注入锚点串见本脚本 MUTATIONS 常量。\n")
    results = [run_case(*m) for m in MUTATIONS]
    for r in results:
        print(f"[{r['case']:>2}] {r['kind']} | exit={r['exit']} | {r['status']} | {r['detail']}")
        print(f"     变异内容：{r['note']}")
        if r["fails"]:
            print(f"     全部失败断言：{'、'.join(r['fails'])}")
        print()
    killed = sum(1 for r in results if r["exit"] not in (None, 0))
    escaped = [r["case"] for r in results if r["exit"] == 0]
    inject_fail = [r["case"] for r in results if r["exit"] is None]
    print(f"--- 事实汇总（不作判定）：注入 {len(results)} 例；exit≠0 计 {killed} 例；"
          f"exit=0 计 {len(escaped)} 例{('：' + '、'.join(escaped)) if escaped else ''}；"
          f"注入失败 {len(inject_fail)} 例{('：' + '、'.join(inject_fail)) if inject_fail else ''} ---")
    print("--- 本脚本不设退出码判据（留痕用途），恒以 0 结束；击落判据之行使在增量复核会话与 KD ---")


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
GK-31增量复核 · D-1基线核证脚本（复核会话独立书写）
锚点独立性（裁决32-③）：本脚本全部锚点串由复核会话直接从GK主文档独立抽取，
不取自被审代码常量、不取自修复侧留痕件。
核证三问：
  (1) assert_check.py 是否已无手工转录基线常量残留
  (2) 基线是否确由 open() 指向GK主文档、切片行794-860 程序化派生
  (3) 派生产物与源文一致性（复核侧独立派生 vs 被审侧运行时派生 逐项比对）
退出码：0=全通过，1=任一不通过（28-B(ii)：断言非零退出码）
"""
import re
import sys
import os
import importlib.util

GK = "/mnt/project/Greeks_管理方法论主文档_v0_1_2-freeze_交叉一致性修正版_20260616.md"
AC = "/home/claude/gk31/iso/base/verify/assert_check.py"

fail = []
out = []

# ---------- (1) 手工转录常量残留扫描 ----------
src = open(AC, encoding="utf-8").read()

# 复核侧独立书写的旧常量锚点串（取自外审报告D-1所载 v1.0 常量，本处为独立转写核对用）
LEGACY_CONST_NAME = "BOUNDARY_CONTENT_MARKERS"
if re.search(r"^\s*" + LEGACY_CONST_NAME + r"\s*=", src, re.M):
    fail.append("(1) 旧手工转录常量 %s 定义仍在场" % LEGACY_CONST_NAME)
out.append("(1a) %s 定义残留: %s" % (LEGACY_CONST_NAME,
           "在场→FAIL" if LEGACY_CONST_NAME + " =" in src else "不在场→PASS"))

# 独立抽取源文边界条款，检查其任一实质片段是否被写死为字符串字面量
raw_lines = open(GK, encoding="utf-8").read().splitlines()
block = raw_lines[793:860]
bnd = [l.strip() for l in block if l.strip().startswith("边界：")]
out.append("(1b) 复核侧独立抽取 行794-860 '边界：'行数 = %d" % len(bnd))
if len(bnd) != 5:
    fail.append("(1b) 复核侧独立抽取行数=%d，非5" % len(bnd))

# 复核侧独立派生（与被审侧规则同义但独立实现：取"边界："后至首个 ；，。 前）
rv_markers = []
for l in bnd:
    c = l[len("边界："):]
    m = re.search(r"[；，。]", c)
    rv_markers.append((c[:m.start()] if m else c).strip())
out.append("(1c) 复核侧独立派生markers = %s" % rv_markers)

# 检查这些派生串是否被硬编码进脚本（若在场即仍属手工转录形态）
hard = [mk for mk in rv_markers if mk in src]
out.append("(1d) 派生marker全串在脚本源码中硬编码在场数 = %d" % len(hard))
if hard:
    fail.append("(1d) 以下marker以字面串硬编码于assert_check.py: %s" % hard)

# ---------- (2) open() 指向源文 + 行区间 ----------
has_open_doc = re.search(r"open\(\s*doc_path", src) is not None
path_const = re.search(r'GK_MAIN_DOC_PATH\s*=.*?Greeks_管理方法论主文档', src, re.S) is not None
line_start = re.search(r"GK_BOUNDARY_LINE_START\s*=\s*(\d+)", src)
line_end = re.search(r"GK_BOUNDARY_LINE_END\s*=\s*(\d+)", src)
out.append("(2a) open(doc_path) 在场: %s" % has_open_doc)
out.append("(2b) GK_MAIN_DOC_PATH 指向GK主文档: %s" % path_const)
out.append("(2c) 行区间 = %s-%s" % (line_start.group(1) if line_start else None,
                                    line_end.group(1) if line_end else None))
if not (has_open_doc and path_const):
    fail.append("(2) 基线未经open()对GK主文档程序化读取")
if not (line_start and line_end and line_start.group(1) == "794" and line_end.group(1) == "860"):
    fail.append("(2c) 行区间与裁决37-B1字面(794-860)不一致")

# ---------- (3) 派生产物一致性：被审侧运行时派生 vs 复核侧独立派生 ----------
spec = importlib.util.spec_from_file_location("ac", AC)
ac = importlib.util.module_from_spec(spec)
sys.modules["ac"] = ac
spec.loader.exec_module(ac)
audited = ac.parse_boundary_markers()
out.append("(3a) 被审侧运行时派生markers = %s" % audited)
if audited != rv_markers:
    fail.append("(3a) 双侧派生产物不一致:\n  被审=%s\n  复核=%s" % (audited, rv_markers))
else:
    out.append("(3a) 双侧派生逐项全等 → PASS")

# ---------- (4) 超集关系核证（修复侧docstring所作声明的实证）----------
# 复核会话独立转写的 v1.0 五常量（源＝外审报告D-1所载/orig包，仅作超集关系比对用）
legacy = ["不能单独批准对冲", "不能证明 safe carry", "不等于 useless cost",
          "只能成为 candidate", "不得新增任何未在用户方法论文件"]
sup = all(any(old in new for new in audited) for old in legacy)
out.append("(4) 新markers对旧五常量呈超集(检出范围不收窄): %s" % sup)
if not sup:
    fail.append("(4) 超集关系不成立，检出范围收窄")

# ---------- (5) fail-closed 结构自检有效性 ----------
has_raise = "raise RuntimeError" in src and "GK_EXPECTED_BOUNDARY_COUNT" in src
out.append("(5) 源文结构变更fail-closed自检在场: %s" % has_raise)
if not has_raise:
    fail.append("(5) 无fail-closed结构自检")

print("\n".join(out))
print("\n===== D-1核证结论: %s =====" % ("PASS" if not fail else "FAIL"))
for f in fail:
    print("FAIL: " + f)
sys.exit(1 if fail else 0)

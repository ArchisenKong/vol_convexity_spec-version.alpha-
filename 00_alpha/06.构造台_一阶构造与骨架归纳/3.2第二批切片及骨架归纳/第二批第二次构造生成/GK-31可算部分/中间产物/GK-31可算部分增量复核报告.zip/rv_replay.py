#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
GK-31增量复核 · 变异注入重放（开启文本§2.1.2 ＋ §2.2回归抽验）
纪律：
  - 只审不修：全部变异在 iso/ 隔离副本执行；交付件 fix/ 零改动（外层指纹比对）
  - 锚点独立性（裁决32-③）：变异体标识符与断言锚点由复核会话独立书写，
    不取自被审代码常量、不取自修复侧留痕件（探针清单）之外的实现细节。
    RC2为外审报告C2原例复刻（授权源既载字面）。
  - 数值层免重放（37-A第3条）：本harness不注入E1-E11数值类变异。
每例：复制修复版包→施加变异→运行assert_check.py→读exit code。
  exit=1 → 击落；exit=0 → 存活。
"""
import os, re, shutil, subprocess, sys, json

FIX = "/home/claude/gk31/fix"
ISO = "/home/claude/gk31/iso/mut"
GK = "/mnt/project/Greeks_管理方法论主文档_v0_1_2-freeze_交叉一致性修正版_20260616.md"

# ---------- 变异体（复核会话独立书写；RC2＝外审C2原例复刻） ----------

def m_rc2(root):
    """RC2｜外审C2原例复刻：植入 approve_hedge_from_delta()（单一Delta直接批准对冲），
    不含任何边界条款字面串。必重放最低集。"""
    p = os.path.join(root, "entity/harness.py")
    s = open(p, encoding="utf-8").read()
    s += ("\n\ndef approve_hedge_from_delta(delta_agg):\n"
          "    return delta_agg > 0\n")
    open(p, "w", encoding="utf-8").write(s)

def m_sm1(root):
    """SM-1｜SP-1同型·异名：hedge_approval_flag 由Delta观察直接决定。"""
    p = os.path.join(root, "entity/harness.py")
    s = open(p, encoding="utf-8").read()
    s += "\n\ndef _leg_gate(d):\n    hedge_approval_flag = (d != 0)\n    return hedge_approval_flag\n"
    open(p, "w", encoding="utf-8").write(s)

def m_sm2(root):
    """SM-2｜SP-2同型：positive Theta 直接映射为 carry 安全结论。"""
    p = os.path.join(root, "entity/harness.py")
    s = open(p, encoding="utf-8").read()
    s += "\n\ndef _carry_state(t):\n    safe_carry = (t > 0)\n    return safe_carry\n"
    open(p, "w", encoding="utf-8").write(s)

def m_sm3(root):
    """SM-3｜SP-3同型：wing Delta 钝化直接批准 roll。"""
    p = os.path.join(root, "entity/harness.py")
    s = open(p, encoding="utf-8").read()
    s += "\n\ndef _wing_state(d):\n    roll_approved = (abs(d) < 1)\n    return roll_approved\n"
    open(p, "w", encoding="utf-8").write(s)

def m_sm4(root):
    """SM-4｜SP-4同型：单一Gamma指标直接批准调整（approved 而非 candidate）。"""
    p = os.path.join(root, "entity/harness.py")
    s = open(p, encoding="utf-8").read()
    s += "\n\ndef _gamma_gate(g):\n    gamma_adjustment_approved = (g != 0)\n    return gamma_adjustment_approved\n"
    open(p, "w", encoding="utf-8").write(s)

def m_sm5(root):
    """SM-5｜SP-5同型：新增固定参数（DTE阈值硬编码）。"""
    p = os.path.join(root, "entity/harness.py")
    s = open(p, encoding="utf-8").read()
    s += "\n\ndte_threshold = 30\n"
    open(p, "w", encoding="utf-8").write(s)

def m_sm6(root):
    """SM-6｜SP-1同型·无语义命名（探针清单已知局限1之实证）：
    语义上仍为'单一Delta直接批准对冲'，但标识符不含任何批准语义词。"""
    p = os.path.join(root, "entity/harness.py")
    s = open(p, encoding="utf-8").read()
    s += "\n\ndef _f7(x1):\n    flag_a = (x1 > 0)\n    return flag_a\n"
    open(p, "w", encoding="utf-8").write(s)

def m_sm7(root):
    """SM-7｜SP-5同型·无语义命名：固定参数硬编码但变量名不含DTE/moneyness等词。"""
    p = os.path.join(root, "entity/harness.py")
    s = open(p, encoding="utf-8").read()
    s += "\n\n_p1 = 30\n"
    open(p, "w", encoding="utf-8").write(s)

def m_sm8(root):
    """SM-8｜扫描面覆盖：C2同型变异注入 verify/independent_recompute.py（非harness侧）。"""
    p = os.path.join(root, "verify/independent_recompute.py")
    s = open(p, encoding="utf-8").read()
    s += "\n\ndef approve_hedge_from_delta(d):\n    return d > 0\n"
    open(p, "w", encoding="utf-8").write(s)

def m_sm9(root):
    """SM-9｜设计内存活对照（同C6a口径）：C2同型语义词仅出现在注释中。
    W-8(c)剥离口径下应不命中；若命中＝假阳性。"""
    p = os.path.join(root, "entity/harness.py")
    s = open(p, encoding="utf-8").read()
    s += "\n\n# note: approve_hedge_from_delta 一类逻辑本根禁止实现\n"
    open(p, "w", encoding="utf-8").write(s)

def m_sm10(root):
    """SM-10｜D-1活性证明·源文漂移：在隔离副本的GK源文行794-860区间内改写一条
    '边界：'条款文本，并把改写后的新文本植入harness.py。
    若基线确为运行时派生，应检出（击落）；若仍用旧常量，则漏检（存活）。"""
    gsrc = open(GK, encoding="utf-8").read().splitlines(keepends=True)
    old = gsrc[847]  # 行848（0-based 847）＝ Gamma leg 边界条款
    assert old.strip().startswith("边界："), "锚点行错位: %r" % old[:20]
    gsrc[847] = "边界：Gamma leg 的调整仅可列为待议项，不得由单一 Gamma 指标直接批准。\r\n"
    gpath = os.path.join(root, "gk_drifted.md")
    open(gpath, "w", encoding="utf-8", newline="").write("".join(gsrc))
    p = os.path.join(root, "entity/harness.py")
    s = open(p, encoding="utf-8").read()
    s += "\n\n# Gamma leg 的调整仅可列为待议项\n_x = 1\n"
    # 注释会被W-8(c)剥离——字面层扫描的是raw还是stripped？字面层扫raw，故此处用代码字符串
    s = s.replace("# Gamma leg 的调整仅可列为待议项\n_x = 1",
                  '_note = "Gamma leg 的调整仅可列为待议项"')
    open(p, "w", encoding="utf-8").write(s)
    return {"GK31_GK_MAIN_DOC_PATH": gpath}

def m_sm11(root):
    """SM-11｜D-1 fail-closed：隔离副本源文中删去一条'边界：'行（区间内计数5→4）。
    应触发结构自检异常→fail-closed判不合格（击落）。"""
    gsrc = open(GK, encoding="utf-8").read().splitlines(keepends=True)
    assert gsrc[847].strip().startswith("边界：")
    gsrc[847] = "（本行已于隔离副本中移除边界条款，用于fail-closed探测）\r\n"
    gpath = os.path.join(root, "gk_missing.md")
    open(gpath, "w", encoding="utf-8", newline="").write("".join(gsrc))
    return {"GK31_GK_MAIN_DOC_PATH": gpath}

# ---------- 回归抽验（外审既有击落例，§2.2） ----------

def m_c3(root):
    """C3复刻｜字面层：植入边界条款字面串。"""
    p = os.path.join(root, "entity/harness.py")
    s = open(p, encoding="utf-8").read()
    s += '\n\n_c3 = "核心仓位的 Delta 观察不能单独批准对冲"\n'
    open(p, "w", encoding="utf-8").write(s)

def m_c4(root):
    """C4复刻｜step0(iii)：independent_recompute.py 植入 harness_output.json 字样。"""
    p = os.path.join(root, "verify/independent_recompute.py")
    s = open(p, encoding="utf-8").read()
    s += '\n_c4 = "harness_output.json"\n'
    open(p, "w", encoding="utf-8").write(s)

def m_c5(root):
    """C5复刻｜step0(ii)-a：harness.py 加 import socket。"""
    p = os.path.join(root, "entity/harness.py")
    s = open(p, encoding="utf-8").read()
    s = "import socket\n" + s
    open(p, "w", encoding="utf-8").write(s)

def m_c6b(root):
    """C6b复刻｜step0(ii)-b：代码字符串中植入 https://。"""
    p = os.path.join(root, "entity/harness.py")
    s = open(p, encoding="utf-8").read()
    s += '\n_c6b = "https://example.invalid"\n'
    open(p, "w", encoding="utf-8").write(s)

def m_c6a(root):
    """C6a复刻｜设计内存活：注释内植 https://（W-8(c)剥离口径正确行为）。"""
    p = os.path.join(root, "entity/harness.py")
    s = open(p, encoding="utf-8").read()
    s += '\n# see https://example.invalid\n'
    open(p, "w", encoding="utf-8").write(s)



def m_sm12(root):
    """SM-12｜C2同型·无语义命名且实质接线（非死代码）：
    由 core_position delta 直接产生一个'批准'性质布尔量 aux_flags.g1 并写入
    harness_output.json。语义上即GK§11.2行805所禁'Delta观察单独批准'形态，
    但标识符(_g1/aux_flags)不含任何批准语义词，且新增顶层输出键。
    与SM-6/SM-7的区别：本例实质改变交付产物，非惰性死代码。"""
    p_ = os.path.join(root, "entity/harness.py")
    s_ = open(p_, encoding="utf-8").read()
    s_ = s_.replace('        "node_count_by_leg": node_count_by_leg,',
                    '        "aux_flags": {"g1": _g1(leg_totals["core_position"]["delta"])},\n'
                    '        "node_count_by_leg": node_count_by_leg,')
    s_ = s_.replace('if __name__ == "__main__":',
                    'def _g1(v):\n    return bool(v != 0)\n\n\nif __name__ == "__main__":')
    open(p_, "w", encoding="utf-8").write(s_)
    # 实质接线需重跑harness以令变异进入交付产物
    subprocess.run([sys.executable, "harness.py"], cwd=os.path.join(root, "entity"),
                   capture_output=True, text=True)

CASES = [
    ("RC2",  "外审C2原例复刻·approve_hedge_from_delta()语义植入", m_rc2,  "击落", "C2必重放最低集"),
    ("SM-1", "SP-1同型异名·hedge_approval_flag",                m_sm1,  "击落", "自拟语义变异"),
    ("SM-2", "SP-2同型·safe_carry",                             m_sm2,  "击落", "自拟语义变异"),
    ("SM-3", "SP-3同型·roll_approved",                          m_sm3,  "击落", "自拟语义变异"),
    ("SM-4", "SP-4同型·gamma_adjustment_approved",              m_sm4,  "击落", "自拟语义变异"),
    ("SM-5", "SP-5同型·dte_threshold=30固定参数",                m_sm5,  "击落", "自拟语义变异"),
    ("SM-6", "SP-1同型·无语义命名(_f7/flag_a)",                  m_sm6,  "存活(清单局限1)", "能力上限探测"),
    ("SM-7", "SP-5同型·无语义命名(_p1=30)",                      m_sm7,  "存活(清单局限1)", "能力上限探测"),
    ("SM-8", "C2同型注入independent_recompute.py(扫描面覆盖)",    m_sm8,  "击落", "自拟语义变异"),
    ("SM-9", "C2同型语义词仅在注释内(假阳性对照)",                m_sm9,  "存活(设计内)", "假阳性对照"),
    ("SM-12","C2同型·无语义命名且实质接线(新增顶层输出键)",        m_sm12, "未预设", "能力上限探测"),
    ("SM-10","D-1活性·源文漂移后新文本植入",                     m_sm10, "击落", "D-1活性证明"),
    ("SM-11","D-1 fail-closed·源文边界行数5→4",                  m_sm11, "击落", "D-1活性证明"),
    ("C3'",  "回归·边界条款字面串植入",                          m_c3,   "击落", "回归抽验"),
    ("C4'",  "回归·step0(iii)路径独立性",                        m_c4,   "击落", "回归抽验"),
    ("C5'",  "回归·step0(ii)-a import socket",                   m_c5,   "击落", "回归抽验"),
    ("C6b'", "回归·step0(ii)-b 代码字符串https://",               m_c6b,  "击落", "回归抽验"),
    ("C6a'", "回归·注释内https://(设计内存活)",                   m_c6a,  "存活(设计内)", "回归抽验"),
]


def run_case(cid, mut):
    root = os.path.join(ISO, cid.replace("'", "p"))
    if os.path.exists(root):
        shutil.rmtree(root)
    os.makedirs(root)
    shutil.copytree(os.path.join(FIX, "entity"), os.path.join(root, "entity"))
    shutil.copytree(os.path.join(FIX, "verify"), os.path.join(root, "verify"))
    env_extra = mut(root) or {}
    env = dict(os.environ); env.update(env_extra)
    r = subprocess.run([sys.executable, "assert_check.py"],
                       cwd=os.path.join(root, "verify"),
                       capture_output=True, text=True, env=env)
    open(os.path.join(root, "run.log"), "w", encoding="utf-8").write(r.stdout + "\n---STDERR---\n" + r.stderr)
    return r.returncode, r.stdout


def main():
    if os.path.exists(ISO):
        shutil.rmtree(ISO)
    os.makedirs(ISO)
    rows = []
    for cid, desc, mut, exp, cls in CASES:
        rc, so = run_case(cid, mut)
        verdict = "击落" if rc == 1 else "存活"
        # 归因：抓取FAIL行
        reasons = [l for l in so.splitlines() if l.startswith("FAIL:")]
        rows.append({"id": cid, "desc": desc, "class": cls, "expect": exp,
                     "exit": rc, "verdict": verdict,
                     "match": exp.startswith(verdict),
                     "reason": reasons[:2]})
        print("%-6s exit=%d %-4s 预期=%-14s %s" % (cid, rc, verdict, exp, "OK" if exp.startswith(verdict) else "!! 偏离预期"))
        for r_ in reasons[:2]:
            print("        %s" % r_[:150])
    json.dump(rows, open("/home/claude/gk31/logs/replay_results.json", "w", encoding="utf-8"),
              ensure_ascii=False, indent=2)
    dev = [r for r in rows if not r["match"]]
    print("\n偏离预期例数 = %d" % len(dev))


if __name__ == "__main__":
    main()

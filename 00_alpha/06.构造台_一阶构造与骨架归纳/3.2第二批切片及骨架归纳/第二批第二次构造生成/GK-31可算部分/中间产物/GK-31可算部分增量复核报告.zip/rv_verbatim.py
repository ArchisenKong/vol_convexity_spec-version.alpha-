#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
GK-31增量复核 · 文档层并正逐字核对（开启文本§2.3.2）
裁定原文锚点＝程序化解析《GK31外审报告与KD裁定落地_v1_0_20260728.md》引用块，
不使用人工转录常量（EXP-006候选形态之自我规避）。
比对目标：37-B5 / 37-B6 / 37-C4 三处替换/追加文本 vs 交付件实际文本。
"""
import re, sys, unicodedata

RULING = "/mnt/user-data/uploads/GK31外审报告与KD裁定落地_v1_0_20260728.md"
FILES = {
    "切片记录v1.1": "/home/claude/gk31/fix/切片记录_GK-31可算部分_v1_1_20260728.md",
    "撞墙清单v1.1": "/home/claude/gk31/fix/撞墙清单_GK-31可算部分_v1_1_20260728.md",
    "input_schema v1.1": "/home/claude/gk31/fix/entity/input_schema.md",
}

fail, out = [], []
rul = open(RULING, encoding="utf-8").read()

def blockquote_after(anchor):
    """程序化抽取：锚点条款号之后的第一个 '> "..."' 引用块正文。"""
    i = rul.index(anchor)
    seg = rul[i:i + 4000]
    m = re.search(r'\n>\s*[“"](.+?)[”"]\s*\n', seg, re.S)
    if not m:
        raise RuntimeError("未定位到 %s 的引用块" % anchor)
    return re.sub(r"\n>\s*", "", m.group(1)).strip()

def norm(s):
    """归一化：去markdown强调/反引号/空白；全角半角标点不归一（逐字口径保留标点差异可见）。"""
    s = s.replace("**", "").replace("`", "")
    s = re.sub(r"\s+", "", s)
    return s

TARGETS = [
    ("37-B5", "**37-B5（D-5）**", ["切片记录v1.1", "撞墙清单v1.1"]),
    ("37-B6", "**37-B6（D-6）**", ["切片记录v1.1"]),
    ("37-C4", "**37-C4（Q-4）", ["input_schema v1.1"]),
]

texts = {name: open(p, encoding="utf-8").read() for name, p in FILES.items()}

for tag, anchor, where in TARGETS:
    ruled = blockquote_after(anchor)
    out.append("\n【%s】裁定原文（程序化抽取，%d字）:\n  %s" % (tag, len(ruled), ruled))
    n = norm(ruled)
    for w in where:
        body = norm(texts[w])
        hit = n in body
        out.append("  → %s : %s" % (w, "逐字在场(归一化后全串命中) PASS" if hit else "未命中 FAIL"))
        if not hit:
            # 定位最长公共前缀，给出首处分歧
            j = 0
            while j < len(n) and n[:j+1] in body:
                j += 1
            out.append("     首处分歧位置≈第%d字；裁定原文该处起=%r" % (j, n[j:j+40]))
            fail.append("%s 在 %s 中非逐字一致" % (tag, w))

# 附随核对：37-B5 中 T-23/B6 之引号形态差异留痕
out.append("\n【标点/强调层差异留痕（非逐字判定失败，供KD过目）】")
for tag, anchor, where in TARGETS:
    ruled = blockquote_after(anchor)
    for w in where:
        body = texts[w]
        if ruled in body:
            out.append("  %s@%s: 未归一化亦全串命中（含标点/强调完全一致）" % (tag, w))
        else:
            out.append("  %s@%s: 归一化后一致、未归一化不一致 → 差异仅在 markdown强调/反引号/空白 层" % (tag, w))

print("\n".join(out))
print("\n===== 逐字核对结论: %s =====" % ("PASS" if not fail else "FAIL"))
for f in fail:
    print("FAIL: " + f)
sys.exit(1 if fail else 0)

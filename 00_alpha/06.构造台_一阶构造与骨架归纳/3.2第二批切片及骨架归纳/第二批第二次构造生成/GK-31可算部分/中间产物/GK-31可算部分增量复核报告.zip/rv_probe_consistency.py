#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
GK-31增量复核 · 探针清单核证（开启文本§2.1.3）
核证三问：
  (a) 清单所列探针逐条在 assert_check.py 实现中在场
  (b) 无清单外静默探针（实现探针集 ⊆ 清单探针集，且反向亦然）
  (c) 探针正则模式在清单与实现之间逐字一致（不含markdown转义差异）
  (d) 探针来源核证：探针pattern是否为对被审代码的镜像转抄（D-1形态是否在探针层复现）
退出码 0=PASS / 1=FAIL
"""
import re, sys, importlib.util

AC = "/home/claude/gk31/iso/base/verify/assert_check.py"
LIST = "/home/claude/gk31/fix/GK-31域边界语义探针清单_呈KD件_v1_0_20260728.md"
AUDITED = ["/home/claude/gk31/fix/entity/harness.py",
           "/home/claude/gk31/fix/verify/independent_recompute.py"]

fail, out = [], []

spec = importlib.util.spec_from_file_location("ac2", AC)
ac = importlib.util.module_from_spec(spec); spec.loader.exec_module(ac)
impl = {p["id"]: p["pattern"].pattern for p in ac.SEMANTIC_PROBES}
out.append("(a1) 实现侧探针集 = %s" % sorted(impl))

md = open(LIST, encoding="utf-8").read()
# 清单表格行：| SP-n | ... | ... | `regex` | ... |
rows = re.findall(r"^\|\s*(SP-\d)\s*\|.*?\|.*?\|\s*`(.+?)`\s*\|", md, re.M)
listed = {rid: pat for rid, pat in rows}
out.append("(a2) 清单侧探针集 = %s" % sorted(listed))

if set(impl) != set(listed):
    fail.append("(a/b) 探针集不一致：实现%s vs 清单%s（差集=%s）"
                % (sorted(impl), sorted(listed), set(impl) ^ set(listed)))
else:
    out.append("(a/b) 探针集双向相等，无清单外静默探针 → PASS")

def norm(s):
    # 清单为markdown表格，'|' 被转义为 '\|'；实现侧正则含 (?i) 前缀与跨行拼接空白
    s = s.replace(r"\|", "|")
    s = re.sub(r"^\(\?i\)", "", s)
    s = re.sub(r"\s+", "", s)
    return s

for rid in sorted(set(impl) & set(listed)):
    a, b = norm(impl[rid]), norm(listed[rid])
    if a != b:
        fail.append("(c) %s 模式不一致:\n    实现=%s\n    清单=%s" % (rid, a, b))
    else:
        out.append("(c) %s 模式逐字一致(归一化后) → PASS" % rid)

# (d) 探针来源：pattern中的标识符是否取自被审代码（镜像转抄形态）
code = "\n".join(open(p, encoding="utf-8").read() for p in AUDITED)
tokens = set()
for pat in impl.values():
    for t in re.findall(r"[A-Za-z_]{4,}", pat):
        if t not in ("i", "w"):
            tokens.add(t)
mirrored = sorted(t for t in tokens if re.search(r"\b" + re.escape(t), code))
out.append("(d) 探针标识符片段总数=%d；其中在被审代码中在场者=%s"
           % (len(tokens), mirrored if mirrored else "无"))
if mirrored:
    out.append("(d) 注：在场即说明探针词取自被审代码 → 需人工判别是否镜像转抄")
else:
    out.append("(d) 探针词无一取自被审代码，非镜像转抄；D-1形态未在探针层复现 → PASS")

print("\n".join(out))
print("\n===== 探针清单核证结论: %s =====" % ("PASS" if not fail else "FAIL"))
for f in fail: print("FAIL: " + f)
sys.exit(1 if fail else 0)

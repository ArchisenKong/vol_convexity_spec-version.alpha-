#!/usr/bin/env python3
"""
T-76 option surface node · 一次性 harness (B段)
职责：喂入(A的人造input) -> 驱动(坐标归属+raw Greeks计算) -> 捕获(写出真数)。
不接任何数据源，不建常设pipeline，仅本次执行使用。
"""
import json
import math
from datetime import date

INPUT_PATH = "entity/input_positions.json"
OUTPUT_PATH = "entity/harness_output.json"


def tenor_bucket(dte: int) -> str:
    if dte <= 30:
        return "0-30D"
    elif dte <= 60:
        return "31-60D"
    elif dte <= 90:
        return "61-90D"
    elif dte <= 180:
        return "91-180D"
    else:
        return "180D+"


def moneyness_bucket(k_over_s: float) -> str:
    if k_over_s < 0.95:
        return "low"
    elif k_over_s <= 1.05:
        return "atm"
    else:
        return "high"


def liquidity_bucket(oi: int) -> str:
    if oi < 100:
        return "low"
    elif oi < 1000:
        return "mid"
    else:
        return "high"


def norm_cdf(x: float) -> float:
    return 0.5 * (1.0 + math.erf(x / math.sqrt(2.0)))


def norm_pdf(x: float) -> float:
    return (1.0 / math.sqrt(2.0 * math.pi)) * math.exp(-0.5 * x * x)


def bs_raw_greeks(S, K, T, r, sigma, option_type):
    d1 = (math.log(S / K) + (r + 0.5 * sigma * sigma) * T) / (sigma * math.sqrt(T))
    d2 = d1 - sigma * math.sqrt(T)
    nd1 = norm_pdf(d1)
    if option_type == "call":
        delta = norm_cdf(d1)
        theta = -(S * nd1 * sigma) / (2 * math.sqrt(T)) - r * K * math.exp(-r * T) * norm_cdf(d2)
        rho = K * T * math.exp(-r * T) * norm_cdf(d2)
    else:  # put
        delta = norm_cdf(d1) - 1.0
        theta = -(S * nd1 * sigma) / (2 * math.sqrt(T)) + r * K * math.exp(-r * T) * norm_cdf(-d2)
        rho = -K * T * math.exp(-r * T) * norm_cdf(-d2)
    gamma = nd1 / (S * sigma * math.sqrt(T))
    vega = S * nd1 * math.sqrt(T)
    return {"delta": delta, "gamma": gamma, "vega": vega, "theta": theta, "rho": rho}


def main():
    with open(INPUT_PATH, "r", encoding="utf-8") as f:
        data = json.load(f)

    val_date = date.fromisoformat(data["valuation_date"])
    positions = data["positions"]

    position_detail = []
    nodes = {}  # coordinate_key -> node dict

    for pos in positions:
        expiry = date.fromisoformat(pos["expiry"])
        dte = (expiry - val_date).days
        T = dte / 365.0
        S = pos["spot"]
        K = pos["strike"]
        r = pos["risk_free_rate"]
        sigma = pos["implied_vol"]
        k_over_s = K / S

        coord = {
            "leg_type": pos["leg_type"],
            "side": pos["side"],
            "option_type": pos["option_type"],
            "tenor_bucket": tenor_bucket(dte),
            "moneyness_bucket": moneyness_bucket(k_over_s),
            "scenario": "base",
        }
        coord_key = json.dumps(coord, sort_keys=True)

        per_unit = bs_raw_greeks(S, K, T, r, sigma, pos["option_type"])
        side_sign = 1.0 if pos["side"] == "long" else -1.0
        scale = pos["multiplier"] * pos["quantity"] * side_sign
        position_greeks = {k: v * scale for k, v in per_unit.items()}

        liq_b = liquidity_bucket(pos["open_interest"])

        position_detail.append({
            "lot_id": pos["lot_id"],
            "coordinate": coord,
            "retained_fields": {
                "expiry": pos["expiry"],
                "strike": K,
                "liquidity_bucket": liq_b,
            },
            "dte": dte,
            "k_over_s": k_over_s,
            "position_greeks": position_greeks,
        })

        if coord_key not in nodes:
            nodes[coord_key] = {
                "coordinate": coord,
                "contributing_lots": [],
                "raw_greeks": {"delta": 0.0, "gamma": 0.0, "vega": 0.0, "theta": 0.0, "rho": 0.0},
            }
        node = nodes[coord_key]
        node["contributing_lots"].append(pos["lot_id"])
        for k in node["raw_greeks"]:
            node["raw_greeks"][k] += position_greeks[k]

    node_list = []
    for i, (coord_key, node) in enumerate(sorted(nodes.items()), start=1):
        node["node_id"] = f"N{i}"
        node_list.append(node)

    output = {
        "valuation_date": data["valuation_date"],
        "nodes": node_list,
        "position_detail": position_detail,
    }

    with open(OUTPUT_PATH, "w", encoding="utf-8") as f:
        json.dump(output, f, ensure_ascii=False, indent=2)

    print(f"harness 真跑完成，节点数={len(node_list)}，持仓数={len(position_detail)}")
    for n in node_list:
        print(f"  {n['node_id']}: {n['coordinate']} <- {n['contributing_lots']}")


if __name__ == "__main__":
    main()

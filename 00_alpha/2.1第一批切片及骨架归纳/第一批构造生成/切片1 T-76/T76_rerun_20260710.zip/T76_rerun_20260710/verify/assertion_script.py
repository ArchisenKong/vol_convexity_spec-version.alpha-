#!/usr/bin/env python3
"""
T-76 · D段断言脚本
step0 前置合规断言 -> step1-2 数值比对(容差=0) -> step3 附加断言
二值判定，不放宽容差，不跳步。
"""
import json
import re

LOG_LINES = []


def log(line=""):
    print(line)
    LOG_LINES.append(line)


def step0():
    log("== step 0 前置合规断言 ==")
    ok = True

    # (i) input 确为人造构造
    with open("../entity/input_positions.json", encoding="utf-8") as f:
        raw = f.read()
    cond_i = '"_data_source": "synthetic_hand_constructed"' in raw
    log(f"(i) input 人造构造声明存在: {cond_i}")
    ok = ok and cond_i

    # (ii) harness 全程无数据源接入 —— 源码级检查禁用模式
    with open("../entity/harness.py", encoding="utf-8") as f:
        harness_src = f.read()
    forbidden = ["requests", "urllib", "socket", "ibkr", "quantconnect",
                 "http.client", "ftplib", "open(\"/mnt", "yfinance"]
    hits = [p for p in forbidden if p.lower() in harness_src.lower()]
    cond_ii = (len(hits) == 0) and ('open(INPUT_PATH' in harness_src)
    log(f"(ii) harness 源码禁用数据源模式检出: {hits if hits else '无'} -> {cond_ii}")
    ok = ok and cond_ii

    # (iii) 独立复算路径自 clean input 独立推导，不取自 harness 中间量/harness_output
    with open("independent_recompute.py", encoding="utf-8") as f:
        indep_src = f.read()
    # 精确检查：排除文档字符串/注释后，代码体内是否存在对 harness_output 的实际访问
    docstring_match = re.search(r'"""(.*?)"""', indep_src, re.DOTALL)
    code_body = indep_src[docstring_match.end():] if docstring_match else indep_src
    references_harness_output = bool(re.search(r"harness_output", code_body))
    imports_harness = bool(re.search(r"import\s+harness\b", indep_src))
    reads_clean_input = 'INPUT_PATH = "../entity/input_positions.json"' in indep_src
    cond_iii = (not references_harness_output) and (not imports_harness) and reads_clean_input
    log(f"(iii) 独立复算不取harness中间量(代码体内检出): {not references_harness_output}, "
        f"不import harness: {not imports_harness}, 直接读clean input: {reads_clean_input} -> {cond_iii}")
    ok = ok and cond_iii

    log(f"step0 结论: {'通过' if ok else '未通过'}")
    return ok


def step1_2():
    log("\n== step 1-2 数值比对（容差=0，精确相等） ==")
    with open("../entity/harness_output.json", encoding="utf-8") as f:
        h = json.load(f)
    with open("independent_output.json", encoding="utf-8") as f:
        i = json.load(f)

    h_nodes = {json.dumps(n["coordinate"], sort_keys=True): n for n in h["nodes"]}
    i_nodes = {json.dumps(n["coordinate"], sort_keys=True): n for n in i["nodes"]}

    diffs = []
    node_keys_match = set(h_nodes.keys()) == set(i_nodes.keys())
    log(f"节点坐标集合一致: {node_keys_match}")

    for key in sorted(h_nodes.keys()):
        hn, iN = h_nodes[key], i_nodes[key]
        lots_match = hn["contributing_lots"] == iN["contributing_lots"]
        if not lots_match:
            diffs.append((key, "contributing_lots", hn["contributing_lots"], iN["contributing_lots"]))
        for gk in ["delta", "gamma", "vega", "theta", "rho"]:
            hv, iv = hn["raw_greeks"][gk], iN["raw_greeks"][gk]
            d = hv - iv
            if d != 0.0:
                diffs.append((key, gk, hv, iv, d))

    if diffs:
        log(f"检出非零差异条目数: {len(diffs)}")
        for entry in diffs:
            if len(entry) == 5:
                key, gk, hv, iv, d = entry
                coord = json.loads(key)
                log(f"  节点{coord} · {gk}: harness={hv!r} independent={iv!r} diff={d!r} (相对diff={d/hv if hv else 'n/a'})")
            else:
                key, field, hval, ival = entry
                log(f"  节点{key} · {field} 不一致: harness={hval} independent={ival}")
    else:
        log("全部字段精确相等（diff==0.0），无非零差异。")

    passed = node_keys_match and (len(diffs) == 0)
    log(f"step1-2 结论: {'通过' if passed else '未通过（检出非零差异，依D段规则=断言不符）'}")
    return passed, diffs


def step3():
    log("\n== step 3 附加断言 ==")
    with open("../entity/harness_output.json", encoding="utf-8") as f:
        h = json.load(f)

    # ① 坐标唯一归属：每笔持仓只出现在一个node的contributing_lots中
    lot_to_nodes = {}
    for n in h["nodes"]:
        for lot in n["contributing_lots"]:
            lot_to_nodes.setdefault(lot, []).append(n["node_id"])
    uniq_ok = all(len(v) == 1 for v in lot_to_nodes.values())
    log(f"① 坐标唯一归属（每lot仅属一个node）: {uniq_ok} · 明细={lot_to_nodes}")

    # ② 坐标各分量与持仓明细一致：position_detail 中的coordinate与其所属node的coordinate一致
    consist_ok = True
    for pd in h["position_detail"]:
        owning_nodes = [n for n in h["nodes"] if pd["lot_id"] in n["contributing_lots"]]
        if len(owning_nodes) != 1 or owning_nodes[0]["coordinate"] != pd["coordinate"]:
            consist_ok = False
    log(f"② 坐标分量与持仓明细一致: {consist_ok}")

    # ③ 输出形态齐备：坐标+raw Greeks两部分均在场
    form_ok = all(
        set(n["coordinate"].keys()) == {"leg_type", "side", "option_type", "tenor_bucket", "moneyness_bucket", "scenario"}
        and set(n["raw_greeks"].keys()) == {"delta", "gamma", "vega", "theta", "rho"}
        for n in h["nodes"]
    )
    log(f"③ 输出形态齐备（坐标+raw Greeks均在场）: {form_ok}")

    passed = uniq_ok and consist_ok and form_ok
    log(f"step3 结论: {'通过' if passed else '未通过'}")
    return passed


def main():
    s0 = step0()
    if not s0:
        log("\n=== 最终结论：不合格（step0未过，不进入数值比对） ===")
        write_log()
        return

    s12, diffs = step1_2()
    s3 = step3()

    log("\n== 综合结论 ==")
    log(f"step0={s0} step1-2={s12} step3={s3}")
    final = s0 and s12 and s3
    log(f"=== 最终结论：{'合格' if final else '不合格'} ===")
    if not final and s12 is False:
        log("不合格原因定位：step1-2数值比对检出非零浮点差异（量级约1e-12~1e-13相对误差），"
            "非坐标逻辑/算法逻辑错误（坐标集合一致、delta与rho精确相等、gamma/vega/theta出现≤2 ULP级差异）。"
            "依D段规则'不得就地放宽容差'，本次不在此脚本内改判，据实记入切片记录并登记开放张力。")

    write_log()


def write_log():
    with open("assertion_log.txt", "w", encoding="utf-8") as f:
        f.write("\n".join(LOG_LINES) + "\n")


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""
T-76 · 独立复算脚本 (D段 step1-2 用)
纪律：
  - 直接读取 entity/input_positions.json（clean人造input），不读取、不import entity/harness.py，
    不取用 entity/harness_output.json 的任何中间量。
  - 计算逻辑独立编写（结构、分解方式与 harness.py 不同），不调用同一函数体。
  - 与 harness 实现共享的仅为 Python 标准库原语（math.erf/exp/sqrt/log），
    这些是语言级数学原语，非本对象的业务计算实现本身。
"""
import json
import math
from datetime import date

INPUT_PATH = "../entity/input_positions.json"
OUTPUT_PATH = "independent_output.json"

# bucket 边界值来自 entity/input_schema.md §3 的既定定义（该定义本身是本根的算法交付物，
# 独立复算引用同一份"定义"是合规的——独立性要求的是"不复用同一段代码/不取用中间量"，
# 不是重新发明一套不同的分桶边界（边界值不是待验证对象，边界到桶标签的赋值是待验证对象）。

def assign_tenor_bucket(days_to_expiry: int) -> str:
    boundaries = [(30, "0-30D"), (60, "31-60D"), (90, "61-90D"), (180, "91-180D")]
    for upper, label in boundaries:
        if days_to_expiry <= upper:
            return label
    return "180D+"


def assign_moneyness_bucket(strike: float, spot: float) -> str:
    ratio = strike / spot
    if ratio > 1.05:
        return "high"
    if ratio < 0.95:
        return "low"
    return "atm"


def std_normal_cdf(z: float) -> float:
    # 与 harness 相同数学定义（N(x)只有一个正确公式），代码独立编写、独立调用点
    return 0.5 * math.erfc(-z / math.sqrt(2.0))  # 用 erfc 而非 erf，数学等价但函数入口不同


def std_normal_pdf(z: float) -> float:
    return math.exp(-(z ** 2) / 2.0) / math.sqrt(2.0 * math.pi)


def independent_bs_greeks(spot, strike, years, rate, vol, opt_type):
    sqrt_t = math.sqrt(years)
    numerator = math.log(spot / strike) + years * (rate + (vol ** 2) / 2.0)
    d1 = numerator / (vol * sqrt_t)
    d2 = d1 - vol * sqrt_t
    pdf_d1 = std_normal_pdf(d1)
    disc = math.exp(-rate * years)

    gamma_v = pdf_d1 / (spot * vol * sqrt_t)
    vega_v = spot * pdf_d1 * sqrt_t

    if opt_type == "put":
        delta_v = std_normal_cdf(d1) - 1.0
        theta_v = (-spot * pdf_d1 * vol) / (2.0 * sqrt_t) + rate * strike * disc * std_normal_cdf(-d2)
        rho_v = -strike * years * disc * std_normal_cdf(-d2)
    else:
        delta_v = std_normal_cdf(d1)
        theta_v = (-spot * pdf_d1 * vol) / (2.0 * sqrt_t) - rate * strike * disc * std_normal_cdf(d2)
        rho_v = strike * years * disc * std_normal_cdf(d2)

    return {"delta": delta_v, "gamma": gamma_v, "vega": vega_v, "theta": theta_v, "rho": rho_v}


def main():
    with open(INPUT_PATH, "r", encoding="utf-8") as f:
        raw = json.load(f)

    base_date = date.fromisoformat(raw["valuation_date"])

    node_accumulator = {}
    per_position = []

    for entry in raw["positions"]:
        exp_date = date.fromisoformat(entry["expiry"])
        days = (exp_date - base_date).days
        yrs = days / 365.0

        tb = assign_tenor_bucket(days)
        mb = assign_moneyness_bucket(entry["strike"], entry["spot"])

        coord = {
            "leg_type": entry["leg_type"],
            "side": entry["side"],
            "option_type": entry["option_type"],
            "tenor_bucket": tb,
            "moneyness_bucket": mb,
            "scenario": "base",
        }
        key = json.dumps(coord, sort_keys=True)

        unit_g = independent_bs_greeks(
            entry["spot"], entry["strike"], yrs,
            entry["risk_free_rate"], entry["implied_vol"], entry["option_type"]
        )
        sign = 1.0 if entry["side"] == "long" else -1.0
        factor = entry["multiplier"] * entry["quantity"] * sign
        pos_g = {k: v * factor for k, v in unit_g.items()}

        per_position.append({"lot_id": entry["lot_id"], "coordinate": coord, "position_greeks": pos_g})

        if key not in node_accumulator:
            node_accumulator[key] = {
                "coordinate": coord,
                "contributing_lots": [],
                "raw_greeks": {"delta": 0.0, "gamma": 0.0, "vega": 0.0, "theta": 0.0, "rho": 0.0},
            }
        acc = node_accumulator[key]
        acc["contributing_lots"].append(entry["lot_id"])
        for gk in acc["raw_greeks"]:
            acc["raw_greeks"][gk] += pos_g[gk]

    nodes_sorted = [node_accumulator[k] for k in sorted(node_accumulator.keys())]

    result = {"nodes": nodes_sorted, "position_detail": per_position}
    with open(OUTPUT_PATH, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)

    print(f"独立复算完成，节点数={len(nodes_sorted)}")


if __name__ == "__main__":
    main()

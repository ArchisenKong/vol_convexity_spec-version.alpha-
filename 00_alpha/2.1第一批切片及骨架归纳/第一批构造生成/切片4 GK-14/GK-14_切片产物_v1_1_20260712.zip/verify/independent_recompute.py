"""
verify/independent_recompute.py · GK-14 · 独立复算（D段）
函数式/生成器风格：itertools.groupby + 生成器表达式 + collections.defaultdict。
数据源独立：仅读 entity/input_data.json，不 import harness 模块，不读 harness_output.json。
本文件出现的"harness"字样仅限本段 docstring 独立性声明，不构成实际耦合。
"""
import json
from fractions import Fraction as F
from itertools import groupby
from collections import defaultdict

with open("entity/input_data.json") as f:
    DATA = json.load(f)

NODES = DATA["node_ledger"]
TENOR_ORDER = DATA["coordinate_ordering"]["tenor_bucket"]
MONEY_ORDER = DATA["coordinate_ordering"]["moneyness_bucket"]
RULES = DATA["form_rules_declaration"]

# GK§6.2 行486-493 双轴标注（人工转录，第二次，独立于 entity/harness.py 单独重打）
AXIS_ANNOTATION = {
    "raw Vega": {
        "methodology_status_translation_strength": "Direct source-supported observation",
        "operating_phase": "Phase 2 raw observation",
    },
    "tenor Vega": {
        "methodology_status_translation_strength": "Direct + Derived methodology translation",
        "operating_phase": "Phase 2 bucket observation / Phase 3 diagnostic",
    },
    "forward-segmented Vega": {
        "methodology_status_translation_strength": "Direct source-supported observation + Derived segmentation",
        "operating_phase": "Phase 3 diagnostic",
    },
    "surface Vega": {
        "methodology_status_translation_strength": "Direct + Derived methodology candidate",
        "operating_phase": "Phase 3 diagnostic / Phase 4 input only",
    },
    "grid Vega": {
        "methodology_status_translation_strength": "Direct + Derived methodology candidate",
        "operating_phase": "Phase 3 diagnostic",
    },
    "scenario-stressed Vega": {
        "methodology_status_translation_strength": "Strategy Mapping / Future Engineering Candidate",
        "operating_phase": "Phase 3 scenario diagnostic / Phase 4 governance input",
    },
}

w_tau = {k: F(v) for k, v in RULES["tenor_weight"]["w_tau"].items()}
k = F(RULES["scenario_stress"]["k_fixed_response_coefficient"])
multiplier = F(1) + k

output = {}

# ---- 1. raw Vega ----
output["raw Vega"] = {
    "axis_annotation": AXIS_ANNOTATION["raw Vega"],
    "components": [
        {"component_id": n["node_id"], "value": str(F(n["raw_vega"])), "lineage": "node_ledger:" + n["node_id"]}
        for n in NODES
    ],
}

# ---- 2/3. tenor Vega & forward-segmented Vega：groupby 分桶（分叉点：分组机制非手工dict累加） ----
def bucket_by(key_fn, order):
    sorted_nodes = sorted(NODES, key=key_fn)
    grouped = {k_: list(g) for k_, g in groupby(sorted_nodes, key=key_fn)}
    comps = []
    for tau in order:
        members = grouped.get(tau)
        if members:
            val = sum((w_tau[tau] * F(m["raw_vega"]) for m in members), F(0))
            comps.append({
                "component_id": tau,
                "value": str(val),
                "lineage": "node_ledger:" + "+".join(m["node_id"] for m in members),
            })
    return comps

output["tenor Vega"] = {
    "axis_annotation": AXIS_ANNOTATION["tenor Vega"],
    "components": bucket_by(lambda n: n["tenor_bucket"], TENOR_ORDER),
}
output["forward-segmented Vega"] = {
    "axis_annotation": AXIS_ANNOTATION["forward-segmented Vega"],
    "components": bucket_by(lambda n: n["tenor_bucket"], TENOR_ORDER),  # 占位：forward_segment=tenor_bucket
    "placeholder_note": "forward_segment(n)=tenor_bucket(n)，TPL1-GK14-01占位桩，非claim语义等价",
}

# ---- 4/5. surface Vega & grid Vega：defaultdict + 生成器求和（分叉点：无groupby，直接键控累加） ----
cell_map = defaultdict(list)
for n in NODES:
    cell_map[(n["tenor_bucket"], n["moneyness_bucket"])].append(n)

def cell_value(cell):
    return sum((F(m["raw_vega"]) for m in cell_map[cell]), F(0))

surface_components = [
    {
        "component_id": f"{tau}|{m}",
        "value": str(cell_value((tau, m))),
        "lineage": "node_ledger:" + "+".join(x["node_id"] for x in cell_map[(tau, m)]),
    }
    for tau in TENOR_ORDER for m in MONEY_ORDER if (tau, m) in cell_map
]
output["surface Vega"] = {
    "axis_annotation": AXIS_ANNOTATION["surface Vega"],
    "components": surface_components,
    "scenario_set_candidate": RULES["surface_scenario_set_candidate"],
    "scenario_set_status": "未冻结，候选枚举，本形态未对其执行冲击计算",
}

grid_components = [
    {
        "component_id": f"{cell[0]}|{cell[1]}",
        "value": str(cell_value(cell)),
        "lineage": "node_ledger:" + "+".join(x["node_id"] for x in members),
    }
    for cell, members in cell_map.items()
]
output["grid Vega"] = {
    "axis_annotation": AXIS_ANNOTATION["grid Vega"],
    "components": grid_components,
    "grid_schema_note": "本根工程裁定，复用tenor_bucket×moneyness_bucket坐标，不外推为production grid；correlation matrix出域不计算",
}

# ---- 6. scenario-stressed Vega：列表推导式 + 内置sum（分叉点：无显式for累加循环） ----
stressed_list = [(n["node_id"], F(n["raw_vega"]) * multiplier) for n in NODES]
stressed_components = [
    {"component_id": nid, "value": str(v), "lineage": "node_ledger:" + nid}
    for nid, v in stressed_list
]
stressed_components.append({
    "component_id": "aggregate_total",
    "value": str(sum((v for _, v in stressed_list), F(0))),
    "lineage": "node_ledger:" + "+".join(nid for nid, _ in stressed_list),
})
output["scenario-stressed Vega"] = {
    "axis_annotation": AXIS_ANNOTATION["scenario-stressed Vega"],
    "components": stressed_components,
    "scenario_id": RULES["scenario_stress"]["scenario_id"],
    "vol_shock": RULES["scenario_stress"]["vol_shock"],
    "action_rule_form": RULES["scenario_stress"]["action_rule_form"],
    "placeholder_implementation": RULES["scenario_stress"]["placeholder_implementation"],
    "revaluation_supply_ref": RULES["scenario_stress"]["revaluation_supply_ref"],
}

with open("verify/independent_output.json", "w") as f:
    json.dump(output, f, ensure_ascii=False, indent=2)

print("independent recompute done, forms:", list(output.keys()))

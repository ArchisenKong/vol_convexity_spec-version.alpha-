"""
verify/assert_check.py · GK-14 · 断言脚本
step0前置合规 -> 数值比对(裁决13子口径a: bit-exact) -> 附加断言(六形态计数/轴分离标注逐字一致/形态齐备)
"""
import json
import re
from fractions import Fraction as F

LOG = []
def log(msg):
    LOG.append(msg)
    print(msg)

ALL_PASS = True
def check(name, cond, detail=""):
    global ALL_PASS
    status = "PASS" if cond else "FAIL"
    if not cond:
        ALL_PASS = False
    log(f"[{status}] {name}" + (f" — {detail}" if detail else ""))
    return cond

# ============ step0(i) input人造性核验 ============
with open("entity/input_data.json", encoding="utf-8") as f:
    input_data = json.load(f)
check("step0(i) _data_source核验", input_data.get("_data_source") == "synthetic_hand_constructed",
      f"实际值={input_data.get('_data_source')!r}")

# ============ step0(ii) harness.py 静态扫描：无数据源接入 ============
FORBIDDEN_PATTERNS = [
    r"\bimport\s+requests\b", r"\bimport\s+urllib\b", r"\bimport\s+socket\b",
    r"\bimport\s+yfinance\b", r"\bimport\s+ibapi\b", r"\bimport\s+ib_insync\b",
    r"\bimport\s+pandas_datareader\b",
    r"\bfrom\s+requests\b", r"\bfrom\s+urllib\b", r"\bfrom\s+socket\b",
    r"\bfrom\s+yfinance\b", r"\bfrom\s+ibapi\b", r"\bfrom\s+ib_insync\b",
    r"\bfrom\s+pandas_datareader\b",
    # W-5 bare import 形态（KD裁定D4，20260711）
    r"^\s*import\s+(requests|urllib|socket|yfinance|ibapi|ib_insync|pandas_datareader)\b",
]

def strip_comments_and_docstrings(src: str) -> str:
    # 剥离三引号docstring
    src = re.sub(r'"""[\s\S]*?"""', "", src)
    src = re.sub(r"'''[\s\S]*?'''", "", src)
    # 剥离行内 # 注释
    lines = []
    for line in src.splitlines():
        if "#" in line:
            line = line.split("#", 1)[0]
        lines.append(line)
    return "\n".join(lines)

with open("entity/harness.py", encoding="utf-8") as f:
    harness_src_raw = f.read()
harness_src_clean = strip_comments_and_docstrings(harness_src_raw)

hits = []
for pat in FORBIDDEN_PATTERNS:
    for m in re.finditer(pat, harness_src_clean, flags=re.MULTILINE):
        hits.append((pat, m.group(0)))
check("step0(ii) harness.py forbidden模式扫描(剥离注释/docstring后)", len(hits) == 0,
      f"命中数={len(hits)} " + (str(hits) if hits else ""))

# ============ step0(iii) independent_recompute.py 路径独立性核验 ============
with open("verify/independent_recompute.py", encoding="utf-8") as f:
    indep_src_raw = f.read()

# 剥离注释/docstring后再判定实际耦合（docstring内的"不import harness"独立性自述属预期文本，非代码耦合，
# 若在剥离前的原始文本上做字符串匹配会对该自述产生假阳性——本脚本改在 indep_clean 上判定，剥离前命中行号仅作留痕展示）
indep_clean = strip_comments_and_docstrings(indep_src_raw)
no_harness_import = not re.search(r"\bimport\s+harness\b|\bfrom\s+harness\b", indep_clean)
no_harness_output_read = "harness_output.json" not in indep_clean

# 人工grep交叉核验："harness"字样命中位置需全部落在docstring内
harness_word_leftover = "harness" in indep_clean.lower()
raw_harness_hits = [i for i, line in enumerate(indep_src_raw.splitlines(), 1) if "harness" in line.lower()]

check("step0(iii)-a 未import harness模块", no_harness_import)
check("step0(iii)-b 未读取harness_output.json", no_harness_output_read)
check("step0(iii)-c 剥离docstring/注释后0处harness字样残留", not harness_word_leftover,
      f"剥离前命中行号(应全部落在docstring/#注释内，非可执行代码)={raw_harness_hits}")

# ============ 数值比对：harness_output vs independent_output ============
with open("entity/harness_output.json", encoding="utf-8") as f:
    harness_out = json.load(f)
with open("verify/independent_output.json", encoding="utf-8") as f:
    indep_out = json.load(f)

SIX_FORMS = ["raw Vega", "tenor Vega", "forward-segmented Vega", "surface Vega", "grid Vega", "scenario-stressed Vega"]

comparison_rows = []
numeric_all_zero = True
for form in SIX_FORMS:
    h_comps = {c["component_id"]: c["value"] for c in harness_out[form]["components"]}
    i_comps = {c["component_id"]: c["value"] for c in indep_out[form]["components"]}
    assert set(h_comps.keys()) == set(i_comps.keys()), f"{form} 分量集合不一致: {h_comps.keys()} vs {i_comps.keys()}"
    for cid in h_comps:
        hv = F(h_comps[cid])
        iv = F(i_comps[cid])
        diff = hv - iv
        if diff != 0:
            numeric_all_zero = False
        comparison_rows.append((form, cid, str(hv), str(iv), str(diff)))

check("数值比对：全部分量 diff=0（裁决13子口径a·bit-exact）", numeric_all_zero,
      f"比对分量总数={len(comparison_rows)}")

with open("verify/comparison_table.tsv", "w", encoding="utf-8") as f:
    f.write("form\tcomponent_id\tharness_value\tindependent_value\tdiff\tjudgement\n")
    for row in comparison_rows:
        judgement = "限内(0)" if row[4] == "0" else "越限"
        f.write("\t".join(row) + f"\t{judgement}\n")

# ============ 附加断言① 六形态计数=6且集合一致 ============
check("附加断言① 六形态计数=6且集合与GK§6.2一致",
      set(harness_out.keys()) == set(SIX_FORMS) and set(indep_out.keys()) == set(SIX_FORMS),
      f"harness集合={set(harness_out.keys())}")

# ============ 附加断言② 轴分离标注齐备+与GK§6.2源文逐字一致（独立锚定源文，不复用harness/独立复算侧转录） ============
GK_SOURCE_PATH = "/mnt/project/Greeks_管理方法论主文档_v0_1_2-freeze_交叉一致性修正版_20260616.md"
with open(GK_SOURCE_PATH, encoding="utf-8") as f:
    gk_text = f.read()
sec_start = gk_text.index("### 6.2")
sec_end = gk_text.index("### 6.3", sec_start)
section = gk_text[sec_start:sec_end]
table_rows = [ln for ln in section.splitlines() if ln.strip().startswith("|")]
data_rows = [r for r in table_rows if not r.strip().startswith("|---") and "Vega 形态" not in r]

source_axis = {}
for r in data_rows:
    cells = [c.strip() for c in r.strip().strip("|").split("|")]
    if len(cells) >= 3:
        source_axis[cells[0]] = {
            "methodology_status_translation_strength": cells[1],
            "operating_phase": cells[2],
        }

check("源文抽取六形态齐备（供断言基准）", set(source_axis.keys()) == set(SIX_FORMS),
      f"源文抽取集合={set(source_axis.keys())}")

axis_ok = True
axis_detail = []
for form in SIX_FORMS:
    for side_name, side_out in [("harness", harness_out), ("independent", indep_out)]:
        ann = side_out[form]["axis_annotation"]
        # 两轴字段须独立存在，不得合并为单一"layer"/"tier"字段
        has_two_separate_keys = set(ann.keys()) == {"methodology_status_translation_strength", "operating_phase"}
        matches_source = (ann["methodology_status_translation_strength"] == source_axis[form]["methodology_status_translation_strength"]
                           and ann["operating_phase"] == source_axis[form]["operating_phase"])
        if not (has_two_separate_keys and matches_source):
            axis_ok = False
            axis_detail.append((form, side_name, ann, source_axis[form]))

check("附加断言② 轴分离标注齐备+两轴不合并+与GK§6.2源文（独立程序化抽取，非复用转录）逐字一致",
      axis_ok, "" if axis_ok else f"不一致明细={axis_detail}")

# ============ 附加断言③ 形态齐备：多分量度量，分量携带source_ref/lineage指针 ============
shape_ok = True
shape_detail = []
for side_name, side_out in [("harness", harness_out), ("independent", indep_out)]:
    for form in SIX_FORMS:
        comps = side_out[form]["components"]
        if len(comps) < 2:
            shape_ok = False
            shape_detail.append((side_name, form, "分量数<2"))
        for c in comps:
            if "lineage" not in c or not c["lineage"]:
                shape_ok = False
                shape_detail.append((side_name, form, c.get("component_id"), "缺lineage指针"))

check("附加断言③ 形态齐备：每形态≥2分量，每分量携带source_ref/lineage可追溯指针",
      shape_ok, "" if shape_ok else f"缺陷明细={shape_detail}")

# ============ 汇总 ============
log("")
log(f"总体判定：{'PASS' if ALL_PASS else 'FAIL'}")

with open("verify/assert_log.txt", "w", encoding="utf-8") as f:
    f.write("\n".join(LOG) + "\n")

import sys
sys.exit(0 if ALL_PASS else 1)

"""
entity/harness.py · GK-14 Vega六形态（GK版）· 一次性夹具（B段）
命令式风格：显式for循环+dict累加。不建常设pipeline，不接任何数据源。
"""
import json
from fractions import Fraction as F

with open("entity/input_data.json") as f:
    DATA = json.load(f)

NODES = DATA["node_ledger"]
TENOR_ORDER = DATA["coordinate_ordering"]["tenor_bucket"]
MONEY_ORDER = DATA["coordinate_ordering"]["moneyness_bucket"]
RULES = DATA["form_rules_declaration"]

# GK§6.2 行486-493 双轴标注（人工转录，第一次）
AXIS_ANNOTATION = {
    "raw Vega": {
        "methodology_status_translation_strength": "Direct source-supported observation",
        "operating_phase": "Phase 2 raw observation",
    },
    "tenor Vega": {
        "methodology_status_translation_strength": "Direct + Derived methodology translation",
        "operating_phase": "Phase 2 bucket observation / Phase 3 diagnostic",
    },
    "forward-segmented Vega": {
        "methodology_status_translation_strength": "Direct source-supported observation + Derived segmentation",
        "operating_phase": "Phase 3 diagnostic",
    },
    "surface Vega": {
        "methodology_status_translation_strength": "Direct + Derived methodology candidate",
        "operating_phase": "Phase 3 diagnostic / Phase 4 input only",
    },
    "grid Vega": {
        "methodology_status_translation_strength": "Direct + Derived methodology candidate",
        "operating_phase": "Phase 3 diagnostic",
    },
    "scenario-stressed Vega": {
        "methodology_status_translation_strength": "Strategy Mapping / Future Engineering Candidate",
        "operating_phase": "Phase 3 scenario diagnostic / Phase 4 governance input",
    },
}

output = {}

# ---- 1. raw Vega ----
raw_components = []
for n in NODES:
    raw_components.append({
        "component_id": n["node_id"],
        "value": str(F(n["raw_vega"])),
        "lineage": "node_ledger:" + n["node_id"],
    })
output["raw Vega"] = {
    "axis_annotation": AXIS_ANNOTATION["raw Vega"],
    "components": raw_components,
}

# ---- 2. tenor Vega (等权 w_tau=1, 类三占位) ----
w_tau = {k: F(v) for k, v in RULES["tenor_weight"]["w_tau"].items()}
tenor_sum = {}
tenor_members = {}
for n in NODES:
    tau = n["tenor_bucket"]
    if tau not in tenor_sum:
        tenor_sum[tau] = F(0)
        tenor_members[tau] = []
    tenor_sum[tau] += w_tau[tau] * F(n["raw_vega"])
    tenor_members[tau].append(n["node_id"])

tenor_components = []
for tau in TENOR_ORDER:
    if tau in tenor_sum:
        tenor_components.append({
            "component_id": tau,
            "value": str(tenor_sum[tau]),
            "lineage": "node_ledger:" + "+".join(tenor_members[tau]),
        })
output["tenor Vega"] = {
    "axis_annotation": AXIS_ANNOTATION["tenor Vega"],
    "components": tenor_components,
}

# ---- 3. forward-segmented Vega (占位: forward_segment = tenor_bucket) ----
fwd_sum = {}
fwd_members = {}
for n in NODES:
    seg = n["tenor_bucket"]  # 占位分段规则 TPL1-GK14-01
    if seg not in fwd_sum:
        fwd_sum[seg] = F(0)
        fwd_members[seg] = []
    fwd_sum[seg] += w_tau[seg] * F(n["raw_vega"])
    fwd_members[seg].append(n["node_id"])

fwd_components = []
for seg in TENOR_ORDER:
    if seg in fwd_sum:
        fwd_components.append({
            "component_id": seg,
            "value": str(fwd_sum[seg]),
            "lineage": "node_ledger:" + "+".join(fwd_members[seg]),
        })
output["forward-segmented Vega"] = {
    "axis_annotation": AXIS_ANNOTATION["forward-segmented Vega"],
    "components": fwd_components,
    "placeholder_note": "forward_segment(n)=tenor_bucket(n)，TPL1-GK14-01占位桩，非claim语义等价",
}

# ---- 4. surface Vega (cell矩阵 + scenario_set候选) ----
cell_sum = {}
cell_members = {}
for n in NODES:
    cell = (n["tenor_bucket"], n["moneyness_bucket"])
    if cell not in cell_sum:
        cell_sum[cell] = F(0)
        cell_members[cell] = []
    cell_sum[cell] += F(n["raw_vega"])
    cell_members[cell].append(n["node_id"])

surface_components = []
for tau in TENOR_ORDER:
    for m in MONEY_ORDER:
        cell = (tau, m)
        if cell in cell_sum:
            surface_components.append({
                "component_id": f"{tau}|{m}",
                "value": str(cell_sum[cell]),
                "lineage": "node_ledger:" + "+".join(cell_members[cell]),
            })
output["surface Vega"] = {
    "axis_annotation": AXIS_ANNOTATION["surface Vega"],
    "components": surface_components,
    "scenario_set_candidate": RULES["surface_scenario_set_candidate"],
    "scenario_set_status": "未冻结，候选枚举，本形态未对其执行冲击计算",
}

# ---- 5. grid Vega (flat cell list，同cell基底) ----
grid_components = []
for cell, val in cell_sum.items():
    grid_components.append({
        "component_id": f"{cell[0]}|{cell[1]}",
        "value": str(val),
        "lineage": "node_ledger:" + "+".join(cell_members[cell]),
    })
output["grid Vega"] = {
    "axis_annotation": AXIS_ANNOTATION["grid Vega"],
    "components": grid_components,
    "grid_schema_note": "本根工程裁定，复用tenor_bucket×moneyness_bucket坐标，不外推为production grid；correlation matrix出域不计算",
}

# ---- 6. scenario-stressed Vega (线性近似 k=1/20) ----
k = F(RULES["scenario_stress"]["k_fixed_response_coefficient"])
multiplier = F(1) + k
stressed_components = []
total = F(0)
for n in NODES:
    sv = F(n["raw_vega"]) * multiplier
    total += sv
    stressed_components.append({
        "component_id": n["node_id"],
        "value": str(sv),
        "lineage": "node_ledger:" + n["node_id"],
    })
stressed_components.append({
    "component_id": "aggregate_total",
    "value": str(total),
    "lineage": "node_ledger:" + "+".join(n["node_id"] for n in NODES),
})
output["scenario-stressed Vega"] = {
    "axis_annotation": AXIS_ANNOTATION["scenario-stressed Vega"],
    "components": stressed_components,
    "scenario_id": RULES["scenario_stress"]["scenario_id"],
    "vol_shock": RULES["scenario_stress"]["vol_shock"],
    "action_rule_form": RULES["scenario_stress"]["action_rule_form"],
    "placeholder_implementation": RULES["scenario_stress"]["placeholder_implementation"],
    "revaluation_supply_ref": RULES["scenario_stress"]["revaluation_supply_ref"],
}

with open("entity/harness_output.json", "w") as f:
    json.dump(output, f, ensure_ascii=False, indent=2)

print("harness done, forms:", list(output.keys()))

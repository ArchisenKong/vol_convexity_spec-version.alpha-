#!/usr/bin/env python3
"""
T3-03 独立复算脚本 · v1.0 · 20260711

独立性声明：
- 本脚本只读取 entity/input_data.json（clean 人造 input），不 import entity/harness.py，
  不读取 entity/harness_output.json，不取用 harness 任何中间量。
- 实现路径与 harness.py 在核心计算表达式上分叉：
  分桶用 itertools.groupby（非 harness 的手工 dict 累加）；
  求和用生成器表达式 sum(...)（非 harness 的 for 循环 += 累加）；
  risk-equivalent 直接从 raw legs 按 tenor 过滤求和推导（非 harness 经由 proxy_slice 中间产物链式推导），
    确保风险等价折算这一非平凡核心分叉点落在独立路径上，而非只在外壳分叉。
- 平凡 primitive（fractions.Fraction 精确有理数运算本身）与 harness 共用，符合"平凡primitive可共用"许可。
"""
import json
from fractions import Fraction as F
from itertools import groupby
from pathlib import Path

HERE = Path(__file__).parent
INPUT_PATH = HERE.parent / "entity" / "input_data.json"
OUTPUT_PATH = HERE / "independent_output.json"


def load_clean_input():
    with open(INPUT_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def as_frac(leg):
    return {**leg, **{k: F(leg[k]) for k in ("moneyness", "delta", "gamma", "vega", "theta", "rho")}}


def recompute_raw(legs):
    return {
        leg["leg_id"]: {k: str(leg[k]) for k in ("moneyness", "delta", "gamma", "vega", "theta", "rho")}
        for leg in legs
    }


def recompute_proxy(legs, metrics):
    key = lambda l: l["tenor_days"]
    out = {}
    for tenor, group in groupby(sorted(legs, key=key), key=key):
        grp = list(group)
        out[f"{tenor}D"] = {m: str(sum((g[m] for g in grp), F(0))) for m in metrics}
    return out


def recompute_diagnostic(legs):
    weighted = sum((abs(l["gamma"]) * l["moneyness"] for l in legs), F(0))
    total_abs_gamma = sum((abs(l["gamma"]) for l in legs), F(0))
    gamma_center = weighted / total_abs_gamma

    tenors = {l["tenor_days"] for l in legs}
    bucket_abs_vega = {
        t: sum((abs(l["vega"]) for l in legs if l["tenor_days"] == t), F(0))
        for t in tenors
    }
    vega_concentration = max(bucket_abs_vega.values()) / sum(bucket_abs_vega.values(), F(0))
    return {"gamma_center": str(gamma_center), "vega_concentration": str(vega_concentration)}


def recompute_risk_equivalent(legs, r):
    # \u76f4\u63a5\u4ece raw legs \u6309 tenor \u8fc7\u6ee4\u6c42\u548c\uff0c\u4e0d\u7ecf\u8fc7 proxy \u4e2d\u95f4\u4ea7\u7269\uff08\u4e0e harness \u94fe\u5f0f\u63a8\u5bfc\u5206\u53c9\uff09
    vega_30 = sum((l["vega"] for l in legs if l["tenor_days"] == 30), F(0))
    vega_90 = sum((l["vega"] for l in legs if l["tenor_days"] == 90), F(0))
    gamma_30 = sum((l["gamma"] for l in legs if l["tenor_days"] == 30), F(0))
    gamma_90 = sum((l["gamma"] for l in legs if l["tenor_days"] == 90), F(0))
    return {
        "vega_90D_equiv": str(vega_30 * r + vega_90),
        "gamma_90D_equiv": str(gamma_30 * r + gamma_90),
    }


def recompute_scenario(legs, delta_s, vega_mult):
    stressed = [
        {
            "leg_id": l["leg_id"],
            "stressed_delta": str(l["delta"] + l["gamma"] * delta_s),
            "stressed_vega": str(l["vega"] * vega_mult),
        }
        for l in legs
    ]
    delta_total = sum((F(s["stressed_delta"]) for s in stressed), F(0))
    vega_total = sum((F(s["stressed_vega"]) for s in stressed), F(0))
    return stressed, str(delta_total), str(vega_total)


def recompute_governance_input(risk_equiv, delta_total_s1, vega_total_s1):
    return {
        "risk_equivalent.vega_90D_equiv": risk_equiv["vega_90D_equiv"],
        "risk_equivalent.gamma_90D_equiv": risk_equiv["gamma_90D_equiv"],
        "scenario_stressed.delta_total_S1": delta_total_s1,
        "scenario_stressed.vega_total_S1": vega_total_s1,
    }


def main():
    data = load_clean_input()
    assert data.get("_data_source") == "synthetic_hand_constructed"

    legs = [as_frac(leg) for leg in data["raw_ledger"]]
    decl = data["aggregation_declaration"]

    raw = recompute_raw(legs)
    proxy = recompute_proxy(legs, decl["proxy"]["metrics"])
    diagnostic = recompute_diagnostic(legs)
    risk_equiv = recompute_risk_equivalent(legs, F(decl["risk_equivalent"]["r_30_to_90"]))
    per_leg, delta_total_s1, vega_total_s1 = recompute_scenario(
        legs, F(decl["scenario_stressed"]["delta_S_dollar"]), F(decl["scenario_stressed"]["vega_multiplier"])
    )
    governance_input = recompute_governance_input(risk_equiv, delta_total_s1, vega_total_s1)

    result = {
        "raw": raw,
        "proxy": proxy,
        "diagnostic": diagnostic,
        "risk_equivalent": risk_equiv,
        "scenario_stressed": {"per_leg": per_leg, "delta_total_S1": delta_total_s1, "vega_total_S1": vega_total_s1},
        "governance_input": governance_input,
    }

    with open(OUTPUT_PATH, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)

    print(f"\u72ec\u7acb\u590d\u7b97\u5b8c\u6210\uff0c\u8f93\u51fa\u5199\u5165 {OUTPUT_PATH}")


if __name__ == "__main__":
    main()

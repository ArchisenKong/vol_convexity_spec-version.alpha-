#!/usr/bin/env python3
"""
T3-03 一次性 harness · v1.0 · 20260711

用途：喂入 entity/input_data.json（人造 raw ledger + 聚合声明），实际跑出
六 slice 状态值 + 三项标注，写出 entity/harness_output.json。

纪律：
- 只负责 喂入 -> 驱动 -> 捕获，不建常设 pipeline / 数据接口 / 持久服务。
- 不接任何数据源（本文件不含任何网络/IBKR/QuantConnect/外部文件数据源调用）。
- 全程使用 fractions.Fraction 精确有理数运算，不引入超越函数。
"""
import json
from fractions import Fraction as F
from pathlib import Path

HERE = Path(__file__).parent
INPUT_PATH = HERE / "input_data.json"
OUTPUT_PATH = HERE / "harness_output.json"

# T3\u00a713.2 / T2/00A\u00a74 \u884c77-82 \u539f\u6587\u76f4\u63a5\u6458\u5f55\uff08\u4e0d\u53e6\u9020\u8bed\u4e49\uff09
SLICE_TAGS = {
    "raw": {
        "source_phase": "Phase 2",
        "aggregation_scope": "lot / leg / tenor / side / option type / moneyness / expiry \u7684\u539f\u59cb\u8282\u70b9",
        "allowed_usage": "\u4e8b\u5b9e\u8bb0\u5f55\u3001lineage \u4e0e\u540e\u7eed\u8bca\u65ad\u8f93\u5165\uff1b\u4e0d\u5f97\u76f4\u63a5\u751f\u6210 candidate \u6216\u88c1\u51b3"
    },
    "proxy": {
        "source_phase": "Phase 2 observation\uff1b\u53ef\u4f5c\u4e3a Phase 3 input",
        "aggregation_scope": "\u5df2\u58f0\u660e\u538b\u7f29\u3001\u5206\u6876\u6216\u6458\u8981\u8303\u56f4",
        "allowed_usage": "\u89c2\u5bdf\u4e0e\u8bca\u65ad\u8f93\u5165\uff1b\u4e0d\u5f97\u66ff\u4ee3\u5b8c\u6574\u5bf9\u8c61\u72b6\u6001\u6216 constraint stack"
    },
    "diagnostic": {
        "source_phase": "Phase 3",
        "aggregation_scope": "\u5df2\u58f0\u660e diagnostic unit\u3001\u6765\u6e90\u8282\u70b9\u4e0e\u89e3\u91ca\u8303\u56f4",
        "allowed_usage": "\u89e3\u91ca gamma center\u3001vega concentration\u3001theta burn\u3001wing dullness \u7b49\u72b6\u6001\uff0c\u5e76\u53ef\u5f62\u6210 candidate input\uff1b\u4e0d\u5f97\u6279\u51c6\u52a8\u4f5c"
    },
    "risk_equivalent": {
        "source_phase": "Phase 3\uff1b\u53ef\u4f5c\u4e3a Phase 4 input",
        "aggregation_scope": "\u5df2\u58f0\u660e risk-equivalence rule\u3001\u805a\u5408\u8303\u56f4\u4e0e\u9002\u7528\u5047\u8bbe",
        "allowed_usage": "\u8bca\u65ad\u6216\u6cbb\u7406\u8f93\u5165\uff1b\u672a\u58f0\u660e\u7b49\u4ef7\u89c4\u5219\u65f6\u4e0d\u5f97\u4f7f\u7528"
    },
    "scenario_stressed": {
        "source_phase": "Phase 3\uff1b\u53ef\u4f5c\u4e3a Phase 4 input",
        "aggregation_scope": "\u5df2\u58f0\u660e\u4ef7\u683c\u3001IV\u3001skew\u3001term structure\u3001liquidity \u60c5\u666f\u53ca\u8282\u70b9\u8303\u56f4",
        "allowed_usage": "\u538b\u529b\u8bca\u65ad\u4e0e\u6cbb\u7406\u8f93\u5165\uff1b\u4e0d\u5f97\u66ff\u4ee3\u6cbb\u7406\u88c1\u51b3"
    },
    "governance_input": {
        "source_phase": "Phase 4",
        "aggregation_scope": "\u5df2\u58f0\u660e\u8fdb\u5165 constraint stack \u7684\u8303\u56f4\u4e0e lineage",
        "allowed_usage": "\u8f85\u52a9 approval / block / manual review\uff1b\u4e0d\u7b49\u4e8e governance decision"
    }
}


def load_input():
    with open(INPUT_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def to_frac_leg(leg):
    out = dict(leg)
    for k in ("moneyness", "delta", "gamma", "vega", "theta", "rho"):
        out[k] = F(leg[k])
    return out


def build_raw_slice(legs):
    components = []
    for leg in legs:
        components.append({
            "leg_id": leg["leg_id"],
            "tenor_days": leg["tenor_days"],
            "side": leg["side"],
            "option_type": leg["option_type"],
            "moneyness": str(leg["moneyness"]),
            "delta": str(leg["delta"]),
            "gamma": str(leg["gamma"]),
            "vega": str(leg["vega"]),
            "theta": str(leg["theta"]),
            "rho": str(leg["rho"]),
            "source_ref": leg["leg_id"]
        })
    return components


def build_proxy_slice(legs, decl):
    group_field = decl["group_by"]
    metrics = decl["metrics"]
    buckets = {}
    bucket_members = {}
    for leg in legs:
        key = leg[group_field]
        if key not in buckets:
            buckets[key] = {m: F(0) for m in metrics}
            bucket_members[key] = []
        for m in metrics:
            buckets[key][m] += leg[m]
        bucket_members[key].append(leg["leg_id"])
    components = []
    for key in sorted(buckets.keys()):
        entry = {"bucket": f"{key}D", "source_ref": bucket_members[key]}
        for m in metrics:
            entry[m] = str(buckets[key][m])
        components.append(entry)
    return components


def build_diagnostic_slice(legs, decl):
    # gamma_center: gamma \u5e45\u503c\u52a0\u6743 moneyness \u5747\u503c
    num = F(0)
    den = F(0)
    for leg in legs:
        g_abs = abs(leg["gamma"])
        num += g_abs * leg["moneyness"]
        den += g_abs
    gamma_center = num / den

    # vega_concentration: \u6700\u5927 tenor \u6876 |vega| \u5360\u603b |vega| \u6bd4\u4f8b
    tenor_vega_abs = {}
    for leg in legs:
        tenor_vega_abs.setdefault(leg["tenor_days"], F(0))
        tenor_vega_abs[leg["tenor_days"]] += abs(leg["vega"])
    total_abs_vega = sum(tenor_vega_abs.values(), F(0))
    max_bucket_abs_vega = max(tenor_vega_abs.values())
    vega_concentration = max_bucket_abs_vega / total_abs_vega

    return [
        {
            "diagnostic_unit": "gamma_center",
            "value": str(gamma_center),
            "source_ref": [leg["leg_id"] for leg in legs],
            "declaration_ref": decl["declaration_ref"]
        },
        {
            "diagnostic_unit": "vega_concentration",
            "value": str(vega_concentration),
            "source_ref": [leg["leg_id"] for leg in legs],
            "declaration_ref": decl["declaration_ref"]
        }
    ]


def build_risk_equivalent_slice(proxy_components, decl):
    r = F(decl["r_30_to_90"])
    by_bucket = {c["bucket"]: c for c in proxy_components}
    vega_30 = F(by_bucket["30D"]["vega"])
    vega_90 = F(by_bucket["90D"]["vega"])
    gamma_30 = F(by_bucket["30D"]["gamma"])
    gamma_90 = F(by_bucket["90D"]["gamma"])

    vega_90_equiv = vega_30 * r + vega_90
    gamma_90_equiv = gamma_30 * r + gamma_90

    return [
        {
            "field": "vega_90D_equiv",
            "value": str(vega_90_equiv),
            "source_ref": ["30D_bucket", "90D_bucket"],
            "declaration_ref": decl["declaration_ref"]
        },
        {
            "field": "gamma_90D_equiv",
            "value": str(gamma_90_equiv),
            "source_ref": ["30D_bucket", "90D_bucket"],
            "declaration_ref": decl["declaration_ref"]
        }
    ]


def build_scenario_stressed_slice(legs, decl):
    delta_s = F(decl["delta_S_dollar"])
    vega_mult = F(decl["vega_multiplier"])
    per_leg = []
    delta_total = F(0)
    vega_total = F(0)
    for leg in legs:
        stressed_delta = leg["delta"] + leg["gamma"] * delta_s
        stressed_vega = leg["vega"] * vega_mult
        delta_total += stressed_delta
        vega_total += stressed_vega
        per_leg.append({
            "leg_id": leg["leg_id"],
            "stressed_delta": str(stressed_delta),
            "stressed_vega": str(stressed_vega),
            "source_ref": leg["leg_id"]
        })
    aggregate = {
        "scenario_id": decl["scenario_id"],
        "delta_total_S1": str(delta_total),
        "vega_total_S1": str(vega_total),
        "source_ref": [leg["leg_id"] for leg in legs],
        "declaration_ref": decl["declaration_ref"]
    }
    return {"per_leg": per_leg, "aggregate": aggregate}


def build_governance_input_slice(risk_equiv_components, scenario_aggregate, decl):
    re_by_field = {c["field"]: c["value"] for c in risk_equiv_components}
    values = {
        "risk_equivalent.vega_90D_equiv": re_by_field["vega_90D_equiv"],
        "risk_equivalent.gamma_90D_equiv": re_by_field["gamma_90D_equiv"],
        "scenario_stressed.delta_total_S1": scenario_aggregate["delta_total_S1"],
        "scenario_stressed.vega_total_S1": scenario_aggregate["vega_total_S1"]
    }
    entries = []
    for field in decl["entry_scope"]:
        entries.append({
            "field": field,
            "value": values[field],
            "lineage": list(decl["lineage_base"]),
            "declaration_ref": decl["declaration_ref"]
        })
    return entries


def main():
    data = load_input()
    assert data.get("_data_source") == "synthetic_hand_constructed"

    legs = [to_frac_leg(leg) for leg in data["raw_ledger"]]
    decl = data["aggregation_declaration"]

    raw_slice = build_raw_slice(legs)
    proxy_slice = build_proxy_slice(legs, decl["proxy"])
    diagnostic_slice = build_diagnostic_slice(legs, decl["diagnostic"])
    risk_equivalent_slice = build_risk_equivalent_slice(proxy_slice, decl["risk_equivalent"])
    scenario_slice = build_scenario_stressed_slice(legs, decl["scenario_stressed"])
    governance_input_slice = build_governance_input_slice(
        risk_equivalent_slice, scenario_slice["aggregate"], decl["governance_input"]
    )

    output = {
        "raw": {"tags": SLICE_TAGS["raw"], "components": raw_slice},
        "proxy": {"tags": SLICE_TAGS["proxy"], "components": proxy_slice},
        "diagnostic": {"tags": SLICE_TAGS["diagnostic"], "components": diagnostic_slice},
        "risk_equivalent": {"tags": SLICE_TAGS["risk_equivalent"], "components": risk_equivalent_slice},
        "scenario_stressed": {
            "tags": SLICE_TAGS["scenario_stressed"],
            "components": scenario_slice["per_leg"] + [scenario_slice["aggregate"]]
        },
        "governance_input": {"tags": SLICE_TAGS["governance_input"], "components": governance_input_slice}
    }

    with open(OUTPUT_PATH, "w", encoding="utf-8") as f:
        json.dump(output, f, ensure_ascii=False, indent=2)

    print(f"harness \u5b8c\u6210\uff0c\u8f93\u51fa\u5199\u5165 {OUTPUT_PATH}")
    for slice_name in output:
        print(f"  - {slice_name}: {len(output[slice_name]['components'])} \u4e2a\u5206\u91cf")


if __name__ == "__main__":
    main()

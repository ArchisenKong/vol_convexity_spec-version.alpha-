#!/usr/bin/env python3
"""
T3-03 断言脚本 · v1.0 · 20260711

依任务包§3 D段三步顺序：
  step0 前置合规断言（人造input / harness无数据源接入 / 复算路径独立）
  step1-2 数值比对（harness_output.json vs verify/independent_output.json，逐分量，容差子口径(a) bit-exact）
  step3 附加断言（六slice全部在场 / 标注齐备 / 形态齐备）
"""
import json
import re
from fractions import Fraction as F
from pathlib import Path

HERE = Path(__file__).parent
ENTITY = HERE.parent / "entity"
INPUT_DATA_PATH = ENTITY / "input_data.json"
HARNESS_SRC_PATH = ENTITY / "harness.py"
HARNESS_OUTPUT_PATH = ENTITY / "harness_output.json"
INDEPENDENT_SRC_PATH = HERE / "independent_recompute.py"
INDEPENDENT_OUTPUT_PATH = HERE / "independent_output.json"
LOG_PATH = HERE / "assert_log.txt"

FORBIDDEN_PATTERNS = [
    r"\bibkr\b", r"\bibapi\b", r"ib_insync", r"quantconnect", r"QCAlgorithm",
    r"requests\.", r"urllib", r"socket\.", r"yfinance", r"pandas_datareader",
    r"open\(.*(http|ftp)",
]
FORBIDDEN_BARE_IMPORT_PATTERNS = [
    r"^\s*import\s+(requests|urllib|socket|yfinance|ibapi|ib_insync|pandas_datareader)\b",
    r"^\s*from\s+(requests|urllib|socket|yfinance|ibapi|ib_insync|pandas_datareader)\b",
]

# T3\u00a713.2 \u884c1281-1292 \u539f\u6587\u76f4\u63a5\u6458\u5f55\uff0c\u4f5c\u4e3a\u6807\u6ce8\u9f50\u5907\u6bd4\u5bf9\u57fa\u51c6\uff08\u4e0e harness.py \u5185 SLICE_TAGS \u72ec\u7acb\u8f6c\u5f55\uff0c\u4e0d\u76f4\u63a5 import\uff09
REFERENCE_TAGS = {
    "raw": {
        "source_phase": "Phase 2",
        "aggregation_scope": "lot / leg / tenor / side / option type / moneyness / expiry 的原始节点",
        "allowed_usage": "事实记录、lineage 与后续诊断输入；不得直接生成 candidate 或裁决"
    },
    "proxy": {
        "source_phase": "Phase 2 observation；可作为 Phase 3 input",
        "aggregation_scope": "已声明压缩、分桶或摘要范围",
        "allowed_usage": "观察与诊断输入；不得替代完整对象状态或 constraint stack"
    },
    "diagnostic": {
        "source_phase": "Phase 3",
        "aggregation_scope": "已声明 diagnostic unit、来源节点与解释范围",
        "allowed_usage": "解释 gamma center、vega concentration、theta burn、wing dullness 等状态，并可形成 candidate input；不得批准动作"
    },
    "risk_equivalent": {
        "source_phase": "Phase 3；可作为 Phase 4 input",
        "aggregation_scope": "已声明 risk-equivalence rule、聚合范围与适用假设",
        "allowed_usage": "诊断或治理输入；未声明等价规则时不得使用"
    },
    "scenario_stressed": {
        "source_phase": "Phase 3；可作为 Phase 4 input",
        "aggregation_scope": "已声明价格、IV、skew、term structure、liquidity 情景及节点范围",
        "allowed_usage": "压力诊断与治理输入；不得替代治理裁决"
    },
    "governance_input": {
        "source_phase": "Phase 4",
        "aggregation_scope": "已声明进入 constraint stack 的范围与lineage",
        "allowed_usage": "辅助 approval / block / manual review；不等于 governance decision"
    }
}


def strip_comments_and_docstrings(src: str) -> str:
    # \u5265\u79bb\u4e09\u5f15\u53f7 docstring/\u5b57\u7b26\u4e32\u5757
    src = re.sub(r'"""[\s\S]*?"""', "", src)
    src = re.sub(r"'''[\s\S]*?'''", "", src)
    # \u9010\u884c\u5265\u79bb # \u6ce8\u91ca\uff08\u7c97\u7565\u5904\u7406\uff0c\u672c\u6587\u4ef6\u65e0\u5b57\u7b26\u4e32\u5185 # \u7684\u8fb9\u754c\u60c5\u51b5\uff09
    lines = []
    for line in src.splitlines():
        idx = line.find("#")
        lines.append(line if idx == -1 else line[:idx])
    return "\n".join(lines)


def step0_i_input_synthetic(log):
    with open(INPUT_DATA_PATH, "r", encoding="utf-8") as f:
        data = json.load(f)
    ok = data.get("_data_source") == "synthetic_hand_constructed"
    log.append(f"[step0-i] input `_data_source` = {data.get('_data_source')!r} -> {'PASS' if ok else 'FAIL'}")
    return ok


def step0_ii_harness_no_datasource(log):
    src = HARNESS_SRC_PATH.read_text(encoding="utf-8")
    stripped = strip_comments_and_docstrings(src)
    hits = []
    for pat in FORBIDDEN_PATTERNS:
        if re.search(pat, stripped, re.IGNORECASE):
            hits.append(("forbidden_call_pattern", pat))
    for pat in FORBIDDEN_BARE_IMPORT_PATTERNS:
        if re.search(pat, stripped, re.IGNORECASE | re.MULTILINE):
            hits.append(("forbidden_bare_import_pattern(W-5)", pat))
    ok = len(hits) == 0
    log.append(f"[step0-ii] harness.py 静态扫描（剥离注释/docstring后）命中 forbidden 模式数 = {len(hits)} -> {'PASS' if ok else 'FAIL'}")
    if hits:
        for kind, pat in hits:
            log.append(f"           命中: {kind} :: {pat}")
    return ok


def step0_iii_independent_no_coupling(log):
    src = INDEPENDENT_SRC_PATH.read_text(encoding="utf-8")
    stripped = strip_comments_and_docstrings(src)
    coupling_patterns = [
        r"import\s+harness",
        r"from\s+\S*harness\S*\s+import",
        r"harness_output",
    ]
    hits = [pat for pat in coupling_patterns if re.search(pat, stripped, re.IGNORECASE)]
    ok = len(hits) == 0
    log.append(f"[step0-iii] independent_recompute.py 剥离注释/docstring后扫描 harness 耦合痕迹 = {len(hits)} -> {'PASS' if ok else 'FAIL'}")
    if hits:
        for pat in hits:
            log.append(f"            命中: {pat}")
    # \u4eba\u5de5 grep \u4ea4\u53c9\u6838\u9a8c\uff1a\u672a\u5265\u79bb\u7248\u672c\u4e2d\u5168\u90e8"harness"\u5b57\u6837\u547d\u4e2d\u662f\u5426\u5747\u843d\u5728 docstring \u58f0\u660e\u5185
    raw_hits = [i for i, line in enumerate(src.splitlines(), 1) if "harness" in line.lower()]
    log.append(f"            原始源码中含'harness'字样的行号（人工核验用）: {raw_hits}")
    return ok


def to_frac(x):
    return F(x)


def compare_scalar(path, a, b, log, rows):
    fa, fb = to_frac(a), to_frac(b)
    diff = fa - fb
    ok = diff == 0
    rows.append((path, str(fa), str(fb), str(diff), "限内(0)" if ok else "越限"))
    return ok


def step1_2_numeric_compare(log):
    with open(HARNESS_OUTPUT_PATH, "r", encoding="utf-8") as f:
        h = json.load(f)
    with open(INDEPENDENT_OUTPUT_PATH, "r", encoding="utf-8") as f:
        r = json.load(f)

    rows = []
    all_ok = True

    # raw: 4 legs x 6 fields(moneyness,delta,gamma,vega,theta,rho)
    h_raw_by_leg = {c["leg_id"]: c for c in h["raw"]["components"]}
    for leg_id, r_leg in r["raw"].items():
        h_leg = h_raw_by_leg[leg_id]
        for field in ("moneyness", "delta", "gamma", "vega", "theta", "rho"):
            ok = compare_scalar(f"raw.{leg_id}.{field}", h_leg[field], r_leg[field], log, rows)
            all_ok &= ok

    # proxy: 2 buckets x 3 metrics
    h_proxy_by_bucket = {c["bucket"]: c for c in h["proxy"]["components"]}
    for bucket, r_bucket in r["proxy"].items():
        h_bucket = h_proxy_by_bucket[bucket]
        for metric in ("delta", "gamma", "vega"):
            ok = compare_scalar(f"proxy.{bucket}.{metric}", h_bucket[metric], r_bucket[metric], log, rows)
            all_ok &= ok

    # diagnostic: gamma_center, vega_concentration
    h_diag_by_unit = {c["diagnostic_unit"]: c["value"] for c in h["diagnostic"]["components"]}
    for unit in ("gamma_center", "vega_concentration"):
        ok = compare_scalar(f"diagnostic.{unit}", h_diag_by_unit[unit], r["diagnostic"][unit], log, rows)
        all_ok &= ok

    # risk_equivalent: vega_90D_equiv, gamma_90D_equiv
    h_re_by_field = {c["field"]: c["value"] for c in h["risk_equivalent"]["components"]}
    for field in ("vega_90D_equiv", "gamma_90D_equiv"):
        ok = compare_scalar(f"risk_equivalent.{field}", h_re_by_field[field], r["risk_equivalent"][field], log, rows)
        all_ok &= ok

    # scenario_stressed: per-leg stressed_delta/stressed_vega + aggregate delta_total_S1/vega_total_S1
    h_scenario_per_leg = {c["leg_id"]: c for c in h["scenario_stressed"]["components"] if "leg_id" in c}
    r_scenario_per_leg = {c["leg_id"]: c for c in r["scenario_stressed"]["per_leg"]}
    for leg_id in r_scenario_per_leg:
        for field in ("stressed_delta", "stressed_vega"):
            ok = compare_scalar(
                f"scenario_stressed.{leg_id}.{field}",
                h_scenario_per_leg[leg_id][field], r_scenario_per_leg[leg_id][field], log, rows
            )
            all_ok &= ok
    h_scenario_agg = [c for c in h["scenario_stressed"]["components"] if "scenario_id" in c][0]
    ok = compare_scalar("scenario_stressed.aggregate.delta_total_S1",
                         h_scenario_agg["delta_total_S1"], r["scenario_stressed"]["delta_total_S1"], log, rows)
    all_ok &= ok
    ok = compare_scalar("scenario_stressed.aggregate.vega_total_S1",
                         h_scenario_agg["vega_total_S1"], r["scenario_stressed"]["vega_total_S1"], log, rows)
    all_ok &= ok

    # governance_input: 4 entries
    h_gov_by_field = {c["field"]: c["value"] for c in h["governance_input"]["components"]}
    for field, r_value in r["governance_input"].items():
        ok = compare_scalar(f"governance_input.{field}", h_gov_by_field[field], r_value, log, rows)
        all_ok &= ok

    log.append(f"[step1-2] 逐分量比对共 {len(rows)} 项，越限 {sum(1 for row in rows if row[4]=='越限')} 项 -> {'PASS' if all_ok else 'FAIL'}")
    return all_ok, rows


def step3_additional_assertions(log):
    with open(HARNESS_OUTPUT_PATH, "r", encoding="utf-8") as f:
        h = json.load(f)

    # \u2460 \u516d slice \u5168\u90e8\u5728\u573a
    expected_slices = {"raw", "proxy", "diagnostic", "risk_equivalent", "scenario_stressed", "governance_input"}
    present_slices = set(h.keys())
    ok1 = present_slices == expected_slices
    log.append(f"[step3-\u2460] slice \u8ba1\u6570 = {len(present_slices)}\uff0c\u9884\u671f\u96c6\u5408\u4e00\u81f4 -> {'PASS' if ok1 else 'FAIL'} ({sorted(present_slices)})")

    # \u2461 \u6807\u6ce8\u9f50\u5907\uff1a\u4e09\u5b57\u6bb5\u5728\u573a\u4e14\u4e0e T3\u00a713.2 \u539f\u6587\u4e00\u81f4
    ok2 = True
    for slice_name, ref in REFERENCE_TAGS.items():
        tags = h[slice_name]["tags"]
        for field in ("source_phase", "aggregation_scope", "allowed_usage"):
            match = tags.get(field) == ref[field]
            ok2 &= match
            if not match:
                log.append(f"           标注不一致: {slice_name}.{field} harness={tags.get(field)!r} ref={ref[field]!r}")
    log.append(f"[step3-\u2461] \u516d slice \u00d7 \u4e09\u5b57\u6bb5\u6807\u6ce8\u9f50\u5907\u4e14\u53d6\u503c\u4e0e T3\u00a713.2\u8868\u4e00\u81f4 -> {'PASS' if ok2 else 'FAIL'}")

    # \u2462 \u5f62\u6001\u9f50\u5907\uff1a\u6bcf slice \u4e3a\u591a\u5206\u91cf\u7ed3\u6784\uff0c\u5206\u91cf\u53ef\u8ffd\u6eaf
    ok3 = True
    for slice_name in expected_slices:
        components = h[slice_name]["components"]
        is_multi = isinstance(components, list) and len(components) >= 2
        traceable = all(
            ("source_ref" in c) or ("lineage" in c) for c in components
        )
        ok3 &= is_multi and traceable
        if not (is_multi and traceable):
            log.append(f"           形态不齐备: {slice_name} is_multi={is_multi} traceable={traceable}")
    log.append(f"[step3-\u2462] \u6bcf slice \u4e3a\u591a\u5206\u91cf\u72b6\u6001\u5411\u91cf\u4e14\u5206\u91cf\u53ef\u8ffd\u6eaf(source_ref/lineage) -> {'PASS' if ok3 else 'FAIL'}")

    return ok1 and ok2 and ok3


def main():
    log = []
    log.append("=" * 70)
    log.append("T3-03 D\u6bb5\u65ad\u8a00\u65e5\u5fd7 v1.0 20260711")
    log.append("=" * 70)

    log.append("")
    log.append("--- step0 \u524d\u7f6e\u5408\u89c4\u65ad\u8a00 ---")
    ok_i = step0_i_input_synthetic(log)
    ok_ii = step0_ii_harness_no_datasource(log)
    ok_iii = step0_iii_independent_no_coupling(log)
    step0_ok = ok_i and ok_ii and ok_iii
    log.append(f"step0 \u6574\u4f53 -> {'PASS' if step0_ok else 'FAIL\uff08\u672c\u6839\u76f4\u63a5\u5224\u4e0d\u5408\u683c\uff0c\u4e0d\u8fdb\u5165\u6570\u503c\u6bd4\u5bf9\uff09'}")

    if not step0_ok:
        log.append("")
        log.append("\u6700\u7ec8\u5224\u5b9a: \u4e0d\u5408\u683c\uff08step0\u672a\u901a\u8fc7\uff09")
        LOG_PATH.write_text("\n".join(log), encoding="utf-8")
        print("\n".join(log))
        return

    log.append("")
    log.append("--- step1-2 \u6570\u503c\u6bd4\u5bf9\uff08\u88c1\u51b313 \u5b50\u53e3\u5f84(a)\uff1a0\uff0cbit-exact\uff09 ---")
    step12_ok, rows = step1_2_numeric_compare(log)

    log.append("")
    log.append("--- step3 \u9644\u52a0\u65ad\u8a00 ---")
    step3_ok = step3_additional_assertions(log)

    final_ok = step0_ok and step12_ok and step3_ok
    log.append("")
    log.append(f"\u6700\u7ec8\u5224\u5b9a: {'\u5408\u683c\uff08\u901a\u8fc7\uff09' if final_ok else '\u4e0d\u5408\u683c'}")

    LOG_PATH.write_text("\n".join(log), encoding="utf-8")

    # \u9010\u9879\u6bd4\u5bf9\u8868\u5355\u72ec\u5199\u51fa\uff0c\u4f9b\u5207\u7247\u8bb0\u5f55\u5f15\u7528
    with open(HERE / "comparison_table.tsv", "w", encoding="utf-8") as f:
        f.write("component\tharness\tindependent\tdiff\t判定\n")
        for row in rows:
            f.write("\t".join(row) + "\n")

    print("\n".join(log))


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""entity/roll_optionality_state_checker.py · 被测实现（窗3 · T3-24 六问验收状态量）

职责边界（下边界显式化，F-13；与 input_schema.md §9 反面陈述段逐条对表）：
  - 本实现**只做**：记录面形态核验（phase1 结构 / phase2 分量）＋ 极性映射 ＋ 三态投影。
  - 本实现**零自算**：不计算任何 Gamma / wing / moneyness / funding / payoff / identity
    之实质判定；六分量之答案一律取自上游供给形态或声明桩（消费型状态量）。
  - 本实现**不产出**：六问不利之处置、candidate 生成、整体验收结论、交易信号、
    结构选型（wing moneyness／长短端比例／期限取位）、任何参数取值。

F-14：全部判据面取自 t324_state_declaration.json（schema 本体入比对面），
      本文件**不以字面量复刻**六问集、极性表、值域、码集。

触发条件来源（v1.1 增量批，裁决91-4(iv)）：phase2 之逐分量核验一律以**声明面**为触发
      基准——分量集取 declaration.components，分派标签先对声明面钉定值作一致性核验
      （K13），门控键与容器之**缺席等同非法**（K10／K11）。被检记录不得经自声明标签
      或删键/删容器令核验静默跳过。
"""
import json
import os
import sys

sys.dont_write_bytecode = True

HERE = os.path.dirname(os.path.abspath(__file__))
DECL_PATH = os.path.join(HERE, "t324_state_declaration.json")


def load_declaration(path=DECL_PATH):
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def _all_keys(obj):
    """递归产出 record 树内全部键名（K12 全域扫描；locus container 统一为 record）。"""
    if isinstance(obj, dict):
        for k, v in obj.items():
            yield k
            for kk in _all_keys(v):
                yield kk
    elif isinstance(obj, list):
        for it in obj:
            for kk in _all_keys(it):
                yield kk


class T324StateChecker:

    def __init__(self, decl):
        self.d = decl
        comps = decl["components"]
        self.keys = [c["key"] for c in comps]
        self.polarity = {c["key"]: c["polarity"] for c in comps}
        self.verdict_source = {c["key"]: c["verdict_source"] for c in comps}
        # 声明面钉定值（v1.1 增量批）：分派标签、必载 target_provenance 之分量、槽位符号集。
        # 三者均自 declaration 取，构成 phase2 各核验之**触发条件来源**——不由被检记录控制。
        self.supply_form_pinned = {c["key"]: c["supply_form"] for c in comps}
        self.tp_required = set(decl["target_provenance_required_on"])
        self.required_slots = [s["slot_symbol"] for s in decl["parameter_slots"]]
        self.state_domain = decl["verdict_domain"]
        self.pass_s, self.fail_s, self.indet_s = self.state_domain
        self.phase1 = decl["check_phases"]["phase1_structural"]
        self.phase2 = decl["check_phases"]["phase2_component"]

    # ---------------------------------------------------------- phase 1
    def _phase1(self, rec):
        v = []
        d = self.d

        ev = rec.get("roll_event") or {}
        if (not ev.get("action_id")) or ev.get("action_subtype") != d["required_action_subtype"]:
            v.append(("K01", "roll_event", "action_subtype"))

        anchor_state = (rec.get("lifecycle_anchor") or {}).get("state")
        if anchor_state != d["lifecycle_anchor_required"]:
            v.append(("K02", "lifecycle_anchor", "state"))

        comps = rec.get("components") or {}

        present = set(comps.keys())
        declared = set(self.keys)
        for k in sorted(declared - present):
            v.append(("K04", "components", k))
        for k in sorted(present - declared):
            v.append(("K04", "components", k))

        aid = ev.get("action_id")
        for k in self.keys:
            if k not in comps:
                continue
            a = comps[k].get("anchor") or {}
            if a.get("pre") is None or a.get("post") is None or a.get("pre") != aid or a.get("post") != aid:
                v.append(("K03", "components", k))

        slots = rec.get("slots")
        if not isinstance(slots, dict):
            v.append(("K11", "record", "slots"))
            slots = {}
        for sym in self.required_slots:
            if sym not in slots:
                v.append(("K11", "slots", sym))
        for slot_name, slot in slots.items():
            sv = slot if isinstance(slot, dict) else {}
            if sv.get("value") is not None:
                v.append(("K11", "slots", slot_name))

        c7 = set(d["forbidden_keys"]["c7_loop_closure"])
        for key in _all_keys(rec):
            if key in c7:
                v.append(("K12", "record", key))

        return v

    # ---------------------------------------------------------- phase 2
    def _phase2(self, rec):
        """返回 (violations, 受污染分量集)。"""
        v = []
        d = self.d
        comps = rec.get("components") or {}
        req = d["t3_22_required_fields"]
        enums = req["enum_domains"]
        carry_forbidden = set(d["forbidden_keys"]["carry_frozen_form"])

        for k in self.keys:
            c = comps.get(k) or {}
            form = c.get("supply_form")
            label_ok = (form == self.supply_form_pinned[k])

            if not label_ok:
                v.append(("K13", k, "supply_form"))

            if label_ok and form == "t3_22_wing_vector":
                for wing in ("put_wing", "call_wing"):
                    w = c.get(wing)
                    if not isinstance(w, dict):
                        v.append(("K05", k, wing))
                        continue
                    for fld in req[wing]:
                        if fld not in w:
                            v.append(("K05", k, "%s.%s" % (wing, fld)))
                        elif fld in enums and w[fld] not in enums[fld]:
                            v.append(("K05", k, "%s.%s" % (wing, fld)))

            if label_ok and form == "t3_18_breach_flag":
                cal = c.get("funding_caliber_declaration")
                dom = d["funding_caliber_domain"]
                if (not isinstance(cal, list)) or len(cal) != 1 or cal[0] not in dom:
                    v.append(("K06", k, "funding_caliber_declaration"))
                if c.get("positive_carry_caliber_form") != d["positive_carry_caliber_form_required"]:
                    v.append(("K07", k, "positive_carry_caliber_form"))
                for fk in sorted(set(c.keys()) & carry_forbidden):
                    v.append(("K07", k, fk))

            if label_ok and form == "w1_identity_audit":
                if c.get("outcome") not in d["identity_audit_outcome_domain"]:
                    v.append(("K09", k, "outcome"))

            if self.verdict_source.get(k) == "declared_stub":
                if c.get("_stub_degraded") is not True:
                    v.append(("K08", k, "_stub_degraded"))

            if k in self.tp_required or "target_provenance" in c:
                if c.get("target_provenance") != d["target_provenance_required"]:
                    v.append(("K10", k, "target_provenance"))

        polluted = set(x[1] for x in v)
        return v, polluted

    # ---------------------------------------------------------- 三态投影
    def _answer(self, key, comp):
        """返回问句之布尔答案；None ＝ 未标定/缺供给。本根零自算：答案一律取自供给面。"""
        src = self.verdict_source[key]
        if src == "declared_stub":
            return comp.get("verdict_declared")
        if src == "upstream_flag":
            return comp.get("breach_flag")
        if src == "upstream_declared_value":
            out = comp.get("outcome")
            if out not in self.d["identity_audit_outcome_domain"]:
                return None
            return out == "drift_detected"
        return None

    def _project(self, key, answer):
        if answer is None:
            return self.indet_s
        if self.polarity[key] == "positive":
            return self.pass_s if answer is True else self.fail_s
        return self.fail_s if answer is True else self.pass_s

    # ---------------------------------------------------------- 主入口
    def evaluate(self, rec):
        raw = self._phase1(rec)
        comps = rec.get("components") or {}

        if raw:
            states = {k: self.indet_s for k in self.keys}
            diagnostics = {}
        else:
            p2, polluted = self._phase2(rec)
            raw = raw + p2
            states = {}
            echo = {}
            for k in self.keys:
                c = comps.get(k) or {}
                echo[k] = c.get("supply_form")
                if k in polluted:
                    states[k] = self.indet_s
                else:
                    states[k] = self._project(k, self._answer(k, c))
            diagnostics = {"supply_form_echo": echo}

        violations = [{"code": c, "locus": {"container": ct, "key": ky}}
                      for (c, ct, ky) in sorted(set(raw))]

        return {
            "record_id": rec.get("record_id"),
            "component_states": states,
            "violations": violations,
            "diagnostics": diagnostics,
        }

# entity/input_schema.md · 五·窗3·T3-24 六问验收状态量 · v1.1 · 20260816

> **性质**：candidate 态（构造会话产出，未经外审、未经 KD 收口裁定）。本文内「本根裁定登记」各项均为**呈KD候选**，非终裁。
> **构造会话身份**：窗3切片构造会话（独立 session）。本会话**不兼外审、不兼裁决、不自评**（裁决29-A 生产者不能自审）。
> **授权链**：《第五批窗3任务包 v1.2 定稿·已裁生效 20260816》＋《W-23设计窗产出 v1.1》§2.2窗3甲乙边界＋《裁决86落地文档 v1.1》§4 分档表＋《裁决90落地文档 v1.0》＋《窗2增量复核与KD收口裁定落地 v1.0》收-6/收-7；**v1.1 增量面授权源＝《裁决91落地文档 v1.0》91-4(iv)／91-8／91-10 ＋《窗3增量构造会话开启文本 v1.0》靶-1/靶-2/靶-3**。
> **v1.1 修订记录（cp-then-edit 自 v1.0，逐处 `assert count==1`，difflib 核验，diff 清单随交付）**：
> **靶-1**（91-4(iv)，判定面）——(a) 增 K13：记录面 `supply_form` ≠ declaration 钉定值即击落（键缺席 ≡ 值非法）；(b) K10 触发条件改「键缺席 ≡ 值非法」（钉定必载分量表 `target_provenance_required_on`）、K11 触发条件改「容器缺席 ≡ 内容非法」（槽位符号集取自 `parameter_slots`）；(c) 负例补五条（N16 逃-1／N17 逃-2／N18 逃-3／N19 逃-4／N20 观-5形态），恰界注入随之扩至八处；独立复算侧同步承接 (a)(b) 并各自实现。
> **靶-2**（91-8）——B-2 取择案 (ii)：诊断字段更名 `supply_form_echo` 并改标「形态回显（记录面再读）」，撤「取自实际执行路径返回值」措辞；B-3：A18 改逐条机械对表（对表基准 `negative_statement_map` 入声明面）；B-5：① `instrument_annotation_pointer` 节号位补 `§6`。
> **靶-3**（91-8 B-6／91-10 观-6）——`_scale` 四项真值源改实件程序化实测（A19 取实测面，A25 核镜像零漂移）；81-10 清单外装载依据补申报页随交付。
> **附带项（靶集外，呈KD追认）**：`closure_limitation_verbatim` 依收-6原件逐字回补（外审 B-4 之构造侧同步；v1.0 所载为任务包 v1.1 节略转写，上游已由 91-8 经任务包 v1.2 回补）——零判定面影响，F-12 机械核证未入交付前断言。
> **判定面变动射程**：限上列靶集枚举项；靶集外零判定面变动（既有十九条钉值零回改，A06 首跑即全数一致）。
> **装载载体留痕**：消费面《一阶实体_T3-18_input_schema_v1_2_20260810》经 KD 于 20260816 改钉（任务包必装清单原钉 v1.1 历史件，41-9 偏差 DEF-LOAD-3），因 `/mnt/project` 该件不在场，由 KD 以上传件投放全文装载——**全文在场，非记忆代装载**（裁决90-4-4 先例形态，续行处置）。cp-then-edit 血缘经程序化核证：v1.2 头注声明底版 md5 与实测 v1.1 md5 一致。

---

## §0 对象与 Q4 判据锚定

T3-24 ＝ roll optionality state（roll 后 optionality 与凸性维护之验收状态量）。窗3 单对象根（裁决86-3 之 P1-1 方案A 第三切片）；形态＝**六分量三态向量核验型**（W-23 §2.2 甲面既裁形态）。

**判据源出处（程序化行号级核证，20260816）**：T3 §13.6 行1340-1351。核证结论与任务3产出 v1.4 条目登记一致，零偏差。**行界实况**：行1340 标题／行1341 空行／行1342 功能定义句／行1343 空行／行1344 fence／行1345-1350 六问句／行1351 fence。

> **行界订正留痕**：任务包 §2-1 与随包件B″ 行界核证注均枚举 1340／1343／1344／1351 为无成分行，**漏列行1341 空行**（span 十二行，原枚举覆盖十一行）。本根构造侧补齐，已作 DEF-LOAD-4 经 KD 裁定（20260816）回传裁决台下次再版；判据面零影响（1341 与 1343 同为无成分空行，T3·614 先例）。

**源文转录（来源 `3_波动率凸性操作方法论主文档_T0_frozen_clean_20260615.md`，一档只引用不再生）**：

> 行1342：`roll optionality state` 用于确认动态 roll 是否仍在维护 optionality 与凸性，而不是机械展期或收益锁定动作。它必须回答：
> 行1345：roll 前后的 Gamma center 是否仍有效；
> 行1346：long put / long call wing integrity 是否被维护；
> 行1347：moneyness relevance 是否仍匹配目标路径；
> 行1348：roll cost 是否破坏 funding relation；
> 行1349：roll 后 payoff shape 是否仍守住左尾 protection 与右尾 participation；
> 行1350：roll 是否造成 object identity drift。

**外部装载依赖显式声明（乙-3：交付包不自带源文副本）**：断言 A23 对上列转录与源文行号作字面级核对，须以装载域源文在场为前提（路径可由环境变量覆盖）；A24 同理依赖随包件B″ 在场。二者不在包内并存副本。

---

## §1 对象语义与边界

### 1.1 上边界（要件）

六问逐一投影为一个验收分量，共 **分量 6 个**，各出三态之一；三态值域**消费窗1 既建形态** `judgment_verdict_domain`（窗1 §10 C-12 类一定案；T3-18 三态先例）。绑定要件：roll 事件（窗2 记录形态之动作身份主键）＋生命周期锚位（窗1 `executed` 之强制终止态 `post_action_checked`）。

### 1.2 下边界（本根零自算，F-13）

本根为**消费型状态量**（W-23 §1「六问全部指向判据根输出，**自算面为零**」）：六问之答案一律取自上游供给形态或降格声明桩，**本根不计算任何实质判定**。可核验内容＝形态核验 ＋ 极性映射 ＋ 三态投影，见 §9 反面陈述段。

### 1.3 供给面实况（**本根首要构造发现**，假设级回流，86-4 明文不构成缺陷）

任务包 §2-2 将 ①④ 之「消费口径待核」与 ⑤ 之「供给方缺位」列为假设级，要求消费口径实况入切片记录。本根逐分量实查结果：

| 分量 | 供给域实查 | 判定谓词是否有供给方 | 处置 |
|---|---|---|---|
| ① Gamma center | T3-03 §3.2 供 `gamma_center` **值**（其计算规则本身挂 TPL1-T303-02 类二·缺定义 open）；FW-03-甲 供 roll **触发侧**过零事件与恒正诊断 | **无**——两域均不产出「roll 前后是否仍有效」之判定 | 降格声明桩＋**TPL1-T324-02** |
| ② wing integrity | T3-22 §2 供五问→输出分量**向量**（band 位置／四因读数／presence／bleed 账本三字段） | **无**——无 integrity 单一聚合判定 | 向量入形态核验（K05）；判定降格声明桩＋**TPL1-T324-03** |
| ③ moneyness relevance | target ＝声明值输入（W-24 零侵入落点，边界级） | **无**——匹配判定谓词无供给方 | 降格声明桩＋**TPL1-T324-04** |
| ④ funding relation | T3-18 v1.2 §4③ 破坏形态布尔（其 §4① funding_gap 公式**含 roll_cost 项**）；GL-06 为旁供给（不含 roll cost） | **部分**——供状态不供归因，源问句两读法分叉 | 阶段A取状态读法候选；**TPL2-T324-01** 呈KD |
| ⑤ payoff shape | 缺位（86-4 既裁） | **无** | 降格声明桩＋**TPL1-T324-01** |
| ⑥ identity drift | 窗1 §3 `object_identity_audit.outcome ∈ {no_drift, drift_detected}` | **有** | 直接消费声明值（治理域不代裁） |

结论：六分量中仅 ⑥ 有直接判定供给，④ 有状态型供给但读法分叉，①②③⑤ 判定谓词供给方缺位——**缺口登记 5 条**（§11／撞墙清单）。此为 G-3 占位纪律之正常形态，非不合格。

### 1.4 乙面（登记不建）

六问不利时之处置＝回窗1 candidate 生成——**环路闭合位不在窗3内实现**（86-4 C7 边界级）。本根登记指针在场（本节），实现零在场（A16 机械核证）。

---

## §2 人造 input（模板三 A 段；裁决1 全程强制）

- **文件**：`entity/synthetic_input.json`（由 `entity/build_synthetic_input.py` 手工构造器产出），头部载 `_data_source: synthetic_hand_constructed` 与零数据源声明。
- **规模**：**记录 24 条** ＝ **正例 4 条**（P1–P4）＋ **负例 20 条**（N01–N20）。
- **负例设计口径**：**逐条单码**——每条负例恰好命中一个违规码，使断言击落力可逐码定位（窗1／窗2 同型）。
- **恰界值/off-by-one 注入（89-9-2 成文判据，本根适用非空白申报）**：**恰界注入 8 处**——N02（生命周期锚位恰差一跳：`executed` 为 `post_action_checked` 之恰前一状态）／N04（六问集恰缺一键）／N05（六问集恰多一键，检多侧，F-7）／N06（T3-22 必需字段恰缺一）／N07（band 枚举恰越一元素）／N12（identity audit outcome 枚举恰越一元素）／**N18（门控键恰缺一：`target_provenance`）／N19（槽位容器恰缺一：`slots`）**。后两处为 v1.1 增量批新增，按 N04「键集恰缺一」先例同型归入 89-9-2 恰界口径——**分类理由如实呈KD**（§11 B档-10）。
- **自声明标签门控逃逸形态（v1.1 增量批，靶-1(c)）**：负例补五条——N16（② 改标签并删双翼字段）／N17（④ 改标签、删口径声明并植入正Carry禁形键）／N18（删 ③ 之 `target_provenance` 键）／N19（删整个 `slots` 容器）／N20（⑥ 改标签致码语义错位之对照例）。五条形态逐条取自窗3切片外审报告 §1.1 之四探针与观-5 对照例，**入包成为常设负例**（探针一次性 → 判据常设）。
- **人造测试值隔离**：`action_id`／`audit_ref`／`target_path_id`／各读数均为人造符号与字符串，显式隔离于 `_synthetic_test_values` 并标注不外推、非生产标识规范（裁决14）。**全程零算术运算**——读数以字符串承载，本根不对其求值。
- **钉表独立通道（F-8）**：`entity/expected_pin_table.json` 为**手写**钉表，**不由构造器生成、不由被测实现回写**，避免判据基线件由单通道重生成而退化为同义反复。

---

## §3 声明面（F-4 声明侧；F-14 schema 本体入比对面）

下列声明块为本根**权威声明面**，与 `entity/t324_state_declaration.json` **逐字节同一**（断言 A04 程序化核证）。三方对表（F-15⑧）：**本内嵌块** ↔ `entity/t324_state_declaration.json`（被测侧读取源） ↔ `verify/independent_recompute.py` 解析结果。被测实现与独立复算**均不以字面量复刻**六问集／极性表／值域／码集（F-14）。

<!-- W3-T324-DECL-EMBED -->

```json
{
  "_declaration_id": "W3-T324-DECL",
  "_declaration_version": "v1.1",
  "_object_id": "五·窗3·T3-24六问验收状态量",
  "_constituent_objects": [
    "T3-24"
  ],
  "_pin_order_declaration": "先钉表后跑数：本声明面与 input_schema.md §7 期望值钉表与 synthetic_input.json 同轮提交，先于 harness 实跑（F-10 文字声明三处一致）。v1.1 增量批：因靶-1(c)新增五条负例而扩表，扩表部分与新负例同轮提交、先于实跑，既有十九条钉值零回改（乙-2）",
  "source_span": {
    "document": "3_波动率凸性操作方法论主文档_T0_frozen_clean_20260615.md",
    "section": "§13.6 Roll optionality state",
    "lines": "1340-1351",
    "no_component_lines": [
      1340,
      1341,
      1343,
      1344,
      1351
    ],
    "no_component_note": "1340标题／1341空行／1343空行／1344·1351 fence＝无成分（T3·614先例）。行1341之枚举为本根构造侧补齐——任务包§2-1与随包件B″行界核证均漏列该行，已作DEF-LOAD-4回传裁决台（KD裁定20260816）",
    "functional_definition_line": 1342
  },
  "components": [
    {
      "key": "q1_gamma_center",
      "source_line": "T3·1345",
      "question": "roll 前后的 Gamma center 是否仍有效",
      "polarity": "positive",
      "supply_form": "declared_verdict_stub",
      "verdict_source": "declared_stub",
      "gap_ref": "TPL1-T324-02",
      "supply_domain_probed": "T3-03（gamma_center 值，其计算规则本身挂 TPL1-T303-02 类二·缺定义 open）／FW-03-甲（roll触发侧过零事件，非roll后验收侧）",
      "instrument_annotation_pointer": "EP-06(a)：本分量为模型派生量之间接消费面；仪表身份标注由上游根承载——指针＝一阶实体_T3-03_input_schema.md §3.2 diagnostic Greeks 声明（TPL1-T303-02 占位声明）＋一阶实体_FW-03-甲_input_schema_v2_1 §6 之 M1 契约⑥仪表读数非定价真理源。本根不逐处复标注"
    },
    {
      "key": "q2_wing_integrity",
      "source_line": "T3·1346",
      "question": "long put / long call wing integrity 是否被维护",
      "polarity": "positive",
      "supply_form": "t3_22_wing_vector",
      "verdict_source": "declared_stub",
      "gap_ref": "TPL1-T324-03",
      "supply_domain_probed": "T3-22（五问→输出分量向量在场；无 integrity 单一聚合判定）",
      "instrument_annotation_pointer": "EP-06(a)：upside_convexity_reading 等读数为间接消费面；仪表身份标注指针＝一阶实体_T3-22_input_schema_v1_2 §2/§3#6（raw_gamma 贴标签，未引入新计算规则）"
    },
    {
      "key": "q3_moneyness_relevance",
      "source_line": "T3·1347",
      "question": "moneyness relevance 是否仍匹配目标路径",
      "polarity": "positive",
      "supply_form": "declared_verdict_stub",
      "verdict_source": "declared_stub",
      "gap_ref": "TPL1-T324-04",
      "supply_domain_probed": "target＝声明值输入（W-24 零侵入落点，边界级）；匹配判定谓词无供给方",
      "instrument_annotation_pointer": "不适用（无模型派生量消费）"
    },
    {
      "key": "q4_funding_relation",
      "source_line": "T3·1348",
      "question": "roll cost 是否破坏 funding relation",
      "polarity": "negative",
      "supply_form": "t3_18_breach_flag",
      "verdict_source": "upstream_flag",
      "gap_ref": "TPL2-T324-01",
      "supply_domain_probed": "T3-18 v1.2 §4③破坏形态布尔（funding_gap 公式含 roll_cost 项，§4①）；GL-06 为旁供给（Theta收入/保护成本时间价值比值，不含 roll cost）",
      "instrument_annotation_pointer": "不适用（账本现金流量，非模型派生量；T3-18 §7／GL-06 §6 同型注记）"
    },
    {
      "key": "q5_payoff_shape",
      "source_line": "T3·1349",
      "question": "roll 后 payoff shape 是否仍守住左尾 protection 与右尾 participation",
      "polarity": "positive",
      "supply_form": "declared_verdict_stub",
      "verdict_source": "declared_stub",
      "gap_ref": "TPL1-T324-01",
      "supply_domain_probed": "供给方缺位（裁决86-4 既裁，假设级 C6 桩位）",
      "instrument_annotation_pointer": "不适用（桩，无上游读数消费）"
    },
    {
      "key": "q6_identity_drift",
      "source_line": "T3·1350",
      "question": "roll 是否造成 object identity drift",
      "polarity": "negative",
      "supply_form": "w1_identity_audit",
      "verdict_source": "upstream_declared_value",
      "gap_ref": null,
      "supply_domain_probed": "窗1 input_schema §3 object_identity_audit.outcome ∈ identity_audit_outcome_domain（声明值/manual review 位，治理域不代裁）",
      "instrument_annotation_pointer": "不适用（治理域声明值）"
    }
  ],
  "verdict_domain": [
    "pass",
    "fail",
    "indeterminate"
  ],
  "verdict_domain_source": "窗1 input_schema v1.2 §3 judgment_verdict_domain（窗1 §10 C-12 类一定案；T3-18 三态先例）＝『窗3消费本根之生命周期语义与未标定三态形态』（窗1 §1 下游消费面 C9）",
  "polarity_semantics": {
    "positive": "问句肯定答案 ⇒ pass；否定答案 ⇒ fail",
    "negative": "问句肯定答案 ⇒ fail；否定答案 ⇒ pass"
  },
  "polarity_source": "T3·1342『用于确认动态 roll 是否仍在维护 optionality 与凸性』× T3·1345-1350 各问句字面：『是否破坏』（1348）与『是否造成』（1350）之肯定答案与『仍在维护』矛盾，其余四问肯定答案与之相容",
  "indeterminate_rule": "未标定（verdict 为 null）／缺供给／该分量形态核验命中 ⇒ 该分量 indeterminate（裁决86-4 C10条3 同型；任务包§2-2）",
  "upstream_consumption_W1": {
    "consumed": [
      "judgment_verdict_domain 三态形态",
      "action_states 之 executed→post_action_checked 强制终止态语义（mandatory_terminal_for_executed）",
      "identity_audit_outcome_domain"
    ],
    "not_consumed": [
      "状态转移表逐条核验（窗1域，不重复判定）",
      "Phase 4 裁决语义与 T-13 值域",
      "no-action 周期审计条件",
      "换装联动重置机制"
    ],
    "authority": "一阶实体_五窗1_动作生命周期状态机_input_schema_v1_2_20260814 §3 ＋ 窗1切片记录 v1.2",
    "reuse_form": "一阶实体产物消费（声明值接收形态，无逐字claim），不走 C4②，引用不重登；不在 F-12 射程（61-3 裁定边界）"
  },
  "upstream_consumption_W2": {
    "consumed": [
      "roll 事件记录之动作身份主键 action_id 与 source_execution_ref",
      "action_subtype = roll 之子类语义"
    ],
    "not_consumed": [
      "迁移闭合断言 CA-1/CA-2/CA-3 之重复核验",
      "违规码 R01–R12 之重复判定",
      "lot 集／账本迁移映射／功能承担者映射之内容判定"
    ],
    "authority": "一阶实体_五窗2_roll事件记录_input_schema_v1_1_20260815（收口态）",
    "closure_limitation_verbatim": "修订后CA-1/CA-2/CA-3三条，在现有记录面字段域内为T1行1099之最小充分闭合形态；数量维缺席已登记为TPL1-W2-03已知不完备面，最小充分主张不外推至数量守恒。后续任何读取窗2收口态者按此限定语引用，不得读作数量面已闭合。",
    "closure_limitation_verbatim_note": "v1.1 增量批回补：本值经与收-6原件（窗2增量复核与KD收口裁定落地 v1.0）程序化逐字比对（剥离强调标记后全等）取得；v1.0 所载为任务包 v1.1 之节略转写（外审 B-4），上游已由裁决91-8经任务包 v1.2 回补。F-12 之机械核证本版仍以构造期一次性比对承载、未入交付前断言——呈KD（靶集外附带项）",
    "closure_limitation_source": "窗2增量复核与KD收口裁定落地 v1.0 收-6（强制随行，任务包§2-3／§5-3）"
  },
  "lifecycle_anchor_required": "post_action_checked",
  "lifecycle_anchor_source": "窗1 §3 mandatory_terminal_for_executed（executed 之强制终止态）；验收面以 post-action legality check 完成为前置",
  "required_action_subtype": "roll",
  "t3_22_required_fields": {
    "put_wing": [
      "tail_coverage_band_position",
      "moneyness_drift",
      "time_decay_fraction",
      "skew_change",
      "liquidity_deterioration",
      "premium_bleed_booked",
      "premium_bleed_downgrade_flag",
      "premium_bleed_integrity_check"
    ],
    "call_wing": [
      "tail_coverage_band_position",
      "upside_convexity_reading",
      "wing_presence_status",
      "premium_bleed_booked",
      "premium_bleed_downgrade_flag",
      "premium_bleed_integrity_check"
    ],
    "source": "一阶实体_T3-22_input_schema_v1_2_20260802 §2 五问→输出分量映射表＋§4",
    "enum_domains": {
      "tail_coverage_band_position": [
        "below",
        "within",
        "above"
      ],
      "wing_presence_status": [
        "present",
        "deleted",
        "over_monetized",
        "covered_call_shipped",
        "roll_misplaced"
      ]
    }
  },
  "identity_audit_outcome_domain": [
    "no_drift",
    "drift_detected"
  ],
  "funding_caliber_domain": [
    "量甲",
    "量乙"
  ],
  "funding_caliber_source": "F-19（裁决83-4.5）：下游根消费『长端时间成本』类量须显式声明取量甲（供血成本量，TPL3-T24-01 槽位域）或量乙（MTM 归因 t 通道，C51）；未声明或混用→GAP-1 自动呈单点裁。随行义务＝分账并列／不混用不相减／不跨根相加（宪-ST-06／75-21）",
  "positive_carry_caliber_form_required": "non_frozen_non_trigger",
  "positive_carry_caliber_source": "术语册正Carry口径禁形（随包件A 三-2 登记源）：90%+ 不得读作已冻结阈值或自动触发规则",
  "target_provenance_required": "declared_input",
  "target_provenance_source": "裁决86-4 边界级 W-24 零侵入落点：③之 target ＝消费声明值为输入，本根不产生、不选择 target",
  "target_provenance_required_on": [
    "q3_moneyness_relevance"
  ],
  "target_provenance_required_on_source": "裁决91-4(iv)(b)：K10 触发条件由『键在场』改『键缺席 ≡ 值非法』——本表钉定必须承载 target_provenance 之分量（③为 W-24 零侵入落点），其键缺席即命中；表外分量携带该键者按值核验（检多不止检缺，F-7）",
  "forbidden_keys": {
    "carry_frozen_form": [
      "carry_threshold_frozen",
      "carry_auto_trigger",
      "positive_carry_threshold_value"
    ],
    "c7_loop_closure": [
      "disposition",
      "candidate_generated",
      "repair_candidate",
      "next_action"
    ],
    "c7_source": "裁决86-4 边界级 C7：六问不利处置＝回窗1 candidate 生成，环路闭合位不在窗3内实现——登记指针可在、实现不可在"
  },
  "check_phases": {
    "phase1_structural": [
      "K01",
      "K02",
      "K03",
      "K04",
      "K11",
      "K12"
    ],
    "phase2_component": [
      "K05",
      "K06",
      "K07",
      "K08",
      "K09",
      "K10",
      "K13"
    ],
    "gating": [
      "phase1 命中非空 ⇒ 跳过 phase2，且六分量全判 indeterminate（结构前置未过时分量不可判，避免级联码稀释单码区分力；窗2 check_phases 同型）",
      "phase2 某分量命中 ⇒ 该分量判 indeterminate，其余分量照常判定",
      "phase2 之分量级核验触发条件一律取自声明面（components 键集、verdict_source、supply_form 钉定值、target_provenance_required_on、parameter_slots），不由被检记录自身控制；记录面 supply_form ≠ 声明面钉定值 ⇒ K13 命中且该分量之 form 分派核验（K05/K06/K07/K09）不执行——分派基准已失效时执行分派检查将产出码语义错位（v1.1 增量批，裁决91-4(iv)）"
    ],
    "diagnostics_condition": "phase1 clean ⇒ 产出 supply_form_echo（形态回显：记录面 components[k].supply_form 之再读，非执行路径返回值；比对面两侧同源，A21 为形态核验非能力核验）；否则诊断为空对象"
  },
  "violation_codes": [
    {
      "code": "K01",
      "text": "roll 事件绑定缺失或 action_subtype ≠ roll",
      "tier": "假设级",
      "rule_ref": "upstream_consumption_W2"
    },
    {
      "code": "K02",
      "text": "生命周期锚位 ≠ post_action_checked（验收前置未达）",
      "tier": "假设级",
      "rule_ref": "lifecycle_anchor_required"
    },
    {
      "code": "K03",
      "text": "分量前后锚不成对（pre/post 缺一，或两侧 roll_event_ref 不一致）",
      "tier": "假设级",
      "rule_ref": "components"
    },
    {
      "code": "K04",
      "text": "分量键集 ≠ 六问集（增／删／改名；双向对表）",
      "tier": "边界级",
      "rule_ref": "C6 六问集本体（裁决86-4）"
    },
    {
      "code": "K05",
      "text": "② T3-22 输出形态不合（缺翼／缺必需字段／枚举越域）",
      "tier": "假设级",
      "rule_ref": "t3_22_required_fields"
    },
    {
      "code": "K06",
      "text": "④ funding 口径声明缺失、越域或混用（量甲/量乙）",
      "tier": "假设级",
      "rule_ref": "funding_caliber_domain（F-19）"
    },
    {
      "code": "K07",
      "text": "④ 正Carry口径禁形（冻结阈值／自动触发形态在场）",
      "tier": "假设级",
      "rule_ref": "positive_carry_caliber_form_required"
    },
    {
      "code": "K08",
      "text": "declared_stub 形态分量缺降格标注（_stub_degraded 非 true）",
      "tier": "假设级",
      "rule_ref": "受控文本 §3 桩不 claim 语义等价"
    },
    {
      "code": "K09",
      "text": "⑥ identity audit outcome 越域",
      "tier": "假设级",
      "rule_ref": "identity_audit_outcome_domain"
    },
    {
      "code": "K10",
      "text": "③ target 由本根产生／选择（target_provenance ≠ declared_input）",
      "tier": "边界级",
      "rule_ref": "W-24 零侵入（裁决86-4）"
    },
    {
      "code": "K11",
      "text": "parameter_slot_candidate 被赋值",
      "tier": "边界级",
      "rule_ref": "C15 槽位登记不赋值（裁决86-4）"
    },
    {
      "code": "K12",
      "text": "记录面出现处置／candidate 生成成分（环路闭合实现）",
      "tier": "边界级",
      "rule_ref": "C7 环闭合禁令（裁决86-4）"
    },
    {
      "code": "K13",
      "text": "记录面自声明之分派标签 supply_form ≠ declaration 对该分量之钉定值（键缺席 ≡ 值非法）",
      "tier": "假设级",
      "rule_ref": "裁决91-4(iv)(a)；码号本会话工程取用不外推（裁决14）"
    }
  ],
  "parameter_slots": [
    {
      "slot_symbol": "acceptance_evaluation_window",
      "form": "parameter_slot_candidate",
      "value": null,
      "channel": "自由度治理册信号登记通道",
      "source": "本根构造撞出（六问验收之评估窗口长度源文未定义）",
      "phase_a_consumption": "零消费（仅登记，无断言依赖其值）"
    }
  ],
  "tolerance": {
    "sub_caliber": "(a)",
    "value": 0,
    "basis": "本根输出为离散判定面（三态枚举＋违规码集），全程无数值运算、无超越函数；C3 分派判据判定属离散/精确有理计算，分派子口径 (a)＝0 bit-exact（裁决13/19；任务包§4 D段容差）"
  },
  "prose_count_pointers": [
    {
      "id": "P-01",
      "pattern": "记录\\s*(\\d+)\\s*条",
      "truth_source": "_scale.records"
    },
    {
      "id": "P-02",
      "pattern": "正例\\s*(\\d+)\\s*条",
      "truth_source": "_scale.positive"
    },
    {
      "id": "P-03",
      "pattern": "负例\\s*(\\d+)\\s*条",
      "truth_source": "_scale.negative"
    },
    {
      "id": "P-04",
      "pattern": "违规码\\s*(\\d+)\\s*码",
      "truth_source": "_scale.codes"
    },
    {
      "id": "P-05",
      "pattern": "分量\\s*(\\d+)\\s*个",
      "truth_source": "_scale.components"
    },
    {
      "id": "P-06",
      "pattern": "恰界注入\\s*(\\d+)\\s*处",
      "truth_source": "_scale.boundary_injections"
    },
    {
      "id": "P-07",
      "pattern": "变异\\s*(\\d+)\\s*例",
      "truth_source": "measured.mutations"
    },
    {
      "id": "P-08",
      "pattern": "断言\\s*(\\d+)\\s*条",
      "truth_source": "measured.assertions"
    },
    {
      "id": "P-09",
      "pattern": "缺口登记\\s*(\\d+)\\s*条",
      "truth_source": "measured.gap_entries"
    },
    {
      "id": "P-10",
      "pattern": "交付件\\s*(\\d+)\\s*件",
      "truth_source": "measured.deliverables"
    }
  ],
  "_sweep_exclusions": "章节号/版本号/源文行号/裁决号型数字（前置 §／v／行／裁决／T3·／条款编号），非计数陈述",
  "_scale_measured_keys": [
    "mutations",
    "assertions",
    "gap_entries",
    "deliverables"
  ],
  "_scale_measured_source": "裁决91-10 观-6：本四项之真值源在包外／运行期，v1.0 之 A19 链为『声明对声明』。v1.1 改：A19 取值直接取自实件实测（negative_control 变异登记实测／assert 栈本轮实跑条目实测／撞墙清单条目行实测／交付清单全包域实测），_scale 同名字段降为镜像值，由 A25 机械核其与实测一致；镜像漂移即非零退出",
  "_scale": {
    "records": 24,
    "positive": 4,
    "negative": 20,
    "codes": 13,
    "components": 6,
    "boundary_injections": 8,
    "mutations": 13,
    "assertions": 25,
    "gap_entries": 5,
    "deliverables": 14
  },
  "negative_statement_map": [
    {
      "n": 1,
      "schema_token": "不闭合环路",
      "task_package_anchor": "C7乙环闭合禁令（边界级重申）",
      "anchor_loc": "任务包 §4"
    },
    {
      "n": 2,
      "schema_token": "聚合裁断",
      "task_package_anchor": "C6六问集本体（边界级重申）",
      "anchor_loc": "任务包 §4"
    },
    {
      "n": 3,
      "schema_token": "结构选型",
      "task_package_anchor": "W-24零侵入",
      "anchor_loc": "任务包 §4"
    },
    {
      "n": 4,
      "schema_token": "自算面为零",
      "task_package_anchor": "本根零消费 engine.py",
      "anchor_loc": "任务包 §1"
    },
    {
      "n": 5,
      "schema_token": "CA-1/CA-2/CA-3",
      "task_package_anchor": "C9构造序",
      "anchor_loc": "任务包 §2-2"
    },
    {
      "n": 6,
      "schema_token": "identity/target review",
      "task_package_anchor": "H_identity_target",
      "anchor_loc": "任务包 §2-5"
    },
    {
      "n": 7,
      "schema_token": "parameter_slot_candidate",
      "task_package_anchor": "C15槽位登记不赋值",
      "anchor_loc": "任务包 §2-2"
    },
    {
      "n": 8,
      "schema_token": "跨根命名规范",
      "task_package_anchor": "裁决14",
      "anchor_loc": "任务包 §5-1"
    }
  ],
  "negative_statement_map_source": "F-13 扩注（v1.12，DOC-30⑤）：反面陈述段与任务包不裁决/不修改清单逐条机械对表为交付前断言项。本表为 A18 之对表基准，逐条钉定『schema §9 第 n 条之字面锚』与『任务包对应条之字面锚』；映射选取为构造会话判断，呈KD（裁决91-8 之 B-3 执行）",
  "_data_source": "synthetic_hand_constructed"
}
```

---

## §4 既裁边界分档对照（裁决86-4，构造按档执行）

| 既裁项 | 档位 | 本根落点 | 核证位 |
|---|---|---|---|
| C6 六问集本体（不增不减不改语义） | **边界级** | 分量键集恰等于六问集；K04 双向击落 | A08／A10 |
| C7 乙环闭合禁令 | **边界级** | 判定路径三件零处置成分；K12 记录面击落 | A16／K12 |
| C15 槽位登记不赋值 | **边界级** | `parameter_slot_candidate` 值恒 null；K11 击落（v1.1：**容器缺席 ≡ 内容非法**，机械承载加固，条款语义零变动） | A17 |
| W-24 零侵入（③ target ＝声明值输入） | **边界级** | `target_provenance` 恒 `declared_input`；K10 击落（v1.1：**键缺席 ≡ 值非法**，机械承载加固，条款语义零变动） | A15／A18 |
| C10条3 未标定⇒不可判三态 | **边界级** | 第三态 `indeterminate` 承接窗1 形态 | A07／A09 |
| C6 输入面分层与桩位（①④供给口径待核／⑤桩） | **假设级** | §1.3 实况登记，四桩＋一读法分叉 | §11／撞墙清单 |
| C8 负例集构成（杀灭率口径除外） | **假设级** | 负例 20 条 ＋ 恰界注入 8 处，构成可证伪 | §11 B档 |

---

## §5 违规码与 locus 定义

**违规码 13 码**（K01–K13），逐码之 tier／rule_ref 见 §3 声明块 `violation_codes`。相位分组与门控见 `check_phases`：

- **phase1（结构前置）**：K01 K02 K03 K04 K11 K12。命中非空 ⇒ **跳过 phase2**，六分量全判 `indeterminate`（结构前置未过时分量不可判，避免级联码稀释单码区分力；窗2 `check_phases` 同型）。
- **phase2（分量形态）**：K05 K06 K07 K08 K09 K10 K13。某分量命中 ⇒ **该分量**判 `indeterminate`，其余分量照常判定（单分量污染不外溢，区分力设计）。

**触发条件来源纪律（v1.1 增量批，裁决91-4(iv)）**：phase2 之逐分量核验一律以**声明面**为触发基准——分量集取 `components` 键集，分派标签先对声明面钉定值作一致性核验（**K13**），门控键与容器之**缺席等同非法**（**K10** 之 `target_provenance_required_on`／**K11** 之 `parameter_slots`）。**记录面不得经自声明标签或删键/删容器令核验静默跳过**。标签不符时该分量之 form 分派核验（K05/K06/K07/K09）**不执行**——分派基准已失效仍执行分派检查将产出码语义错位（v1.0 之观-5 实况：⑥ 改标签后误触 funding 类码且 locus 落 q6）。

`locus` 键集＝`{container, key}`；`violations` 按 `(code, container, key)` 字典序排序以保证 bit-exact 可比。

---

## §6 容差声明面（W-4 两子口径；F-4 机械对表）

本根输出为**离散判定面**（三态枚举 ＋ 违规码集 ＋ 诊断枚举），全程无算术运算、无浮点、无超越函数。C3 分派判据判定属离散/精确有理计算，分派**子口径 (a)＝0（bit-exact）**（裁决13/19；任务包 §4 D段容差）。子口径 (b) 本根未触发——无数值面出现，如实登记。

---

## §7 期望值钉表（乙-2；F-10 构造顺序留痕之第一处）

**先钉表后跑数**：`entity/expected_pin_table.json`（手写，独立通道）与人造 input 同轮提交，**先于** harness 实跑。钉表逐记录钉定六分量三态、违规码与 locus、诊断面空/非空，并附 `pin_reason`。文字声明三处一致（F-10 最低形态）：本节 ＋ `verify/assert_check.py` 头注 ＋ 切片记录。

**首跑实况**：钉表 ↔ harness 逐记录全数一致（24/24），零回改钉表（A06）。**v1.1 扩表留痕（乙-2）**：N16–N20 五条钉值（含逐条期望击落码与 locus）与其人造记录同轮提交、先于实跑；既有十九条钉值零回改，程序化比对 v1.0↔v1.1 钉表之既有条目差异数为零。

---

## §8 交付件双钉声明面（F-5／F-8）

**交付件 14 件**（指纹射程内；`verify/provenance.json` 自身与 `verify/logs/*` 为声明排除面，排除理由＝自指与运行期日志，排除面最小化）：

`entity/`：`input_schema.md`（本件）／`t324_state_declaration.json`／`build_synthetic_input.py`／`synthetic_input.json`／`expected_pin_table.json`／`roll_optionality_state_checker.py`（被测实现）／`harness.py`／`outputs/run_output.json`
`verify/`：`independent_recompute.py`／`assert_check.py`／`negative_control.py`／`build_provenance.py`／`final_sweep.py`／`recompute_output.json`

指纹侧＝`verify/provenance.json`（SHA256 全量重建，不读自身既往产物）；声明侧＝本节。双钉缺一不满足（A13 核指纹、A14 双向核包完整性）。

**v1.1 封装形态（裁决91-5(c) 统一 zip 封装首次适用）**：zip 根下 `判据档/` 为**判据档包根**（本节之全部路径均相对该包根），呈报件（切片记录／撞墙清单）与随附件（81-10 申报页／diff 清单／SHA256 指纹表）与 `判据档/` **同级并列**、**不入包根**——故交付件计数与指纹射程零变动，A14／final_sweep 之全包域双向对表亦零变动。

---

## §9 反面陈述段（F-13 下边界显式化；与任务包 §4 逐条机械对表，断言 A18）

本根**不做**：

1. 不实现六问不利之**处置**、不生成回窗1 candidate、不闭合环路（C7 边界级；登记指针可在、实现不可在）。
2. 不产出**整体验收结论**或六分量之聚合裁断——源文只要求回答六问，聚合属外推（最小充分不外推）。
3. 不产生、不选择 **target**，不做任何结构选型（wing moneyness／长短端比例／期限取位）——W-24 域硬互斥。
4. 不计算 Gamma center／wing integrity／moneyness 匹配／funding 破坏／payoff shape／identity drift 之**实质判定**（自算面为零）。
5. 不重复窗1 生命周期推进判定与 Phase 4 裁决语义、不重复窗2 迁移闭合断言 CA-1/CA-2/CA-3（C9 单向消费，引用不重登）。
6. 不代裁 identity/target review 之判定内容（治理域）；不产出交易信号、不建常设 pipeline／数据接口／持久服务。
7. 不赋任何**参数取值**（类三纪律，`parameter_slot_candidate` 零赋值）。
8. 字段名与记录形态＝本根工程取用，不**外推**为跨根命名规范（裁决14）。

---

## §10 计算成分三分判别（乙-7：逐处回引《计算成分三分判别受控文本》v1.2 条款号；单向回引）

| 成分 | 三分归属 | 回引条款 | 依据与留痕（双重引用：程序性纪律＋实质依据） |
|---|---|---|---|
| C-1 六问集本体＝六分量恰好 | KD 既裁承接，不重走判别 | 受控文本 §1 KD 既裁项承接条 | 实质依据＝裁决86-4 C6 边界级 |
| C-2 三态值域 `{pass, fail, indeterminate}` | KD 既裁承接 | 受控文本 §1 | 实质依据＝窗1 §3 `judgment_verdict_domain`（窗1 §10 C-12 类一定案）＋T3-18 三态先例；86-4 C10条3 |
| C-3 极性映射（①②③⑤正／④⑥反） | **类一** | 受控文本 §2 | T＝T3·1342「仍在维护 optionality 与凸性」×T3·1348「是否**破坏**」／T3·1350「是否**造成**」——两问之肯定答案与 T 矛盾，候选「六问同极性」当场裁掉 |
| C-4 未标定/缺供给 ⇒ `indeterminate` | KD 既裁承接 | 受控文本 §1 | 实质依据＝86-4 C10条3 同型（任务包 §2-2） |
| C-5 phase1 命中 ⇒ 全分量不可判之门控 | **类一** | 受控文本 §2 | T＝窗2 §3 `check_phases` 门控条款「结构前置未过时闭合判据不可判」（既建根形态为权威文本之一）；候选「结构未过仍逐分量判定」与 T 矛盾 |
| C-6 ① 判定谓词 | **类二·缺定义型** | 受控文本 §3 ＋ §3 供给方自指补注 | 供给方穷举＝T3-03／FW-03-甲域（**在场未发声**，非本实体自身 ⇒ 供给方自指不成立，类二成立；对照实例＝四3丙成分先例）。桩＝声明值接收，降格标注在场，**桩不 claim 语义等价**。登记＝TPL1-T324-02 |
| C-7 ② 聚合判定谓词 | **类二·缺定义型** | 受控文本 §3 | 供给方＝T3-22 域（在场未发声：供分量向量不供聚合判定）。登记＝TPL1-T324-03 |
| C-8 ③ 匹配判定谓词 | **类二·缺定义型** | 受控文本 §3 ＋ 供给方措辞纪律〔裁决21(a)修正②〕 | 供给方指向 moneyness relevance／目标路径定义域；**模块归属保持开放**，不预裁归属。登记＝TPL1-T324-04 |
| C-9 ⑤ 判定谓词 | **类二·缺定义型** | 受控文本 §3 | 供给方缺位（86-4 既裁）。登记＝TPL1-T324-01（任务包 §5-1 强制建档项） |
| C-10 ④ 供给消费之读法（状态读法／归因读法） | **读法分叉 ⇒ 呈KD，施工侧不自决** | 受控文本 §4 末句 | 见 §10.1 双栏留痕。阶段A取状态读法候选并标注「候选之一」；登记＝TPL2-T324-01 |
| C-11 ⑥ audit outcome 之消费 | **数据**（刀口前置分流，不入三分） | 受控文本 §1 数据/机制刀口 | 成分只作为值被消费（声明值接收），本根不判其内容与充分性 |
| C-12 ③ target 值 | **数据** | 受控文本 §1 | 同上；W-24 零侵入之落点 |
| C-13 T3-22 必需字段集与枚举值域 | **数据**（逐字取自上游声明） | 受控文本 §1 | 取自 T3-22 §2 映射表＋§4；**声明值接收形态，无逐字 claim**，不在 F-12 射程（61-3 裁定边界） |
| C-14 违规码集与 locus 规则 | 假设级构成域（86-4 C8），不入三分测试 | 受控文本 §1 KD 既裁项承接条 | 实质依据＝86-4 分档表；最小充分性属可证伪面（§11 B档） |

### 10.1 类三否定结论双栏留痕（受控文本 §4 v1.2 双栏义务；缺一栏即测试未完成）

**本根类三成分＝零**；C-10 为**读法分叉**而非类三定性（施工侧不自决，呈KD）。双栏如下：

- **文本面查过什么**：T3 §13.6 行1340-1351 全段；T3 §5.5 行609（T3-18 判据源，`funding_gap` 含 roll_cost 项）；T3 §13.4 行1319-1326（T3-22 判据源）；T3-18 v1.2 §2 随行指针三条／§4①②③；GL-06 §0/§1/§4③；T3-03 §3.2／§4.2；FW-03-甲 §1/§2；窗1 §3 声明块全量键；窗2 §3/§12；W-23 §2.2窗3；裁决86-4 分档表；随包件B″ v1.1 已裁七行锚定组；随包件A 三-2 两禁形登记源；模块划分 v1.3（M7 归因分解，裁决81）。
- **逻辑面查过什么（逐候选实查，非默认全相容）**：① ④ 之两读法——**状态读法**（问「计入 roll cost 后 funding relation 是否已破坏」）由 T3-18 §4① 公式含 roll_cost 项直接承接；**归因读法**（问「roll cost 是否为破坏之成因」）须归因分解供给，M7 模块在场但**无已建归因根**。两候选均未被任何文本排除，逻辑上均自洽 ⇒ 不自决，呈KD（受控文本 §4 末句：读法分叉本身即呈KD事项）。② ①之判定谓词是否可由 FW-03-甲 过零事件替代——**逻辑排除成立**：FW-03-甲 之 `speed`/`gamma_curvature` 过零为 roll **触发侧**判据（宪-ST-08 触发判准），而 T3·1345 明为 roll **后**验收形；触发与验收为不同时点之不同判据，不可替代。③ ②之聚合判定是否可由 T3-22 之 `premium_bleed_integrity_check` 单字段代表——**逻辑排除成立**：该字段仅承载 Q5 bleed 账本联合布尔，不覆盖 Q1/Q3 band 位置与 Q4 presence，以之代表 integrity 全体将丢失三问射程。④ 三态是否需第四态（如 `not_applicable`）——**逻辑排除成立**：窗1 既建三态形态为既裁承接面，增态即改既裁形态，须走缺陷回传而非构造自决。

---

## §11 本根裁定登记（逐项呈KD，非终裁；档位按 55-3a 标注）

**A档（逐项呈：不可逆／经济实质类）**

1. **【A档】供给面实况与四桩一分叉之定性**（§1.3）。本根实查结论＝六分量中仅 ⑥ 有直接判定供给，①②③⑤ 判定谓词供给方缺位，④ 供状态不供归因。**呈KD**：(a) 四条 TPL1 登记（T324-01/02/03/04）是否成立、编号是否照采；(b) ①②③ 三条为**设计窗未预期之新发现**（W-23 仅将 ① 列「供给口径待核」、未标 ②③），是否按假设级回流处置（86-4 明文不构成缺陷）。指针＝§10 C-6~C-9、撞墙清单。
2. **【A档】④ 读法分叉之择定**（TPL2-T324-01）。阶段A取**状态读法**候选（理由＝T3-18 §4① 公式已含 roll_cost 项，文本面承接最直接），标注「候选之一，待 KD 裁定，不外推」。**呈KD**：状态读法与归因读法之择一；若裁归因读法，本根 ④ 消费面须改指 M7 归因分解域（无已建根 ⇒ ④ 降为全 `indeterminate`），属判定翻转，走缺陷回传通道。
3. **【A档】聚合裁断之不产出**（§9 反面陈述 2）。源文「它必须回答」后列六问，未要求聚合结论；本根按最小充分不外推**不产出**任何整体验收裁断，亦不产出「不利分量清单」类派生投影。**呈KD**：此不产出是否为该行之最小充分形态；若KD认为需要向窗1 回传之指针面，则该指针属 C7 环路闭合位、须由 KD 显式开边界。

**B档（批量呈，"all confirm" 合法：程序/机械/留痕类）**

1. **违规码集之命名与构成**＝本根工程取用，不外推为跨根命名规范（裁决14）；集合最小充分性属假设级可证伪面。
2. **相位门控三条**（phase1 ⇒ 跳 phase2 且全分量不可判；phase2 单分量污染不外溢；**v1.1 增补第三条**＝触发条件来源纪律：分量级核验之触发条件一律取自声明面，标签不符时该分量 form 分派核验不执行）＝构造反推之区分力保障，假设级，回流通道不因 confirm 关闭。
3. **诊断字段 `supply_form_echo`**（v1.1 更名）＝**形态回显：记录面 `components[k].supply_form` 之再读**，**非**执行路径返回值——比对面两侧同源，A21 显式标注为**形态核验非能力核验**（变异 M10 反测在场，其射程限「回显改同名常量」子形态）。**不产生判定**。**择案理由（裁决91-8 B-2 二择一）**：取 (ii) 而非 (i)——诊断面本非承载面，为使 F-15⑥ claim 成真而令 `_phase2` 返回分派结果属为真而真之增设，与最小充分不外推相悖；且 (ii) 与 91-7 之 G-9候选-W3-01 闭合路径 (b)「同义反复型断言显式标注」同向。
4. **槽位新登记 `acceptance_evaluation_window`**（六问验收之评估窗口长度，源文未定义）＝`parameter_slot_candidate` 符号形态，零赋值，入自由度治理册信号登记通道。**呈KD**：是否登记、编号形态。
5. **零回改钉表**：钉表 ↔ harness 首跑即全数一致，无「跑后改钉」实况，如实留痕。
6. **变异 13 例、杀灭率 13/13**（v1.1 扩表后实况；分母＝有效变异口径，裁决38-3／24-A1）；F-9 计算面击落例在场（M01–M09 与 M11–M13 经 A05/A06 判定面比对击落，非新鲜度通道）。
7. **DEF-LOAD-4 行界订正**（§0）＝上游呈报件缺陷，已经 KD 裁定回传裁决台下次再版，本根如实留痕不代改上游件。
8. **构造期自查击出三项（交付前订正，静默＝缺陷，故如实登记）**：①`build_synthetic_input.py` 之**零数据源声明字符串自身**含厂商字面，触发 F-1 机械前哨——按 F-1「否定语境不另设豁免清单」（裁决48 Q-5）**不改扫描器、改载体文本**（docstring 内裁决1 字面保留不动，剥离面不入判定基面）；②A03 判据之锚定串取自剥离后文本而剥离以换行拼接 token，致判据恒假——**判据表述错层**，锚面改取原始源码；③schema §4 一处计数陈述未走登记指针、A19 反向清扫之声明面已成文排除口径（`_sweep_exclusions`）未实装——两侧同批订正。三项**均由本根断言栈在交付前击出**，非交付后发现；②为「断言写错致假阴性」形态，与判定面缺陷不同型，呈KD定性。

**——以下 9–16 为 v1.1 增量批新增（裁决91-4(iv)／91-8／91-10 执行侧产物，逐项呈KD）——**

9. **K13 之码号、相位归属与标签门控形态**：码号 K13 ＝本会话工程取用、不外推为跨根码号规范（裁决14）；归 phase2 而非 phase1 ＝构造反推之择定（失效面为**单分量**分派基准，phase1 归属将令单分量标签不符外溢为全分量不可判），属假设级可证伪面。**标签不符 ⇒ 该分量 form 分派核验不执行**之门控形态同属假设级——其直接实益＝观-5 之码语义错位消解（修复后 N20 恰命中 K13 一码、locus 落 q6）。**残余如实申报**：K05/K06/K07/K09 仍由 form 分派，故标签不符时禁形键（如 N17 之 `carry_threshold_frozen`）不再另行由 K07 单列击落，改由 K13 兜底（该记录不得判 pass）；裁决91-4(iv) 之处置枚举为 (a)(b)(c) 三项，K07 触发条件不在其内，本会话不越靶集自改——**是否需将禁形键扫描改为不受 form 门控之全分量扫描，呈KD**。
10. **恰界注入由六处扩至八处之分类理由**：N18（门控键恰缺一）／N19（槽位容器恰缺一）按既有 N04「六问集键恰缺一」之先例同型归入 89-9-2 恰界口径；另一可选读法＝「删除对象为门控键/容器，属逃逸形态族而非恰界值族」，本会话取前者（同型先例优先、避免向下少报），**分类择定呈KD**。
11. **变异 13 例、杀灭率 13/13（v1.1 扩表后）**：新增 M11（K13 标签一致性不检）／M12（K10 触发条件退回「键在场」）／M13（K11 容器缺席不报），三例逐例经 A05/A06 判定面比对击落（F-9 计算面通道）；分母＝有效变异口径（裁决38-3／24-A1）。
12. **A18 对表基准 `negative_statement_map` 入声明面**：八条逐条钉定「§9 第 n 条之字面锚」与「任务包对应条之字面锚」（锚位含 §1／§2-2／§2-5／§4／§5-1，非限 §4）。**映射选取为构造会话判断**——第二条（不产出聚合裁断）之任务包锚取 C6 六问集本体条，第四条（自算面为零）之锚取任务包 §1 引擎消费声明条，两处非字面同义而系职能对应，**呈KD**。
13. **`_scale` 四项实测回填与 A25**（观-6 执行侧）：真值源改实件实测，`_scale` 降镜像；`assertions` 一项因「A19 早于栈末」而取**实件调用点实测**，并由 A25 与本轮实跑登记数机械对表（实件实测 ↔ 实跑计数双向绑定）——该二次绑定形态为本会话反推，呈KD。
14. **交付形态＝统一 zip 封装首次适用（91-5(c)）**：包结构为 zip 根下 `判据档/`（＝ entity/＋verify/ 双子目录判据档，W-9(1) 判据档在此层）与**同级并列**之呈报件与随附件。判据档包根不含呈报件——A14／final_sweep 之全包域双向对表射程与交付件 14 件之计数因此零变动；A19 之呈报件射程仍取包根同级目录（原路径解析逻辑零改，仅钉版更新）。**该结构择定呈KD**。
15. **B-4 构造侧同步（靶集外附带项）＋ F-12 残余**：`closure_limitation_verbatim` 依收-6 原件逐字回补（见 §15-3）。该项不在开启文本靶集内（91-8 将 B-4 之修复分流至上游任务包 v1.2），本会话执行理由＝上游订正后本件转写落后于现行权威转写、且该字段自带 `verbatim` claim；**零判定面影响**（无断言依赖该字段）。**F-12 残余**：逐字 claim 之机械核证仍以构造期一次性程序化比对承载、未入交付前断言。两项均**呈KD追认**。
16. **外部装载钉版更新与中文数字维先行自查**：A18 之任务包路径钉版由 v1.1 改 v1.2（B-4 上游订正后现行版），A19 之呈报件文件名钉版由 v1_0 改 v1_1；三处路径均可由环境变量覆盖，装载域不在包内。**中文数字维**（91-6② 转化候选）：本会话对三件呈报件之中文数字型计数陈述作**先行人工＋程序化自查**，不改 A19 之正则射程——成文兑现归下批任务包模板，先行自查不构成提前立规，只构成本包自检加严（自查结果入切片记录）。

---

## §12 输出形态声明（裁决39-B 输出结构封闭）

顶层键集＝`{record_id, component_states, violations, diagnostics}`，**无声明外字段**。
`component_states` 键集＝六问集恰好，值 ∈ `{pass, fail, indeterminate}`。
`violations[]` 项键集＝`{code, locus}`，`locus` 键集＝`{container, key}`，字典序排序。
`diagnostics` ＝ `{}`（phase1 命中时）或 `{supply_form_echo: {六键→记录面供给形态之回显}}`。

**语义边界**：`pass/fail` 指**该问之验收面成立与否**，`indeterminate` 指**不可判**（未标定/缺供给/形态不合格）——三者均**不是**动作合法性判定（窗1 域 `legal/illegal`）、**不是**迁移闭合判定（窗2 域 `closed/not_closed`）。命名刻意三分，防跨窗语义混读。

---

## §13 交付件清单

见 §8。指纹全量见切片记录指纹列（W-13(17)）。交付包不自带源文副本（乙-3）。

---

## §14 A9 第七维回填检验之消费形态标注（86-3 之 P4；89-6 判例三要件）

本根记录面**零持仓引用**：无 `lot_id`／`instrument_type`／`position_id` 或任何同义字段——按 89-6 三要件字面（取其名／取其值域／进入核验路径）逐条核对，**三要件均不满足**。故本根**不构成消费**，按 43 B-4 义务承接如实留痕（统计面如实，非默认忽略）。②分量虽消费 T3-22 输出形态，但所取字段为翼级读数与状态标签，非持仓坐标键。

---

## §15 随包义务处置（任务包 §5 五项，缺一＝包义务未兑现）

1. **TPL1-T324-01 权威登记**（86 暂载→宿主兑现）：⑤ payoff shape 左尾/右尾供给方缺位，模板一缺定义型条目已于**本根撞墙清单建档落写**，桩降格标注在场（K08 机械核证），缺口描述限功能需求、不含接口设计（裁决14）。
2. **三-2 两禁形携带**：**正Carry口径禁形**——`positive_carry_caliber_form` 恒 `non_frozen_non_trigger`，禁形键集（冻结阈值/自动触发形态）经 K07 机械击落（负例 N10）；本根全文零处出现「90%+」之阈值化或触发器化表述。**量甲/量乙二分禁形**——④ 消费面强制 `funding_caliber_declaration` 单值声明（F-19），缺声明与混用均经 K06 击落（负例 N08/N09），分账并列／不混用不相减／不跨根相加（宪-ST-06／75-21）随行。
3. **收-6 限定语承接**：窗2 记录面消费处明写限定语，见 §3 声明块 `upstream_consumption_W2.closure_limitation_verbatim`——数量维缺席已登记为 TPL1-W2-03 已知不完备面，**最小充分主张不外推至数量守恒**，**不得读作数量面已闭合**。本根消费面仅取动作身份主键与子类语义，不触碰迁移闭合面。**v1.1 回补留痕（外审 B-4）**：v1.0 所载为任务包 v1.1 之节略转写（脱漏「最小充分主张不外推至数量守恒。后续任何读取窗2收口态者按此限定语引用」一句半并少一逗号）；上游已由裁决91-8 经任务包 v1.2 回补，本件同步改取**收-6 原件逐字**（构造期程序化比对：剥离强调标记后与收-6 原件全等）。该逐字 claim 之机械核证**未入交付前断言**（F-12 面残余，呈KD，见 §11 B档-15）。
4. **三-1 EP-06 承接（KD 裁定 (a)）**：schema 对间接消费面**挂上游根仪表标注指针**，指针要件明写于 §3 声明块各分量之 `instrument_annotation_pointer`（①指向 T3-03 §3.2 diagnostic 声明＋FW-03-甲 **§6** M1 契约⑥〔v1.1 补节号位，外审 B-5〕；②指向 T3-22 §2/§3#6）；③④⑤⑥ 显式标注「不适用」并注明理由，非默认忽略。**不沿 24-E3 形态逐处标注**；防护由上游根标注＋指针链可达承载。
5. **86-8 对照页（随包件A）承接**：宪-ST-08 对照零违反——六问全为结构/功能问句，本根零价格/盈亏/方向成分（判定面无任何数值比较）；`H_identity_target` 禁形随行（③⑥承接位：target 变化须进入 identity/target review，本根不代裁）；`parameter_slot_candidate` 禁形随行（§11 B档-4，零赋值）。

---

## §16 源文锚、层界标注与审计表状态（F-18 L2 完整性维）

- **判据级引用**：限随包件B″ v1.1 已裁行——T3·1342 ＋ T3·1345-1350（**七行**，KD 批裁 20260816）。三态＝思想锚定，主锚/交叉指针见该件。
- **未审引用**：T3 §13.5 域行1330-1338、§13.7 行1353 及其余相邻行一律标 **"未审引用"**（C4④），本根未消费其内容。
- **审计表状态**：《翻译审计表》v1.6 零含上述行键；新消费面按 C4② 先入表获 KD 三态裁定，载体＝随包件B″ v1.1 已裁版；物理收入挂审计表 v1.7 下次再版（50-3 滞后读法），**过渡期已裁版为权威**。
- **上游件缺陷留痕**：随包件B″ v1.1 版头行仍书 `v1.0`、标题括注仍书「三态候选」、层界核证总述仍称「锚定终态以 KD confirm 为准」——三处与已裁态矛盾（DEF-LOAD-1/2），已经 KD 裁定回传裁决台下次再版；判据面（表体七行）不受影响，本根按已裁态引用。

---

## §17 散文面数量指针对表登记（裁决90-5／收-7 成文判据之**首个成文载体**，强制）

- **射程**：本件散文面（**剔除 §3 内嵌声明块以避免自指**）∪ 本根撞墙清单 ∪ 本根切片记录之条目计数栏——即**全部呈报件散文面**（收-7 (ii) 射程扩至呈报件面，非仅 schema 首发件）。
- **真值源（v1.1 改，裁决91-10 观-6）**：`_scale.mutations／assertions／gap_entries／deliverables` 四项之真值源**改由实件程序化实测取得**——负控变异登记实测／断言栈调用点实件实测（并与本轮实跑登记数机械对表）／撞墙清单条目行实测／交付清单全包域实测；`_scale` 同名字段**降为镜像值**，镜像漂移即由 A25 非零退出击落。其余六项（`records／positive／negative／codes／components／boundary_injections`）之真值维持 `_scale`，其自身另由 A10／A12 与实件对表。登记表载于 `prose_count_pointers`（唯一权威源，本节不复刻正则字面量，防 F-14 所禁之字面量替代 schema 解析）。
- **双向形态（F-7）**：正向＝每一登记指针在射程内命中且取值与真值源一致；反向＝射程内全部数字型计数陈述须被某一登记指针之命中区间覆盖，未覆盖者即判不符（检多不止检缺）。
- **交叉指针对表（收-7 (iii)）**：呈报件内部之 TPL 条目号、B档-n／§n 指针、同批件名指针经机械对表，指向不存在或错位者即判不符（A20）。
- **纳入交付前断言**：A19（数量）＋A20（交叉指针）为交付前断言项，失败即非零退出。

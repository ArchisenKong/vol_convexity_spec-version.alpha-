#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""verify/negative_control.py · 负向对照（乙-4 最小形态）

变异**打在被测实现**（entity/roll_optionality_state_checker.py），非比对器、非 input。
每例变异指名其**实际失败断言**；杀灭率分母＝有效变异口径（裁决38-3／24-A1）。

F-9：变异集含 ≥1 例经**计算面**断言击落（A05/A06 之数值/判定面比对），
     非新鲜度或流水线通道击落——本集 M01–M09 九例与 v1.1 增量批之 M11–M13 三例
     均属计算面路径。

判定口径：变异后重跑被测实现，若其输出与手写钉表/独立复算发生差异（或诊断面
反测失败），即判该变异被**击落**；无差异＝逃逸（不合格信号）。
"""
import json
import os
import sys

sys.dont_write_bytecode = True

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(HERE)
ENT = os.path.join(PKG, "entity")
TARGET = os.path.join(ENT, "roll_optionality_state_checker.py")

MUTATIONS = [
    ("M01", "极性反转移除（负极性分量按正极性投影）",
     'return self.fail_s if answer is True else self.pass_s',
     'return self.pass_s if answer is True else self.fail_s', "A05/A06/A09"),
    ("M02", "未标定态判 pass（第三态塌缩）",
     'if answer is None:\n            return self.indet_s',
     'if answer is None:\n            return self.pass_s', "A05/A06"),
    ("M03", "phase1 门控移除（结构未过仍逐分量判定）",
     'if raw:\n            states = {k: self.indet_s for k in self.keys}',
     'if False:\n            states = {k: self.indet_s for k in self.keys}', "A05/A06"),
    ("M04", "K04 只检缺不检多（F-7 反向面失守）",
     'for k in sorted(present - declared):\n            v.append(("K04", "components", k))',
     'for k in []:\n            v.append(("K04", "components", k))', "A05/A06"),
    ("M05", "K05 枚举值域核验放宽",
     'elif fld in enums and w[fld] not in enums[fld]:\n                            v.append(("K05", k, "%s.%s" % (wing, fld)))',
     'elif False:\n                            v.append(("K05", k, "%s.%s" % (wing, fld)))', "A05/A06"),
    ("M06", "K06 量甲/量乙混用放行（F-19 失守）",
     'if (not isinstance(cal, list)) or len(cal) != 1 or cal[0] not in dom:',
     'if (not isinstance(cal, list)) or len(cal) < 1 or cal[0] not in dom:', "A05/A06"),
    ("M07", "K08 桩降格标注不检（桩被读作真值）",
     'if c.get("_stub_degraded") is not True:\n                    v.append(("K08", k, "_stub_degraded"))',
     'if False:\n                    v.append(("K08", k, "_stub_degraded"))', "A05/A06"),
    ("M08", "K10 target 来源不检（W-24 零侵入失守）",
     'if c.get("target_provenance") != d["target_provenance_required"]:\n                    v.append(("K10", k, "target_provenance"))',
     'if False:\n                    v.append(("K10", k, "target_provenance"))', "A05/A06"),
    ("M09", "K12 环闭合禁形键不检（C7 失守）",
     'if key in c7:\n                v.append(("K12", "record", key))',
     'if False:\n                v.append(("K12", "record", key))', "A05/A06"),
    ("M10", "诊断回显改同名常量（形态回显之记录面绑定失守）",
     'echo[k] = c.get("supply_form")',
     'echo[k] = "declared_verdict_stub"', "A21"),
    # ---- v1.1 增量批（靶-1）：新增三码/新触发条件之击落力锚 ----
    ("M11", "K13 标签一致性不检（自声明标签门控逃逸重现）",
     'if not label_ok:\n                v.append(("K13", k, "supply_form"))',
     'if False:\n                v.append(("K13", k, "supply_form"))', "A05/A06"),
    ("M12", "K10 触发条件退回『键在场』（门控键删除即逃逸）",
     'if k in self.tp_required or "target_provenance" in c:',
     'if "target_provenance" in c:', "A05/A06"),
    ("M13", "K11 容器缺席不报（槽位容器删除即逃逸）",
     'v.append(("K11", "record", "slots"))\n            slots = {}',
     'slots = {}', "A05/A06"),
]


def load_mutated(src):
    ns = {"__name__": "mutated_checker", "__file__": TARGET}
    exec(compile(src, "<mutated>", "exec"), ns)
    return ns["T324StateChecker"]


def run(cls, decl, records):
    ck = cls(decl)
    return [ck.evaluate(r) for r in records]


def main():
    base_src = open(TARGET, encoding="utf-8").read()
    decl = json.load(open(os.path.join(ENT, "t324_state_declaration.json"), encoding="utf-8"))
    inp = json.load(open(os.path.join(ENT, "synthetic_input.json"), encoding="utf-8"))
    pin = json.load(open(os.path.join(ENT, "expected_pin_table.json"), encoding="utf-8"))["records"]
    comp_keys = [c["key"] for c in decl["components"]]
    records = inp["records"]

    if len(MUTATIONS) != decl["_scale"]["mutations"]:
        raise SystemExit("变异登记实测数 %d ≠ 声明面镜像 _scale.mutations=%d（观-6 实测回填面）"
                         % (len(MUTATIONS), decl["_scale"]["mutations"]))

    killed, escaped, rows = 0, [], []
    for mid, desc, old, new, named in MUTATIONS:
        if base_src.count(old) != 1:
            raise SystemExit("变异锚定失败（命中数 != 1）: %s" % mid)
        res = run(load_mutated(base_src.replace(old, new)), decl, records)

        if named == "A21":
            expect = {r["record_id"]: {k: (next(x for x in records
                                                if x["record_id"] == r["record_id"])
                                            ["components"].get(k) or {}).get("supply_form")
                                       for k in comp_keys}
                      for r in res if r["diagnostics"]}
            diff = [rid for rid, m in expect.items()
                    if next(r for r in res if r["record_id"] == rid)
                    ["diagnostics"]["supply_form_echo"] != m]
        else:
            diff = [r["record_id"] for r in res
                    if r["component_states"] != pin[r["record_id"]]["component_states"]
                    or r["violations"] != pin[r["record_id"]]["violations"]]

        if diff:
            killed += 1
            rows.append({"id": mid, "desc": desc, "killed_by": named,
                         "first_failing_records": diff[:4], "status": "KILLED"})
        else:
            escaped.append(mid)
            rows.append({"id": mid, "desc": desc, "killed_by": named,
                         "first_failing_records": [], "status": "ESCAPED"})

    rate = "%d/%d" % (killed, len(MUTATIONS))
    print("=" * 78)
    for r in rows:
        print("[%s] %-4s %-34s ← %-10s %s"
              % (r["status"], r["id"], r["desc"][:34], r["killed_by"],
                 ",".join(r["first_failing_records"])))
    print("=" * 78)
    print("变异 %d 例；杀灭率 %s（分母＝有效变异口径，裁决38-3／24-A1）" % (len(MUTATIONS), rate))
    os.makedirs(os.path.join(HERE, "logs"), exist_ok=True)
    if not escaped:
        json.dump({"status": "PASS", "kill_rate": rate,
                   "mutations_measured": len(MUTATIONS), "mutations": rows},
                  open(os.path.join(HERE, "logs", "negative_control_log.json"),
                       "w", encoding="utf-8"), ensure_ascii=False, indent=2)
    sys.exit(0 if not escaped else 1)


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""五·窗2 负向对照（乙-4 mutation 最小形态；F-9 计算面击落例）。

v1.1（裁决90-2 甲案随动）：M07 重设计为「后侧非空判据取反」；新增 M11（前侧对称面）、
M12（多值形态回退恰1之守护变异）。

注入位**全部打在被测实现** `entity/roll_record_checker.py`（源级变异后于隔离命名空间
编译执行），非比对器、非人造 input、非声明面、非钉表。
击落判据＝变异后之逐记录输出 vs 钉表（判定面逐值比对，即 A04/A05/A06 之同路径）——
故全部击落例均为**经计算面断言击落**（F-9 之「≥1 例」以 10 例满足）。
失败输出指名实际失败断言（不写死单一归因，W-9(3)）。
"""
import json
import os
import sys

sys.dont_write_bytecode = True

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
ENTITY = os.path.join(ROOT, "entity")
LOGS = os.path.join(HERE, "logs")
os.makedirs(LOGS, exist_ok=True)

SRC = os.path.join(ENTITY, "roll_record_checker.py")

# (编号, 说明, 原串, 变异串)
MUTATIONS = [
    ("M01", "CA-1 两端非空判据取反（closing 空不再击落）",
     "if not clos:\n            out.append(self._viol(\"R01\", \"record\", \"closing_lots\"))",
     "if False:\n            out.append(self._viol(\"R01\", \"record\", \"closing_lots\"))"),
    ("M02", "CA-1 不相交判据删除（同一 lot 既平又开被放行）",
     "inter = set(clos) & set(opn)", "inter = set()"),
    ("M03", "CA-2 定义域双向对表退化为单向（只检缺不检多）",
     "sym = dom.symmetric_difference(clos)", "sym = clos - dom if False else (clos - dom)"),
    ("M04", "CA-2 值域封闭判据取反",
     "if t not in opn:", "if t in opn and False:"),
    ("M05", "CA-2 账本来源 migrated/映射目标一致性判据删除",
     "elif o == \"migrated\" and lid not in targets:", "elif False:"),
    ("M06", "CA-3 功能位键集相等判据删除",
     "rsym = set(before).symmetric_difference(set(after))", "rsym = set()"),
    ("M07", "CA-3 后侧承担者非空判据取反（后侧空集被放行；多值形态下界）",
     "if len(a) == 0:", "if False:"),
    ("M08", "CA-3 归属集判据取反（后承担者越集被放行）",
     "if not set(a) <= opn:", "if not set(a) <= opn and False:"),
    ("M09", "A9 第七维值域封闭判据删除",
     "if lot.get(\"instrument_type\") not in self.itype_domain:", "if False:"),
    ("M10", "门控错位：phase1 命中后不再跳过 phase2（单码设计被破坏）",
     "        v1 = self._p1(rec)\n        if v1:", "        v1 = self._p1(rec)\n        if v1 and False:"),
    ("M11", "CA-3 前侧承担者非空判据取反（前侧空集被放行；R08 双侧对称面）",
     "if len(b) == 0:", "if False:"),
    ("M12", "CA-3 多值形态回退为恰1形态（多值合法侧被误击落；裁决90-2 修订面守护）",
     "if len(a) == 0:", "if len(a) != 1:"),
]


def run_with(src_text):
    ns = {"__name__": "mutant_checker"}
    code = compile(src_text, "<mutant>", "exec")
    exec(code, ns)  # 隔离命名空间；不污染交付实现
    decl = json.load(open(os.path.join(ENTITY, "roll_record_declaration.json"), encoding="utf-8"))
    inp = json.load(open(os.path.join(ENTITY, "synthetic_input.json"), encoding="utf-8"))
    chk = ns["RollRecordChecker"](decl)
    return [chk.check(r) for r in inp["records"]]


def compare(results, pin):
    """返回被击落之具体断言名与首个差异点（不写死单一归因）。"""
    fails = []
    for r in results:
        e = pin[r["record_id"]]
        if r["verdict"] != e["verdict"]:
            fails.append(("A04(verdict bit-exact)", r["record_id"],
                          "%s != %s" % (r["verdict"], e["verdict"])))
        if r["violations"] != e["violations"]:
            fails.append(("A05(violations 逐项一致)", r["record_id"],
                          "got %s exp %s" % (json.dumps(r["violations"], ensure_ascii=False),
                                             json.dumps(e["violations"], ensure_ascii=False))))
        if r["diagnostics"] != e["diagnostics"]:
            fails.append(("A06(三方对表·diagnostics)", r["record_id"], "diag mismatch"))
    return fails


def main():
    base_src = open(SRC, encoding="utf-8").read()
    pin = json.load(open(os.path.join(ENTITY, "expected_pin_table.json"), encoding="utf-8"))["expected"]

    lines = ["=== 基线（零变异） ==="]
    base_fail = compare(run_with(base_src), pin)
    if base_fail:
        lines.append("BASELINE BROKEN: %s" % base_fail[:3])
        print("\n".join(lines))
        open(os.path.join(LOGS, "negative_control_log.txt"), "w", encoding="utf-8").write("\n".join(lines))
        return 1
    lines.append("baseline clean: %d/%d 与钉表一致，exit 0" % (len(pin), len(pin)))

    killed, survived = 0, []
    lines.append("=== 变异注入（被测实现侧，源级） ===")
    for mid, desc, old, new in MUTATIONS:
        if base_src.count(old) != 1:
            lines.append("%s ANCHOR-ERROR 命中数=%d：%s" % (mid, base_src.count(old), desc))
            survived.append(mid)
            continue
        mutant = base_src.replace(old, new, 1)
        try:
            fails = compare(run_with(mutant), pin)
        except Exception as ex:  # 变异致运行期异常亦计击落，但须指名
            fails = [("运行期异常", "-", type(ex).__name__)]
        if fails:
            killed += 1
            a, rid, det = fails[0]
            lines.append("%s KILLED  by %s @ %s | %s | %s" % (mid, a, rid, desc, det[:110]))
        else:
            survived.append(mid)
            lines.append("%s SURVIVED | %s" % (mid, desc))

    lines.append("-" * 62)
    lines.append("杀灭率 %d/%d（分母＝有效变异，裁决38-3／24-A1 标尺）" % (killed, len(MUTATIONS)))
    calc = sum(1 for ln in lines if "KILLED  by A0" in ln)
    lines.append("F-9：经**计算面断言**（判定面逐值比对 A04/A05/A06）击落 %d 例，"
                 "余者为变异致运行期异常；零例经新鲜度/流水线通道击落" % calc)
    out = "\n".join(lines)
    print(out)
    open(os.path.join(LOGS, "negative_control_log.txt"), "w", encoding="utf-8").write(out + "\n")
    return 0 if not survived else 1


if __name__ == "__main__":
    sys.exit(main())

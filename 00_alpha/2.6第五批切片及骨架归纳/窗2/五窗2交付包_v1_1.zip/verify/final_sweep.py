#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""五·窗2 末位复扫（F-15⑨ 全部脚本执行完毕后复扫；C-3／F-15③ 交付态原样复跑）。

四项：①包完整性双向对表（F-7 检"多"不止检"缺"）②脚本自产残留零（__pycache__/.pyc）
③交付态原样复跑之数值产物逐字节不变 ④指纹 12 件双向对表 ＋ 钉定件自摘要独立重算。
"""
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile

sys.dont_write_bytecode = True

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
LOGS = os.path.join(HERE, "logs")
os.makedirs(LOGS, exist_ok=True)
LINES, OK = [], True


def chk(name, ok, detail=""):
    global OK
    OK = OK and ok
    LINES.append("%-28s %-4s %s" % (name, "PASS" if ok else "FAIL", detail))


def sha256(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for c in iter(lambda: f.read(65536), b""):
            h.update(c)
    return h.hexdigest()


PROV = json.load(open(os.path.join(HERE, "provenance.json"), encoding="utf-8"))

# ① 包完整性双向
delivered = []
for dp, dns, fns in os.walk(ROOT):
    for fn in fns:
        delivered.append(os.path.relpath(os.path.join(dp, fn), ROOT).replace(os.sep, "/"))
allow = {"verify/recompute_output.json", "verify/provenance.json",
         "verify/logs/assert_log.txt", "verify/logs/negative_control_log.txt",
         "verify/logs/final_sweep_log.txt", "verify/logs/scan_exclusion_log.txt"}
declared = set(PROV["digests"]) | allow
missing = set(PROV["digests"]) - set(delivered)      # 核心交付件必在（"缺"侧）
extra = set(delivered) - declared                     # 域外未声明件（"多"侧，F-7）
chk("pkg_closure(双向)", not missing and not extra,
    "交付%d 缺%d 域外%d" % (len(delivered), len(missing), len(extra)))

# ② 脚本自产残留
residue = [r for r in delivered if r.endswith(".pyc") or "__pycache__" in r]
chk("no_script_residue", not residue, "残留 %d" % len(residue))
srcs = [r for r in delivered if r.endswith(".py")]
nobc = all("dont_write_bytecode" in open(os.path.join(ROOT, r), encoding="utf-8").read() for r in srcs)
chk("dont_write_bytecode(全脚本)", nobc, "%d/%d" % (sum(1 for r in srcs), len(srcs)))

# ③ 交付态原样复跑：数值产物逐字节不变
before = sha256(os.path.join(ROOT, "entity/outputs/run_output.json"))
tmp = tempfile.mkdtemp()
try:
    shutil.copytree(os.path.join(ROOT, "entity"), os.path.join(tmp, "entity"))
    subprocess.run([sys.executable, os.path.join(tmp, "entity", "harness.py")],
                   check=True, capture_output=True)
    after = sha256(os.path.join(tmp, "entity", "outputs", "run_output.json"))
finally:
    shutil.rmtree(tmp, ignore_errors=True)
chk("rerun_bit_identical", before == after, before[:12] + " vs " + after[:12])

# ④ 指纹双向 ＋ 自摘要
live = {k: sha256(os.path.join(ROOT, k)) for k in PROV["digests"]}
self_dig = hashlib.sha256(json.dumps(live, ensure_ascii=False, sort_keys=True,
                                     separators=(",", ":")).encode("utf-8")).hexdigest()
chk("fingerprints(12件双向)", live == PROV["digests"], "%d 件" % len(live))
chk("self_manifest_digest", self_dig == PROV["_self_manifest_digest"], self_dig[:12])

out = "\n".join(LINES) + "\n" + ("ALL PASS" if OK else "SWEEP FAILED")
print(out)
open(os.path.join(LOGS, "final_sweep_log.txt"), "w", encoding="utf-8").write(out + "\n")
sys.exit(0 if OK else 1)

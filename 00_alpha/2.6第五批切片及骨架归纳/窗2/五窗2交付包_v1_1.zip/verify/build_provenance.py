#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""交付件指纹钉定件之生成/核验（F-5 双钉之指纹半；F-8 钉定件自指闭环禁令）。

--generate：构造期生成 verify/provenance.json
--verify  ：交付态核验（默认）——逐件重算 SHA256 与钉定件比对，并重算钉定件自摘要。
F-8 兑现：钉定件自身入双钉射程——载荷条目集之 SHA256 写入 `_self_manifest_digest`，
          由 assert_check.py 独立重算核对（非本脚本自证）。
"""
import hashlib
import json
import os
import sys

sys.dont_write_bytecode = True

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
PIN = os.path.join(HERE, "provenance.json")

MANIFEST = [
    "entity/expected_pin_table.json",
    "entity/harness.py",
    "entity/input_schema.md",
    "entity/outputs/run_output.json",
    "entity/roll_record_checker.py",
    "entity/roll_record_declaration.json",
    "entity/synthetic_input.json",
    "verify/assert_check.py",
    "verify/build_provenance.py",
    "verify/final_sweep.py",
    "verify/independent_recompute.py",
    "verify/negative_control.py",
]


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def digests():
    return {rel: sha256(os.path.join(ROOT, rel)) for rel in MANIFEST}


def self_digest(d):
    blob = json.dumps(d, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()


def main():
    mode = "--verify"
    for a in sys.argv[1:]:
        if a in ("--generate", "--verify"):
            mode = a
    d = digests()
    if mode == "--generate":
        payload = {"_produced_by": "verify/build_provenance.py",
                   "_scope": "entity/ 与 verify/ 全交付件（12 件），不含本钉定件自身之文件哈希（自指闭环禁令，F-8）",
                   "_self_manifest_digest": self_digest(d),
                   "digests": d}
        with open(PIN, "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False, indent=2, sort_keys=True)
            f.write("\n")
        print("provenance generated: %d entries" % len(d))
        return 0
    with open(PIN, encoding="utf-8") as f:
        pinned = json.load(f)
    bad = [k for k in sorted(set(d) | set(pinned["digests"]))
           if d.get(k) != pinned["digests"].get(k)]
    if bad:
        print("PROVENANCE MISMATCH: %s" % ", ".join(bad))
        return 1
    if self_digest(d) != pinned["_self_manifest_digest"]:
        print("SELF MANIFEST DIGEST MISMATCH")
        return 1
    print("provenance verified: %d/%d entries bit-identical; self digest OK" % (len(d), len(MANIFEST)))
    return 0


if __name__ == "__main__":
    sys.exit(main())

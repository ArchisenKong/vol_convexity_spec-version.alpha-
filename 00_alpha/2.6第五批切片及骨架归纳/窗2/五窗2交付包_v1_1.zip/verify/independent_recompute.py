#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""五·窗2 独立复算路径（模板三 D 段②）。

独立性形态（F-2 判别据＝是否共享同一失效模式）：
  被测实现＝相位顺序推进 · 早退门控（命中即 return，门控与判定交织）；
  本路径  ＝**全谓词矩阵先算尽、门控作后置过滤器**（判定与门控分离，
            每个违规码由独立闭包谓词各自从 clean 人造 input 求值）。
  v1.1（裁决90-2 甲案随动）：R08 谓词由「基数 != 1」改「集为空」；诊断改承担者集之品种去重表。
  两路径对「门控错位」「码间级联」「排序」三类失效模式不共享——代数等价改写与零重写复制均不构成分叉（F-2），本路径非此二者。

独立性封闭规则：
  - 不 import、不读取 entity/ 下任何 .py；
  - 不读取 entity/outputs/run_output.json（不取 harness 中间量或产物）；
  - 不读取自身既往产物（F-8）；
  - 唯一共享输入＝人造 input ＋ 声明面 JSON（schema 本体入比对面，F-14）。
"""
import json
import os
import sys

sys.dont_write_bytecode = True

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
ENTITY = os.path.join(ROOT, "entity")

FORBIDDEN_READ = ("run_output.json", "roll_record_checker.py", "harness.py")


def _guard(path):
    base = os.path.basename(path)
    if base in FORBIDDEN_READ:
        raise SystemExit("独立性封闭规则违反：复算路径读取 %s" % base)
    return path


def load(name):
    with open(_guard(os.path.join(ENTITY, name)), encoding="utf-8") as f:
        return json.load(f)


# ---------------- 谓词族（逐码独立闭包；全部从 clean input 求值） ----------------

def build_predicates(decl):
    req = list(decl["record_required_refs"])
    subtype = decl["required_action_subtype"]
    idom = list(decl["position_ref_coordinate_key"]["domain"])
    odom = list(decl["ledger_origin_domain"])

    def P_R10(r):
        return [("record", f) for f in req if r.get(f) in (None, "")]

    def P_R11(r):
        return [] if r.get("action_subtype") == subtype else [("record", "action_subtype")]

    def P_R12(r):
        return [("position_lots_declared", l.get("lot_id"))
                for l in r.get("position_lots_declared", [])
                if l.get("instrument_type") not in idom]

    def P_R03(r):
        hits, declared = [], [l["lot_id"] for l in r.get("position_lots_declared", [])]
        for grp in (r.get("closing_lots", []), r.get("opening_lots", [])):
            counts = {}
            for x in grp:
                counts[x] = counts.get(x, 0) + 1
            rep = [x for x in grp if counts[x] > 1]
            if rep:
                hits.append(("record", rep[0]))
        absent = [x for x in sorted(set(r.get("closing_lots", [])) | set(r.get("opening_lots", [])))
                  if x not in declared]
        hits.extend(("record", x) for x in absent)
        return hits

    def P_R01(r):
        return [("record", k) for k in ("closing_lots", "opening_lots") if not r.get(k)]

    def P_R02(r):
        both = [x for x in r.get("closing_lots", []) if x in set(r.get("opening_lots", []))]
        return [("record", min(both))] if both else []

    def P_R04(r):
        dom = set(m["from_lot"] for m in r.get("ledger_migration_map", []))
        clo = set(r.get("closing_lots", []))
        miss = (dom | clo) - (dom & clo)
        return [("ledger_migration_map", min(miss))] if miss else []

    def P_R05(r):
        opn = set(r.get("opening_lots", []))
        return [("ledger_migration_map", m["to_lot"])
                for m in r.get("ledger_migration_map", []) if m["to_lot"] not in opn]

    def P_R06(r):
        tg = set(m["to_lot"] for m in r.get("ledger_migration_map", []))
        org = r.get("ledger_origin", {})
        hits = []
        for lid in sorted(set(r.get("opening_lots", []))):
            o = org.get(lid)
            ok = (o in odom) and ((o == "migrated") == (lid in tg))
            if not ok:
                hits.append(("ledger_origin", lid))
        return hits

    def P_R07(r):
        b, a = set(r.get("function_roles_before", {})), set(r.get("function_roles_after", {}))
        s = (b | a) - (b & a)
        return [("function_roles", min(s))] if s else []

    def P_R08(r):
        hits = []
        for side, cont in (("function_roles_before", "function_roles_before"),
                           ("function_roles_after", "function_roles_after")):
            for role in sorted(r.get(side, {})):
                if not r[side][role]:
                    hits.append((cont, role))
        return hits

    def P_R09(r):
        hits = []
        for side, target in (("function_roles_before", set(r.get("closing_lots", []))),
                             ("function_roles_after", set(r.get("opening_lots", [])))):
            for role in sorted(r.get(side, {})):
                if any(x not in target for x in r[side][role]):
                    hits.append((side, role))
        return hits

    return {"R01": P_R01, "R02": P_R02, "R03": P_R03, "R04": P_R04, "R05": P_R05,
            "R06": P_R06, "R07": P_R07, "R08": P_R08, "R09": P_R09,
            "R10": P_R10, "R11": P_R11, "R12": P_R12}


def diagnostics(r, suppressed):
    res = {}
    if suppressed:
        return {"role_instrument_type_change": res}
    itype = {l["lot_id"]: l["instrument_type"] for l in r.get("position_lots_declared", [])}
    b, a = r.get("function_roles_before", {}), r.get("function_roles_after", {})
    for role in sorted(b):
        if role not in a:
            continue
        tb = sorted({itype[x] for x in b[role] if x in itype})
        ta = sorted({itype[x] for x in a[role] if x in itype})
        res[role] = {"before": tb, "after": ta, "changed": tb != ta}
    return {"role_instrument_type_change": res}


def recompute(decl, inp):
    preds = build_predicates(decl)
    ph1 = list(decl["check_phases"]["phase1_structural"])
    ph2 = list(decl["check_phases"]["phase2_closure"])
    out = []
    for r in inp["records"]:
        # 1) 全谓词矩阵先算尽（不因门控跳算）
        matrix = {code: fn(r) for code, fn in preds.items()}
        # 2) 门控作后置过滤器
        p1_hits = [(c, loc) for c in ph1 for loc in matrix[c]]
        if p1_hits:
            kept = p1_hits
            suppressed = True
        else:
            r07 = matrix["R07"]
            if r07:
                kept = [("R07", loc) for loc in r07]
                suppressed = True
            else:
                kept = [(c, loc) for c in ph2 for loc in matrix[c]]
                suppressed = False
        vs = sorted(({"code": c, "locus": {"container": loc[0], "key": loc[1]}} for c, loc in kept),
                    key=lambda x: (x["code"], x["locus"]["container"], x["locus"]["key"]))
        out.append({"record_id": r.get("record_id"),
                    "verdict": "not_closed" if vs else "closed",
                    "violations": vs,
                    "diagnostics": diagnostics(r, suppressed)})
    return out


def main():
    decl = load("roll_record_declaration.json")
    inp = load("synthetic_input.json")
    res = recompute(decl, inp)
    payload = {"_produced_by": "verify/independent_recompute.py",
               "_path_independence": "全谓词矩阵＋后置门控（被测侧＝相位早退），非代数等价改写、非零重写复制",
               "_record_count": len(res), "results": res}
    with open(os.path.join(HERE, "recompute_output.json"), "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)
        f.write("\n")
    print("recompute OK: records=%d closed=%d"
          % (len(res), sum(1 for x in res if x["verdict"] == "closed")))


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""五·窗2 合格断言脚本（模板三 D 段；任一断言失败即非零退出码，W-13(2)）。

v1.1（裁决90-2 甲案／90-5 乙类订正随动）：A12 重写为多值形态恰界核证；A17 增诊断值形态核；
A31 恰界重申报自检；**新增 A32 散文面数量指针对表**（90-5 转化候选之本根即时形态）。

钉表构造顺序留痕（F-10 三处一致之第二处）：**先钉表后跑数**——
`entity/expected_pin_table.json` 与 `entity/synthetic_input.json` 同轮提交，
先于 `entity/harness.py` 首次实跑。另两处＝input_schema.md §7、切片记录。

判据面纯净性自扫描射程声明（转-1）：本脚本之自扫描为**字面层**（模式匹配），
非语义层；语义适当性之权威证伪面＝人读审计（外审）。
"""
import hashlib
import json
import os
import re
import sys

sys.dont_write_bytecode = True

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
LOGS = os.path.join(HERE, "logs")
os.makedirs(LOGS, exist_ok=True)

RESULTS = []


def A(name, ok, detail=""):
    RESULTS.append((name, bool(ok), detail))
    print("%-5s %-4s %s" % (name, "PASS" if ok else "FAIL", detail))


def rj(p):
    with open(p, encoding="utf-8") as f:
        return json.load(f)


def rt(p):
    with open(p, encoding="utf-8") as f:
        return f.read()


DECL = rj(os.path.join(ROOT, "entity/roll_record_declaration.json"))
INP = rj(os.path.join(ROOT, "entity/synthetic_input.json"))
PIN = rj(os.path.join(ROOT, "entity/expected_pin_table.json"))
RUN = rj(os.path.join(ROOT, "entity/outputs/run_output.json"))
REC = rj(os.path.join(HERE, "recompute_output.json"))
SCHEMA = rt(os.path.join(ROOT, "entity/input_schema.md"))

RUNM = {r["record_id"]: r for r in RUN["results"]}
RECM = {r["record_id"]: r for r in REC["results"]}
PINM = PIN["expected"]

# ---------------- 源文可及面 ----------------
SOURCE_ROOTS = [p for p in os.environ.get(
    "W2_SOURCE_ROOTS", "/mnt/project:/mnt/user-data/uploads").split(":") if p]


def find_source(frag):
    for root in SOURCE_ROOTS:
        if not os.path.isdir(root):
            continue
        for fn in sorted(os.listdir(root)):
            if frag in fn:
                return os.path.join(root, fn)
    return None


# ================= step0 前置合规 =================
A("A01", INP.get("_data_source") == "synthetic_hand_constructed"
  and "零数据源" in INP.get("_zero_data_source_declaration", "")
  and isinstance(INP.get("_synthetic_test_values"), dict),
  "人造 input 声明＋人造测试值隔离标注在场")

# --- A02 全包域 forbidden 静态扫描（任务6 F-1 现行模式集） ---
SCAN_EXCLUDED = ["verify/assert_check.py"]  # 排除面仅限检测器自身，非空指声明
IMPORT_LIBS = r"(requests|urllib|socket|yfinance|ibapi|ib_insync|pandas_datareader)"
PATTERNS = [
    r"^\s*import\s+" + IMPORT_LIBS + r"\b",
    r"^\s*from\s+" + IMPORT_LIBS + r"\b",
    r"IBKR", r"QuantConnect", r"http" + r"://", r"http" + r"s://",
    r"urlopen", r"requests\.", r"socket\.",
    r"importlib", r"__imp" + r"ort__", r"b64" + r"decode",
]


def strip_comments(src):
    src = re.sub(r'("""|\'\'\')(?:.|\n)*?\1', "", src)
    return "\n".join(re.sub(r"#.*$", "", ln) for ln in src.split("\n"))


scan_files, scan_hits = [], []
for dp, dns, fns in os.walk(ROOT):
    for fn in sorted(fns):
        if not fn.endswith(".py"):
            continue
        rel = os.path.relpath(os.path.join(dp, fn), ROOT).replace(os.sep, "/")
        scan_files.append(rel)
        if rel in SCAN_EXCLUDED:
            continue
        body = strip_comments(rt(os.path.join(dp, fn)))
        for pat in PATTERNS:
            if re.search(pat, body, re.M):
                scan_hits.append((rel, pat))
A("A02", not scan_hits,
  "全包域 %d 件 .py 扫描；排除清单 %d 条（仅检测器自身）；命中 %d"
  % (len(scan_files), len(SCAN_EXCLUDED), len(scan_hits)))

rec_src = rt(os.path.join(HERE, "independent_recompute.py"))
rec_body = strip_comments(rec_src)
A("A03", (not re.search(r"^\s*(from|import)\s+(roll_record_checker|harness)\b", rec_body, re.M))
  and ("FORBIDDEN_READ" in rec_body and "run_output.json" in rec_body and "_guard(" in rec_body)
  and ("recompute_output.json" not in rec_body.split("def main")[0]),
  "独立复算路径隔离：零 import 被测实现/harness、读取封闭规则 _guard 在场且含 run_output.json、零自读既往产物（F-8）")

# ================= 判定比对 =================
A("A04", all(RUNM[k]["verdict"] == RECM[k]["verdict"] for k in PINM),
  "verdict 逐记录 bit-exact（子口径(a)=0，离散判定面）%d/%d" % (len(PINM), len(PINM)))
A("A05", all(RUNM[k]["violations"] == RECM[k]["violations"] for k in PINM),
  "violations 逐项 (code,container,key) 精确一致")
three = all(RUNM[k][f] == RECM[k][f] == PINM[k][f]
            for k in PINM for f in ("verdict", "violations", "diagnostics"))
A("A06", three and len(PINM) == len(RUN["results"]) == len(REC["results"]),
  "钉表·实跑·复算三方程序化对表 %d/%d（F-15⑧）" % (len(PINM), len(PINM)))

# ================= 附加断言 =================
codes = [c["code"] for c in DECL["violation_codes"]]
fired = {}
for k, r in RUNM.items():
    for v in r["violations"]:
        fired.setdefault(v["code"], []).append(k)

A("A07", fired.get("R01") == ["N01", "N13"] and fired.get("R02") == ["N02"]
  and fired.get("R03") == ["N03"] and DECL["closure_assertions"][0]["id"] == "CA-1",
  "CA-1 lot集闭合：R01 双侧（opening 空 N01／closing 空 N13）＋R02/R03 各有负例击落")

n04 = INP["records"][[r["record_id"] for r in INP["records"]].index("N04")]
p4 = INP["records"][[r["record_id"] for r in INP["records"]].index("P4")]
A("A08", fired.get("R04") == ["N04", "N14"]
  and len(n04["ledger_migration_map"]) == len(n04["closing_lots"]) - 1
  and len(p4["ledger_migration_map"]) == len(p4["closing_lots"]),
  "CA-2 定义域双向对表（检缺 N04＋检多 N14）；恰界双侧：合法侧 P4 %d/%d、违规侧 N04 %d/%d"
  % (len(p4["ledger_migration_map"]), len(p4["closing_lots"]),
     len(n04["ledger_migration_map"]), len(n04["closing_lots"])))

A("A09", fired.get("R05") == ["N05"] and fired.get("R06") == ["N06"],
  "CA-2 值域封闭（R05）与账本来源一致性（R06）各有负例击落")

origins = set()
for r in INP["records"]:
    origins |= set(r.get("ledger_origin", {}).values())
A("A10", origins <= set(DECL["ledger_origin_domain"]) and "new_capital" in origins
  and any(v == "new_capital" for v in
          INP["records"][[x["record_id"] for x in INP["records"]].index("P3")]["ledger_origin"].values()),
  "账本来源值域封闭且 new_capital 显式标注实证（P3）")

A("A11", fired.get("R07") == ["N07"], "CA-3 功能位键集前后相等（R07）负例击落")

def recof(rid):
    return INP["records"][[r["record_id"] for r in INP["records"]].index(rid)]


n08 = recof("N08")
cards = [len(v) for r in INP["records"] if r["record_id"].startswith("P")
         for v in list(r["function_roles_before"].values()) + list(r["function_roles_after"].values())]
n08_empty = sorted((sd, role) for sd in ("function_roles_before", "function_roles_after")
                   for role, v in n08[sd].items() if len(v) == 0)
A("A12", sorted(set(fired.get("R08", []))) == ["N08"] and min(cards) == 1 and max(cards) >= 2
  and n08_empty == [("function_roles_after", "r1"), ("function_roles_before", "r2")]
  and all(RUNM[k]["verdict"] == "closed" for k in ("P2", "P3")),
  "CA-3 多值形态（裁决90-2 甲案）：下界恰界合法侧基数 %d／多值合法侧基数 %d 判 closed；违规侧 N08 前后两侧空集各一 locus 击落（%d 处）"
  % (min(cards), max(cards), len(n08_empty)))

A("A13", fired.get("R09") == ["N09"], "CA-3 承担者归属集（R09）负例击落")

A("A14", fired.get("R10") == ["N10"]
  and set(DECL["record_required_refs"]) == {"action_id", "source_execution_ref", "action_subtype"}
  and all(f in SCHEMA for f in DECL["record_required_refs"]),
  "必填引用字段集取自声明面（非脚本字面量，F-14）并有负例击落")

A("A15", fired.get("R11") == ["N11"] and DECL["required_action_subtype"] == "roll",
  "action_subtype 身份核验：声明面驱动，负例击落")

W1 = find_source("五窗1_动作生命周期状态机_input_schema")
w1_ok = False
if W1:
    w1txt = rt(W1)
    w1_ok = ('"field": "instrument_type"' in w1txt) and ("linear" in w1txt and "option" in w1txt)
key7 = DECL["position_ref_coordinate_key"]
A("A16", fired.get("R12") == ["N12"] and key7["field"] == "instrument_type"
  and key7["domain"] == ["linear", "option"] and w1_ok,
  "A9 第七维同名同值域直引；与窗1 schema 坐标键对照在场；越域负例击落")

diag_vals, diag_form = set(), True
idom = set(DECL["position_ref_coordinate_key"]["domain"])
for r in RUN["results"]:
    for v in r["diagnostics"]["role_instrument_type_change"].values():
        diag_vals.add(v["changed"])
        diag_form = diag_form and set(v) == set(DECL["output_form"]["diagnostics_item_fields"]) \
            and isinstance(v["before"], list) and isinstance(v["after"], list) \
            and v["before"] == sorted(set(v["before"])) and v["after"] == sorted(set(v["after"])) \
            and set(v["before"]) <= idom and set(v["after"]) <= idom \
            and v["changed"] == (v["before"] != v["after"])
multi_diag = RUNM["P3"]["diagnostics"]["role_instrument_type_change"]["r1"]
A("A17", diag_vals == {True, False} and diag_form
  and RUNM["P4"]["diagnostics"] == RECM["P4"]["diagnostics"]
  and multi_diag["before"] == ["option"] and multi_diag["after"] == ["option"],
  "诊断字段取自实际执行路径返回值（F-15⑥）：changed 两种取值均实现，非常量回显；"
  "v1.1 值形态＝承担者集品种去重升序表（多值 P3·r1 实证），逐项形态核过")

kr = DECL["_key_roles"]
decl_keys = set(k for k in DECL if not k.startswith("_"))
emb = SCHEMA.split("<!-- W2-ROLLREC-DECL-EMBED -->")[1].split("```json")[1].split("```")[0].strip()
ext = rt(os.path.join(ROOT, "entity/roll_record_declaration.json")).strip()
A("A18", set(kr) == decl_keys and set(kr.values()) <= {"impl", "assert", "registry"}
  and emb == ext,
  "声明面键角色三分双向对表（%d 键全覆盖、无声明外键）＋内嵌块 vs 外置件逐字节同一（F-12 逐字复用机械核证）"
  % len(decl_keys))

out_codes = set(fired)
A("A19", out_codes <= set(codes) and set(DECL["locus_rule"]) == set(codes)
  and all(set(r) == set(DECL["output_form"]["per_record"]) for r in RUN["results"])
  and set(r["verdict"] for r in RUN["results"]) <= set(DECL["output_form"]["verdict_domain"]),
  "输出形态封闭＋违规码集封闭＋locus_rule 键集对表（%d 码）" % len(codes))

# --- A20 反面陈述段 vs 任务包 §4 逐条机械对表 ---
PKG = find_source("第五批窗2任务包")
pkg_items = []
if PKG:
    ptxt = rt(PKG)
    seg = ptxt.split("## §4 反面陈述段")[1].split("## §5")[0] if "## §4 反面陈述段" in ptxt else ""
    pkg_items = re.findall(r"^(\d+)\.\s+(.+)$", seg, re.M)
sch_seg = SCHEMA.split("## §9 反面陈述段")[1].split("## §10")[0] if "## §9 反面陈述段" in SCHEMA else ""
sch_items = re.findall(r"^(\d+)\.\s+(.+)$", sch_seg, re.M)
anchors = ["触发", "选型", "生命周期", "六问", "纠正", "pipeline", "参数取值", "外推"]
pair_ok = (len(pkg_items) == len(sch_items) == 8)
if pair_ok:
    for a, (i, txt) in zip(anchors, sch_items):
        if a not in txt:
            pair_ok = False
A("A20", pair_ok, "反面陈述段 vs 任务包 §4 逐条机械对表 %d/%d（F-13 v1.12 扩注）"
  % (len(sch_items), len(pkg_items)))

# --- A21 F-18 L2 完整性四项 ---
T1 = find_source("1_可复用方法论主题树")
l2_1 = False
if T1:
    lines = rt(T1).split("\n")
    l2_1 = (lines[1088].strip().startswith("### 4. roll = 功能迁移")
            and "delta" in lines[1090]
            and "迁移账本关系与功能承担者" in lines[1098])
l2_2 = ("受控文本" in SCHEMA) and ("§2" in SCHEMA and "§3" in SCHEMA and "§4" in SCHEMA)
l2_3 = ("随包件B" in SCHEMA) and ("未审" in SCHEMA)
l2_4 = ("思想层一手材料" in SCHEMA) and ("三件并联" in SCHEMA) and ("不适用" in SCHEMA.split("三件并联")[1][:200])
A("A21", l2_1 and l2_2 and l2_3 and l2_4,
  "[%s%s%s%s] " % (int(l2_1), int(l2_2), int(l2_3), int(l2_4)) +
  "F-18 L2 四项：①源文行1089/1091/1099 字面在场 ②三分回引条款号在场 ③审计表行状态与类B标注在场 ④思想层一手材料三件并联＝不适用之如实声明")

# --- A22 F-5/F-8 双钉 ---
PROV = rj(os.path.join(HERE, "provenance.json"))


def sha256f(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for c in iter(lambda: f.read(65536), b""):
            h.update(c)
    return h.hexdigest()


live = {k: sha256f(os.path.join(ROOT, k)) for k in PROV["digests"]}
self_dig = hashlib.sha256(json.dumps(live, ensure_ascii=False, sort_keys=True,
                                     separators=(",", ":")).encode("utf-8")).hexdigest()
A("A22", live == PROV["digests"] and self_dig == PROV["_self_manifest_digest"]
  and "指纹" in SCHEMA,
  "F-5 双钉（指纹%d件＋schema 声明面）；F-8 钉定件自摘要由本脚本独立重算核对" % len(live))

# --- A23 F-7 包完整性封闭（双向，检多不止检缺） ---
delivered = []
for dp, dns, fns in os.walk(ROOT):
    for fn in sorted(fns):
        rel = os.path.relpath(os.path.join(dp, fn), ROOT).replace(os.sep, "/")
        delivered.append(rel)
allow_extra = {"verify/recompute_output.json", "verify/provenance.json",
               "verify/logs/assert_log.txt", "verify/logs/negative_control_log.txt",
               "verify/logs/final_sweep_log.txt", "verify/logs/scan_exclusion_log.txt"}
declared = set(PROV["digests"]) | allow_extra
missing = sorted(set(PROV["digests"]) - set(delivered))   # 核心交付件必在
extra = sorted(set(delivered) - declared)                  # 检"多"：域外未声明件
A("A23", not missing and not extra,
  "F-7 包完整性双向对表：交付 %d 件、缺 %d、域外未声明 %d" % (len(delivered), len(missing), len(extra)))

A("A24", SCHEMA.lstrip().startswith("# 一阶实体") and "呈报态" in SCHEMA[:1200]
  and "构造会话" in SCHEMA[:2200],
  "F-15④ 状态头/身份头扫描：schema 状态头＝呈报态、会话身份头在场")

f10 = ("先钉表后跑数" in SCHEMA) and ("先钉表后跑数" in rt(os.path.join(HERE, "assert_check.py"))) \
      and ("先钉表后跑数" in PIN["_pin_order"])
A("A25", f10, "F-10 三处声明一致：schema §7 ／本脚本头注 ／钉表 _pin_order")

pure = ("字面层" in rt(os.path.join(HERE, "assert_check.py"))[:1500])
A("A26", pure, "判据面纯净性自扫描射程声明＝字面层（转-1）")

layers = re.findall(r"可检层次[：:]\s*(字面层|语义层)", SCHEMA)
A("A27", len(layers) >= len(DECL["closure_assertions"]),
  "F-3 可检层次逐条声明在场（%d 处）" % len(layers))

A("A28", DECL["parameter_slots"] == [] and "零赋值" in DECL["parameter_slots_note"]
  and "不外推" in json.dumps(INP["_synthetic_test_values"], ensure_ascii=False),
  "类三纪律：槽位空集·零赋值（C15）；人造测试值隔离标注在场")

# --- A29 乙面双留位零实现（代码面字面层） ---
BAN = ["moneyness", "strike_select", "tenor_select", "expiry_select",
       "roll_trigger", "trigger_time", "signal", "schedule"]
ban_hits = []
for rel in [x for x in scan_files if x not in SCAN_EXCLUDED]:   # 检测器自排除（同 A02）
    body = strip_comments(rt(os.path.join(ROOT, rel))).lower()
    for w in BAN:
        if w in body:
            ban_hits.append((rel, w))
A("A29", not ban_hits,
  "乙面双留位零实现（W-24 域＋FW-03-乙域）：代码面禁形词 %d 项零命中，扫描 %d 件（排除检测器自身）；射程＝字面层"
  % (len(BAN), len(scan_files) - len(SCAN_EXCLUDED)))

dup_codes = len(codes) != len(set(codes))
tiers = set(c["tier"] for c in DECL["violation_codes"])
ca_ids = [c["id"] for c in DECL["closure_assertions"]]
A("A30", (not dup_codes) and len(ca_ids) == len(set(ca_ids))
  and all(("边界级" in t) or ("假设级" in t) for t in tiers),
  "声明面域与集合闭合：码集无重复、CA 编号唯一、档位标注值域封闭")

p2c = max(len(v) for v in recof("P2")["function_roles_before"].values())
p3c = max(len(v) for v in recof("P3")["function_roles_after"].values())
A("A31", "_boundary_injection_declaration" in INP and "_coverage_backflow" in INP
  and "恰界" in INP["_boundary_injection_declaration"]
  and "重申报" in INP["_boundary_injection_declaration"]
  and fired.get("R04") == ["N04", "N14"] and sorted(set(fired.get("R08", []))) == ["N08"]
  and fired.get("R07") == ["N07"] and fired.get("R05") == ["N05"] and fired.get("R09") == ["N09"]
  and p2c >= 2 and p3c >= 2,
  "89-9-2 重申报自检（修订后判据实况）：计数/边界比较判据四处（R04 对称差／R08 基数下界／R07 键集对称差／R05·R09 子集越界）"
  "各有恰界合法侧与恰越违规侧；多值合法侧 P2 前侧 %d、P3 后侧 %d 实证，非空白申报" % (p2c, p3c))

# --- A32 散文面数量指针对表（裁决90-5 转化候选之本根即时形态；F-7 双向） ---
PCP = DECL["prose_count_pointers"]
_h, _r = SCHEMA.split("<!-- W2-ROLLREC-DECL-EMBED -->", 1)
_pre, _af = _r.split("```json", 1)
PROSE = _h + _pre + _af.split("\n```", 1)[1]          # 剔除 §3 内嵌声明块，避免自指
TRUTH = {"records_total": len(INP["records"]),
         "records_positive": sum(1 for r in INP["records"] if r["record_id"].startswith("P")),
         "records_negative": sum(1 for r in INP["records"] if r["record_id"].startswith("N")),
         "violation_code_count": len(DECL["violation_codes"])}
scale_ok = (INP["_scale"]["records"] == TRUTH["records_total"]
            and INP["_scale"]["positive"] == TRUTH["records_positive"]
            and INP["_scale"]["negative"] == TRUTH["records_negative"]
            and INP["_scale"]["positive"] + INP["_scale"]["negative"] == INP["_scale"]["records"])
fwd, spans = [], []
for ptr in PCP["pointers"]:
    ms = list(re.finditer(ptr["regex"], PROSE))
    hit = (len(ms) == 1) and all(int(g) == TRUTH[t] for g, t in zip(ms[0].groups(), ptr["truth"]))
    fwd.append((ptr["id"], hit))
    spans.extend((m.start(), m.end()) for m in ms)
uncovered = [m.group(0) for m in re.finditer(PCP["_sweep_regex"], PROSE)
             if not any(a <= m.start() and m.end() <= b for a, b in spans)]
A("A32", scale_ok and all(h for _, h in fwd) and not uncovered,
  "散文面数量指针对表（90-5）：正向 %d/%d 指针恰命中一次且与实件计数一致；反向清扫未覆盖计数陈述 %d 处；`_scale` 自洽"
  % (sum(1 for _, h in fwd if h), len(fwd), len(uncovered)))

# ================= 收口 =================
fail = [n for n, ok, _ in RESULTS if not ok]
with open(os.path.join(LOGS, "assert_log.txt"), "w", encoding="utf-8") as f:
    for n, ok, d in RESULTS:
        f.write("%s\t%s\t%s\n" % (n, "PASS" if ok else "FAIL", d))
    f.write("TOTAL %d/%d\n" % (len(RESULTS) - len(fail), len(RESULTS)))
with open(os.path.join(LOGS, "scan_exclusion_log.txt"), "w", encoding="utf-8") as f:
    f.write("SCAN_EXCLUDED (非空指声明，仅检测器自身):\n")
    for x in SCAN_EXCLUDED:
        f.write("  %s\n" % x)
    f.write("scanned .py files: %d\n" % len(scan_files))

print("-" * 62)
print("ASSERT SUMMARY: %d/%d PASS" % (len(RESULTS) - len(fail), len(RESULTS)))
if fail:
    print("FAILED: %s" % ", ".join(fail))
    sys.exit(1)
sys.exit(0)

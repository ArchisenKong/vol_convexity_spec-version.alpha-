#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""五·窗2 被测实现 —— roll 事件记录之迁移闭合核验器。

形态＝记录/归因 schema 型（T3-15/T3-16 同型先例）。
输入＝一条 roll 事件记录（人造）；输出＝该记录之迁移闭合判定与违规点定位。
实现风格：相位顺序推进 · 早退门控（phase1 命中即跳过 phase2；R07 命中即跳过 R08/R09）。
v1.1（裁决90-2 甲案随动）：CA-3 承担者改多值形态——R08 由「基数恰1」改「集为空」；诊断改承担者集之品种去重表。
本实现不做：触发时点/通道选择、目标合约选择、动作生命周期推进、六问验收、纠正语义。
"""
import sys

sys.dont_write_bytecode = True


class RollRecordChecker:
    def __init__(self, decl):
        self.decl = decl
        self.required_refs = decl["record_required_refs"]
        self.required_subtype = decl["required_action_subtype"]
        self.itype_domain = set(decl["position_ref_coordinate_key"]["domain"])
        self.origin_domain = set(decl["ledger_origin_domain"])
        self.phase1 = decl["check_phases"]["phase1_structural"]
        self.phase2 = decl["check_phases"]["phase2_closure"]

    # ---------- 工具 ----------
    @staticmethod
    def _viol(code, container, key):
        return {"code": code, "locus": {"container": container, "key": key}}

    @staticmethod
    def _sort(vs):
        return sorted(vs, key=lambda x: (x["code"], x["locus"]["container"], x["locus"]["key"]))

    @staticmethod
    def _first_dup(seq):
        seen = set()
        for x in seq:
            if x in seen:
                return x
            seen.add(x)
        return None

    # ---------- phase 1：结构前置 ----------
    def _p1(self, rec):
        out = []
        # R10 必填引用字段在场性（窗1 C9 消费面之身份引用）
        for f in self.required_refs:
            if f not in rec or rec[f] in (None, ""):
                out.append(self._viol("R10", "record", f))
        # R11 子类身份
        if rec.get("action_subtype") != self.required_subtype:
            out.append(self._viol("R11", "record", "action_subtype"))
        # R12 A9 第七维值域封闭
        declared = rec.get("position_lots_declared", [])
        for lot in declared:
            if lot.get("instrument_type") not in self.itype_domain:
                out.append(self._viol("R12", "position_lots_declared", lot.get("lot_id")))
        # R03 lot 集完整性（在场性 + 无重复）
        dset = set(l["lot_id"] for l in declared)
        clos = rec.get("closing_lots", [])
        opn = rec.get("opening_lots", [])
        for grp in (clos, opn):  # 集内重复；跨集重叠归 R02，射程不混
            dup = self._first_dup(list(grp))
            if dup is not None:
                out.append(self._viol("R03", "record", dup))
        for lid in sorted(set(clos) | set(opn)):
            if lid not in dset:
                out.append(self._viol("R03", "record", lid))
        # R01 两端非空
        if not clos:
            out.append(self._viol("R01", "record", "closing_lots"))
        if not opn:
            out.append(self._viol("R01", "record", "opening_lots"))
        # R02 不相交
        inter = set(clos) & set(opn)
        if inter:
            out.append(self._viol("R02", "record", min(inter)))
        return out

    # ---------- phase 2：迁移闭合（CA-1 残余 / CA-2 / CA-3） ----------
    def _p2(self, rec):
        out = []
        clos = set(rec["closing_lots"])
        opn = set(rec["opening_lots"])
        mp = rec.get("ledger_migration_map", [])
        dom = set(m["from_lot"] for m in mp)
        origin = rec.get("ledger_origin", {})

        # R04 定义域双向对表（检"缺"亦检"多"）
        sym = dom.symmetric_difference(clos)
        if sym:
            out.append(self._viol("R04", "ledger_migration_map", min(sym)))
        # R05 值域封闭
        targets = set()
        for m in mp:
            t = m["to_lot"]
            targets.add(t)
            if t not in opn:
                out.append(self._viol("R05", "ledger_migration_map", t))
        # R06 账本来源在场性 / 值域 / 与映射一致性
        for lid in sorted(opn):
            o = origin.get(lid)
            if o not in self.origin_domain:
                out.append(self._viol("R06", "ledger_origin", lid))
            elif o == "migrated" and lid not in targets:
                out.append(self._viol("R06", "ledger_origin", lid))
            elif o == "new_capital" and lid in targets:
                out.append(self._viol("R06", "ledger_origin", lid))

        before = rec.get("function_roles_before", {})
        after = rec.get("function_roles_after", {})
        # R07 功能位键集相等
        rsym = set(before).symmetric_difference(set(after))
        if rsym:
            out.append(self._viol("R07", "function_roles", min(rsym)))
            return out  # 门控：键集不等时逐位检查病态
        for role in sorted(before):
            b, a = before[role], after[role]
            # R08 承担者集非空（多值形态：同一功能位可由多 lot 共担，仅设下界）
            if len(b) == 0:
                out.append(self._viol("R08", "function_roles_before", role))
            if len(a) == 0:
                out.append(self._viol("R08", "function_roles_after", role))
            # R09 归属集
            if not set(b) <= clos:
                out.append(self._viol("R09", "function_roles_before", role))
            if not set(a) <= opn:
                out.append(self._viol("R09", "function_roles_after", role))
        return out

    # ---------- 诊断（F-15⑥：取值来自实际执行路径返回值） ----------
    def _diag(self, rec, p1_hit, r07_hit):
        res = {}
        if p1_hit or r07_hit:
            return {"role_instrument_type_change": res}
        itype = {l["lot_id"]: l["instrument_type"] for l in rec["position_lots_declared"]}
        before = rec["function_roles_before"]
        after = rec["function_roles_after"]
        for role in sorted(before):
            if role not in after:
                continue
            tb = sorted(set(itype[x] for x in before[role] if x in itype))
            ta = sorted(set(itype[x] for x in after[role] if x in itype))
            res[role] = {"before": tb, "after": ta, "changed": tb != ta}
        return {"role_instrument_type_change": res}

    # ---------- 主入口 ----------
    def check(self, rec):
        v1 = self._p1(rec)
        if v1:
            vs = self._sort(v1)
            return {"record_id": rec.get("record_id"), "verdict": "not_closed",
                    "violations": vs, "diagnostics": self._diag(rec, True, False)}
        v2 = self._p2(rec)
        r07 = any(x["code"] == "R07" for x in v2)
        vs = self._sort(v2)
        return {"record_id": rec.get("record_id"),
                "verdict": "not_closed" if vs else "closed",
                "violations": vs,
                "diagnostics": self._diag(rec, False, r07)}

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""五·窗2 一次性 harness（裁决1 B 段）。

职责：喂入人造 input → 驱动被测实现 → 捕获输出数 → 落 run_output.json。
不承担数据获取、不建常设 pipeline / 数据接口 / 持久服务、零数据源。
"""
import json
import os
import sys

sys.dont_write_bytecode = True

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

from roll_record_checker import RollRecordChecker  # noqa: E402


def main():
    with open(os.path.join(HERE, "roll_record_declaration.json"), encoding="utf-8") as f:
        decl = json.load(f)
    with open(os.path.join(HERE, "synthetic_input.json"), encoding="utf-8") as f:
        inp = json.load(f)
    if inp.get("_data_source") != "synthetic_hand_constructed":
        raise SystemExit("input 非人造声明，拒跑（裁决1）")

    checker = RollRecordChecker(decl)
    results = [checker.check(rec) for rec in inp["records"]]

    out = {
        "_produced_by": "entity/harness.py",
        "_declaration_id": decl["_declaration_id"],
        "_declaration_version": decl["_declaration_version"],
        "_record_count": len(results),
        "results": results,
    }
    odir = os.path.join(HERE, "outputs")
    os.makedirs(odir, exist_ok=True)
    with open(os.path.join(odir, "run_output.json"), "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2, sort_keys=False)
        f.write("\n")
    n_closed = sum(1 for r in results if r["verdict"] == "closed")
    print("harness OK: records=%d closed=%d not_closed=%d"
          % (len(results), n_closed, len(results) - n_closed))


if __name__ == "__main__":
    main()

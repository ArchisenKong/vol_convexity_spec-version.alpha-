#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""verify/build_provenance.py · 交付件双钉之指纹侧（F-5／F-8）

指纹件与声明面双钉：本脚本产出 SHA256 指纹表，schema §8 载声明面；
断言 A13 核指纹、A14 双向核包完整性（检多不止检缺）。
本脚本**不读取自身既往产物**（provenance.json 每次全量重建）。
"""
import hashlib
import json
import os
import sys

sys.dont_write_bytecode = True

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(HERE)
OUT = os.path.join(HERE, "provenance.json")


def walk():
    out = []
    for root, dirs, files in os.walk(PKG):
        dirs[:] = [d for d in dirs if d != "__pycache__"]
        for fn in files:
            if fn.endswith(".pyc"):
                continue
            rel = os.path.relpath(os.path.join(root, fn), PKG).replace(os.sep, "/")
            if rel.startswith("verify/logs/") or rel == "verify/provenance.json":
                continue
            out.append(rel)
    return sorted(out)


def main():
    decl = json.load(open(os.path.join(PKG, "entity", "t324_state_declaration.json"),
                          encoding="utf-8"))
    files = [{"path": rel,
              "sha256": hashlib.sha256(open(os.path.join(PKG, rel), "rb").read()).hexdigest()}
             for rel in walk()]
    payload = {"_producer": "verify/build_provenance.py",
               "_declaration_id": decl["_declaration_id"],
               "_declaration_version": decl["_declaration_version"],
               "_file_count": len(files),
               "_exclusion_declaration": "排除面＝verify/logs/*（运行期日志）与 provenance.json "
                                         "自身（自指）；排除面最小化，宽于此即开口（F-7）",
               "files": files}
    json.dump(payload, open(OUT, "w", encoding="utf-8"),
              ensure_ascii=False, indent=2)
    open(OUT, "a", encoding="utf-8").write("\n")
    print("provenance ok: %d files" % len(files))


if __name__ == "__main__":
    main()

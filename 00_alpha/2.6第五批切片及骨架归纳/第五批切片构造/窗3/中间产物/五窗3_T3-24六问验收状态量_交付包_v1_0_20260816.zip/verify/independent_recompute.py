#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""verify/independent_recompute.py · 独立复算路径（模板三 D 段①②）

独立性口径（D段②＋F-2）：判别据＝改写后是否仍共享同一失效模式。
本路径与 entity/roll_optionality_state_checker.py 的**实现结构不同**：
  - 被测侧：按 phase 分段之命令式函数，逐分量 if 分支追加元组，末端 sorted(set(...))；
    三态由 if/else 分支产生。
  - 本侧：**码→谓词注册表**驱动，逐码独立求 locus 集合；三态由
    (极性, 答案) → 状态 之**查表映射**产生，不含分支判定；键名递归扫描改为**显式栈遍历**。
  两侧不共享任何函数、类或模块（本文件不 import 被测实现）。

F-8 独立性封闭规则：本脚本**不读取自身既往产物**、不读取 harness 中间量或
outputs/run_output.json；输入仅 entity/synthetic_input.json 与
entity/t324_state_declaration.json 两件 clean 人造/声明件。
"""
import json
import os
import sys

sys.dont_write_bytecode = True

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(HERE)
ENT = os.path.join(PKG, "entity")
OUT = os.path.join(HERE, "recompute_output.json")

FORBIDDEN_READS = ("run_output.json", "recompute_output.json", "provenance.json")


def _read(name):
    for bad in FORBIDDEN_READS:
        if bad in name:
            raise RuntimeError("独立性封闭规则违反：本脚本不得读取 %s" % bad)
    with open(os.path.join(ENT, name), encoding="utf-8") as f:
        return json.load(f)


def key_stream(node):
    """显式栈遍历（非递归），产出树内全部键名。"""
    stack = [node]
    while stack:
        cur = stack.pop()
        if isinstance(cur, dict):
            for k, v in cur.items():
                yield k
                stack.append(v)
        elif isinstance(cur, list):
            stack.extend(cur)


def build_predicates(D):
    """码 → 谓词。每个谓词接收 record，返回 [(container, key), ...]。"""
    comp_keys = [c["key"] for c in D["components"]]
    vsrc = {c["key"]: c["verdict_source"] for c in D["components"]}
    req = D["t3_22_required_fields"]
    enums = req["enum_domains"]
    c7 = frozenset(D["forbidden_keys"]["c7_loop_closure"])
    carry_bad = frozenset(D["forbidden_keys"]["carry_frozen_form"])

    def comps(r):
        return r.get("components") or {}

    def by_form(r, form):
        return [(k, c) for k, c in comps(r).items()
                if k in comp_keys and (c or {}).get("supply_form") == form]

    def k01(r):
        ev = r.get("roll_event") or {}
        ok = bool(ev.get("action_id")) and ev.get("action_subtype") == D["required_action_subtype"]
        return [] if ok else [("roll_event", "action_subtype")]

    def k02(r):
        got = (r.get("lifecycle_anchor") or {}).get("state")
        return [] if got == D["lifecycle_anchor_required"] else [("lifecycle_anchor", "state")]

    def k03(r):
        aid = (r.get("roll_event") or {}).get("action_id")
        out = []
        for k in comp_keys:
            if k not in comps(r):
                continue
            a = (comps(r)[k].get("anchor") or {})
            if [a.get("pre"), a.get("post")] != [aid, aid]:
                out.append(("components", k))
        return out

    def k04(r):
        present, declared = set(comps(r)), set(comp_keys)
        return [("components", k) for k in sorted(present ^ declared)]

    def k05(r):
        out = []
        for k, c in by_form(r, "t3_22_wing_vector"):
            for wing in ("put_wing", "call_wing"):
                w = c.get(wing)
                if not isinstance(w, dict):
                    out.append((k, wing))
                    continue
                out.extend((k, "%s.%s" % (wing, f)) for f in req[wing] if f not in w)
                out.extend((k, "%s.%s" % (wing, f)) for f in req[wing]
                           if f in w and f in enums and w[f] not in enums[f])
        return out

    def k06(r):
        dom, out = D["funding_caliber_domain"], []
        for k, c in by_form(r, "t3_18_breach_flag"):
            cal = c.get("funding_caliber_declaration")
            good = isinstance(cal, list) and len(cal) == 1 and cal[0] in dom
            if not good:
                out.append((k, "funding_caliber_declaration"))
        return out

    def k07(r):
        out = []
        for k, c in by_form(r, "t3_18_breach_flag"):
            if c.get("positive_carry_caliber_form") != D["positive_carry_caliber_form_required"]:
                out.append((k, "positive_carry_caliber_form"))
            out.extend((k, f) for f in sorted(carry_bad.intersection(c.keys())))
        return out

    def k08(r):
        return [(k, "_stub_degraded") for k, c in comps(r).items()
                if vsrc.get(k) == "declared_stub" and (c or {}).get("_stub_degraded") is not True]

    def k09(r):
        return [(k, "outcome") for k, c in by_form(r, "w1_identity_audit")
                if c.get("outcome") not in D["identity_audit_outcome_domain"]]

    def k10(r):
        return [(k, "target_provenance") for k, c in comps(r).items()
                if "target_provenance" in (c or {})
                and c["target_provenance"] != D["target_provenance_required"]]

    def k11(r):
        return [("slots", n) for n, s in (r.get("slots") or {}).items()
                if (s or {}).get("value") is not None]

    def k12(r):
        return [("record", k) for k in key_stream(r) if k in c7]

    return {"K01": k01, "K02": k02, "K03": k03, "K04": k04, "K05": k05, "K06": k06,
            "K07": k07, "K08": k08, "K09": k09, "K10": k10, "K11": k11, "K12": k12}


def build_projection(D):
    """(极性, 答案) → 状态 之查表映射（无分支判定）。"""
    p, f, i = D["verdict_domain"]
    return {("positive", True): p, ("positive", False): f, ("positive", None): i,
            ("negative", True): f, ("negative", False): p, ("negative", None): i}


def answer_of(D, key, comp, vsrc):
    src = vsrc[key]
    table = {
        "declared_stub": lambda c: c.get("verdict_declared"),
        "upstream_flag": lambda c: c.get("breach_flag"),
        "upstream_declared_value": lambda c: (
            None if c.get("outcome") not in D["identity_audit_outcome_domain"]
            else c.get("outcome") == D["identity_audit_outcome_domain"][1]),
    }
    return table.get(src, lambda c: None)(comp or {})


def recompute(D, records):
    preds = build_predicates(D)
    proj = build_projection(D)
    comp_keys = [c["key"] for c in D["components"]]
    pol = {c["key"]: c["polarity"] for c in D["components"]}
    vsrc = {c["key"]: c["verdict_source"] for c in D["components"]}
    ph1, ph2 = D["check_phases"]["phase1_structural"], D["check_phases"]["phase2_component"]
    indet = D["verdict_domain"][2]

    out = []
    for r in records:
        hits1 = [(code, ct, ky) for code in ph1 for (ct, ky) in preds[code](r)]
        if hits1:
            raw, states, diag = hits1, dict.fromkeys(comp_keys, indet), {}
        else:
            hits2 = [(code, ct, ky) for code in ph2 for (ct, ky) in preds[code](r)]
            polluted = frozenset(h[1] for h in hits2)
            cs = r.get("components") or {}
            states = {k: (indet if k in polluted
                          else proj[(pol[k], answer_of(D, k, cs.get(k), vsrc))])
                      for k in comp_keys}
            diag = {"supply_form_consumed": {k: (cs.get(k) or {}).get("supply_form")
                                             for k in comp_keys}}
            raw = hits2
        viol = [{"code": c, "locus": {"container": ct, "key": ky}}
                for c, ct, ky in sorted(set(raw), key=lambda t: (t[0], t[1], t[2]))]
        out.append({"record_id": r.get("record_id"), "component_states": states,
                    "violations": viol, "diagnostics": diag})
    return out


def main():
    D = _read("t324_state_declaration.json")
    data = _read("synthetic_input.json")
    results = recompute(D, data["records"])
    payload = {"_producer": "verify/independent_recompute.py",
               "_independence_declaration": "未 import 被测实现；未读取 harness 产物；"
                                            "码→谓词注册表 ＋ 查表投影 ＋ 显式栈遍历，"
                                            "与被测侧不共享失效模式（F-2）",
               "_record_count": len(results), "results": results}
    with open(OUT, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2, sort_keys=False)
        f.write("\n")
    print("independent ok: %d records -> %s" % (len(results), OUT))


if __name__ == "__main__":
    main()

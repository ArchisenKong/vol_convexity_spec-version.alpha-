#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""verify/final_sweep.py · 全部脚本执行完毕后之包完整性复扫（F-15⑨）

射程含脚本自产残留（__pycache__ / *.pyc / 临时件）。
复扫在最后执行——早于全部脚本跑完的扫描不构成本项兑现。
"""
import json
import os
import sys

sys.dont_write_bytecode = True

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(HERE)


def main():
    prov = json.load(open(os.path.join(HERE, "provenance.json"), encoding="utf-8"))
    declared = set(e["path"] for e in prov["files"])
    residue, actual = [], set()
    for root, dirs, files in os.walk(PKG):
        for d in list(dirs):
            if d == "__pycache__":
                residue.append(os.path.relpath(os.path.join(root, d), PKG))
        for fn in files:
            rel = os.path.relpath(os.path.join(root, fn), PKG).replace(os.sep, "/")
            if fn.endswith(".pyc"):
                residue.append(rel)
                continue
            if rel.startswith("verify/logs/") or rel == "verify/provenance.json":
                continue
            actual.add(rel)
    missing, extra = sorted(declared - actual), sorted(actual - declared)
    ok = not residue and not missing and not extra
    print("final_sweep: residue=%s missing=%s extra=%s" % (residue, missing, extra))
    print("final_sweep: %s" % ("PASS" if ok else "FAIL"))
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()

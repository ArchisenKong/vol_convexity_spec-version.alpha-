#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""verify/assert_check.py · 断言栈（模板三 D 段；W-13(2) 非零退出码）

构造顺序留痕（F-10，三处一致之第三处）：
    期望值钉表（entity/expected_pin_table.json，手写、独立通道）与人造 input
    同轮提交，**先于** harness 实跑；本脚本以钉表为基线之一执行对表。

断言 24 条（A01–A24）。任一失败即非零退出，且不写成功日志（F-3 流水线级 observable）。
"""
import hashlib
import io
import json
import os
import re
import subprocess
import sys
import tokenize

sys.dont_write_bytecode = True

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(HERE)
ENT = os.path.join(PKG, "entity")
LOGS = os.path.join(HERE, "logs")

# 外部装载件（乙-3：交付包不自带源文副本；以下为装载域只读引用）
SRC_DOC = os.environ.get(
    "T324_SRC_DOC",
    "/mnt/project/3_波动率凸性操作方法论主文档_T0_frozen_clean_20260615.md")
AUDIT_ADDENDUM = os.environ.get(
    "T324_AUDIT_ADDENDUM",
    "/mnt/user-data/uploads/随包件B__窗3审计表增量件_v1_1_20260816.md")
TASK_PACKAGE = os.environ.get(
    "T324_TASK_PACKAGE",
    "/mnt/user-data/uploads/第五批窗3任务包_v1_1_20260816.md")

# ---- F-1 静态扫描模式表（本文件为模式表宿主 ⇒ 检测器自排除，排除清单非空指声明）----
SCAN_EXCLUDED = ["assert_check.py"]          # 唯一条目＝检测器自身
DATA_SOURCE_PATTERNS = [
    "ibkr", "ib_insync", "quantconnect", "yfinance", "alpha_vantage", "polygon.io",
    "quandl", "requests.get", "requests.post", "urllib.request", "socket.socket",
    "http://", "https://", "read_csv", "read_parquet", "sqlite3", "psycopg", "pymysql",
    "boto3", "importlib", "__import__", "b64decode",
]
W24_TOKENS = ["wing_moneyness", "moneyness_depth", "strike_selection", "tenor_selection",
              "长短端比例", "期限取位", "结构选型"]
C7_TOKENS = ["disposition", "candidate_generated", "repair_candidate", "next_action"]
C7_SCOPE = ["roll_optionality_state_checker.py", "harness.py", "independent_recompute.py"]
C7_SCOPE_REASON = ("射程限判定路径三件；input 构造器与负控件须能将该类键**作为数据**构造出违例记录"
                   "（K12 之负例 N15 与变异均依赖之），故排除面恰为「非判定路径」，"
                   "不宽于正当理由（F-7）")

RESULTS = []


def A(idx, name, cond, detail=""):
    RESULTS.append({"id": idx, "name": name, "pass": bool(cond), "detail": detail})
    return bool(cond)


def rj(p):
    with open(p, encoding="utf-8") as f:
        return json.load(f)


def rt(p):
    with open(p, encoding="utf-8") as f:
        return f.read()


def strip_code(src):
    """剥离注释与 docstring，得判定基面（F-1）。"""
    out, prev_end, prev_tok = [], (1, 0), tokenize.INDENT
    try:
        toks = list(tokenize.generate_tokens(io.StringIO(src).readline))
    except Exception:
        return src
    for tt, ts, start, end, line in toks:
        if tt == tokenize.COMMENT:
            continue
        if tt == tokenize.STRING and prev_tok in (tokenize.INDENT, tokenize.NEWLINE,
                                                  tokenize.NL, tokenize.DEDENT,
                                                  tokenize.ENCODING):
            prev_tok = tt
            continue
        out.append(ts)
        if tt not in (tokenize.NL, tokenize.NEWLINE, tokenize.INDENT, tokenize.DEDENT):
            prev_tok = tt
    return "\n".join(out)


def all_pkg_files():
    """全包域遍历（F-7：发现面覆盖包根与全部子目录）。"""
    found = []
    for root, dirs, files in os.walk(PKG):
        dirs[:] = [d for d in dirs if d != "__pycache__"]
        for fn in files:
            if fn.endswith(".pyc"):
                continue
            found.append(os.path.relpath(os.path.join(root, fn), PKG).replace(os.sep, "/"))
    return sorted(found)


def sha256(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()


def main():
    D = rj(os.path.join(ENT, "t324_state_declaration.json"))
    inp = rj(os.path.join(ENT, "synthetic_input.json"))
    pin = rj(os.path.join(ENT, "expected_pin_table.json"))
    har = rj(os.path.join(ENT, "outputs", "run_output.json"))
    ind = rj(os.path.join(HERE, "recompute_output.json"))
    schema_md = rt(os.path.join(ENT, "input_schema.md"))
    comp_keys = [c["key"] for c in D["components"]]
    scripts = [f for f in all_pkg_files() if f.endswith(".py")]

    # ---------------------------------------------------------------- A01
    A("A01", "step0(i) input 人造构造",
      inp.get("_data_source") == "synthetic_hand_constructed"
      and "不接" in inp.get("_zero_data_source_declaration", ""),
      "_data_source=%s" % inp.get("_data_source"))

    # ---------------------------------------------------------------- A02
    hits = []
    for rel in scripts:
        if os.path.basename(rel) in SCAN_EXCLUDED:
            continue
        base = strip_code(rt(os.path.join(PKG, rel))).lower()
        for pat in DATA_SOURCE_PATTERNS:
            if pat.lower() in base:
                hits.append((rel, pat))
    A("A02", "step0(ii) 静态扫描面（%d 脚本，检测器自排除=%s）" % (len(scripts), SCAN_EXCLUDED),
      not hits, "命中=%s" % hits)

    # ---------------------------------------------------------------- A03
    ind_src = rt(os.path.join(HERE, "independent_recompute.py"))
    ind_base = strip_code(ind_src)
    reads = set(re.findall(r'_read\s*\(\s*"([^"]+)"', ind_src))
    A("A03", "step0(iii) 独立复算独立性封闭",
      ("roll_optionality_state_checker" not in ind_base)
      and ("FORBIDDEN_READS" in ind_base)
      and ("outputs" not in ind_base)
      and reads == {"t324_state_declaration.json", "synthetic_input.json"},
      "未 import 被测实现；禁读清单在场；实读件=%s" % sorted(reads))

    # ---------------------------------------------------------------- A04
    m = re.search(r"<!-- W3-T324-DECL-EMBED -->\s*\n```json\n(.*?)\n```", schema_md, re.S)
    embed_ok = False
    if m:
        embed_ok = json.loads(m.group(1)) == D
    A("A04", "三方对表：schema 内嵌块 ↔ declaration.json ↔ independent 解析（F-15⑧）",
      embed_ok and ind["_record_count"] == len(inp["records"]),
      "内嵌块解析一致=%s" % embed_ok)

    # ---------------------------------------------------------------- A05
    A("A05", "harness ↔ independent 逐记录 bit-exact（容差子口径 (a)＝0）",
      har["results"] == ind["results"] and D["tolerance"]["value"] == 0,
      "记录数=%d" % len(har["results"]))

    # ---------------------------------------------------------------- A06
    bad_pin = [r["record_id"] for r in har["results"]
               if r["component_states"] != pin["records"][r["record_id"]]["component_states"]
               or r["violations"] != pin["records"][r["record_id"]]["violations"]
               or (len(r["diagnostics"]) > 0) != pin["records"][r["record_id"]]["diagnostics_nonempty"]]
    A("A06", "钉表对表（F-10 先钉后跑）", not bad_pin, "不符=%s" % bad_pin)

    # ---------------------------------------------------------------- A07
    top_ok = all(set(r.keys()) == {"record_id", "component_states", "violations", "diagnostics"}
                 for r in har["results"])
    dom_ok = all(v in D["verdict_domain"] for r in har["results"]
                 for v in r["component_states"].values())
    srt_ok = all(r["violations"] == sorted(r["violations"],
                 key=lambda x: (x["code"], x["locus"]["container"], x["locus"]["key"]))
                 for r in har["results"])
    A("A07", "输出形态封闭（顶层键集／三态值域／violations 排序；裁决39-B）",
      top_ok and dom_ok and srt_ok, "top=%s dom=%s sort=%s" % (top_ok, dom_ok, srt_ok))

    # ---------------------------------------------------------------- A08
    src_lines = [c["source_line"] for c in D["components"]]
    keys_ok = all(set(r["component_states"].keys()) == set(comp_keys) for r in har["results"])
    A("A08", "C6 六问集本体：分量键集恰等于声明六问集且逐一绑定源文行（边界级）",
      keys_ok and len(comp_keys) == 6 and src_lines == ["T3·1345", "T3·1346", "T3·1347",
                                                        "T3·1348", "T3·1349", "T3·1350"],
      "keys=%d lines=%s" % (len(comp_keys), src_lines))

    # ---------------------------------------------------------------- A09
    pol = {c["key"]: c["polarity"] for c in D["components"]}
    # 反测：负极性分量之肯定答案必判 fail（P2/P4 实证），移除反转即被 A06 击落
    p2 = next(r for r in har["results"] if r["record_id"] == "P2")
    p4 = next(r for r in har["results"] if r["record_id"] == "P4")
    A("A09", "极性映射表一致性＋反测（F-4/F-14）",
      pol == {"q1_gamma_center": "positive", "q2_wing_integrity": "positive",
              "q3_moneyness_relevance": "positive", "q4_funding_relation": "negative",
              "q5_payoff_shape": "positive", "q6_identity_drift": "negative"}
      and p2["component_states"]["q4_funding_relation"] == "fail"
      and p4["component_states"]["q6_identity_drift"] == "fail",
      "负极性两分量肯定答案均判 fail")

    # ---------------------------------------------------------------- A10
    codes = [c["code"] for c in D["violation_codes"]]
    fired = set(v["code"] for r in har["results"] for v in r["violations"])
    phases = set(D["check_phases"]["phase1_structural"] + D["check_phases"]["phase2_component"])
    A("A10", "违规码集一致（%d 码）＋逐码 ≥1 负例命中" % len(codes),
      set(codes) == fired == phases and len(codes) == D["_scale"]["codes"],
      "未命中=%s" % sorted(set(codes) - fired))

    # ---------------------------------------------------------------- A11
    multi = [r["record_id"] for r in har["results"]
             if r["record_id"].startswith("N") and len(set(v["code"] for v in r["violations"])) != 1]
    clean_pos = [r["record_id"] for r in har["results"]
                 if r["record_id"].startswith("P") and r["violations"]]
    A("A11", "逐条单码设计（负例恰一码）＋正例零码",
      not multi and not clean_pos, "多码/零码负例=%s 带码正例=%s" % (multi, clean_pos))

    # ---------------------------------------------------------------- A12
    binj = inp["_boundary_injections"]
    binj_hit = all(any(v for v in next(r for r in har["results"]
                                       if r["record_id"] == rid)["violations"]) for rid in binj)
    A("A12", "恰界值/off-by-one 注入（89-9-2）：清单在场且逐条命中",
      len(binj) == D["_scale"]["boundary_injections"] and binj_hit,
      "注入=%s" % binj)

    # ---------------------------------------------------------------- A13
    prov_path = os.path.join(HERE, "provenance.json")
    prov = rj(prov_path)
    dk_bad = [e["path"] for e in prov["files"] if sha256(os.path.join(PKG, e["path"])) != e["sha256"]]
    A("A13", "交付件双钉：SHA256 ↔ 声明面（F-5/F-8）",
      not dk_bad and prov["_declaration_id"] == D["_declaration_id"], "指纹不符=%s" % dk_bad)

    # ---------------------------------------------------------------- A14
    declared = set(e["path"] for e in prov["files"])
    actual = set(f for f in all_pkg_files() if not f.startswith("verify/logs/")
                 and f != "verify/provenance.json")
    A("A14", "包完整性双向对表（F-7：检多不止检缺，全包域）",
      declared == actual,
      "缺=%s 多=%s" % (sorted(declared - actual), sorted(actual - declared)))

    # ---------------------------------------------------------------- A15
    w24 = [(rel, t) for rel in scripts for t in W24_TOKENS
           if os.path.basename(rel) not in SCAN_EXCLUDED
           and t in strip_code(rt(os.path.join(PKG, rel)))]
    A("A15", "W-24 零侵入：判定/构造脚本零结构选型成分", not w24, "命中=%s" % w24)

    # ---------------------------------------------------------------- A16
    c7 = [(rel, t) for rel in scripts if os.path.basename(rel) in C7_SCOPE
          for t in C7_TOKENS if t in strip_code(rt(os.path.join(PKG, rel)))]
    A("A16", "C7 环闭合禁令：判定路径三件零处置/candidate 生成实现", not c7,
      "射程=%s；命中=%s" % (C7_SCOPE, c7))

    # ---------------------------------------------------------------- A17
    slots_ok = all(s["value"] is None and s["form"] == "parameter_slot_candidate"
                   for s in D["parameter_slots"])
    A("A17", "C15 槽位登记不赋值（parameter_slot_candidate 零赋值）", slots_ok,
      "槽位=%s" % [s["slot_symbol"] for s in D["parameter_slots"]])

    # ---------------------------------------------------------------- A18
    neg_sec = re.search(r"## §9 反面陈述段(.*?)\n---", schema_md, re.S)
    neg_items = re.findall(r"^\d+\. ", neg_sec.group(1), re.M) if neg_sec else []
    tp = rt(TASK_PACKAGE) if os.path.exists(TASK_PACKAGE) else ""
    A("A18", "反面陈述段 ↔ 任务包 §4 逐条机械对表（F-13 扩注）",
      len(neg_items) >= 8 and "C7乙环闭合禁令（边界级重申）" in tp and "W-24零侵入" in tp,
      "反面陈述 %d 条；任务包 §4 关键条在场" % len(neg_items))

    # ---------------------------------------------------------------- A19
    prose_files = {"entity/input_schema.md": schema_md}
    sib = os.path.dirname(PKG)
    for extra in ("撞墙清单_五窗3_T3-24六问验收状态量_v1_0_20260816.md",
                  "切片记录_五窗3_T3-24六问验收状态量_v1_0_20260816.md"):
        p = os.path.join(sib, extra)
        if not os.path.exists(p):
            raise SystemExit("A19 射程缺件（呈报件未在场）: %s" % extra)
        prose_files[extra] = rt(p)
    fwd, covered = [], {k: [] for k in prose_files}
    for ptr in D["prose_count_pointers"]:
        truth = D["_scale"][ptr["truth_source"].split(".")[-1]]
        n = 0
        for k, txt in prose_files.items():
            body = re.sub(r"<!-- W3-T324-DECL-EMBED -->.*?```\n", "", txt, flags=re.S)
            for mm in re.finditer(ptr["pattern"], body):
                n += 1
                covered[k].append(mm.span())
                if int(mm.group(1)) != truth:
                    fwd.append((ptr["id"], k, mm.group(0), truth))
        if n == 0:
            fwd.append((ptr["id"], "未命中", "", truth))
    rev = []
    for k, txt in prose_files.items():
        body = re.sub(r"<!-- W3-T324-DECL-EMBED -->.*?```\n", "", txt, flags=re.S)
        for mm in re.finditer(r"\d+\s*(?:条|码|个|处|例|件)", body):
            pre = body[mm.start() - 1] if mm.start() else " "
            if pre in ".§·-" or ("a" <= pre.lower() <= "z"):
                continue          # _sweep_exclusions：版本号/章节号/行号/裁决号/条款编号型
            if not any(s <= mm.start() and mm.end() <= e for s, e in covered[k]):
                rev.append((k, mm.group(0), body[max(0, mm.start() - 12):mm.end() + 4]))
    A("A19", "散文面数量指针对表·双向（裁决90-5／收-7；射程含全部呈报件）",
      not fwd and not rev, "正向异常=%s；反向未覆盖=%s" % (fwd, rev[:6]))

    # ---------------------------------------------------------------- A20
    xref_bad = []
    for k, txt in prose_files.items():
        for ref in re.findall(r"TPL[12]-T324-\d{2}", txt):
            if ref not in ("TPL1-T324-01", "TPL1-T324-02", "TPL1-T324-03",
                           "TPL1-T324-04", "TPL2-T324-01"):
                xref_bad.append((k, ref))
        for ref in re.findall(r"§(\d+)", txt):
            if k == "entity/input_schema.md" and int(ref) > 17:
                xref_bad.append((k, "§" + ref))
    A("A20", "呈报件内部交叉指针机械对表（收-7 (iii)）", not xref_bad, "错位=%s" % xref_bad)

    # ---------------------------------------------------------------- A21
    diag_ok = all(r["diagnostics"]["supply_form_consumed"] ==
                  {k: (next(x for x in inp["records"] if x["record_id"] == r["record_id"])
                       ["components"].get(k) or {}).get("supply_form") for k in comp_keys}
                  for r in har["results"] if r["diagnostics"])
    diag_empty = [r["record_id"] for r in har["results"] if not r["diagnostics"]]
    A("A21", "诊断字段取自实际执行路径返回值（F-15⑥）＋ phase1 命中时诊断为空",
      diag_ok and set(diag_empty) == {"N01", "N02", "N03", "N04", "N05", "N14", "N15"},
      "诊断为空记录=%s" % sorted(diag_empty))

    # ---------------------------------------------------------------- A22
    sec = re.search(r"## §10 计算成分三分判别(.*?)\n## ", schema_md, re.S)
    body = sec.group(1) if sec else ""
    A("A22", "三分归属逐条回引受控文本条款号在场（乙-7／F-18②）",
      body.count("受控文本 §") >= 10 and "§10.1" in schema_md,
      "回引条款号出现 %d 处" % body.count("受控文本 §"))

    # ---------------------------------------------------------------- A23
    lit_ok, span_ok = False, False
    if os.path.exists(SRC_DOC):
        lines = open(SRC_DOC, encoding="utf-8").read().split("\n")
        want = {1342: "roll optionality state", 1345: "Gamma center", 1346: "wing integrity",
                1347: "moneyness relevance", 1348: "funding relation",
                1349: "payoff shape", 1350: "object identity drift"}
        lit_ok = all(v in lines[k - 1] for k, v in want.items())
        span_ok = (lines[1339].startswith("## 13.6")
                   and lines[1343].strip() == "```text" and lines[1350].strip() == "```"
                   and lines[1340].strip() == "" and lines[1342].strip() == "")
    A("A23", "源文行号指针可解析且字面在场（F-18①；行界含 1341 空行）",
      lit_ok and span_ok, "源文=%s" % os.path.basename(SRC_DOC))

    # ---------------------------------------------------------------- A24
    add_ok = False
    if os.path.exists(AUDIT_ADDENDUM):
        a = rt(AUDIT_ADDENDUM)
        add_ok = all(("T3·%d" % n) in a for n in (1342, 1345, 1346, 1347, 1348, 1349, 1350))
    unaudited = "未审引用" in schema_md
    head_ok = schema_md.lstrip().startswith("# entity/input_schema.md · 五·窗3")
    dwb = all("sys.dont_write_bytecode = True" in rt(os.path.join(PKG, s)) for s in scripts)
    A("A24", "审计表已裁行在场／未审引用标注／状态头／dont_write_bytecode 全脚本（F-18③；F-15④⑨）",
      add_ok and unaudited and head_ok and dwb,
      "随包件B″七行=%s 未审标注=%s 状态头=%s dwb=%s" % (add_ok, unaudited, head_ok, dwb))

    # ---------------------------------------------------------------- 汇总
    ok = all(r["pass"] for r in RESULTS)
    os.makedirs(LOGS, exist_ok=True)
    print("=" * 78)
    for r in RESULTS:
        print("[%s] %-4s %s" % ("PASS" if r["pass"] else "FAIL", r["id"], r["name"]))
        if not r["pass"]:
            print("        detail: %s" % r["detail"])
    print("=" * 78)
    print("断言 %d 条；通过 %d 条" % (len(RESULTS), sum(1 for r in RESULTS if r["pass"])))
    if ok:
        with open(os.path.join(LOGS, "assert_log.json"), "w", encoding="utf-8") as f:
            json.dump({"status": "PASS", "assertions": RESULTS}, f, ensure_ascii=False, indent=2)
    else:
        p = os.path.join(LOGS, "assert_log.json")
        if os.path.exists(p):
            os.remove(p)          # 失败运行不得残留成功日志（F-3）
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()

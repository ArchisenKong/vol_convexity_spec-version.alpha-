#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""entity/harness.py · 一次性 harness（模板三 B 段；裁决1）

一次性——不建常设 pipeline / 数据接口 / 持久服务。
真跑——实际执行并写出 outputs/run_output.json。
零数据源——输入仅 entity/synthetic_input.json（人造）与 entity/t324_state_declaration.json（声明面）。

职责边界：喂入 → 驱动 → 捕获。不承担数据获取、不承担生产集成、不承担断言（断言在 verify/）。
"""
import json
import os
import sys

sys.dont_write_bytecode = True

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

from roll_optionality_state_checker import T324StateChecker, load_declaration  # noqa: E402

INPUT = os.path.join(HERE, "synthetic_input.json")
OUTDIR = os.path.join(HERE, "outputs")
OUTPUT = os.path.join(OUTDIR, "run_output.json")


def main():
    decl = load_declaration()
    with open(INPUT, encoding="utf-8") as f:
        data = json.load(f)

    if data.get("_data_source") != "synthetic_hand_constructed":
        raise SystemExit("harness abort: input 非人造构造声明（裁决1）")

    checker = T324StateChecker(decl)
    results = [checker.evaluate(rec) for rec in data["records"]]

    os.makedirs(OUTDIR, exist_ok=True)
    payload = {
        "_producer": "entity/harness.py",
        "_declaration_id": decl["_declaration_id"],
        "_declaration_version": decl["_declaration_version"],
        "_record_count": len(results),
        "results": results,
    }
    with open(OUTPUT, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2, sort_keys=False)
        f.write("\n")
    print("harness ok: %d records -> %s" % (len(results), OUTPUT))


if __name__ == "__main__":
    main()

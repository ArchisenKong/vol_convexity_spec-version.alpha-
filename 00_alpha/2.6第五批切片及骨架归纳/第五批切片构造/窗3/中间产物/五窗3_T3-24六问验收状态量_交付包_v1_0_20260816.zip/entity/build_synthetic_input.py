#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""entity/build_synthetic_input.py · 窗3 人造 input 构造器（模板三 A 段）

裁决1 全程强制：本文件为**手工构造**之人造 input 构造器。
零数据源——不接 IBKR / QuantConnect / 历史行情 / 实时行情 / 任何文件数据源；
全部取值为手写常量，无外部读取（除写出自身产物外无 I/O 输入）。

构造顺序留痕（F-10，文字声明三处一致之第一处）：
    本构造器与 entity/expected_pin_table.json（手写钉表，独立通道）与
    input_schema.md §7 钉表节 同轮提交，先于 harness 实跑。
    钉表**不由本构造器生成**（F-8：判据基线件不得由同一单通道重生成）。

负例设计口径：逐条单码——每条负例恰好命中一个违规码。
"""
import json
import os
import sys

sys.dont_write_bytecode = True

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "synthetic_input.json")

# ---------------------------------------------------------------- 人造测试值隔离
SYNTHETIC_TEST_VALUES = {
    "note": "下列符号与读数均为人造测试值（数据层构造自由度），不外推、非生产标识规范、"
            "非任何校准值（裁决14）。读数以字符串承载以保证 JSON 往返 bit-exact，"
            "本根全程不对其做任何算术运算。",
    "action_ids": ["A-001"],
    "execution_refs": ["E-001"],
    "audit_refs": ["AU-001"],
    "target_path_ids": ["TP-001"],
    "readings": ["0.982", "0.977", "0.03", "0.12", "-0.02", "0.05", "0.041"],
}


def _put_wing():
    return {
        "tail_coverage_band_position": "within",
        "moneyness_drift": "0.03",
        "time_decay_fraction": "0.12",
        "skew_change": "-0.02",
        "liquidity_deterioration": "0.05",
        "premium_bleed_booked": True,
        "premium_bleed_downgrade_flag": False,
        "premium_bleed_integrity_check": True,
    }


def _call_wing():
    return {
        "tail_coverage_band_position": "within",
        "upside_convexity_reading": "0.041",
        "wing_presence_status": "present",
        "premium_bleed_booked": True,
        "premium_bleed_downgrade_flag": False,
        "premium_bleed_integrity_check": True,
    }


def _anchor(aid="A-001"):
    return {"pre": aid, "post": aid}


def _base_components():
    """六分量基线（全 well-formed）。各分量之 supply_form / verdict_source
    照 t324_state_declaration.json §components 之实况登记。"""
    return {
        "q1_gamma_center": {
            "anchor": _anchor(),
            "supply_form": "declared_verdict_stub",
            "verdict_source": "declared_stub",
            "_stub_degraded": True,
            "verdict_declared": True,
            "gamma_center_pre": "0.982",
            "gamma_center_post": "0.977",
        },
        "q2_wing_integrity": {
            "anchor": _anchor(),
            "supply_form": "t3_22_wing_vector",
            "verdict_source": "declared_stub",
            "_stub_degraded": True,
            "verdict_declared": True,
            "put_wing": _put_wing(),
            "call_wing": _call_wing(),
        },
        "q3_moneyness_relevance": {
            "anchor": _anchor(),
            "supply_form": "declared_verdict_stub",
            "verdict_source": "declared_stub",
            "_stub_degraded": True,
            "verdict_declared": True,
            "target_path_id": "TP-001",
            "target_provenance": "declared_input",
        },
        "q4_funding_relation": {
            "anchor": _anchor(),
            "supply_form": "t3_18_breach_flag",
            "verdict_source": "upstream_flag",
            "breach_flag": False,
            "funding_caliber_declaration": ["量甲"],
            "positive_carry_caliber_form": "non_frozen_non_trigger",
        },
        "q5_payoff_shape": {
            "anchor": _anchor(),
            "supply_form": "declared_verdict_stub",
            "verdict_source": "declared_stub",
            "_stub_degraded": True,
            "verdict_declared": True,
        },
        "q6_identity_drift": {
            "anchor": _anchor(),
            "supply_form": "w1_identity_audit",
            "verdict_source": "upstream_declared_value",
            "audit_ref": "AU-001",
            "trigger": "transition_verification",
            "outcome": "no_drift",
        },
    }


def _base_record(rid):
    return {
        "record_id": rid,
        "roll_event": {
            "action_id": "A-001",
            "source_execution_ref": "E-001",
            "action_subtype": "roll",
        },
        "lifecycle_anchor": {"state": "post_action_checked"},
        "slots": {
            "acceptance_evaluation_window": {
                "form": "parameter_slot_candidate",
                "value": None,
            }
        },
        "components": _base_components(),
    }


# ---------------------------------------------------------------- 正例 4 条
def positives():
    recs = []

    p1 = _base_record("P1")                       # 六分量全 pass
    recs.append(p1)

    p2 = _base_record("P2")                       # ④负极性：破坏⇒fail
    p2["components"]["q4_funding_relation"]["breach_flag"] = True
    recs.append(p2)

    p3 = _base_record("P3")                       # ①未标定⇒indeterminate（第三态）
    p3["components"]["q1_gamma_center"]["verdict_declared"] = None
    recs.append(p3)

    p4 = _base_record("P4")                       # ⑥负极性 fail ＋ ②正极性 fail
    p4["components"]["q6_identity_drift"]["outcome"] = "drift_detected"
    p4["components"]["q2_wing_integrity"]["verdict_declared"] = False
    recs.append(p4)

    return recs


# ---------------------------------------------------------------- 负例 15 条（逐条单码）
def negatives():
    recs = []

    n = _base_record("N01")                       # K01
    n["roll_event"]["action_subtype"] = "repair"
    recs.append(n)

    n = _base_record("N02")                       # K02 · 恰界：executed 恰差一跳
    n["lifecycle_anchor"]["state"] = "executed"
    recs.append(n)

    n = _base_record("N03")                       # K03
    n["components"]["q1_gamma_center"]["anchor"]["post"] = None
    recs.append(n)

    n = _base_record("N04")                       # K04 · 恰界：键集恰缺一
    del n["components"]["q5_payoff_shape"]
    recs.append(n)

    n = _base_record("N05")                       # K04 · 恰界：键集恰多一（检多侧，F-7）
    n["components"]["q7_extra"] = {
        "anchor": _anchor(),
        "supply_form": "declared_verdict_stub",
        "verdict_source": "declared_stub",
        "_stub_degraded": True,
        "verdict_declared": True,
    }
    recs.append(n)

    n = _base_record("N06")                       # K05 · 恰界：必需字段恰缺一
    del n["components"]["q2_wing_integrity"]["call_wing"]["wing_presence_status"]
    recs.append(n)

    n = _base_record("N07")                       # K05 · 恰界：枚举恰越一元素
    n["components"]["q2_wing_integrity"]["put_wing"]["tail_coverage_band_position"] = "outside"
    recs.append(n)

    n = _base_record("N08")                       # K06 · 缺声明（F-19）
    del n["components"]["q4_funding_relation"]["funding_caliber_declaration"]
    recs.append(n)

    n = _base_record("N09")                       # K06 · 混用（F-19「不混用」）
    n["components"]["q4_funding_relation"]["funding_caliber_declaration"] = ["量甲", "量乙"]
    recs.append(n)

    n = _base_record("N10")                       # K07 · 正Carry禁形键在场
    n["components"]["q4_funding_relation"]["carry_threshold_frozen"] = "0.90"
    recs.append(n)

    n = _base_record("N11")                       # K08 · 桩降格标注缺失
    n["components"]["q5_payoff_shape"]["_stub_degraded"] = False
    recs.append(n)

    n = _base_record("N12")                       # K09 · 恰界：枚举恰越一元素
    n["components"]["q6_identity_drift"]["outcome"] = "drift_suspected"
    recs.append(n)

    n = _base_record("N13")                       # K10 · W-24 侵入
    n["components"]["q3_moneyness_relevance"]["target_provenance"] = "selected_in_root"
    recs.append(n)

    n = _base_record("N14")                       # K11 · 槽位被赋值
    n["slots"]["acceptance_evaluation_window"]["value"] = 5
    recs.append(n)

    n = _base_record("N15")                       # K12 · C7 环闭合成分在场
    n["disposition"] = "generate_candidate_to_W1"
    recs.append(n)

    return recs


def build():
    pos = positives()
    neg = negatives()
    recs = pos + neg
    doc = {
        "_data_source": "synthetic_hand_constructed",
        "_zero_data_source_declaration": (
            "本文件全部记录为手工构造；不接任何外部数据源——券商 API／回测平台／"
            "历史行情／实时行情／文件数据源一律禁止（裁决1 全程强制）。"
        ),
        "_synthetic_test_values": SYNTHETIC_TEST_VALUES,
        "_scale": {
            "records": len(recs),
            "positive": len(pos),
            "negative": len(neg),
        },
        "_boundary_injections": ["N02", "N04", "N05", "N06", "N07", "N12"],
        "records": recs,
    }
    return doc


if __name__ == "__main__":
    with open(OUT, "w", encoding="utf-8") as f:
        json.dump(build(), f, ensure_ascii=False, indent=2, sort_keys=False)
        f.write("\n")
    print("written:", OUT)

# -*- coding: utf-8 -*-
"""
末位复扫（F-15⑨ 包完整性复扫；F-15③／C-3 交付态零修改可重跑）· 窗1

执行序末位：全部脚本执行完毕后复扫，射程含**脚本自产残留**（字节码/缓存目录）。
"""
import sys

sys.dont_write_bytecode = True

import os

_HERE = os.path.dirname(os.path.abspath(__file__))
_PKG = os.path.dirname(_HERE)
sys.path.insert(0, _HERE)
sys.path.insert(0, os.path.join(_PKG, "entity"))

import build_provenance as PROV  # noqa: E402
import harness as H              # noqa: E402

RUN_PATH = os.path.join(_PKG, "entity", "outputs", "run_output.json")


def check_residue():
    bad = []
    for dirpath, dirnames, filenames in os.walk(_PKG):
        for d in dirnames:
            if d == "__pycache__":
                bad.append(os.path.relpath(os.path.join(dirpath, d), _PKG))
        for f in filenames:
            if f.endswith((".pyc", ".pyo")):
                bad.append(os.path.relpath(os.path.join(dirpath, f), _PKG))
    return bad


def check_bytecode_flag():
    missing = []
    for rel in PROV.iter_package_files(_PKG):
        if not rel.endswith(".py"):
            continue
        with open(os.path.join(_PKG, rel), "r", encoding="utf-8") as fh:
            if "sys.dont_write_bytecode = True" not in fh.read():
                missing.append(rel)
    return missing


def check_rerun_idempotent():
    with open(RUN_PATH, "rb") as fh:
        before = fh.read()
    H.main()
    with open(RUN_PATH, "rb") as fh:
        after = fh.read()
    return before == after


def main():
    ok = True
    residue = check_residue()
    if residue:
        print("[sweep] FAIL 脚本自产残留：%s" % residue); ok = False
    else:
        print("[sweep] PASS 零脚本自产残留")

    miss = check_bytecode_flag()
    if miss:
        print("[sweep] FAIL 未统一设置 dont_write_bytecode：%s" % miss); ok = False
    else:
        print("[sweep] PASS 全脚本统一 dont_write_bytecode")

    if check_rerun_idempotent():
        print("[sweep] PASS 交付态复跑：run_output.json 逐字节不变（C-3）")
    else:
        print("[sweep] FAIL 交付态复跑产物字节漂移"); ok = False

    rc = PROV.verify()
    if rc != 0:
        ok = False
    residue2 = check_residue()
    if residue2:
        print("[sweep] FAIL 复跑后残留：%s" % residue2); ok = False
    print("[sweep] %s" % ("ALL PASS" if ok else "FAILED"))
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())

# -*- coding: utf-8 -*-
"""
指纹钉定件生成/核验（F-5 外置数据件双钉；F-8 钉定件自身入射程）

默认模式＝ --verify（交付态零修改可重跑，F-15③／C-3）；--generate 仅构造期使用。
自指闭环处置（F-8）：本件自身之内容完整性由 `_self_manifest_digest` 承担
——该摘要覆盖除自身字段外之全部条目载荷，由 verify/assert_check.py 独立重算核对。
免疫射程：单面篡改检出；协同篡改不在射程（schema §8 明文，不宣称协同免疫）。
"""
import sys

sys.dont_write_bytecode = True

import hashlib
import json
import os

_HERE = os.path.dirname(os.path.abspath(__file__))
_PKG = os.path.dirname(_HERE)
PROV_PATH = os.path.join(_HERE, "provenance.json")
SELF_NAME = "verify/provenance.json"

# 指纹射程：交付件全集减去钉定件自身与运行期日志目录
EXCLUDED_RELPATHS = {SELF_NAME}
EXCLUDED_DIRS = {os.path.join("verify", "logs")}


def iter_package_files(root=_PKG):
    out = []
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d != "__pycache__"]
        for fn in sorted(filenames):
            full = os.path.join(dirpath, fn)
            rel = os.path.relpath(full, root).replace(os.sep, "/")
            out.append(rel)
    return sorted(out)


def in_scope(rel):
    if rel in EXCLUDED_RELPATHS:
        return False
    for d in EXCLUDED_DIRS:
        if rel.startswith(d.replace(os.sep, "/") + "/"):
            return False
    return True


def sha256_of(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def build_entries(root=_PKG):
    entries = {}
    for rel in iter_package_files(root):
        if not in_scope(rel):
            continue
        entries[rel] = sha256_of(os.path.join(root, rel))
    return entries


def self_digest(entries):
    payload = json.dumps(entries, ensure_ascii=False, sort_keys=True,
                         separators=(",", ":"))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def generate():
    entries = build_entries()
    doc = {
        "_pin_id": "W1-PROVENANCE",
        "_scope_declaration": "\u4ea4\u4ed8\u5305\u5168\u57df\u51cf\u9489\u5b9a\u4ef6\u81ea\u8eab\u4e0e verify/logs/",
        "_self_manifest_digest": self_digest(entries),
        "_file_count": len(entries),
        "entries": entries,
    }
    with open(PROV_PATH, "w", encoding="utf-8") as fh:
        json.dump(doc, fh, ensure_ascii=False, indent=2, sort_keys=True)
        fh.write("\n")
    print("[provenance] generated %d entries -> %s" % (len(entries), PROV_PATH))
    return 0


def verify():
    with open(PROV_PATH, "r", encoding="utf-8") as fh:
        doc = json.load(fh)
    actual = build_entries()
    pinned = doc["entries"]

    missing = sorted(set(pinned) - set(actual))
    extra = sorted(set(actual) - set(pinned))
    changed = sorted(k for k in set(pinned) & set(actual) if pinned[k] != actual[k])

    ok = True
    if missing:
        print("[provenance] FAIL 声明在表而实际缺失: %s" % missing); ok = False
    if extra:
        print("[provenance] FAIL 实际在场而声明缺项（检多）: %s" % extra); ok = False
    if changed:
        print("[provenance] FAIL 指纹不符: %s" % changed); ok = False
    if doc["_self_manifest_digest"] != self_digest(pinned):
        print("[provenance] FAIL 钉定件自摘要不自洽（F-8）"); ok = False
    if doc["_file_count"] != len(pinned):
        print("[provenance] FAIL _file_count 与条目数不一致"); ok = False

    print("[provenance] %s: %d entries, 双向对表%s"
          % ("PASS" if ok else "FAIL", len(pinned), "通过" if ok else "未通过"))
    return 0 if ok else 1


def main():
    if "--generate" in sys.argv:
        return generate()
    return verify()


if __name__ == "__main__":
    sys.exit(main())

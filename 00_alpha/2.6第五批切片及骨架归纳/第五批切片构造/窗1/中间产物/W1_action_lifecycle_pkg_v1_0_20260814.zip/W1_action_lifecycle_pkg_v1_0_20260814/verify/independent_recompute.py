# -*- coding: utf-8 -*-
"""
独立复算（模板三 D段①②）· 窗1 动作生命周期状态机

路径独立性声明（D段②／F-2）：
  * 本脚本 **不 import** entity/state_machine.py 与 entity/harness.py；
  * 本脚本 **不读取** entity/outputs/run_output.json（F-8 独立性封闭规则：不自读被比对产物）；
  * 算法族不同：被测侧＝逐事件状态推进＋查表；本侧＝**全序列谓词集 ＋ 区间覆盖式**判定
    （no-action 审计条件由「以 verification_period 为半径之覆盖并集是否盖满段区间」判出，
     非「逐相邻间隔求差」），二者不共享同一失效模式。
  * 声明面来源不同：被测侧读 entity/lifecycle_declaration.json；本侧解析
    entity/input_schema.md 之内嵌声明块 —— 构成 F-15⑧ 三方对表之第三方。

零数据源：仅读取交付包内人造件与 schema 文本。
"""
import sys

sys.dont_write_bytecode = True

import json
import os

_HERE = os.path.dirname(os.path.abspath(__file__))
_PKG = os.path.dirname(_HERE)
SCHEMA_PATH = os.path.join(_PKG, "entity", "input_schema.md")
INPUT_PATH = os.path.join(_PKG, "entity", "synthetic_input.json")
EMBED_MARKER = "W1-LIFECYCLE-DECL-EMBED"


# ---------------------------------------------------------------- 声明面解析
def parse_embedded_declaration(schema_path=SCHEMA_PATH, marker=EMBED_MARKER):
    with open(schema_path, "r", encoding="utf-8") as fh:
        lines = fh.read().split("\n")
    start = None
    for i, ln in enumerate(lines):
        if marker in ln:
            start = i
            break
    if start is None:
        raise RuntimeError("schema 内嵌声明块标记未找到：%s" % marker)
    open_i = None
    for i in range(start, len(lines)):
        if lines[i].strip() == "```json":
            open_i = i
            break
    if open_i is None:
        raise RuntimeError("schema 内嵌声明块起始 fence 未找到")
    close_i = None
    for i in range(open_i + 1, len(lines)):
        if lines[i].strip() == "```":
            close_i = i
            break
    if close_i is None:
        raise RuntimeError("schema 内嵌声明块结束 fence 未找到")
    return json.loads("\n".join(lines[open_i + 1:close_i]))


def load_input(path=INPUT_PATH):
    with open(path, "r", encoding="utf-8") as fh:
        return json.load(fh)


# ---------------------------------------------------------------- 谓词工具
def _present(v):
    return v is not None and v != ""


def _mk(code, t, etype, key):
    return {"code": code, "locus": {"t": t, "event_type": etype, "key": key}}


def _key_of(ev):
    for k in ("audit_ref", "action_id", "diagnostic_id", "rebasing_action_ref", "basis_id"):
        if ev.get(k) is not None:
            return ev[k]
    return (ev.get("position_ref") or {}).get("position_id")


def _pick_boundary_event(events, t):
    same = [e for e in events if e["t"] == t]
    for e in same:
        if e["type"] == "periodic_audit":
            return e
    return same[-1]


# ---------------------------------------------------------------- 逐码谓词
def _valid_execution_map(events, decl):
    """返回 {execution事件索引: (是否状态合法, 违规码或None)}，纯索引关系判定。"""
    domain = decl["governance_decision_domain"]
    nonapproval = [d for d in domain if d != "approval"]
    out = {}
    for i, ev in enumerate(events):
        if ev["type"] != "execution":
            continue
        aid = ev.get("action_id")
        born = [j for j, e in enumerate(events)
                if e["type"] == "candidate_generated" and e.get("action_id") == aid and j < i]
        decs = [e for j, e in enumerate(events)
                if e["type"] == "phase4_decision" and e.get("action_id") == aid and j < i]
        if not born:
            out[i] = (False, "V03")
        elif not decs:
            out[i] = (False, "V03")
        else:
            last = decs[-1].get("decision")
            if last == "approval":
                out[i] = (True, None)
            elif last in nonapproval:
                out[i] = (False, "V02")
            else:
                out[i] = (False, "V03")
    return out


def _no_action_coverage(events, period):
    """区间覆盖式：段内以各检查点为左端、半径 period 之闭区间并集须盖满段区间。"""
    ts = [e["t"] for e in events]
    t_min, t_max = min(ts), max(ts)
    exec_ts = sorted({e["t"] for e in events if e["type"] == "execution"})
    audit_ts = sorted(e["t"] for e in events if e["type"] == "periodic_audit")
    marks = [t_min] + exec_ts + [t_max]
    out = []
    for a, b in zip(marks[:-1], marks[1:]):
        if b < a:
            continue
        checkpoints = sorted({a} | {t for t in audit_ts if a <= t <= b})
        uncovered = None
        for p in range(a, b + 1):
            if not any(c <= p <= c + period for c in checkpoints):
                uncovered = p
                break
        if uncovered is None:
            continue
        nxt = [c for c in sorted(set(checkpoints) | {b}) if c >= uncovered]
        later_t = nxt[0] if nxt else b
        ev = _pick_boundary_event(events, later_t)
        out.append(_mk("V08", later_t, ev["type"], _key_of(ev)))
    return out


def evaluate(sequence, decl, period, declared_targets):
    events = sequence["events"]
    V = []
    domain = decl["governance_decision_domain"]
    itypes = decl["position_ref_coordinate_key"]["domain"]
    req_refs = decl["action_record_required_refs"]
    conf = decl["execution_confirmation_requirement"]
    reb = decl["rebasing_semantics"]
    declared = set(declared_targets)

    # V01 / V14 —— candidate 生成面
    for i, ev in enumerate(events):
        if ev["type"] != "candidate_generated":
            continue
        aid = ev.get("action_id")
        pos = ev.get("position_ref") or {}
        if pos.get("instrument_type") not in itypes:
            V.append(_mk("V14", ev["t"], ev["type"], aid))
        upstream = {e["diagnostic_id"] for j, e in enumerate(events)
                    if e["type"] == "phase3_diagnostic" and j < i}
        if ev.get("source_diagnostic_ref") not in upstream:
            V.append(_mk("V01", ev["t"], ev["type"], aid))

    # V13 —— 裁决值域
    for ev in events:
        if ev["type"] == "phase4_decision" and ev.get("decision") not in domain:
            V.append(_mk("V13", ev["t"], ev["type"], ev.get("decision_ref")))

    # V02 / V03 / V05 / V06 / V04 —— 执行面
    valid = _valid_execution_map(events, decl)
    for i, ev in enumerate(events):
        if ev["type"] != "execution":
            continue
        aid = ev.get("action_id")
        ok, code = valid[i]
        if not ok:
            V.append(_mk(code, ev["t"], ev["type"], aid))
        rec = ev.get("action_record") or {}
        if any(not _present(rec.get(k)) for k in req_refs):
            V.append(_mk("V05", ev["t"], ev["type"], aid))
        ch = ev.get("execution_channel")
        exempt = (ch in conf["channel_domain"] and ch != conf["required_when_channel"])
        if not exempt and not _present(ev.get(conf["required_field"])):
            V.append(_mk("V06", ev["t"], ev["type"], aid))
        if ok:
            post = [j for j, e in enumerate(events)
                    if e["type"] == "post_action_legality_check"
                    and e.get("action_id") == aid and j > i]
            if not post:
                V.append(_mk("V04", ev["t"], ev["type"], aid))

    # V07 —— 强平配对（贪心，按时序）；事件名取自声明面 external_override
    ext = decl["external_override"]
    fls = [e for e in events if e["type"] == ext["event"]]
    auds = [e for e in events if e["type"] == ext["mandatory_consequence"]["event"]
            and e.get("trigger") == ext["mandatory_consequence"]["trigger"]]
    used = set()
    for fl in fls:
        hit = None
        for k, a in enumerate(auds):
            if k in used:
                continue
            if a["t"] >= fl["t"]:
                hit = k
                break
        if hit is None:
            V.append(_mk("V07", fl["t"], fl["type"],
                         (fl.get("position_ref") or {}).get("position_id")))
        else:
            used.add(hit)

    # V12 —— 漂移检出须申报
    declared_refs = {e.get("targets_audit_ref") for e in events
                     if e["type"] == "phase4_decision"
                     and e.get("decision") == "identity_drift_declaration"
                     and _present(e.get("targets_audit_ref"))}
    for ev in events:
        if ev["type"] == ext["mandatory_consequence"]["event"] and ev.get("outcome") == "drift_detected":
            if ev.get("audit_ref") not in declared_refs:
                V.append(_mk("V12", ev["t"], ev["type"], ev.get("audit_ref")))

    # V09 / V10 —— 换装联动重置
    for i, ev in enumerate(events):
        if ev["type"] != "calibration_state_reset":
            continue
        ra = ev.get("rebasing_action_ref")
        births = [e for j, e in enumerate(events)
                  if e["type"] == "candidate_generated" and e.get("action_id") == ra and j < i]
        subtype_ok = bool(births) and births[-1].get("action_subtype") == reb["action_subtype"]
        refs = (births[-1].get("rebasing_refs") or {}) if births else {}
        refs_ok = all(_present(refs.get(k)) for k in reb["extra_required_refs"])
        exec_ok = any(valid.get(j, (False, None))[0] for j, e in enumerate(events)
                      if e["type"] == "execution" and e.get("action_id") == ra and j < i)
        if not (subtype_ok and refs_ok and exec_ok):
            V.append(_mk("V09", ev["t"], ev["type"], ra))
        elif set(ev.get("reset_targets") or []) != declared:
            V.append(_mk("V10", ev["t"], ev["type"], ra))

    # V11 —— 未标定态之三态输出
    tgt_set_id = reb["reset_on_effect"]["target_set_id"]
    required_verdict = reb["uncalibrated_judgment_state"]
    for i, ev in enumerate(events):
        if ev["type"] != "judgment_emission" or ev.get("basis_id") != tgt_set_id:
            continue
        touched = any(set(e.get("reset_targets") or []) & declared
                      for j, e in enumerate(events)
                      if e["type"] == "calibration_state_reset" and j < i)
        if touched and ev.get("verdict") != required_verdict:
            V.append(_mk("V11", ev["t"], ev["type"], ev.get("basis_id")))

    # V08 —— no-action 周期审计（覆盖式）
    V.extend(_no_action_coverage(events, period))

    V = sorted(V, key=lambda v: (v["locus"]["t"], v["code"]))
    return {"sequence_id": sequence["sequence_id"],
            "verdict": "illegal" if V else "legal",
            "violations": V}


def recompute_all(reset_set_key=None):
    decl = parse_embedded_declaration()
    data = load_input()
    period = data["_synthetic_test_values"]["verification_period"]
    key = reset_set_key or data["active_reset_target_set"]
    targets = data["reset_target_sets"][key]
    return {
        "_produced_by": "verify/independent_recompute.py",
        "_declaration_source": "entity/input_schema.md 内嵌声明块",
        "_verification_period_used": period,
        "_reset_target_set_used": key,
        "_sequence_count": len(data["sequences"]),
        "results": [evaluate(s, decl, period, targets) for s in data["sequences"]],
    }


def main():
    payload = recompute_all()
    out_dir = os.path.join(_HERE, "logs")
    if not os.path.isdir(out_dir):
        os.makedirs(out_dir)
    out_path = os.path.join(out_dir, "independent_recompute_output.json")
    with open(out_path, "w", encoding="utf-8") as fh:
        json.dump(payload, fh, ensure_ascii=False, indent=2)
        fh.write("\n")
    n_ill = sum(1 for r in payload["results"] if r["verdict"] == "illegal")
    print("[recompute] sequences=%d legal=%d illegal=%d"
          % (payload["_sequence_count"], payload["_sequence_count"] - n_ill, n_ill))
    print("[recompute] output -> %s" % out_path)
    return 0


if __name__ == "__main__":
    sys.exit(main())

# -*- coding: utf-8 -*-
"""
负向对照（乙-4 mutation 最小形态）· 窗1 动作生命周期状态机

注入位＝**被测实现** `entity/state_machine.py`（源级变异后于隔离命名空间编译执行），
**非比对器**、**非人造 input**、**非声明面**——三例共同失效点之否定形（T-33 O-3／GK-31 O-10／裁决48 Q-12）。

击落判据：对每一变异，实际调用断言函数集并**指名实际返回 FAIL 之断言 ID**；
零 FAIL 即该变异逃逸。杀灭率口径沿既裁标准（100% 标尺；分母＝有效变异，裁决38-3／24-A1）。

F-9 满足性：击落路径含**判定面逐值比对断言**（A04/A05/A06），非新鲜度/流水线通道。
"""
import sys

sys.dont_write_bytecode = True

import json
import os

_HERE = os.path.dirname(os.path.abspath(__file__))
_PKG = os.path.dirname(_HERE)
sys.path.insert(0, _HERE)
sys.path.insert(0, os.path.join(_PKG, "entity"))

import assert_check as AC  # noqa: E402

SM_PATH = os.path.join(_PKG, "entity", "state_machine.py")
PROBE_IDS = ["A04", "A05", "A06", "A07", "A08", "A09", "A10", "A11",
             "A12", "A13", "A14", "A15", "A16", "A17"]

# (变异ID, 说明, 原串, 变异串)
MUTATIONS = [
    ("M01", "允许 executed 直接出自 candidate（越级转移放行）",
     'violations.append(self._mk("V03", t, etype, aid))\n                    act["exec_t"] = t',
     'act["state"] = "executed"\n                    act["exec_t"] = t'),
    ("M02", "approved 入口对任意裁决值放行（唯一入口失守）",
     'guard = "approval" if dec == "approval" else "__nonapproval__"',
     'guard = "approval"'),
    ("M03", "动作记录必填引用由五项削为四项",
     'missing = [k for k in self.required_refs if not self._present(rec.get(k))]',
     'missing = [k for k in self.required_refs[:4] if not self._present(rec.get(k))]'),
    ("M04", "实盘通道执行确认权要件失效",
     'if not exempt:',
     'if False:'),
    ("M05", "强平不再强制触发 identity audit",
     'for fl in pending_forced:\n            if not fl["satisfied"]:',
     'for fl in pending_forced:\n            if False:'),
    ("M06", "no-action 审计周期比较放宽（周期外挂裕度）",
     'if gap > self.period:',
     'if gap > self.period + 10:'),
    ("M07", "换装联动重置完备性改为子集判定（放行部分重置）",
     'if got != set(self.reset_targets):',
     'if not (got <= set(self.reset_targets)):'),
    ("M08", "未标定态下允许二值判定",
     'if ev.get("verdict") != required:',
     'if False:'),
    ("M09", "instrument_type 值域检查失效",
     'if itype not in self.instrument_domain:',
     'if itype is None:'),
    ("M10", "executed 后 post-action check 强制性失效",
     'if act["state"] == "executed":\n                out.append(self._mk("V04"',
     'if False:\n                out.append(self._mk("V04"'),
]


def load_mutated(src_text):
    ns = {"__name__": "state_machine_mutant", "__file__": SM_PATH}
    exec(compile(src_text, SM_PATH, "exec"), ns)
    return ns["ActionLifecycleMachine"]


def run_with(machine_cls):
    decl = json.loads(AC.read(AC.DECL_JSON))
    inp = json.loads(AC.read(AC.INPUT_JSON))
    period = inp["_synthetic_test_values"]["verification_period"]
    targets = inp["reset_target_sets"][inp["active_reset_target_set"]]
    m = machine_cls(decl, period, targets)
    results = [m.run(s) for s in inp["sequences"]]
    return {
        "_produced_by": "entity/harness.py",
        "_input_data_source": inp["_data_source"],
        "_verification_period_used": period,
        "_reset_target_set_used": inp["active_reset_target_set"],
        "_reset_targets_used": list(targets),
        "_declaration_version_used": decl["_declaration_version"],
        "_sequence_count": len(results),
        "results": results,
    }


def probe(run_payload):
    """以给定 run 产物替换断言侧视图，实际调用断言函数集，返回实测 FAIL 之断言ID。"""
    old_run, old_map = AC.RUN, AC.RUN_MAP
    AC.RUN = run_payload
    AC.RUN_MAP = {r["sequence_id"]: r for r in run_payload["results"]}
    fails = []
    try:
        for aid, _layer, _desc, fn in AC.ASSERTIONS:
            if aid not in PROBE_IDS:
                continue
            try:
                ok, _d = fn()
            except Exception:
                ok = False
            if not ok:
                fails.append(aid)
    finally:
        AC.RUN, AC.RUN_MAP = old_run, old_map
    return fails


def main():
    src = AC.read(SM_PATH)
    lines = ["# 负向对照记录（乙-4；注入位＝被测实现）", ""]

    base_fails = probe(run_with(load_mutated(src)))
    ok_base = not base_fails
    lines.append("基线（零变异）：探针断言 %d 条全过＝%s%s"
                 % (len(PROBE_IDS), ok_base, "" if ok_base else "；FAIL=%s" % base_fails))
    print(lines[-1])

    killed, escaped, rows = 0, [], []
    for mid, desc, old, new in MUTATIONS:
        if src.count(old) != 1:
            escaped.append((mid, "变异锚命中数≠1（%d），变异无效" % src.count(old)))
            rows.append((mid, desc, "锚失效", "—"))
            continue
        fails = probe(run_with(load_mutated(src.replace(old, new))))
        if fails:
            killed += 1
            rows.append((mid, desc, "击落", ",".join(fails)))
        else:
            escaped.append((mid, "零断言失败"))
            rows.append((mid, desc, "逃逸", "—"))
        print("[%s] %s -> %s (%s)" % (mid, desc, rows[-1][2], rows[-1][3]))

    lines += ["", "| 变异 | 说明 | 结果 | 实际失败断言 |", "|---|---|---|---|"]
    lines += ["| %s | %s | %s | %s |" % r for r in rows]
    total = len(MUTATIONS)
    lines += ["", "杀灭率＝%d/%d（分母＝有效变异；100%% 标尺，裁决38-3／24-A1）"
              % (killed, total)]
    if escaped:
        lines += ["", "逃逸/无效：%s" % escaped]
    log = os.path.join(AC.LOG_DIR, "negative_control_log.md")
    if not os.path.isdir(AC.LOG_DIR):
        os.makedirs(AC.LOG_DIR)
    with open(log, "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n")
    print("杀灭率＝%d/%d；日志 -> %s" % (killed, total, log))
    return 0 if (ok_base and killed == total) else 1


if __name__ == "__main__":
    sys.exit(main())

# -*- coding: utf-8 -*-
"""
被测实现 · 窗1 动作生命周期状态机（表驱动·状态推进式）

实现路径特征（供 D段② 路径独立判别使用）：
  逐事件推进 —— 维护 per-action 状态字典，按 allowed_transitions 表查表推进；
  终局违规（V04/V07/V08/V12）于全序列推进完毕后由 finalize 一次性结算。
  失效模式族＝「状态推进/查表」族。

乙面禁建声明（C3 边界级）：
  本实现不判定「合法状态」之实质内容、不实现 constraint stack 内容；
  pre_state_legality_ref / post_state_legality_ref 一律按声明值接收，仅核在场性。

零数据源：本模块不引入任何网络/文件数据源；声明面由 entity/lifecycle_declaration.json 提供。
"""
import sys

sys.dont_write_bytecode = True

import json
import os

_HERE = os.path.dirname(os.path.abspath(__file__))
DECLARATION_PATH = os.path.join(_HERE, "lifecycle_declaration.json")


def load_declaration(path=DECLARATION_PATH):
    """被测侧声明面来源＝外置 JSON 声明件（F-14：不以脚本内字面量替代声明解析）。"""
    with open(path, "r", encoding="utf-8") as fh:
        return json.load(fh)


class ActionLifecycleMachine(object):
    def __init__(self, declaration, verification_period, declared_reset_targets):
        self.decl = declaration
        self.period = verification_period
        self.reset_targets = list(declared_reset_targets)

        self.decision_domain = list(declaration["governance_decision_domain"])
        self.instrument_domain = list(
            declaration["position_ref_coordinate_key"]["domain"])
        self.required_refs = list(declaration["action_record_required_refs"])
        self.confirm_spec = declaration["execution_confirmation_requirement"]
        self.ext = declaration["external_override"]
        self.ext_event = self.ext["event"]
        self.ext_consequence = self.ext["mandatory_consequence"]

        # 由 allowed_transitions 表解析出的查表结构（非硬编码）
        self.transition_table = {}
        for tr in declaration["allowed_transitions"]:
            key = (tr["from"], tr["trigger"], tr.get("guard_decision"))
            if key in self.transition_table:
                raise RuntimeError("allowed_transitions \u952e\u78b0\u649e: %s" % (key,))
            self.transition_table[key] = tr["to"]

    def _lookup(self, frm, trigger, guard=None):
        return self.transition_table[(frm, trigger, guard)]

    # ---------- 工具 ----------
    @staticmethod
    def _present(value):
        return value is not None and value != ""

    def _mk(self, code, t, event_type, key):
        return {"code": code, "locus": {"t": t, "event_type": event_type, "key": key}}

    # ---------- 主循环 ----------
    def run(self, sequence):
        events = sequence["events"]
        violations = []

        diagnostics = set()
        actions = {}
        audits = {}
        calibration = {}          # target -> 'calibrated' | 'uncalibrated'
        for tgt in self.reset_targets:
            calibration[tgt] = "calibrated"
        pending_forced = []       # 未被 identity audit 满足之强平事件
        drift_audits = []         # outcome=drift_detected 之审计
        drift_declared_refs = set()
        audit_ts = []
        exec_ts = []

        for ev in events:
            etype = ev["type"]
            t = ev["t"]

            if etype == "phase3_diagnostic":
                diagnostics.add(ev["diagnostic_id"])

            elif etype == "candidate_generated":
                aid = ev["action_id"]
                pos = ev.get("position_ref") or {}
                itype = pos.get("instrument_type")
                if itype not in self.instrument_domain:
                    violations.append(self._mk("V14", t, etype, aid))
                if ev.get("source_diagnostic_ref") not in diagnostics:
                    violations.append(self._mk("V01", t, etype, aid))
                target = self._lookup("__none__", "candidate_generated")
                actions[aid] = {
                    "state": target,
                    "subtype": ev.get("action_subtype"),
                    "last_decision": None,
                    "rebasing_refs": ev.get("rebasing_refs"),
                    "exec_t": None,
                }

            elif etype == "phase4_decision":
                aid = ev["action_id"]
                dec = ev.get("decision")
                if dec not in self.decision_domain:
                    violations.append(self._mk("V13", t, etype, ev.get("decision_ref")))
                if dec == "identity_drift_declaration":
                    if self._present(ev.get("targets_audit_ref")):
                        drift_declared_refs.add(ev["targets_audit_ref"])
                act = actions.get(aid)
                if act is not None:
                    act["last_decision"] = dec
                    if act["state"] == "candidate" and dec in self.decision_domain:
                        guard = "approval" if dec == "approval" else "__nonapproval__"
                        act["state"] = self._lookup("candidate", "phase4_decision", guard)

            elif etype == "execution":
                aid = ev["action_id"]
                act = actions.get(aid)
                rec = ev.get("action_record") or {}

                if act is None:
                    violations.append(self._mk("V03", t, etype, aid))
                elif act["state"] == "approved":
                    act["state"] = self._lookup("approved", "execution")
                    act["exec_t"] = t
                elif act["last_decision"] in [d for d in self.decision_domain
                                              if d != "approval"]:
                    violations.append(self._mk("V02", t, etype, aid))
                    act["exec_t"] = t
                else:
                    violations.append(self._mk("V03", t, etype, aid))
                    act["exec_t"] = t

                missing = [k for k in self.required_refs if not self._present(rec.get(k))]
                if missing:
                    violations.append(self._mk("V05", t, etype, aid))

                channel = ev.get("execution_channel")
                exempt = (channel in self.confirm_spec["channel_domain"]
                          and channel != self.confirm_spec["required_when_channel"])
                if not exempt:
                    # 保守缺省：未知通道按需确认权处置（不以未声明通道取得豁免）
                    if not self._present(ev.get(self.confirm_spec["required_field"])):
                        violations.append(self._mk("V06", t, etype, aid))
                exec_ts.append(t)

            elif etype == "post_action_legality_check":
                act = actions.get(ev["action_id"])
                if act is not None and act["state"] == "executed":
                    act["state"] = self._lookup("executed", "post_action_legality_check")

            elif etype == "periodic_audit":
                audit_ts.append(t)

            elif etype == self.ext_event:
                pending_forced.append({"t": t, "pos": (ev.get("position_ref") or {}).get("position_id"),
                                       "satisfied": False})

            elif etype == self.ext_consequence["event"]:
                audits[ev["audit_ref"]] = ev
                if ev.get("trigger") == self.ext_consequence["trigger"]:
                    for fl in pending_forced:
                        if not fl["satisfied"] and fl["t"] <= t:
                            fl["satisfied"] = True
                            break
                if ev.get("outcome") == "drift_detected":
                    drift_audits.append(ev)

            elif etype == "calibration_state_reset":
                ra_id = ev.get("rebasing_action_ref")
                ra = actions.get(ra_id)
                bypass = (
                    ra is None
                    or ra.get("subtype") != self.decl["rebasing_semantics"]["action_subtype"]
                    or ra.get("state") not in ("executed", "post_action_checked")
                    or not self._all_rebasing_refs_present(ra)
                )
                if bypass:
                    violations.append(self._mk("V09", t, etype, ra_id))
                else:
                    got = set(ev.get("reset_targets") or [])
                    if got != set(self.reset_targets):
                        violations.append(self._mk("V10", t, etype, ra_id))
                for tgt in (ev.get("reset_targets") or []):
                    if tgt in calibration:
                        calibration[tgt] = "uncalibrated"

            elif etype == "judgment_emission":
                basis = ev.get("basis_id")
                if basis == self.decl["rebasing_semantics"]["reset_on_effect"]["target_set_id"]:
                    if any(v == "uncalibrated" for v in calibration.values()):
                        required = self.decl["rebasing_semantics"]["uncalibrated_judgment_state"]
                        if ev.get("verdict") != required:
                            violations.append(self._mk("V11", t, etype, basis))

        violations.extend(self._finalize(events, actions, pending_forced,
                                         drift_audits, drift_declared_refs,
                                         audit_ts, exec_ts))
        violations = sorted(violations, key=lambda v: (v["locus"]["t"], v["code"]))
        verdict = "illegal" if violations else "legal"
        return {"sequence_id": sequence["sequence_id"],
                "verdict": verdict,
                "violations": violations}

    def _all_rebasing_refs_present(self, act):
        need = self.decl["rebasing_semantics"]["extra_required_refs"]
        refs = act.get("rebasing_refs") or {}
        return all(self._present(refs.get(k)) for k in need)

    # ---------- 终局结算 ----------
    def _finalize(self, events, actions, pending_forced, drift_audits,
                  drift_declared_refs, audit_ts, exec_ts):
        out = []

        for aid, act in actions.items():
            if act["state"] == "executed":
                out.append(self._mk("V04", act["exec_t"], "execution", aid))

        for fl in pending_forced:
            if not fl["satisfied"]:
                out.append(self._mk("V07", fl["t"], self.ext_event, fl["pos"]))

        for aud in drift_audits:
            if aud["audit_ref"] not in drift_declared_refs:
                out.append(self._mk("V12", aud["t"], "object_identity_audit",
                                    aud["audit_ref"]))

        out.extend(self._no_action_audit_check(events, audit_ts, exec_ts))
        return out

    def _no_action_audit_check(self, events, audit_ts, exec_ts):
        if not events:
            return []
        ts = [e["t"] for e in events]
        t_min, t_max = min(ts), max(ts)
        bounds = [t_min] + sorted(set(exec_ts)) + [t_max]
        segments = [(bounds[i], bounds[i + 1]) for i in range(len(bounds) - 1)]

        out = []
        for (s, e) in segments:
            if e < s:
                continue
            inner = sorted([t for t in audit_ts if s <= t <= e])
            checkpoints = [s] + inner + [e]
            for i in range(len(checkpoints) - 1):
                gap = checkpoints[i + 1] - checkpoints[i]
                if gap > self.period:
                    later_t = checkpoints[i + 1]
                    ev = self._event_at(events, later_t, inner, i, len(checkpoints))
                    out.append(self._mk("V08", later_t, ev["type"],
                                        self._event_key(ev)))
        return out

    @staticmethod
    def _event_at(events, t, inner, idx, n):
        # 后界事件：优先取该 t 上之 periodic_audit，否则取该 t 上最后一个事件
        cands = [e for e in events if e["t"] == t]
        for e in cands:
            if e["type"] == "periodic_audit":
                return e
        return cands[-1]

    @staticmethod
    def _event_key(ev):
        for k in ("audit_ref", "action_id", "diagnostic_id", "rebasing_action_ref",
                  "basis_id"):
            if k in ev and ev[k] is not None:
                return ev[k]
        pos = ev.get("position_ref") or {}
        return pos.get("position_id")

# -*- coding: utf-8 -*-
"""
一次性 harness（模板三 B 段）· 窗1 动作生命周期状态机

职责边界：喂入 → 驱动 → 捕获 → 落盘。不承担数据获取、不建常设 pipeline、不做断言。
零数据源（裁决1 全程强制）：输入唯一来源＝ entity/synthetic_input.json（人造）。
F-15⑥：run_output 之回显字段全部取自实际执行路径返回值，非同名常量直接回显。
"""
import sys

sys.dont_write_bytecode = True

import json
import os

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)

from state_machine import ActionLifecycleMachine, load_declaration  # noqa: E402

INPUT_PATH = os.path.join(_HERE, "synthetic_input.json")
OUT_DIR = os.path.join(_HERE, "outputs")
OUT_PATH = os.path.join(OUT_DIR, "run_output.json")


def load_input(path=INPUT_PATH):
    with open(path, "r", encoding="utf-8") as fh:
        return json.load(fh)


def build_machine(decl, data, reset_set_key=None):
    """返回 (machine, used_period, used_targets) —— used_* 为实际注入值之返回，供回显。"""
    used_period = data["_synthetic_test_values"]["verification_period"]
    key = reset_set_key or data["active_reset_target_set"]
    used_targets = list(data["reset_target_sets"][key])
    machine = ActionLifecycleMachine(decl, used_period, used_targets)
    return machine, used_period, used_targets, key


def run_all(decl=None, data=None, reset_set_key=None):
    decl = decl if decl is not None else load_declaration()
    data = data if data is not None else load_input()
    machine, used_period, used_targets, used_key = build_machine(decl, data, reset_set_key)
    results = [machine.run(seq) for seq in data["sequences"]]
    return {
        "_produced_by": "entity/harness.py",
        "_input_data_source": data["_data_source"],
        "_verification_period_used": used_period,
        "_reset_target_set_used": used_key,
        "_reset_targets_used": used_targets,
        "_declaration_version_used": decl["_declaration_version"],
        "_sequence_count": len(results),
        "results": results,
    }


def main():
    if not os.path.isdir(OUT_DIR):
        os.makedirs(OUT_DIR)
    payload = run_all()
    with open(OUT_PATH, "w", encoding="utf-8") as fh:
        json.dump(payload, fh, ensure_ascii=False, indent=2, sort_keys=False)
        fh.write("\n")
    n_illegal = sum(1 for r in payload["results"] if r["verdict"] == "illegal")
    print("[harness] sequences=%d legal=%d illegal=%d period=%s reset_set=%s"
          % (payload["_sequence_count"],
             payload["_sequence_count"] - n_illegal,
             n_illegal,
             payload["_verification_period_used"],
             payload["_reset_target_set_used"]))
    print("[harness] output -> %s" % OUT_PATH)
    return 0


if __name__ == "__main__":
    sys.exit(main())

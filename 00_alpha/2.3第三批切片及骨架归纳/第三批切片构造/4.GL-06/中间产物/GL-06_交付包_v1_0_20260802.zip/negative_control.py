#!/usr/bin/env python3
"""
GL-06 · verify/negative_control.py

被测侧注入变异（乙-4：向被测实现非比对器侧注入已知变异）：
构造entity/harness.py核心比较逻辑之变异副本 M-GL06-01——比较算子由"≥"误写为"＞"
（边界语义变异），断言该变异被**计算面断言**（数值/恒等式类，非新鲜度或流水线通道）击落（F-9）。

人造input中t=5、t=10为特意构造之ratio恰等于阈值边界期，该变异将使这两期由达标误判为不达标，
构成可被独立复算期望值（verify/independent_expected.json）直接数值比对击落之案例。

失败时输出指名实际失败断言（W-9(3)：不写死单一失败原因）。
"""
import json
import os
import sys

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LOG_PATH = os.path.join(BASE, "verify", "negative_control_log.txt")


def load_json(rel):
    with open(os.path.join(BASE, rel), encoding="utf-8") as f:
        return json.load(f)


def compute_gl06_mutant_gt(ledger):
    """变异体 M-GL06-01：比较算子由>=错误改写为>（边界语义变异）。"""
    W = ledger["slots"]["averaging_window_days"]["value"]
    thr_num = ledger["slots"]["ratio_threshold"]["numerator"]
    thr_den = ledger["slots"]["ratio_threshold"]["denominator"]
    periods = ledger["periods"]
    cost_by_t = {p["t"]: p["protection_cost_tv_cents"] for p in periods}
    income_by_t = {p["t"]: p["theta_income_cents"] for p in periods}
    ts_sorted = sorted(cost_by_t.keys())

    mutant_results = {}
    for t in ts_sorted:
        if t < W:
            continue
        window_ts = [t - k for k in range(W)]
        window_sum_cost = sum(cost_by_t[wt] for wt in window_ts)
        income_t = income_by_t[t]
        lhs = income_t * W * thr_den
        rhs = thr_num * window_sum_cost
        mutant_val = lhs > rhs  # 变异点：正确实现应为 >=，此处误写为 >
        mutant_results[t] = mutant_val
    return mutant_results


def main():
    ledger = load_json("entity/ledger_input.json")
    mutant_results = compute_gl06_mutant_gt(ledger)

    # 期望值取自独立复算路径（非harness_output.json，避免被同一处变异污染的比对基准）
    indep = load_json("verify/independent_expected.json")
    expected_by_t = {r["t"]: r["ratio_meets_threshold"] for r in indep["results"] if r["evaluated"]}

    mismatches = []
    for t, mutant_val in sorted(mutant_results.items()):
        expected_val = expected_by_t.get(t)
        if mutant_val != expected_val:
            mismatches.append({"t": t, "mutant": mutant_val, "expected": expected_val})

    log_lines = ["GL-06 negative_control log (M-GL06-01: >= mis-written as >)", "=" * 60]

    if not mismatches:
        log_lines.append("[FAIL] 变异体M-GL06-01未被计算面断言击落——判据不符档（F-9要求未满足）")
        with open(LOG_PATH, "w", encoding="utf-8") as f:
            f.write("\n".join(log_lines) + "\n")
        print("\n".join(log_lines))
        sys.exit(1)
    else:
        log_lines.append(
            f"[PASS] 变异体M-GL06-01被计算面断言击落（击落路径＝数值比对，非新鲜度/流水线通道），"
            f"共{len(mismatches)}处不一致："
        )
        for m in mismatches:
            log_lines.append(f"  t={m['t']}: mutant={m['mutant']} expected={m['expected']}")
        log_lines.append(
            f"击落期数={[m['t'] for m in mismatches]}（与§2声明之边界构造期t=5,10吻合）"
        )
        with open(LOG_PATH, "w", encoding="utf-8") as f:
            f.write("\n".join(log_lines) + "\n")
        print("\n".join(log_lines))
        sys.exit(0)


if __name__ == "__main__":
    main()

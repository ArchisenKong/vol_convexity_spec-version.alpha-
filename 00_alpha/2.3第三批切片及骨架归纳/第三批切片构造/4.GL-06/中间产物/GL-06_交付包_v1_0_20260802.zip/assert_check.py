#!/usr/bin/env python3
"""
GL-06 · verify/assert_check.py

合格断言脚本（任务6模板三D段）。

钉表顺序留痕（F-10，三处一致之一，另两处见entity/input_schema.md §钉表节与切片记录）：
entity/ledger_input.json（钉表）先于entity/harness.py与verify/independent_recompute.py
之首次执行写定；本脚本对二者产出数值的比对，晚于两条独立路径均已真跑。

断言顺序：
  step0(i)   input确为人造声明
  step0(ii)  静态扫描：entity/harness.py 等交付脚本无数据源接入代码（W-5/W-8统一口径）
  step0(iii) 独立复算路径未复用harness中间量/产物
  1. 数值比对：harness_output.json vs independent_expected.json，逐评估期bit-exact一致
  2. 窗口排除正确性：t<W的期数在两侧均标记未评估，数量一致
  3. 边界(>=)语义断言：t=5、t=10两处ratio恰等于阈值，须判定为达标（验证实现用>=而非>）
  4. F-4声明-实现一致性：entity/input_schema.md文本声明之threshold/window数值与
     entity/ledger_input.json实际槽位值一致
  5. F-8双钉核证：build_provenance.json记录之SHA256与当前文件实际SHA256一致
  6. falsification_trigger_flags按Step3哲学准入判定应为空（本根C-6不标记）

任一断言失败 => 非零退出码，输出指名实际失败的断言（不写死单一失败原因）。
"""
import hashlib
import json
import os
import re
import sys

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # GL-06/
LOG_PATH = os.path.join(BASE, "verify", "assert_check_log.txt")

failures = []
passes = []


def record(ok, label, detail=""):
    if ok:
        passes.append(f"[PASS] {label}" + (f" ({detail})" if detail else ""))
    else:
        failures.append(f"[FAIL] {label}" + (f" ({detail})" if detail else ""))


def strip_comments_and_docstrings(src: str) -> str:
    """剥离#行注释与'''/\"\"\"三引号docstring/块字符串，供W-8(c)剥离后文本判定使用。"""
    # 去三引号块（简化处理：非完美python parser，但足以满足静态前哨扫描需求）
    src = re.sub(r'"""[\s\S]*?"""', "", src)
    src = re.sub(r"'''[\s\S]*?'''", "", src)
    lines = []
    for line in src.splitlines():
        # 去行内 # 注释（简化：不处理字符串内含#的边缘情形，逃逸风险已知，终判仍需源码人工核查）
        idx = line.find("#")
        if idx >= 0:
            line = line[:idx]
        lines.append(line)
    return "\n".join(lines)


def step0_i_input_synthetic():
    with open(os.path.join(BASE, "entity", "ledger_input.json"), encoding="utf-8") as f:
        ledger = json.load(f)
    ok = ledger.get("_data_source") == "synthetic_hand_constructed"
    record(ok, "step0(i)_input_synthetic", f"_data_source={ledger.get('_data_source')}")
    return ok


def step0_ii_no_data_source_static_scan():
    with open(os.path.join(BASE, "verify", "scan_patterns.json"), encoding="utf-8") as f:
        patterns = json.load(f)
    scan_set = patterns["scan_object_set"]
    forbidden_imports = [re.compile(p, re.MULTILINE) for p in patterns["forbidden_import_patterns"]]
    forbidden_keywords = patterns["forbidden_keyword_patterns"]

    all_clean = True
    hit_detail = []
    for rel in scan_set:
        path = os.path.join(BASE, rel)
        with open(path, encoding="utf-8") as f:
            raw = f.read()
        stripped = strip_comments_and_docstrings(raw)

        for pat in forbidden_imports:
            if pat.search(stripped):
                all_clean = False
                hit_detail.append(f"{rel}: forbidden import pattern '{pat.pattern}'")

        for kw in forbidden_keywords:
            if kw in stripped:
                all_clean = False
                hit_detail.append(f"{rel}: forbidden keyword '{kw}'")

    record(all_clean, "step0(ii)_no_data_source_static_scan",
           "; ".join(hit_detail) if hit_detail else f"{len(scan_set)} files scanned, clean")
    return all_clean


def step0_iii_independent_recompute_no_harness_reuse():
    """判定统一在剥离注释/docstring后的文本上执行（W-8(c)口径）：本脚本docstring内以自然语言
    说明"不读取harness_output.json"这一约束本身，剥离前会命中同名子串，剥离后基于代码语句判定，
    避免GK-14/TC-33型假阳性教训（说明性文本 vs 实际读取操作，二者须区分）。剥离前命中仅作留痕展示。"""
    path = os.path.join(BASE, "verify", "independent_recompute.py")
    with open(path, encoding="utf-8") as f:
        src = f.read()
    stripped = strip_comments_and_docstrings(src)
    forbidden_tokens = ["harness_output", "import harness", "from entity.harness", "from entity import harness"]

    raw_hit = [t for t in forbidden_tokens if t in src]
    stripped_hit = [t for t in forbidden_tokens if t in stripped]

    ok = len(stripped_hit) == 0
    detail = f"stripped_hit={stripped_hit}"
    if raw_hit and not stripped_hit:
        detail += f"; 剥离前命中(留痕展示,非判定依据)={raw_hit}（docstring说明性文本，非实际读取语句）"
    record(ok, "step0(iii)_independent_recompute_no_harness_reuse", detail)
    return ok


def load_json(rel):
    with open(os.path.join(BASE, rel), encoding="utf-8") as f:
        return json.load(f)


def numeric_compare_ratio_meets_threshold(harness_out, indep_out):
    h_by_t = {r["t"]: r for r in harness_out["results"]}
    i_by_t = {r["t"]: r for r in indep_out["results"]}
    mismatches = []
    if set(h_by_t.keys()) != set(i_by_t.keys()):
        mismatches.append(f"period set mismatch: harness={sorted(h_by_t)} indep={sorted(i_by_t)}")
    for t in sorted(set(h_by_t) & set(i_by_t)):
        h, i = h_by_t[t], i_by_t[t]
        if h["evaluated"] != i["evaluated"]:
            mismatches.append(f"t={t}: evaluated mismatch harness={h['evaluated']} indep={i['evaluated']}")
            continue
        if not h["evaluated"]:
            continue
        if h["ratio_meets_threshold"] != i["ratio_meets_threshold"]:
            mismatches.append(
                f"t={t}: ratio_meets_threshold mismatch harness={h['ratio_meets_threshold']} "
                f"indep={i['ratio_meets_threshold']}"
            )
        if h["window_sum_protection_cost_tv_cents"] != i["window_sum_protection_cost_tv_cents"]:
            mismatches.append(f"t={t}: window_sum mismatch")

    ok = len(mismatches) == 0
    record(ok, "numeric_compare_ratio_meets_threshold_bit_exact",
           "; ".join(mismatches) if mismatches else f"{len(h_by_t)} periods cross-checked, all bit-exact match")
    return ok


def window_exclusion_correctness(ledger, harness_out, indep_out):
    W = ledger["slots"]["averaging_window_days"]["value"]
    expected_excluded = set(t for t in range(1, W))  # t=1..W-1
    h_excluded = set(r["t"] for r in harness_out["results"] if not r["evaluated"])
    i_excluded = set(r["t"] for r in indep_out["results"] if not r["evaluated"])
    ok = (h_excluded == expected_excluded == i_excluded)
    record(ok, "window_exclusion_correctness",
           f"expected={sorted(expected_excluded)} harness={sorted(h_excluded)} indep={sorted(i_excluded)}")
    return ok


def boundary_ge_semantics(harness_out):
    """t=5, t=10为人造input中特意构造之ratio恰等于阈值边界期（lhs==rhs）。
    若实现误用>而非>=，两期将被误判为不达标。"""
    h_by_t = {r["t"]: r for r in harness_out["results"]}
    checks = []
    for t in (5, 10):
        r = h_by_t[t]
        is_boundary = (r["lhs_cross_mult"] == r["rhs_cross_mult"])
        checks.append((t, is_boundary, r["ratio_meets_threshold"]))
    ok = all(is_boundary and meets for (_, is_boundary, meets) in checks)
    record(ok, "boundary_ge_not_gt_semantics",
           f"t=5,10 boundary-equal-and-pass check: {checks}")
    return ok


def f4_declaration_implementation_consistency():
    """entity/input_schema.md文本声明之threshold=2/1、window=5，须与ledger_input.json实际槽位值一致。"""
    with open(os.path.join(BASE, "entity", "input_schema.md"), encoding="utf-8") as f:
        schema_text = f.read()
    ledger = load_json("entity/ledger_input.json")
    thr_num = ledger["slots"]["ratio_threshold"]["numerator"]
    thr_den = ledger["slots"]["ratio_threshold"]["denominator"]
    window = ledger["slots"]["averaging_window_days"]["value"]

    threshold_str_hit = (f"{thr_num}/{thr_den}" in schema_text) or (
        thr_den == 1 and f"threshold={thr_num}" in schema_text.replace(" ", "")
    ) or ("ratio_threshold" in schema_text and str(thr_num) in schema_text)
    window_str_hit = (f"window={window}" in schema_text.replace(" ", "")) or (
        "averaging_window_days" in schema_text and str(window) in schema_text
    )
    ok = threshold_str_hit and window_str_hit
    record(ok, "f4_declaration_implementation_consistency",
           f"threshold_hit={threshold_str_hit} window_hit={window_str_hit}")
    return ok


def f8_provenance_double_pin():
    prov = load_json("verify/build_provenance.json")
    all_match = True
    detail = []
    for rel, expected_hash in prov["fingerprints"].items():
        path = os.path.join(BASE, rel)
        h = hashlib.sha256()
        with open(path, "rb") as f:
            h.update(f.read())
        actual = h.hexdigest()
        if actual != expected_hash:
            all_match = False
            detail.append(f"{rel}: provenance={expected_hash[:12]} actual={actual[:12]}")
    record(all_match, "f8_provenance_double_pin_sha256_match",
           "; ".join(detail) if detail else f"{len(prov['fingerprints'])} files match provenance")
    return all_match


def f7_full_package_scan_closure():
    """F-7扫描面封闭形态：发现面须覆盖全包域(含包根与全部子目录)，排除条件最小化，
    检'多'不止检'缺'。以os.walk全量枚举.py文件，与scan_patterns.json声明清单双向比对。"""
    with open(os.path.join(BASE, "verify", "scan_patterns.json"), encoding="utf-8") as f:
        patterns = json.load(f)
    declared = set(patterns["scan_object_set"])

    discovered = set()
    for root, dirs, files in os.walk(BASE):
        # 排除条件最小化：仅排除__pycache__（对其自称用途必要——编译缓存非交付脚本）
        dirs[:] = [d for d in dirs if d != "__pycache__"]
        for fn in files:
            if fn.endswith(".py"):
                rel = os.path.relpath(os.path.join(root, fn), BASE)
                discovered.add(rel.replace(os.sep, "/"))

    missing_from_declared = discovered - declared  # 存在但未声明入清单（"多"）
    declared_but_absent = declared - discovered      # 声明但实际不存在（"缺"）

    ok = (len(missing_from_declared) == 0) and (len(declared_but_absent) == 0)
    record(ok, "f7_full_package_scan_closure",
           f"undeclared_extra={sorted(missing_from_declared)} "
           f"declared_but_missing={sorted(declared_but_absent)}")
    return ok


def f5_f6_not_applicable_notes():
    """F-5（外置数据件双钉）：本根无外置模式表/参数表类制品（ledger_input.json为主人造input，
    非外置模式表），F-5不适用，显式注记非默认省略。
    F-6（锚定词表607-A/B分层）：本对象源文非T3锚定词表覆盖范围（源文为八份思想层材料），F-6不适用。
    本函数恒返回True（非判据缺陷，仅为审计留痕显式声明适用性判断本身）。"""
    record(True, "f5_external_data_file_not_applicable", "无外置模式表/参数表类制品")
    record(True, "f6_anchor_wordlist_layering_not_applicable", "对象源文不在T3锚定词表607-A/B覆盖范围")
    return True


def falsification_trigger_flags_empty(harness_out):
    ok = harness_out.get("falsification_trigger_flags", None) == []
    record(ok, "falsification_trigger_flags_empty_per_step3_no_C6",
           f"flags={harness_out.get('falsification_trigger_flags')}")
    return ok


def main():
    ledger = load_json("entity/ledger_input.json")

    ok0i = step0_i_input_synthetic()
    ok0ii = step0_ii_no_data_source_static_scan()
    ok0iii = step0_iii_independent_recompute_no_harness_reuse()

    step0_ok = ok0i and ok0ii and ok0iii

    if not step0_ok:
        # step0前置合规未过，直接判不合格，不进入数值比对（模板三D段0）
        write_log()
        print(f"\n{'='*60}\nRESULT: FAIL (step0前置合规未通过，未进入数值比对)\n{'='*60}")
        sys.exit(1)

    harness_out = load_json("entity/harness_output.json")
    indep_out = load_json("verify/independent_expected.json")

    ok_numeric = numeric_compare_ratio_meets_threshold(harness_out, indep_out)
    ok_window = window_exclusion_correctness(ledger, harness_out, indep_out)
    ok_boundary = boundary_ge_semantics(harness_out)
    ok_f4 = f4_declaration_implementation_consistency()
    ok_f8 = f8_provenance_double_pin()
    ok_f7 = f7_full_package_scan_closure()
    ok_f56 = f5_f6_not_applicable_notes()
    ok_c6 = falsification_trigger_flags_empty(harness_out)

    all_ok = all([ok_numeric, ok_window, ok_boundary, ok_f4, ok_f8, ok_f7, ok_f56, ok_c6])

    write_log()
    print(f"\n{'='*60}\nRESULT: {'PASS' if all_ok else 'FAIL'}\n{'='*60}")
    sys.exit(0 if all_ok else 1)


def write_log():
    with open(LOG_PATH, "w", encoding="utf-8") as f:
        f.write("GL-06 assert_check log\n")
        f.write("=" * 60 + "\n")
        for line in passes:
            f.write(line + "\n")
        for line in failures:
            f.write(line + "\n")
        f.write("=" * 60 + "\n")
        f.write(f"TOTAL: {len(passes)} passed, {len(failures)} failed\n")


if __name__ == "__main__":
    main()

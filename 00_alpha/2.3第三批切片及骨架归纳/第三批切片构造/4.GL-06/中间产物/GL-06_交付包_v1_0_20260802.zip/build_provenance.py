#!/usr/bin/env python3
"""
GL-06 · verify/build_provenance.py

新鲜度/来源钉定件生成脚本（F-8）：对本切片全部交付脚本与关键数据文件计算SHA256，
写入build_provenance.json，供verify/assert_check.py核验"所审对象与交付对象同一"。

F-8双钉纪律：本钉定件自身（build_provenance.json）之SHA256同样须被assert_check.py核证
（断言脚本核SHA256＋schema声明面双钉），不得由钉定件机制单通道独任承载判据基线——
assert_check.py另行执行独立数值比对（harness_output vs independent_expected）作为
不可被单纯"重生成钉定件"绕过的第二条判据基线。

本脚本不读取自身既往产物（每次运行均对当前文件系统状态重新计算，非累积追加）。
"""
import hashlib
import json
import os

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # GL-06/
OUTPUT_PATH = os.path.join(BASE, "verify", "build_provenance.json")

TRACKED_FILES = [
    "entity/ledger_input.json",
    "entity/harness.py",
    "entity/harness_output.json",
    "verify/independent_recompute.py",
    "verify/independent_expected.json",
]


def sha256_of(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        h.update(f.read())
    return h.hexdigest()


def main():
    fingerprints = {}
    for rel in TRACKED_FILES:
        abs_path = os.path.join(BASE, rel)
        fingerprints[rel] = sha256_of(abs_path)

    output = {
        "object_id": "GL-06",
        "pin_sequence_note": "本次钉定发生于harness.py与independent_recompute.py均已真跑产出数值文件之后，"
                              "assert_check.py执行之前；钉定对象=交付脚本与其产出数据文件之当前内容，"
                              "非跑数前的占位声明。",
        "fingerprints": fingerprints,
    }
    with open(OUTPUT_PATH, "w", encoding="utf-8") as f:
        json.dump(output, f, ensure_ascii=False, indent=2)
    print(f"[build_provenance] wrote {OUTPUT_PATH}: {len(fingerprints)} files fingerprinted")


if __name__ == "__main__":
    main()

"""
负向对照自查（构造侧留痕，非G4外审重放，非合格判定依据本身）

用途：核验 assert_check.py 之检出力非空转。四例篡改逐例注入 → 跑断言 → 记录退出码
→ 复原。含输出形态封闭类注入（裁决38-2 锚点一同型：新增顶层键／删声明键），
以自证第三可检层次在本包内确为可检。
"""

import json
import os
import shutil
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(HERE)
OUT = os.path.join(PKG, "entity", "harness_output.json")
BAK = OUT + ".nc_backup"
LOG = os.path.join(HERE, "negative_control_log.txt")


def run():
    p = subprocess.run([sys.executable, os.path.join(HERE, "assert_check.py")],
                       capture_output=True, text=True)
    return p.returncode


def load():
    with open(OUT, "r", encoding="utf-8") as fh:
        return json.load(fh)


def save(d):
    with open(OUT, "w", encoding="utf-8") as fh:
        json.dump(d, fh, ensure_ascii=False, indent=2)
        fh.write("\n")


def main():
    lines = []
    shutil.copyfile(OUT, BAK)
    base_rc = run()
    lines.append("基线（未篡改）退出码 = %d" % base_rc)

    cases = []

    d = load()
    d["base_valuation"][4]["per_unit"]["delta"] = 0.9
    save(d)
    cases.append(("数值篡改：L05 base per_unit.delta 0.35675831→0.9", run()))
    shutil.copyfile(BAK, OUT)

    d = load()
    d["_shadow_output"] = {"x": 1}
    save(d)
    cases.append(("输出形态封闭：新增未声明顶层键 _shadow_output", run()))
    shutil.copyfile(BAK, OUT)

    d = load()
    del d["time_shift_revaluation"]
    save(d)
    cases.append(("输出形态封闭：静默删声明键 time_shift_revaluation", run()))
    shutil.copyfile(BAK, OUT)

    d = load()
    d["base_valuation"][3]["route_id"] = "bs_no_dividend_closed_form"
    save(d)
    cases.append(("路由身份篡改：L04 futures 路由改标为欧式闭式", run()))
    shutil.copyfile(BAK, OUT)

    for name, rc in cases:
        lines.append("%-58s 退出码=%d  %s" % (name, rc, "检出" if rc else "漏检"))

    final_rc = run()
    lines.append("复原后退出码 = %d" % final_rc)
    os.remove(BAK)

    ok = base_rc == 0 and final_rc == 0 and all(rc != 0 for _, rc in cases)
    lines.append("自查结论：%s（%d/%d 检出）"
                 % ("检出力成立" if ok else "存在漏检", sum(1 for _, rc in cases if rc),
                    len(cases)))
    text = "\n".join(lines)
    with open(LOG, "w", encoding="utf-8") as fh:
        fh.write(text + "\n")
    print(text)


if __name__ == "__main__":
    main()

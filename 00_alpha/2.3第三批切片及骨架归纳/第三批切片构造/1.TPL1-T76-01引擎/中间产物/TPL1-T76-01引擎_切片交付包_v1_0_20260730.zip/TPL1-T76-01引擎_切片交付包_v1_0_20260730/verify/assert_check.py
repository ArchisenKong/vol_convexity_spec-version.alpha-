"""
TPL1-T76-01 引擎 · D段合格断言脚本

判据基线一律**程序化解析自本包内源文件**（entity/input_schema.md 之三个声明块），
不使用任何人工转抄常量（T3-03 缺陷F1 教训：断言基线须独立解析源markdown）。
包自足：不读取 /mnt/project/ 或任何包外路径（W-13(6) 教训）。

失败即以**非零退出码**退出（裁决28-B(ii)，经裁决30-A 溯及既往，本包为存量义务）。
"""

import ast
import json
import os
import re
import sys
from fractions import Fraction

from mpmath import mp, mpf, fabs

mp.dps = 60

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(HERE)
E = lambda *p: os.path.join(PKG, "entity", *p)
V = lambda *p: os.path.join(HERE, *p)

TOL_B = mpf("1e-12")
CONTAINERS = ("base_valuation", "scenario_revaluation", "time_shift_revaluation")

FAILS = []
LOG = []


def check(cond, name, detail=""):
    LOG.append("%s  %s%s" % ("PASS" if cond else "FAIL", name,
                             ("  | " + detail) if detail else ""))
    if not cond:
        FAILS.append(name)
    return cond


def read(path):
    with open(path, "r", encoding="utf-8") as fh:
        return fh.read()


# --------------------------------------------------------------------------
# 判据基线：独立解析 entity/input_schema.md
# --------------------------------------------------------------------------
SCHEMA = read(E("input_schema.md"))


def parse_block(tag):
    m = re.search(r"```\s*\n%s\n(.*?)```" % re.escape(tag), SCHEMA, re.S)
    if not m:
        raise SystemExit("判据基线解析失败：声明块 %s 未在 input_schema.md 中找到" % tag)
    return [ln.strip() for ln in m.group(1).strip().split("\n") if ln.strip()]


DECL_TOPLEVEL = set(parse_block("OUTPUT_TOPLEVEL_DECLARATION"))
DECL_RECORD = set(parse_block("RECORD_KEY_DECLARATION"))
DECL_COMPONENT = set(parse_block("COMPONENT_KEY_DECLARATION"))

DECL_ROUTE = {}
for line in parse_block("ROUTE_DECLARATION"):
    cols = [c.strip() for c in line.split("|")]
    while len(cols) < 4:
        cols.append("")
    DECL_ROUTE[cols[0]] = {
        "route_id": cols[1],
        "computability_status": cols[2],
        "unstated_dimensions_hit": [d for d in cols[3].split(",") if d],
    }

B1_CLAUSE = ("以下为已言明最小面，未言明维度（美式行权、股息、期货保证金形态、"
             "day count等）不构成规格封闭，留引擎切片撞墙")

HARNESS_OUT = json.loads(read(E("harness_output.json")))
INDEP = json.loads(read(V("independent_expected.json")))
INPUT = json.loads(read(E("input_data.json")))


# --------------------------------------------------------------------------
# step 0 · 前置合规断言（先于数值比对）
# --------------------------------------------------------------------------
def strip_code(src):
    """剥离注释与docstring，仅留实际代码。"""
    out_lines = []
    for ln in src.split("\n"):
        out_lines.append(re.sub(r"#.*$", "", ln))
    stripped = "\n".join(out_lines)
    try:
        tree = ast.parse(stripped)
    except SyntaxError:
        return stripped
    spans = []
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef,
                             ast.ClassDef)):
            doc = ast.get_docstring(node, clean=False)
            if doc:
                first = node.body[0]
                spans.append((first.lineno, first.end_lineno))
    lines = stripped.split("\n")
    for a, b in spans:
        for i in range(a - 1, b):
            lines[i] = ""
    return "\n".join(lines)


PATTERNS = json.loads(read(V("scan_patterns.json")))
FORBIDDEN_KEYWORDS = PATTERNS["forbidden_datasource_keywords"]
FORBIDDEN_IMPORT_RE = re.compile(PATTERNS["forbidden_import_regex"], re.M)

# 扫描面：全部代码件。verify/scan_patterns.json 为模式数据件，按构造排除（留痕）。
SCANNED = ["entity/engine.py", "entity/harness.py",
           "verify/independent_recompute.py", "verify/assert_check.py"]
SCAN_EXCLUDED = ["verify/scan_patterns.json"]

raw_hits, stripped_hits = {}, {}
for rel in SCANNED:
    src = read(os.path.join(PKG, rel))
    st = strip_code(src)
    raw_hits[rel] = [k for k in FORBIDDEN_KEYWORDS if k in src]
    hits = [k for k in FORBIDDEN_KEYWORDS if k in st]
    hits += [m.group(1) for m in FORBIDDEN_IMPORT_RE.finditer(st)]
    stripped_hits[rel] = hits

check(INPUT.get("_data_source") == "synthetic_hand_constructed",
      "step0(i) input 为人造构造",
      "_data_source=%r" % INPUT.get("_data_source"))
check(HARNESS_OUT.get("_data_source") == "synthetic_hand_constructed",
      "step0(i-b) 输出承载人造标记")
check(all(not v for v in stripped_hits.values()),
      "step0(ii) 剥离注释/docstring后零数据源接入命中",
      "剥离后=%s；剥离前留痕=%s" % (stripped_hits, {k: v for k, v in raw_hits.items() if v}))

indep_src = read(V("independent_recompute.py"))
indep_code = strip_code(indep_src)
check(("import engine" not in indep_code) and ("from engine" not in indep_code)
      and ("harness_output" not in indep_code) and ("import harness" not in indep_code),
      "step0(iii) 独立复算未import被测模块、未读harness产物",
      "剥离前 'harness' 字样命中%d处（均落在docstring独立性自述内）"
      % indep_src.count("harness"))


# --------------------------------------------------------------------------
# A1 · 输出形态封闭（裁决39-B / 38-2 第三可检层次）
# --------------------------------------------------------------------------
top = set(HARNESS_OUT.keys())
check(top == DECL_TOPLEVEL, "A1 输出顶层键集＝declaration声明集",
      "多出=%s；缺失=%s" % (sorted(top - DECL_TOPLEVEL), sorted(DECL_TOPLEVEL - top)))

rec_ok, comp_ok = True, True
for c in CONTAINERS:
    for r in HARNESS_OUT[c]:
        if set(r.keys()) != DECL_RECORD:
            rec_ok = False
        for layer in ("per_unit", "per_lot"):
            if set(r[layer].keys()) != DECL_COMPONENT:
                comp_ok = False
check(rec_ok, "A1-b 每条记录键集＝RECORD_KEY_DECLARATION")
check(comp_ok, "A1-c per_unit/per_lot 分量键集＝COMPONENT_KEY_DECLARATION")


# --------------------------------------------------------------------------
# A2 · 契约① 供给物语义类型：5全集 raw Greeks ＋ V(t)
# --------------------------------------------------------------------------
need = {"delta", "gamma", "vega", "theta", "rho", "value"}
check(DECL_COMPONENT == need, "A2 契约①分量声明＝5全集＋V(t)")
numeric_ok = all(isinstance(r[l][k], (int, float))
                 for c in CONTAINERS for r in HARNESS_OUT[c]
                 for l in ("per_unit", "per_lot") for k in need)
check(numeric_ok, "A2-b 全部分量为实产数值（非占位null）")


# --------------------------------------------------------------------------
# A3 · 契约② 品种感知路由身份
# --------------------------------------------------------------------------
GAP_DOMAIN = {"spot", "spot_etf", "futures", "index",
              "european_option", "american_option"}
check(set(DECL_ROUTE.keys()) == GAP_DOMAIN,
      "A3 路由声明覆盖缺口原文六品种域", "声明=%s" % sorted(DECL_ROUTE))
check(set(HARNESS_OUT["route_table"].keys()) == GAP_DOMAIN,
      "A3-b 输出 route_table 覆盖六品种域（未静默收窄）")

route_ok, status_ok, exercised = True, True, set()
for c in CONTAINERS:
    for r in HARNESS_OUT[c]:
        d = DECL_ROUTE[r["instrument_class"]]
        exercised.add(r["instrument_class"])
        if r["route_id"] != d["route_id"]:
            route_ok = False
        if (r["computability_status"] != d["computability_status"]
                or r["unstated_dimensions_hit"] != d["unstated_dimensions_hit"]):
            status_ok = False
check(route_ok, "A3-c 逐笔 route_id 与路由声明一致（路由身份可辨识）")
check(status_ok, "A3-d 逐笔可算性标注与未言明维度标注与声明一致（降格标注在场）")
check(exercised == GAP_DOMAIN, "A3-e 人造input实跑覆盖全部六品种",
      "实跑=%s" % sorted(exercised))
check(len({d["route_id"] for d in DECL_ROUTE.values()}) == 4,
      "A3-f 四条互异求值路径在场")


# --------------------------------------------------------------------------
# A4 · 契约④ 已言明最小面 ＋ 45-B1 条款措辞逐字在场
# --------------------------------------------------------------------------
check(B1_CLAUSE in SCHEMA, "A4 45-B1条款措辞逐字载于 input_schema.md")
check(B1_CLAUSE in read(E("engine.py")), "A4-b 45-B1条款措辞逐字载于 engine.py")
eng = read(E("engine.py"))
m = re.search(r"STATED_FACE_FIELDS = \((.*?)\)", eng, re.S)
consumed = set(re.findall(r'"([a-z_]+)"', m.group(1)))
allowed = {"lot_id", "instrument_class", "option_type", "side", "strike",
           "expiry", "spot", "risk_free_rate", "implied_vol", "multiplier",
           "quantity", "valuation_date"}
check(consumed == allowed, "A4-c 求值消费字段集＝已言明最小面（零补白扩张）",
      "消费=%s" % sorted(consumed))
excluded = {"underlying", "leg_type", "open_interest"}
check(not (consumed & excluded), "A4-d 坐标/保留字段未进入求值路径")


# --------------------------------------------------------------------------
# A5 · 契约⑤ 数据源边界：输入面零 vendor 派生量
# --------------------------------------------------------------------------
VENDOR_KEYS = {"delta", "gamma", "vega", "theta", "rho", "model_price",
               "theo_price", "vendor_iv", "greeks", "mark_price_model"}
in_keys = set()
for lot in INPUT["lots"]:
    in_keys |= set(lot.keys())
check(not (in_keys & VENDOR_KEYS), "A5 输入面与vendor派生量键名集之交为空",
      "输入键=%s" % sorted(in_keys))


# --------------------------------------------------------------------------
# A6 · 契约⑥ 措辞审计（审计表行94 证伪证据形态）
# --------------------------------------------------------------------------
CLAIM_PATTERNS = PATTERNS["truth_claim_patterns"]
NEG_MARKERS = PATTERNS["negation_markers"]
NEG_WIN = PATTERNS["negation_window_chars"]
audited = ["entity/engine.py", "entity/harness.py", "entity/input_schema.md",
           "verify/independent_recompute.py", "verify/assert_check.py"]
affirmative, negated = [], []
for rel in audited:
    txt = read(os.path.join(PKG, rel))
    for pat in CLAIM_PATTERNS:
        for mm in re.finditer(re.escape(pat), txt):
            ctx = txt[max(0, mm.start() - NEG_WIN):mm.start()]
            (negated if any(n in ctx for n in NEG_MARKERS) else affirmative
             ).append("%s::%s::…%s|%s" % (rel, pat, ctx[-10:].replace("\n", " "), pat))
check(not affirmative, "A6 措辞审计：零肯定式真理源/获利合法性宣称",
      "否定语境命中%d处（留痕）；肯定式=%s；扫描排除件=%s" % (len(negated), affirmative, SCAN_EXCLUDED))


# --------------------------------------------------------------------------
# A7 · 数值比对（成分级容差分派）＋ 量纲否定式判别
# --------------------------------------------------------------------------
rows = [["container", "lot_id", "layer", "component", "harness",
         "independent", "tol_subcaliber", "rel_diff", "verdict"]]
n_a = n_b = n_bad = 0
worst = mpf(0)

for c in CONTAINERS:
    hmap = {r["lot_id"]: r for r in HARNESS_OUT[c]}
    for ir in INDEP[c]:
        hr = hmap[ir["lot_id"]]
        kind = ir["numeric_kind"]
        for layer in ("per_unit", "per_lot"):
            for k in sorted(DECL_COMPONENT):
                hv = hr[layer][k]
                iv = ir[layer][k]
                if kind == "exact_rational":
                    ok = Fraction(str(hv)) == Fraction(iv)
                    rel, sub = "0" if ok else "nonzero", "(a) bit-exact"
                    n_a += 1
                else:
                    h, i = mpf(str(hv)), mpf(iv)
                    if i == 0:
                        ok, r_ = (h == 0), mpf(0)
                    else:
                        r_ = fabs(h - i) / fabs(i)
                        ok = r_ <= TOL_B
                    worst = max(worst, r_)
                    rel, sub = mp.nstr(r_, 6), "(b) rel<=1e-12"
                    n_b += 1
                if not ok:
                    n_bad += 1
                rows.append([c, ir["lot_id"], layer, k, repr(hv), iv, sub,
                             rel, "OK" if ok else "OUT"])

check(n_bad == 0, "A7 全量分量比对（%d项：(a)%d ／ (b)%d）" % (n_a + n_b, n_a, n_b),
      "越限%d项；(b)类最大相对diff=%s" % (n_bad, mp.nstr(worst, 6)))

with open(V("comparison_table.tsv"), "w", encoding="utf-8") as fh:
    for r in rows:
        fh.write("\t".join(str(x) for x in r) + "\n")

# 量纲否定式判别：若产出为 vega/100、theta/365、rho/100 形态，本组断言须失败
neg_ok = True
for c in CONTAINERS:
    hmap = {r["lot_id"]: r for r in HARNESS_OUT[c]}
    for ir in INDEP[c]:
        if ir["numeric_kind"] != "transcendental":
            continue
        hr = hmap[ir["lot_id"]]
        for k, factor in (("vega", 100), ("theta", 365), ("rho", 100)):
            i = mpf(ir["per_unit"][k])
            if i == 0:
                continue
            scaled = mpf(str(hr["per_unit"][k])) * factor
            if fabs(scaled - i) / fabs(i) <= TOL_B:
                neg_ok = False
check(neg_ok, "A7-b 量纲否定式判别：产出非 vega/100、theta/日、rho/100 缩放形态")


# --------------------------------------------------------------------------
# A8 · 重估形态自洽（同签名再次求值，零新增接口参数）
# --------------------------------------------------------------------------
lens = {c: len(HARNESS_OUT[c]) for c in CONTAINERS}
check(len(set(lens.values())) == 1 and lens["base_valuation"] == len(INPUT["lots"]),
      "A8 三容器逐笔齐备（情景重估／时点推移覆盖全部lot）", str(lens))
sig = re.search(r"def evaluate_lot\((.*?)\)", eng).group(1)
check(sig.strip() == "lot", "A8-b 引擎签名未因重估需求增参",
      "evaluate_lot(%s)" % sig)

opt_moved = all(
    mpf(str(next(r for r in HARNESS_OUT["time_shift_revaluation"]
                 if r["lot_id"] == lid)["per_unit"]["value"]))
    != mpf(str(next(r for r in HARNESS_OUT["base_valuation"]
                    if r["lot_id"] == lid)["per_unit"]["value"]))
    for lid in ("L05", "L06", "L07", "L08"))
check(opt_moved, "A8-c 时点推移使期权估值变动（T-24 V(t0)/V(t1) 消费面可用）")


# --------------------------------------------------------------------------
# 收尾
# --------------------------------------------------------------------------
report = "\n".join(LOG)
with open(V("assert_check_log.txt"), "w", encoding="utf-8") as fh:
    fh.write(report + "\n\n")
    fh.write("失败项：%s\n" % (FAILS if FAILS else "无"))
print(report)
print("\n失败项：%s" % (FAILS if FAILS else "无"))
sys.exit(1 if FAILS else 0)

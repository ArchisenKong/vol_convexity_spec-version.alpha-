"""
FW-03-甲 · 一次性 harness（B段）· v2.0（续3丙类修复后）

真跑出数、不建常设pipeline：单次执行，喂入 entity/input_data.json，驱动
engine.py（逐步两通道求值 → 各通道过零检测 → 曲率通道恒正诊断），捕获全部
中间与终态量，落盘 entity/harness_output.json。

情景重估口径：本根不存在"时点推移"额外接口——scenario本身已含逐步
valuation_date与spot（人造input层面的时间序列声明），harness不做任何二次
冲击构造，纯粹逐步喂入。

v2.0输出形态变更（裁决60-A1两量并出）：state_sequence每条记录并出
speed_raw/speed_adverse/speed_sign 与 gamma_curvature/curvature_sign 两通道，
zero_crossings 由单列表改为按通道分列之字典，always_positive_check 显式标注
其所属通道（gamma_curvature）与诊断性质。全部输出键在
entity/input_schema.md §3.2 声明面成文，并由 verify/assert_check.py 之
A7组断言施加封闭核验（未声明键/层即击落）。
"""

import json
import engine


def main():
    with open("input_data.json", "r", encoding="utf-8") as f:
        doc = json.load(f)

    position = doc["position"]
    bump_config = doc["bump_config"]
    channel_config = doc["channel_config"]
    scenario = doc["scenario"]
    adverse_direction = channel_config["adverse_direction"]

    state_sequence = engine.compute_state_sequence(
        position, bump_config, scenario, adverse_direction)
    crossings = engine.detect_zero_crossings_all(state_sequence)
    positive_check = engine.check_always_positive(state_sequence)

    output = {
        "_data_source": "synthetic_hand_constructed",
        "position": position,
        "bump_config": bump_config,
        "channel_config": {"adverse_direction": adverse_direction},
        "state_sequence": state_sequence,
        "zero_crossings": crossings,
        "always_positive_check": positive_check,
        "summary": {
            "n_steps": len(state_sequence),
            "n_crossings_speed": len(crossings["speed"]),
            "n_crossings_gamma_curvature": len(crossings["gamma_curvature"]),
            "speed_sign_at_start": state_sequence[0]["speed_sign"],
            "speed_sign_at_end": state_sequence[-1]["speed_sign"],
            "curvature_sign_at_start": state_sequence[0]["curvature_sign"],
            "curvature_sign_at_end": state_sequence[-1]["curvature_sign"],
        },
    }

    with open("harness_output.json", "w", encoding="utf-8") as f:
        json.dump(output, f, ensure_ascii=False, indent=2)

    print("harness完成：steps=%d speed过零=%d curvature过零=%d" % (
        output["summary"]["n_steps"],
        output["summary"]["n_crossings_speed"],
        output["summary"]["n_crossings_gamma_curvature"]))


if __name__ == "__main__":
    main()

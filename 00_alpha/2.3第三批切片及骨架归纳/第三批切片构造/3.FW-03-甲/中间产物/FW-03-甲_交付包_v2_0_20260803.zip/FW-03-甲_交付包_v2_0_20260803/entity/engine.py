"""
FW-03-甲 引擎 · 一阶实体本体（被测对象）· v2.0（续3丙类修复后）

对象＝Roll触发判据族首根之状态量：同一时间快照下并出两个数学对象之符号序列
与各自过零事件，其中曲率通道另出恒正诊断。

判据锚（Q4判据，任务5_Step2增量产出v1.0 §1 FW-03行，裁决51已裁态，逐字转抄）：
"甲＝可算部分＝'OTM put之Gamma极值/二阶导过零'状态量与'二阶导恒正'不变量
（喂持仓+行情时序，出二阶导符号序列，判据＝过零检测与恒正核验）。"

── "二阶导"读法＝两量并出（裁决60-A1，KD已裁，本模块为落写执行，非本会话读法）──
源文（关于肥尾行情下期权类问题的亿口气回复.md 行11–12）一句话压缩两个数学对象，
KD以作者语义权确认解压为两量，本模块双通道并出：

  通道一 · speed（触发量）＝∂Γ/∂S，沿不利方向取号
    锚：源文等式句"当otm put 的gamma最大的时候，也就是二阶导为0的时候"
        （Γ峰 ⇔ Speed过零，恒等式）
      ＋宪-CV-06触发半句（Gamma峰值已过时Roll）
      ＋源文"已经变ATM"描述（Γ峰恒在strike附近）。
    取号口径：沿不利方向取号——`speed_adverse` ＝ ∂Γ/∂S × adverse_sign，
      adverse_direction=spot_down 时 adverse_sign=-1。语义＝"沿不利方向移动
      一单位，Γ的变化率"；Γ峰未至时为正（不利方向上Γ仍在增），Γ峰已过时
      为负。由正转负之过零事件＝"Gamma峰值已过"。原始 ∂Γ/∂S 同时输出为
      `speed_raw`，不因取号而丢失。
    Q4判据"Gamma极值 / 二阶导过零"斜杠并置之实现层对应：斜杠左侧（Gamma极值）
      ＝本通道之过零事件；斜杠右侧（二阶导过零）＝通道二之过零事件。两显名
      事件分别落地，不再以一词承担两职。

  通道二 · gamma_curvature（不变量）＝∂²Γ/∂S²（"Gamma的Gamma"，四阶导 ∂⁴V/∂S⁴）
    锚：源文不变量句"保持整个头寸的gamma的二阶导数一直为正"
      ＋宪-CV-06"做多四阶矩"（源文引 未来不可测_但我们有办法.md 行30-32）
      ＋QQQAI杠铃结构交流 行887"做的是Gamma的Gamma的功夫"。
    本通道另出恒正诊断（check_always_positive）。

  附带钉定（裁决60-A1②③，随本模块落写）：
    ①聚合层级维持per-lot；组合级恒正＝下游聚合性质，指针不在本根建。
    ②"恒正靠roll维持"＝组合级设计性质；甲之per-lot恒正核验为**诊断输出、
      非合格判据**——本情景 all_positive=False（18步违反）不构成缺陷。
    ③本情景数值锚（Γ峰、拐点位置）为参数特定值；符号序列输出对参数漂移免疫
      （不同参数下过零时点变，输出形态与语义不变）。

── M1消费形态＝M1源码内嵌（契约面消费）（裁决60-A2，KD已裁）──────────────
本模块之Gamma供给＝TPL1-T76-01引擎（续2求值口径增强 v1.2）之 entity/engine.py
**整文件逐字内嵌**（见下方 M1_VERBATIM_EMBED_BEGIN/END 分区），非import调用、
非独立重导BSM公式。45-A"调用权（纯函数）"之Phase A实现形态由裁决60-A2显式
扩充至内嵌形态（不强制import调用；一次性harness与交付自足性优先）。
  源文件＝TPL1-T76-01引擎_续2求值口径增强_交付包_v1_2_20260802/entity/engine.py
  SHA256＝e31fbcfeacebeb196f7e1d63f41089e7e0a7deb3cc9a9a8b44941af31e194e99
  （＝《切片记录_TPL1-T76-01引擎_续2求值口径增强 v1.2》指纹列声明值）
  内嵌段核证＝verify/assert_check.py 之 F-4 断言组：抽取两标记之间的正文，
  重算SHA256并与上述声明值逐位比对——内嵌段被静默改写即击落。
  路由限制不在内嵌段内改写：european_option 之限制由内嵌段**之外**的
  FW-03适配层（_evaluate_lot_european）承担，内嵌段保持零改动。

  【本根裁定登记#8 · 本轮新发现，呈KD】底版v1.0之"evaluate_lot()逐字内嵌"
  与"嵌入部分零改动（含注释）"claim经本会话对M1交付包实体逐块比对，**不成立**：
  底版所嵌为计算路径之逐字子集，但(a)删去两处注释行；(b)_eval_bs_dividend_yield
  之docstring被改写为一行摘要（M1原docstring所载类三登记、raw量纲口径、q语义
  边界随之丢失）；(c)evaluate_lot被改写（路由表分派改为硬分支），且M1契约面
  返回字段 computability_status / unstated_dimensions_hit 被删。本轮改采整文件
  逐字内嵌后，该claim成立且可机械核证。数值路径两版一致
  （_eval_bs_dividend_yield 计算体逐字相同），故本项不改变任何数值产物。

── 仪表身份标注（对照表§3随行义务③＋§5.4，24-E3形态）────────────────────
本根消费之per_lot gamma读数为M1引擎之仪表读数，非定价真理源；两通道导数量由该
读数有限差分导出，同一仪表身份随行，不因求导运算而升格为真理判定。M1契约⑥
（仪表计算器非定价真理源）随内嵌段原文携带。
"""

# 以下至 M1_VERBATIM_EMBED_END 之间为 TPL1-T76-01引擎 v1.2 entity/engine.py
# **整文件逐字内嵌**（零改动，含全部注释与docstring）。声明指纹见模块
# docstring；机械核证＝verify/assert_check.py F-4断言组（抽取两标记之间
# 正文重算SHA256）。任何改动均将击落该断言——如需随M1再版更新，走撞墙
# 清单登记之触发式重验义务，不得就地修改。
# ═══════════ M1_VERBATIM_EMBED_BEGIN ═══════════════════════════════════
"""
TPL1-T76-01 引擎 · 一阶实体本体（被测对象）

身份：品种感知自算 Greeks/定价引擎之阶段A一阶实体。
边界：本模块只做 per-lot 层求值（per_unit 与 per_lot 两层）。node 级聚合＝T-76 本职
      （裁决14），本模块不做；腿级聚合＝GK-31 本职，本模块不做。

数据源纪律（契约⑤）：本模块零网络、零文件读取、零行情接口。全部市场坐标由调用方
以已言明面字段传入；Greeks 与估值一律自算，不消费任何 vendor 派生量。

已言明最小面声明（裁决45-B1 条款措辞逐字随附）：
以下为已言明最小面，未言明维度（美式行权、股息、期货保证金形态、day count等）不构成规格封闭，留引擎切片撞墙

未言明维度之当前处置：不就地定义。各路由以确定性占位桩承接并在输出中逐笔标注
（computability_status / unstated_dimensions_hit），缺口另行登记于撞墙清单。
占位桩不 claim 语义等价——桩产出与真实定价结果在当前样本上的任何数值关系，
均不构成桩正确性宣称。

定价模型之地位：本模块所路由之模型为计算用途之仪表计算器，不承载定价真理宣称，
不用于裁决任何交易的获利合法性。

── 续2 引擎求值口径增强（KD裁定52-2，欧式分支引入连续股息收益率 q）──────────
本次增强＝欧式期权定价分支由无股息 BS 闭式解，推广为含连续股息收益率 q 之
BS 闭式解（q 承接位＝新增已言明字段 `dividend_yield`，人造声明输入，裁决1
`_data_source` 纪律同§9）。q=0 时公式代数化简至与增强前逐字节一致（回归可证，
见 verify/regression_check.py）。定价模型族地位不变（仍属 TPL3-T7601-01 类三·
阶段B校准项——"连续股息收益率参数化"为52-2既裁之q承接方式本身，非模型族
再选择；GBM闭式解族之内部参数化增强，非换族）。
线性持仓（spot/spot_etf/index）之股息/持有成本处置＝范围裁定不建模（裁决52-2
①，TPL1-T7601-01该分量已闭合），本次增强不触及 `_eval_linear`。
期货持有成本形态（TPL1-T7601-02）、美式早行权溢价（TPL1-T7601-03）维持 open，
本次增强不宣称覆盖；美式桩因承接欧式分支而随之消费 q（如实呈报，见撞墙清单
候选写回），不构成对03之闭合宣称。
day count 分母（TPL1-T7601-04）本次不改动（KD裁定前按桩纪律续用现值 ACT/365）。
"""

import math

# ---------------------------------------------------------------------------
# 已言明最小面（契约④）：本引擎消费之字段集，锚＝T-76 input_schema v2.2
#   §2 字段表（行17–33）＋ §3 行46（valuation_date 权威源，Q-9订正，裁决48 §4）
#   ＋ §4 桩接口段（行60–79）。三段锚定面，非仅两段（续2续修复订正，D-5②）。
# 未列字段（underlying / leg_type / open_interest / lot_id 之外的坐标与保留字段）
# 不进入求值路径。
# `dividend_yield`（续2新增）不在上述T-76锚定面内——该字段承接45-B1所列未言明
# 维度（股息）之q参数化处置（裁决52-2②直接指定），系本根自行取用之已言明字段
# （工程取用，不外推为跨根命名规范，形态先例同 `instrument_class`），非对
# T-76锚定面本身之扩展。
# ---------------------------------------------------------------------------
STATED_FACE_FIELDS = (
    "lot_id",
    "instrument_class",   # 路由键（本根取用，值域取自 TPL1-T76-01 缺口描述原文）
    "option_type",
    "side",
    "strike",
    "expiry",
    "spot",
    "risk_free_rate",
    "implied_vol",
    "multiplier",
    "quantity",
    "valuation_date",
    "dividend_yield",     # 续2新增：q承接位（人造声明输入，仅期权路由消费）
)

# 品种值域＝撞墙清单_T-76 v2.3 缺口描述原文所列六类，逐项映射为路由键
INSTRUMENT_CLASSES = (
    "spot",              # 现货
    "spot_etf",          # 现货ETF
    "futures",           # 期货
    "index",             # 指数
    "european_option",   # 欧式期权
    "american_option",   # 美式期权
)

ROUTE_TABLE = {
    "spot":             "linear_underlying",
    "spot_etf":         "linear_underlying",
    "index":            "linear_underlying",
    "futures":          "linear_underlying_futures_stub",
    "european_option":  "bs_dividend_yield_closed_form",   # 续2改名（原 bs_no_dividend_closed_form）：
                                                            # 旧名于q≠0后失实，改名避免声明-实现名实不符
    "american_option":  "american_via_european_stub",
}

# 各品种命中之未言明维度（45-B1 列示面 ＋ 构造中撞到之同型维度）
#
# 标注语义（裁决48 §3 既裁，乙·求值路径特征级命中）：
#   `unstated_dimensions_hit` ＝「该求值路径之计算是否进入该维度」。
#   线性恒等求值不含时间投影，股息维度不进入计算 → spot / spot_etf / index
#   三条线性路由均不标 dividend_carry；期货路由（结算/持有成本形态本身未言明）
#   维持命中——TPL1-T7601-02（期货结算形态）不入续2范围，futures 分支零改动。
#   经济层之股息现金流缺口（含线性持仓 bleed 漏分红之实况）由撞墙清单
#   TPL1-T7601-01 之缺口描述全域承载，不由本标注承载。
#
# 续2订正（路由声明兑现，KD裁定52-2②）：european_option / american_option 两路由
# 之 dividend_carry 去标——q 承接位已建成，该求值路径之计算已进入股息维度（q≠0
# 时纳入定价与希腊求值）。美式桩因承接同一函数而随之消费 q，如实去标（§2.3边界：
# 不构成对 TPL1-T7601-03 早行权缺口之闭合宣称，early_exercise 维持命中）。
# day_count_convention 两路由均维持命中——TPL1-T7601-04 本次仅呈候选，未经KD裁定。
UNSTATED_DIMENSIONS = {
    "spot":             (),
    "spot_etf":         (),
    "index":            (),
    "futures":          ("futures_settlement_form", "dividend_carry"),
    "european_option":  ("day_count_convention",),
    "american_option":  ("early_exercise", "day_count_convention"),
}

# 三态可算性标注（降格标注，三分判别 §3 处置要求）
COMPUTABILITY = {
    "spot":             "closed_on_stated_face",
    "spot_etf":         "closed_on_stated_face",
    "index":            "closed_on_stated_face",
    "futures":          "placeholder_stub",
    "european_option":  "computed_with_open_dimensions",
    "american_option":  "placeholder_stub",
}

GREEK_KEYS = ("delta", "gamma", "vega", "theta", "rho")

# day count 占位取值：ACT/365（未言明维度之确定性占位桩，不外推）
DAY_COUNT_DENOMINATOR = 365


# --------------------------- 基础数值原语 ---------------------------------

def _norm_cdf(x):
    """标准正态 CDF；erf 入口。"""
    return 0.5 * (1.0 + math.erf(x / math.sqrt(2.0)))


def _norm_pdf(x):
    return math.exp(-0.5 * x * x) / math.sqrt(2.0 * math.pi)


def _side_sign(side):
    if side == "long":
        return 1
    if side == "short":
        return -1
    raise ValueError("side 越出已言明值域 enum{long,short}: %r" % (side,))


def _dte_days(expiry, valuation_date):
    """dte = (expiry - valuation_date).days，整数天（T-76 §3 已言明口径）。
    不引入日历库：两日期以 yyyy-mm-dd 给出，按公历序日差计算。"""
    def _ord(d):
        y, m, dd = (int(t) for t in d.split("-"))
        # 公历序日（Rata Die），纯整数运算
        if m <= 2:
            y -= 1
            m += 12
        return (365 * y + y // 4 - y // 100 + y // 400
                + (153 * (m - 3) + 2) // 5 + dd)
    return _ord(expiry) - _ord(valuation_date)


# --------------------------- 路由分支实现 ---------------------------------

def _eval_linear(lot):
    """线性标的路由（现货／现货ETF／指数）：恒等映射。
    per-unit 估值＝标的报价本身；delta＝1；其余四希腊为 0（精确值，非近似）。
    本路由之求值不含时间投影，股息/持有成本维度不进入计算——三条线性路由
    据裁决48 §3 之求值路径特征级口径均标为 closed_on_stated_face、零维度命中。
    该零命中标注仅就求值路径而言，不构成"线性持仓无股息经济影响"之主张；
    经济层缺口见撞墙清单 TPL1-T7601-01。"""
    return {
        "value": float(lot["spot"]),
        "delta": 1.0,
        "gamma": 0.0,
        "vega": 0.0,
        "theta": 0.0,
        "rho": 0.0,
    }


def _eval_futures_stub(lot):
    """期货路由：确定性占位桩。
    结算/保证金形态未言明（45-B1 明列），本分支不引入任何持有成本或结算约定，
    以标的报价恒等承接。桩不 claim 语义等价：本分支与线性标的路由在阶段A数值重合，
    不构成'期货＝现货'之语义主张。"""
    return {
        "value": float(lot["spot"]),
        "delta": 1.0,
        "gamma": 0.0,
        "vega": 0.0,
        "theta": 0.0,
        "rho": 0.0,
    }


def _eval_bs_dividend_yield(lot):
    """欧式期权路由：含连续股息收益率 q 之 Black-Scholes-Merton 闭式解。
    定价模型族选型＝类三（阶段B校准项，TPL3-T7601-01）：本分支仍属 GBM 闭式解族，
    q 为该族内之参数化增强（续2，KD裁定52-2），非换族；候选之一，声明值不外推，
    待阶段B以回测/实盘数据证伪。

    q 承接位＝`dividend_yield`（续2新增已言明字段，人造声明输入）。q=0 时本公式
    代数化简至增强前（无股息）闭式解逐字节一致（d1/d2 中 −q 项为0，disc_q=e^0=1.0
    精确成立），回归可证——见 verify/regression_check.py（S-1 机械前哨）。

    量纲＝raw（T-76 schema 行80 口径）：delta/gamma 逐份额原始解析值；
    vega 按 sigma 变化 1.0 计；theta 按年计；rho 按 r 变化 1.0 计；零行业缩放。
    q 不新增第六希腊（无 epsilon＝∂V/∂q）——契约①之5全集＋V(t)边界不变，
    q 仅作为定价输入影响既有5希腊之数值，不扩展供给物语义类型。"""
    S = float(lot["spot"])
    K = float(lot["strike"])
    r = float(lot["risk_free_rate"])
    sig = float(lot["implied_vol"])
    q = float(lot["dividend_yield"])
    dte = _dte_days(lot["expiry"], lot["valuation_date"])
    if dte <= 0:
        raise ValueError("dte<=0 落在本分支已言明面之外（到期/已到期形态未言明）")
    T = dte / DAY_COUNT_DENOMINATOR

    sqrtT = math.sqrt(T)
    d1 = (math.log(S / K) + (r - q + 0.5 * sig * sig) * T) / (sig * sqrtT)
    d2 = d1 - sig * sqrtT
    disc_r = math.exp(-r * T)
    disc_q = math.exp(-q * T)
    nd1 = _norm_pdf(d1)

    if lot["option_type"] == "call":
        value = S * disc_q * _norm_cdf(d1) - K * disc_r * _norm_cdf(d2)
        delta = disc_q * _norm_cdf(d1)
        theta = (-(S * disc_q * nd1 * sig) / (2.0 * sqrtT)
                 - r * K * disc_r * _norm_cdf(d2)
                 + q * S * disc_q * _norm_cdf(d1))
        rho = K * T * disc_r * _norm_cdf(d2)
    elif lot["option_type"] == "put":
        value = K * disc_r * _norm_cdf(-d2) - S * disc_q * _norm_cdf(-d1)
        delta = disc_q * (_norm_cdf(d1) - 1.0)
        theta = (-(S * disc_q * nd1 * sig) / (2.0 * sqrtT)
                 + r * K * disc_r * _norm_cdf(-d2)
                 - q * S * disc_q * _norm_cdf(-d1))
        rho = -K * T * disc_r * _norm_cdf(-d2)
    else:
        raise ValueError("option_type 越出已言明值域 enum{call,put}: %r"
                         % (lot["option_type"],))

    gamma = disc_q * nd1 / (S * sig * sqrtT)
    vega = S * disc_q * nd1 * sqrtT
    return {"value": value, "delta": delta, "gamma": gamma,
            "vega": vega, "theta": theta, "rho": rho}


def _eval_american_stub(lot):
    """美式期权路由：确定性占位桩，承接路径＝欧式含股息收益率闭式解。
    早行权维度未言明（45-B1 明列），本分支不计算早行权溢价——早行权溢价通常
    随 q>0（尤其美式put）而非零，本桩不承接该效应，不 claim 语义等价。
    续2订正：本分支因承接欧式分支而随之消费 q（如实呈报，不静默）——
    dividend_carry 已从本路由 unstated_dimensions_hit 去标（q 已进入计算），
    early_exercise 维持命中（本桩产出不构成'美式价值＝欧式价值'之主张，
    亦不构成对早行权溢价大小或方向的任何断言，含 q>0 情形）。"""
    return _eval_bs_dividend_yield(lot)


_DISPATCH = {
    "linear_underlying":              _eval_linear,
    "linear_underlying_futures_stub": _eval_futures_stub,
    "bs_dividend_yield_closed_form":  _eval_bs_dividend_yield,
    "american_via_european_stub":     _eval_american_stub,
}


# --------------------------- 引擎入口 -------------------------------------

def evaluate_lot(lot):
    """品种感知求值：喂一笔 lot（已言明最小面字段），出 per-unit 与 per-lot 两层
    raw Greeks 5全集 ＋ 估值 V(t)。

    情景重估与时点推移不另设参数：调用方以冲击后的市场坐标（spot / implied_vol /
    risk_free_rate / valuation_date）构造同形 lot 再次调用本函数即得重估结果。
    """
    ic = lot["instrument_class"]
    if ic not in ROUTE_TABLE:
        raise ValueError("instrument_class 越出品种值域: %r" % (ic,))
    route = ROUTE_TABLE[ic]
    per_unit = _DISPATCH[route](lot)

    scale = int(lot["multiplier"]) * int(lot["quantity"]) * _side_sign(lot["side"])
    per_lot = {k: per_unit[k] * scale for k in ("value",) + GREEK_KEYS}

    return {
        "lot_id": lot["lot_id"],
        "instrument_class": ic,
        "route_id": route,
        "computability_status": COMPUTABILITY[ic],
        "unstated_dimensions_hit": list(UNSTATED_DIMENSIONS[ic]),
        "per_unit": per_unit,
        "per_lot": per_lot,
    }
# ═══════════ M1_VERBATIM_EMBED_END ═════════════════════════════════════

# ═══════════════════ FW-03-甲 专属逻辑（本根新增，非内嵌段）═══════════════

SIGN_EPSILON = 1e-12
# 符号分类容差（本根裁定登记#6，呈KD追认）：|通道值|<SIGN_EPSILON 时判0
# （未分类/边界），两通道共用。非裁决13/19容差子口径（该口径服务于独立复算
# 路径比对，见 verify/independent_recompute.py 与 verify/assert_check.py，
# 两容差用途不同，分开声明不混用）。取值理由：仅防护literal浮点零；本情景
# 观测量级 speed∈[5e-2,1.5]、gamma_curvature∈[4e-4,1.6e-1]，远高于该阈值，
# 不影响任何实际分类结果，纯防御性声明。

ADVERSE_DIRECTION_TO_SIGN = {"spot_down": -1, "spot_up": 1}
# 不利方向→取号映射（本根裁定登记#5，呈KD）：裁决60-A1"沿不利方向取号"之
# 实现层绑定。本根人造input声明 adverse_direction="spot_down"，理由＝本根对象
# 为杠铃结构之远端OTM put保护腿，其不利方向＝现货下行（源文行11–12之"大幅度
# 下跌"情景）。方向绑定为**头寸级声明**、非全局常量：上行翼头寸（如OTM call
# 保护腿）之不利方向为 spot_up，届时由input声明切换，本模块不写死。


def _bump_h(spot, bump_config):
    """按bump_config声明模式计算bump步长（本根裁定登记#6，呈KD追认）：
    relative模式＝h=spot*bump_ratio（比例bump，跨价格水平量纲一致）；
    absolute模式＝h=abs_h（常数步长）。本情景采用relative，bump_ratio=0.001。"""
    mode = bump_config["bump_mode"]
    if mode == "relative":
        return spot * bump_config["bump_ratio"]
    if mode == "absolute":
        return bump_config["abs_h"]
    raise ValueError("bump_mode 越出已声明值域 enum{relative,absolute}: %r" % (mode,))


def _adverse_sign(adverse_direction):
    """不利方向→取号（本根裁定登记#5）。越出已声明枚举即抛错，不静默取默认。"""
    if adverse_direction not in ADVERSE_DIRECTION_TO_SIGN:
        raise ValueError("adverse_direction 越出已声明值域 enum{spot_down,spot_up}: %r"
                         % (adverse_direction,))
    return ADVERSE_DIRECTION_TO_SIGN[adverse_direction]


def _classify_sign(value):
    """符号分类（SIGN_EPSILON带死区，两通道共用）。"""
    if value > SIGN_EPSILON:
        return 1
    if value < -SIGN_EPSILON:
        return -1
    return 0


def _evaluate_lot_european(lot):
    """FW-03适配层（内嵌段之外）：本根position恒为european_option，其余路由
    不在本根消费面。路由限制在此处施加，内嵌段保持零改动（裁决60-A2形态）。"""
    if lot["instrument_class"] != "european_option":
        raise ValueError(
            "FW-03-甲仅消费 european_option 路由，收到: %r"
            % (lot["instrument_class"],))
    return evaluate_lot(lot)


def bump_and_channels(position, spot_center, valuation_date, bump_config,
                      adverse_direction):
    """单一时间快照之核心计算（纯函数，无副作用）：
    固定valuation_date（即固定τ），仅沿现货S方向bump三点，由同一组三点
    分别得两通道：

      speed_raw       = [Γ(S+h) − Γ(S−h)] / (2h)            ≈ ∂Γ/∂S
      speed_adverse   = speed_raw × adverse_sign            （沿不利方向取号）
      gamma_curvature = [Γ(S+h) − 2Γ(S) + Γ(S−h)] / h²      ≈ ∂²Γ/∂S²

    两通道之截断阶均为O(h²)，但截断量级不同（speed之截断项含∂³Γ/∂S³，
    curvature之截断项含∂⁴Γ/∂S⁴），故量级诊断界须逐通道独立标定
    （裁决60-A1b；界值见 entity/input_schema.md §3）。

    聚合层级＝per-lot（本根裁定登记#2，60-A1附带钉定①维持）：源文与Q4判据
    均以"头寸Gamma"为单位，非跨头寸聚合；side=long时scale>0，per_lot与
    per_unit两通道同号；side=short时scale<0、两通道符号整体翻转，此为per_lot
    口径之应有行为，非缺陷。"""
    h = _bump_h(spot_center, bump_config)
    adv = _adverse_sign(adverse_direction)

    def _lot(spot):
        lot = dict(position)
        lot["spot"] = spot
        lot["valuation_date"] = valuation_date
        return lot

    g_plus = _evaluate_lot_european(_lot(spot_center + h))["per_lot"]["gamma"]
    g_mid = _evaluate_lot_european(_lot(spot_center))["per_lot"]["gamma"]
    g_minus = _evaluate_lot_european(_lot(spot_center - h))["per_lot"]["gamma"]

    speed_raw = (g_plus - g_minus) / (2.0 * h)
    speed_adverse = speed_raw * adv
    curvature = (g_plus - 2.0 * g_mid + g_minus) / (h * h)

    return {
        "spot": spot_center,
        "valuation_date": valuation_date,
        "dte_days": _dte_days(position["expiry"], valuation_date),
        "bump_h": h,
        "gamma_minus": g_minus,
        "gamma_mid": g_mid,
        "gamma_plus": g_plus,
        "speed_raw": speed_raw,
        "speed_adverse": speed_adverse,
        "speed_sign": _classify_sign(speed_adverse),
        "gamma_curvature": curvature,
        "curvature_sign": _classify_sign(curvature),
    }


def compute_state_sequence(position, bump_config, scenario, adverse_direction):
    """喂〔持仓+行情时序〕出〔两通道符号序列〕（Q4判据字面产出）。
    scenario＝[{"t":int,"valuation_date":str,"spot":float}, ...]，
    每步独立调用 bump_and_channels，零跨步状态依赖（纯函数序列）。"""
    seq = []
    for step in scenario:
        rec = bump_and_channels(position, step["spot"], step["valuation_date"],
                                bump_config, adverse_direction)
        rec["t"] = step["t"]
        seq.append(rec)
    return seq


CHANNEL_SIGN_KEYS = {"speed": "speed_sign", "gamma_curvature": "curvature_sign"}


def detect_zero_crossings(state_sequence, sign_key):
    """单通道过零检测（Q4判据"判据＝过零检测"字面产出）：相邻步符号翻转事件。
    sign 0视为"未分类"、不参与翻转判定传递，取上一非零符号延续比较——本情景
    SIGN_EPSILON为防御性极小值，实测不触发0分类，此分支为完备性声明。
    from_spot/to_spot 均落实际现货值（续3 D-9订正：底版 from_spot 恒为 null，
    字段名实不符）。"""
    crossings = []
    prev_sign = None
    prev_t = None
    prev_spot = None
    for rec in state_sequence:
        s = rec[sign_key]
        if s == 0:
            continue
        if prev_sign is not None and s != prev_sign:
            crossings.append({
                "from_t": prev_t, "to_t": rec["t"],
                "from_sign": prev_sign, "to_sign": s,
                "from_spot": prev_spot, "to_spot": rec["spot"],
            })
        prev_sign = s
        prev_t = rec["t"]
        prev_spot = rec["spot"]
    return crossings


def detect_zero_crossings_all(state_sequence):
    """两通道过零事件分通道并出（裁决60-A1"各自过零事件"）。"""
    return {ch: detect_zero_crossings(state_sequence, sk)
            for ch, sk in sorted(CHANNEL_SIGN_KEYS.items())}


def check_always_positive(state_sequence):
    """恒正核验（Q4判据"判据＝…恒正核验"字面产出）——**仅 gamma_curvature 通道**
    （裁决60-A1：恒正诊断属不变量通道；speed通道无恒正语义）。

    诊断量、非合格判据（60-A1附带钉定②）：甲仅核验并报告当前序列是否满足
    "二阶导恒正"不变量，不裁决、不生成使其恒正的动作（该动作属FW-03-乙，
    roll编排域，本根不越界）。"恒正靠roll维持"为**组合级**设计性质，per-lot
    层出现违反步不构成本根缺陷。"""
    per_step = [{"t": rec["t"], "positive": rec["curvature_sign"] > 0}
                for rec in state_sequence]
    all_positive = all(r["positive"] for r in per_step)
    violation_ts = [r["t"] for r in per_step if not r["positive"]]
    return {
        "channel": "gamma_curvature",
        "semantics": "diagnostic_not_pass_fail",
        "aggregation_level": "per_lot",
        "per_step": per_step,
        "all_positive": all_positive,
        "violation_step_count": len(violation_ts),
        "violation_ts": violation_ts,
    }

"""
FW-03-甲 · D段断言脚本 · v2.0（续3丙类修复后）

判据基线程序化解析自 entity/input_schema.md §3 口径声明块（yaml键值对与声明面
表），不硬编码重复声明值（除防御性默认外）。任一断言不符即非零退出码终止
（28-B(ii)）。

── 崩溃安全日志（49-3形态，本轮自查订正）──────────────────────────────
底版v1.0之docstring自称"日志开跑即清、逐断言即时写出"，实测为**汇总时一次性
写出**：脚本中途异常退出时不写日志，上一轮成功日志原地残留＝"失败运行残留
成功日志"（F-3流水线observable之禁止形态）。本轮改为：开跑即truncate并写入
运行头，每条断言即时append+flush，主流程异常亦捕获并写入CRASH行后以退出码2
终止。本项为本会话自查发现、非外审缺陷清单条目，如实登记。

── 钉表构造顺序留痕（F-10最低形态＝文字声明三处一致，第二处）────────────
三处＝本脚本头注（此处）／entity/input_schema.md §5钉表节／切片记录_FW-03-甲
"钉表与构造顺序"节。声明内容：本根期望值钉表＝verify/independent_expected.json，
由 verify/independent_recompute.py 仅据 entity/input_data.json 之人造参数独立
产出，零读被测侧产物、零读自身既往产物（F-8）；构造顺序＝先立钉表、后跑比对
断言。F-10已知限制如实标注：最低形态为文字声明，可程序化时序证据非强制。

── 本轮新增/重写之断言组（对外审缺陷清单D-1~D-9与裁决60-A组落写）──────
step0(ii)  静态扫描面接入（D-1；F-1双向对表、F-7封闭四要件、W-5/W-8三部分、
           关键字一律正则消费、检测器前哨自检）
step0(ii-b) scan_patterns.json 双钉（D-4；F-5）
A3/A4/A5   两通道各自独立核验（裁决60-A1两量并出）
A4         量级诊断界逐通道独立（裁决60-A1b；speed界按三阶导截断量级独立标定）
A7         输出形态封闭扩至嵌套层（D-2；zero_crossings通道键集与条目键集、
           always_positive_check键集、summary键集、per_step条目键集）
A10        产物新鲜度钉定射程扩至全包域＋钉定件重构核证＋pin门（D-3）
A11        dte三实现独立一致性（D-7根治之断言侧第三实现）
A12        M1内嵌段指纹＝M1声明指纹（D-6a；裁决60-A2②）
A13        包域清单双向对表（F-7检"多"不止检"缺"）
"""

import ast
import datetime
import hashlib
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(HERE)
LOG_PATH = os.path.join(HERE, "assert_check_log.txt")

FAIL_COUNT = 0
PASS_COUNT = 0
_LOG_FH = None


def _open_log():
    """开跑即truncate（崩溃安全：中途异常不得残留上一轮成功日志）。"""
    global _LOG_FH
    _LOG_FH = open(LOG_PATH, "w", encoding="utf-8")


def log(msg):
    print(msg)
    if _LOG_FH is not None:
        _LOG_FH.write(msg + "\n")
        _LOG_FH.flush()


def check(name, cond, detail=""):
    global FAIL_COUNT, PASS_COUNT
    if cond:
        PASS_COUNT += 1
        log("PASS %-10s %s" % (name, detail))
    else:
        FAIL_COUNT += 1
        log("FAIL %-10s %s" % (name, detail))


def _sha256_path(path):
    with open(path, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()


def _read(path):
    with open(path, "r", encoding="utf-8") as f:
        return f.read()


# ---------------------------------------------------------------------------
# 断言侧独立日期换算（D-7根治之第三实现；与被测侧Rata Die公式、独立侧stdlib
# datetime 均为不同代码路径：闰年规则＋逐月累计天数表直接累加）
# ---------------------------------------------------------------------------
_CUM_DAYS_NORMAL = (0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334)


def _is_leap(y):
    return (y % 4 == 0 and y % 100 != 0) or (y % 400 == 0)


def _days_from_civil_table(datestr):
    """自公元1年1月1日起之累计天数（表驱动实现，断言侧独立实现）。"""
    y, m, d = (int(x) for x in datestr.split("-"))
    yy = y - 1
    days = yy * 365 + yy // 4 - yy // 100 + yy // 400
    days += _CUM_DAYS_NORMAL[m - 1]
    if m > 2 and _is_leap(y):
        days += 1
    return days + d


def _dte_days_table(expiry, valuation_date):
    return _days_from_civil_table(expiry) - _days_from_civil_table(valuation_date)


# ---------------------------------------------------------------------------
# schema 声明面解析
# ---------------------------------------------------------------------------
def parse_schema_declarations(schema_text):
    """解析 input_schema.md §3.1 之 ```yaml 键值块（行级解析，不依赖yaml库，
    保持verify包自足、零包外路径依赖）。"""
    m = re.search(r"```yaml\n(.*?)\n```", schema_text, re.S)
    if not m:
        raise AssertionError("input_schema.md §3.1口径声明块未找到（```yaml fenced block）")
    decls = {}
    for line in m.group(1).splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        k, v = line.split(":", 1)
        decls[k.strip()] = v.strip()
    return decls


def parse_declared_block(schema_text, tag):
    """解析 input_schema.md 内以 ```json 标注之声明面块，块前一行含 tag 标识。"""
    pat = re.compile(re.escape(tag) + r".*?```json\n(.*?)\n```", re.S)
    m = pat.search(schema_text)
    if not m:
        raise AssertionError("input_schema.md 声明面块未找到：%s" % tag)
    return json.loads(m.group(1))


# ---------------------------------------------------------------------------
# 代码剥离（注释/docstring）——W-8(c)：判定统一在剥离后文本上执行
# ---------------------------------------------------------------------------
def strip_code(src):
    out_lines = [re.sub(r"#.*$", "", ln) for ln in src.split("\n")]
    stripped = "\n".join(out_lines)
    try:
        tree = ast.parse(stripped)
    except SyntaxError:
        return stripped
    spans = []
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef,
                             ast.ClassDef)):
            doc = ast.get_docstring(node, clean=False)
            if doc:
                first = node.body[0]
                spans.append((first.lineno, first.end_lineno))
    lines = stripped.split("\n")
    for a, b in spans:
        for i in range(a - 1, b):
            lines[i] = ""
    return "\n".join(lines)


def _sentinel_for_keyword(pattern):
    """由关键字正则之去转义字面构造合成阳性样本（检测器前哨自检用）。
    关键字组之正则仅含转义点一种元字符，去转义即得字面。"""
    return pattern.replace("\\", "")


def walk_package():
    """全包域发现面（F-7）：遍历包根与全部子目录，返回相对路径集合。"""
    found = set()
    for root, dirs, files in os.walk(PKG):
        dirs[:] = [d for d in dirs if not d.startswith(".") and d != "__pycache__"]
        for fn in files:
            if fn.endswith(".pyc"):
                continue
            rel = os.path.relpath(os.path.join(root, fn), PKG).replace(os.sep, "/")
            found.add(rel)
    return found


def main():
    log("=== FW-03-甲 assert_check v2.0 开跑 %s ===" % datetime.datetime.now().isoformat())

    schema_text = _read(os.path.join(PKG, "entity/input_schema.md"))
    decls = parse_schema_declarations(schema_text)
    ext_decl = parse_declared_block(schema_text, "§3.2")
    inv_decl = parse_declared_block(schema_text, "§3.3")

    input_data = json.loads(_read(os.path.join(PKG, "entity/input_data.json")))
    harness = json.loads(_read(os.path.join(PKG, "entity/harness_output.json")))
    indep = json.loads(_read(os.path.join(HERE, "independent_expected.json")))
    provenance = json.loads(_read(os.path.join(HERE, "build_provenance.json")))
    engine_src = _read(os.path.join(PKG, "entity/engine.py"))
    patterns = json.loads(_read(os.path.join(HERE, "scan_patterns.json")))

    # =====================================================================
    # step0 · 前置合规断言（先于数值比对）
    # =====================================================================
    check("step0-i", input_data.get("_data_source") == "synthetic_hand_constructed",
          "人造input声明：_data_source=%r" % input_data.get("_data_source"))
    check("step0-i-b", harness.get("_data_source") == "synthetic_hand_constructed",
          "输出承载人造标记")

    # --- 发现面与扫描面（F-1／F-7）---
    all_files = walk_package()
    discovered_py = sorted(f for f in all_files if f.endswith(".py"))
    declared_scanned = sorted(inv_decl["scan_face_py"])
    scan_excluded = inv_decl["scan_excluded"]

    check("step0-ii-a", discovered_py == declared_scanned,
          "F-1双向对表：全包域遍历发现之.py件(%d) 与 schema声明扫描面(%d) 逐件相等；"
          "仅声明未交付=%s；仅交付未声明=%s"
          % (len(discovered_py), len(declared_scanned),
             sorted(set(declared_scanned) - set(discovered_py)),
             sorted(set(discovered_py) - set(declared_scanned))))

    kw_regex = [re.compile(p) for p in patterns["forbidden_keyword_regex"]]
    imp_regex = re.compile(patterns["forbidden_import_regex"], re.M)

    raw_hits, stripped_hits = {}, {}
    for rel in discovered_py:
        src = _read(os.path.join(PKG, rel))
        st = strip_code(src)
        raw_hits[rel] = [p.pattern for p in kw_regex if p.search(src)]
        hits = [p.pattern for p in kw_regex if p.search(st)]
        hits += [m.group(1) for m in imp_regex.finditer(st)]
        stripped_hits[rel] = hits

    check("step0-ii", all(not v for v in stripped_hits.values()),
          "剥离注释/docstring后零数据源接入命中（扫描面＝全部交付脚本%d件；"
          "关键字与import模式一律正则消费）；剥离后=%s；剥离前留痕=%s"
          % (len(discovered_py),
             {k: v for k, v in stripped_hits.items() if v},
             {k: v for k, v in raw_hits.items() if v}))

    # step0(ii-b) · 外置数据件双钉（F-5）：指纹 ＋ schema声明面
    sp_path = os.path.join(HERE, "scan_patterns.json")
    sp_hash = _sha256_path(sp_path)
    check("step0-ii-b1", sp_hash == ext_decl["scan_patterns.json"]["sha256"],
          "scan_patterns.json指纹＝schema §3.2声明值（实测%s…）" % sp_hash[:16])
    counts_actual = {
        "forbidden_keyword_regex": len(patterns["forbidden_keyword_regex"]),
        "truth_claim_patterns": len(patterns["truth_claim_patterns"]),
        "action_scope_markers": len(patterns["action_scope_markers"]),
        "negation_markers": len(patterns["negation_markers"]),
    }
    check("step0-ii-b2", counts_actual == ext_decl["scan_patterns.json"]["group_counts"],
          "scan_patterns.json声明面（各模式组条目数）＝schema §3.2：实测%s" % counts_actual)

    # step0(ii-c) · 排除清单与理由留痕（F-7排除最小化；订正D-4之空指声明）
    log("INFO step0-ii-c 扫描排除清单（最小化，逐条理由）：")
    for item in scan_excluded:
        log("     · %s ← %s" % (item["path"], item["reason"]))
    check("step0-ii-c", all(item["path"] not in discovered_py for item in scan_excluded),
          "排除清单%d条均非.py件（.py扫描面零排除）" % len(scan_excluded))

    # step0(ii-d) · 检测器前哨自检（检"多"不止检"缺"：模式须对合成阳性样本实际命中）
    dead_kw = [p.pattern for p in kw_regex
               if not p.search(_sentinel_for_keyword(p.pattern))]
    sent = patterns["sentinel_positive_samples"]
    pos_imp = [v for k, v in sent.items() if k.startswith("forbidden_import_regex")]
    dead_imp = [s for s in pos_imp if not imp_regex.search(s)]
    false_pos = [s for s in patterns["sentinel_negative_samples"] if imp_regex.search(s)]
    check("step0-ii-d", not dead_kw and not dead_imp and not false_pos,
          "检测器活性前哨：关键字死条款=%s；import模式漏检阳性样本=%s；"
          "阴性样本误命中=%s（%d条关键字＋%d条阳性样本＋%d条阴性样本全过）"
          % (dead_kw, dead_imp, false_pos,
             len(kw_regex), len(pos_imp), len(patterns["sentinel_negative_samples"])))

    # step0(iii) · 独立复算之独立性（不import被测模块、不读harness产物、不读自身既往产物）
    indep_src = _read(os.path.join(HERE, "independent_recompute.py"))
    indep_code = strip_code(indep_src)
    forbidden_reads = ["import engine", "from engine", "harness_output",
                       "import harness", "independent_expected.json\", \"r\""]
    check("step0-iii", all(tok not in indep_code for tok in forbidden_reads),
          "独立复算未import被测模块、未读harness产物、未读自身既往产物（F-8后半）")

    # =====================================================================
    # A1 · 目录结构（24-A7 O1）
    # =====================================================================
    check("A1a", os.path.isdir(os.path.join(PKG, "entity")), "entity/目录在场")
    check("A1b", os.path.isdir(os.path.join(PKG, "verify")), "verify/目录在场")

    # =====================================================================
    # A2 · 人造input域与承接（A段）
    # =====================================================================
    check("A2", input_data["channel_config"]["adverse_direction"]
          == harness["channel_config"]["adverse_direction"],
          "adverse_direction声明自input承接至输出：%s"
          % harness["channel_config"]["adverse_direction"])

    # =====================================================================
    # A3 · 符号一致性（主判据，零容差，两通道各自逐格点）
    # =====================================================================
    state_seq = harness["state_sequence"]
    indep_by_t = {r["t"]: r for r in indep["records"]}
    CHANNELS = [
        ("speed", "speed_sign", "speed_adverse",
         "independent_speed_sign", "independent_speed_adverse",
         "MAGNITUDE_TOLERANCE_REL_SPEED_DECLARED", "MAGNITUDE_FLOOR_SPEED_DECLARED"),
        ("gamma_curvature", "curvature_sign", "gamma_curvature",
         "independent_curvature_sign", "independent_gamma_curvature",
         "MAGNITUDE_TOLERANCE_REL_CURVATURE_DECLARED", "MAGNITUDE_FLOOR_CURVATURE_DECLARED"),
    ]
    for ch, sk, vk, isk, ivk, tolkey, floorkey in CHANNELS:
        mis = []
        for rec in state_seq:
            ind = indep_by_t.get(rec["t"])
            if ind is None:
                mis.append((rec["t"], "independent_expected缺该t记录"))
                continue
            if rec[sk] != ind[isk]:
                mis.append((rec["t"], "engine=%r indep=%r" % (rec[sk], ind[isk])))
        check("A3-" + ch, len(mis) == 0,
              "符号逐格点一致性（零容差）：%d/%d 不符 %s"
              % (len(mis), len(state_seq), mis[:3] if mis else ""))

    # =====================================================================
    # A4 · 量级诊断（辅助判据，界值逐通道独立；rel/abs两分支封闭，无静默跳过）
    # =====================================================================
    check("A4-decl",
          abs(float(decls["MAGNITUDE_TOLERANCE_REL_SPEED_DECLARED"])
              - indep["magnitude_tolerance_rel_speed"]) < 1e-15
          and abs(float(decls["MAGNITUDE_TOLERANCE_REL_CURVATURE_DECLARED"])
                  - indep["magnitude_tolerance_rel_curvature"]) < 1e-15
          and abs(float(decls["MAGNITUDE_FLOOR_SPEED_DECLARED"])
                  - indep["magnitude_floor_speed"]) < 1e-30
          and abs(float(decls["MAGNITUDE_FLOOR_CURVATURE_DECLARED"])
                  - indep["magnitude_floor_curvature"]) < 1e-30,
          "两通道容差界与地板：schema声明面 ≡ independent_expected声明面")
    check("A4-sep",
          float(decls["MAGNITUDE_TOLERANCE_REL_SPEED_DECLARED"])
          != float(decls["MAGNITUDE_TOLERANCE_REL_CURVATURE_DECLARED"]),
          "裁决60-A1b：speed通道界独立标定、非沿用curvature之0.01（speed=%s curvature=%s）"
          % (decls["MAGNITUDE_TOLERANCE_REL_SPEED_DECLARED"],
             decls["MAGNITUDE_TOLERANCE_REL_CURVATURE_DECLARED"]))

    for ch, sk, vk, isk, ivk, tolkey, floorkey in CHANNELS:
        tol = float(decls[tolkey])
        floor = float(decls[floorkey])
        abs_tol = tol * floor
        n_rel = n_abs = 0
        viol = []
        max_rel = 0.0
        for rec in state_seq:
            ind = indep_by_t[rec["t"]]
            true_v = ind[ivk]
            eng_v = rec[vk]
            if abs(true_v) >= floor:
                n_rel += 1
                rel = abs(eng_v - true_v) / abs(true_v)
                max_rel = max(max_rel, rel)
                if rel > tol:
                    viol.append((rec["t"], "rel=%.3e>tol" % rel))
            else:
                n_abs += 1
                if abs(eng_v - true_v) > abs_tol:
                    viol.append((rec["t"], "abs=%.3e>abs_tol" % abs(eng_v - true_v)))
        check("A4-" + ch, len(viol) == 0,
              "量级诊断界内：%d超界；相对分支%d点(实测max_rel=%.4e, 界%.4g)＋"
              "绝对分支%d点(abs_tol=%.3e) %s"
              % (len(viol), n_rel, max_rel, tol, n_abs, abs_tol, viol[:3]))
        check("A4-" + ch + "-cover", n_rel + n_abs == len(state_seq),
              "两分支覆盖全部格点、无静默跳过：%d+%d=%d" % (n_rel, n_abs, len(state_seq)))

    # =====================================================================
    # A5 · 过零事件独立核对（两通道各自，独立重算不调用engine）
    # =====================================================================
    def independent_crossings(records, sign_field):
        out = []
        prev_sign = prev_t = prev_spot = None
        for r in sorted(records, key=lambda x: x["t"]):
            s = r[sign_field]
            if s == 0:
                continue
            if prev_sign is not None and s != prev_sign:
                out.append((prev_t, r["t"], prev_sign, s, prev_spot, r["spot"]))
            prev_sign, prev_t, prev_spot = s, r["t"], r["spot"]
        return out

    for ch, sk, vk, isk, ivk, tolkey, floorkey in CHANNELS:
        exp = independent_crossings(indep["records"], isk)
        got = [(c["from_t"], c["to_t"], c["from_sign"], c["to_sign"],
                c["from_spot"], c["to_spot"]) for c in harness["zero_crossings"][ch]]
        check("A5-" + ch, exp == got,
              "过零事件独立核对：期望%d项 实得%d项 %s"
              % (len(exp), len(got), "" if exp == got else (exp, got)))

    # A5-d · D-9订正：from_spot 不得为空（字段名实相符）
    null_spots = [(ch, c) for ch in harness["zero_crossings"]
                  for c in harness["zero_crossings"][ch]
                  if c["from_spot"] is None or c["to_spot"] is None]
    check("A5-spot", len(null_spots) == 0,
          "过零事件之from_spot/to_spot均落实际值（D-9订正）：空值%d项" % len(null_spots))

    # =====================================================================
    # A6 · 恒正诊断独立核对（仅gamma_curvature通道）
    # =====================================================================
    apc = harness["always_positive_check"]
    exp_all_pos = all(r["independent_curvature_sign"] > 0 for r in indep["records"])
    exp_viol = [r["t"] for r in indep["records"] if not r["independent_curvature_sign"] > 0]
    check("A6a", apc["all_positive"] == exp_all_pos,
          "all_positive独立核对：期望%r 实得%r" % (exp_all_pos, apc["all_positive"]))
    check("A6b", apc["violation_ts"] == exp_viol,
          "violation_ts独立核对：期望%d项 实得%d项" % (len(exp_viol), len(apc["violation_ts"])))
    check("A6c", apc["channel"] == "gamma_curvature"
          and apc["semantics"] == "diagnostic_not_pass_fail"
          and apc["aggregation_level"] == "per_lot",
          "恒正核验之通道归属与诊断性质标注在场（裁决60-A1附带钉定②）")

    # =====================================================================
    # A7 · 输出形态封闭（39-B2；D-2：扩至嵌套层与条目键集）
    # =====================================================================
    shape = parse_declared_block(schema_text, "§3.4")
    check("A7a", set(harness.keys()) == set(shape["top_level"]),
          "顶层键封闭：多余%s 缺失%s"
          % (set(harness.keys()) - set(shape["top_level"]),
             set(shape["top_level"]) - set(harness.keys())))
    bad = [r["t"] for r in state_seq if set(r.keys()) != set(shape["state_record"])]
    check("A7b", len(bad) == 0, "state_sequence条目键封闭：%d条不符 %s" % (len(bad), bad[:3]))
    check("A7c", set(harness["zero_crossings"].keys()) == set(shape["zero_crossings_channels"]),
          "zero_crossings通道键集封闭：实得%s" % sorted(harness["zero_crossings"].keys()))
    badx = [(ch, c) for ch in harness["zero_crossings"]
            for c in harness["zero_crossings"][ch]
            if set(c.keys()) != set(shape["zero_crossing_entry"])]
    check("A7d", len(badx) == 0, "zero_crossings条目键集封闭：%d条不符" % len(badx))
    check("A7e", set(apc.keys()) == set(shape["always_positive_check"]),
          "always_positive_check键集封闭：多余%s 缺失%s"
          % (set(apc.keys()) - set(shape["always_positive_check"]),
             set(shape["always_positive_check"]) - set(apc.keys())))
    badp = [p for p in apc["per_step"] if set(p.keys()) != set(shape["per_step_entry"])]
    check("A7f", len(badp) == 0, "always_positive_check.per_step条目键集封闭：%d条不符" % len(badp))
    check("A7g", set(harness["summary"].keys()) == set(shape["summary"]),
          "summary键集封闭：多余%s 缺失%s"
          % (set(harness["summary"].keys()) - set(shape["summary"]),
             set(shape["summary"]) - set(harness["summary"].keys())))

    # =====================================================================
    # A8 · 声明-实现一致性（F-4）
    # =====================================================================
    check("A8a", decls["BUMP_MODE_DECLARED"] == input_data["bump_config"]["bump_mode"],
          "bump_mode声明≡实现：%s" % decls["BUMP_MODE_DECLARED"])
    check("A8b", abs(float(decls["BUMP_RATIO_DECLARED"])
                     - input_data["bump_config"]["bump_ratio"]) < 1e-15,
          "bump_ratio声明≡实现：%s" % decls["BUMP_RATIO_DECLARED"])
    m = re.search(r"^SIGN_EPSILON\s*=\s*([0-9.eE+-]+)", engine_src, re.M)
    check("A8c", m is not None and abs(float(m.group(1))
                                       - float(decls["SIGN_EPSILON_DECLARED"])) < 1e-30,
          "SIGN_EPSILON声明(%s)≡engine.py源码(%s)"
          % (decls["SIGN_EPSILON_DECLARED"], m.group(1) if m else "未找到"))
    check("A8d", decls["AGGREGATION_LEVEL_DECLARED"] == "per_lot"
          and apc["aggregation_level"] == "per_lot",
          "聚合层级声明≡产物标注：per_lot")
    check("A8e", decls["ADVERSE_DIRECTION_DECLARED"]
          == input_data["channel_config"]["adverse_direction"]
          == indep["adverse_direction"],
          "adverse_direction三面一致（schema／input／独立复算）：%s"
          % decls["ADVERSE_DIRECTION_DECLARED"])
    mdc = re.search(r"^DAY_COUNT_DENOMINATOR\s*=\s*(\d+)", engine_src, re.M)
    check("A8f", mdc is not None
          and int(mdc.group(1)) == int(decls["DAY_COUNT_DENOMINATOR_DECLARED"])
          == int(indep["day_count_denominator"]),
          "day count分母三面一致：%s" % decls["DAY_COUNT_DENOMINATOR_DECLARED"])
    check("A8g", decls["DERIVATIVE_VARIABLE_DECLARED"] == "spot",
          "求导变量声明＝spot（本根裁定登记#3）")
    # 实现侧对应：bump仅沿spot方向、valuation_date在单步内不变
    mvar = re.search(r"lot\[\"spot\"\]\s*=\s*spot", engine_src)
    check("A8h", mvar is not None and "lot[\"valuation_date\"] = valuation_date" in engine_src,
          "求导变量声明≡实现：单步内仅spot被bump、valuation_date固定")

    # =====================================================================
    # A9 · 参数声明域
    # =====================================================================
    pos = input_data["position"]
    check("A9a", pos["option_type"] == "put", "option_type=put（本根声明域）")
    check("A9b", pos["instrument_class"] == "european_option", "instrument_class声明域")
    check("A9c", pos["side"] in ("long", "short"), "side枚举域")
    check("A9d", int(pos["multiplier"]) > 0 and int(pos["quantity"]) > 0,
          "multiplier/quantity正整数")
    dte_bad = [s for s in input_data["scenario"]
               if _dte_days_table(pos["expiry"], s["valuation_date"]) <= 0]
    check("A9e", len(dte_bad) == 0,
          "全程dte>0（未落入未言明维度分支）：%d步违反" % len(dte_bad))

    # =====================================================================
    # A10 · 产物新鲜度钉定（D-3：射程扩至全包域；含钉定件重构核证与pin门）
    # =====================================================================
    pin_domain_expected = sorted(
        f for f in all_files
        if (f.startswith("entity/") or f.startswith("verify/"))
        and f not in set(inv_decl["pin_excluded_paths"]))
    check("A10a", sorted(provenance["fingerprints"].keys()) == pin_domain_expected,
          "钉定射程重构核证：钉定件字段集 ≡ 按封闭规则重算之应钉集(%d件)；"
          "缺钉=%s 多钉=%s"
          % (len(pin_domain_expected),
             sorted(set(pin_domain_expected) - set(provenance["fingerprints"])),
             sorted(set(provenance["fingerprints"]) - set(pin_domain_expected))))
    fresh_bad = []
    for rel, pinned in provenance["fingerprints"].items():
        p = os.path.join(PKG, rel)
        if not os.path.exists(p):
            fresh_bad.append((rel, "钉定件所指路径缺位"))
            continue
        cur = _sha256_path(p)
        if cur != pinned:
            fresh_bad.append((rel, "%s→%s" % (pinned[:10], cur[:10])))
    check("A10b", len(fresh_bad) == 0,
          "产物新鲜度：%d件钉定全部现行一致；不符%s"
          % (len(provenance["fingerprints"]), fresh_bad))
    check("A10c", provenance.get("pin_excluded_paths") == inv_decl["pin_excluded_paths"]
          and provenance.get("closure_rule") == inv_decl["pin_closure_rule"],
          "钉定件之排除清单与封闭规则 ≡ schema §3.3声明面（F-5双钉之声明面半）")
    check("A10d", "verify/build_provenance.py" in provenance["fingerprints"],
          "F-8：钉定脚本自身入钉定射程（钉定件不可单通道重生成而不留痕）")

    # =====================================================================
    # A11 · dte三实现独立一致性（D-7根治；M8共模变异闭合）
    # =====================================================================
    dte_mis = []
    for rec in state_seq:
        ind = indep_by_t[rec["t"]]
        d_table = _dte_days_table(pos["expiry"], rec["valuation_date"])
        if not (rec["dte_days"] == ind["independent_dte_days"] == d_table):
            dte_mis.append((rec["t"], rec["dte_days"], ind["independent_dte_days"], d_table))
    check("A11", len(dte_mis) == 0,
          "dte三实现（被测Rata Die／独立stdlib／断言表驱动）逐步整数相等：%d步不符 %s"
          % (len(dte_mis), dte_mis[:3]))

    # =====================================================================
    # A12 · M1内嵌段指纹（D-6a；裁决60-A2②）
    # =====================================================================
    BEG = "# ═══════════ M1_VERBATIM_EMBED_BEGIN ═══════════════════════════════════\n"
    END = "# ═══════════ M1_VERBATIM_EMBED_END ═════════════════════════════════════\n"
    ok_marker = BEG in engine_src and END in engine_src
    seg_hash = None
    if ok_marker:
        a = engine_src.index(BEG) + len(BEG)
        b = engine_src.index(END)
        seg_hash = hashlib.sha256(engine_src[a:b].encode("utf-8")).hexdigest()
    check("A12a", ok_marker, "engine.py内嵌段起止标记在场")
    check("A12b", seg_hash == decls["M1_SOURCE_SHA256_DECLARED"],
          "内嵌段重算SHA256 ≡ schema声明之M1源指纹（%s…）；实测%s"
          % (decls["M1_SOURCE_SHA256_DECLARED"][:16],
             (seg_hash[:16] + "…") if seg_hash else "标记缺位"))
    check("A12c", decls["M1_SOURCE_SHA256_DECLARED"] in engine_src,
          "engine.py docstring所载M1源指纹 ≡ schema声明值（两声明面无漂移）")

    # =====================================================================
    # A13 · 包域清单双向对表（F-7：检"多"不止检"缺"）
    # =====================================================================
    declared_inventory = sorted(inv_decl["package_inventory"])
    actual_inventory = sorted(all_files)
    check("A13", declared_inventory == actual_inventory,
          "包域清单双向对表：声明%d件／实际%d件；域外未声明件=%s；声明未交付件=%s"
          % (len(declared_inventory), len(actual_inventory),
             sorted(set(actual_inventory) - set(declared_inventory)),
             sorted(set(declared_inventory) - set(actual_inventory))))

    # --- 汇总 ---
    log("=== 汇总：PASS=%d FAIL=%d ===" % (PASS_COUNT, FAIL_COUNT))


if __name__ == "__main__":
    _open_log()
    try:
        main()
    except BaseException as exc:  # 崩溃安全：异常亦留痕，且不残留成功汇总
        log("CRASH assert_check异常终止：%s: %s" % (type(exc).__name__, exc))
        _LOG_FH.close()
        sys.exit(2)
    _LOG_FH.close()
    sys.exit(1 if FAIL_COUNT > 0 else 0)

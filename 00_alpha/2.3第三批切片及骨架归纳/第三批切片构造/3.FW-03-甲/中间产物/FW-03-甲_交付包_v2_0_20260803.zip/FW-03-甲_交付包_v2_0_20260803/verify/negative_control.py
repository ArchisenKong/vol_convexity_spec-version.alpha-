"""
FW-03-甲 · 负向对照自查（构造/修复侧留痕，非G4外审重放，非合格判定依据本身）

── 本轮形态变更（续4 O-4同型闭合；裁决60-C1 M8计入口径）──────────────────
底版v1.0在**真实交付树上**就地变异再复原（复原以SHA256核验）。本轮改为
**隔离副本树**：每案例将整包复制至独立临时目录，在副本上变异并实跑完整断言栈
（harness → independent_recompute → build_provenance → assert_check），真实交付树
全程零写入。案例结束后删除副本；末步另核真实树全部文件指纹与开跑前逐位一致
（形式上"复原"退化为"从未触碰"之核验，攻击面更小）。

── 案例集（10例）与其目标击落通道 ────────────────────────────────────
  NC-1  声明-实现不一致（engine.py改SIGN_EPSILON、schema不改）        → A8c
  NC-2  源码变异且不重跑下游产物                                       → pin门拒绝(exit3) ＋ A10b
  NC-3  源码变异且全链重跑（真实计算bug）                              → 计算面 A3/A4〔F-9〕
  NC-4  harness输出注入未声明**顶层键**                                → A7a〔D-2〕
  NC-5  harness输出注入未声明**嵌套层键**（过零事件条目）              → A7d〔D-2嵌套半〕
  NC-6  **M8共模变异**：dte 于被测侧与独立侧同步+30天                  → A11（断言侧第三实现）〔D-7根治，60-C1重放〕
  NC-7  交付脚本注入数据源import＋关键字（守卫式，行为不变）           → step0-ii〔D-1／M6同型〕
  NC-8  钉定件射程被静默收窄（删若干钉定条目）                         → A10a〔D-3〕
  NC-9  scan_patterns.json静默改写＋重跑钉定（洗指纹）                 → step0-ii-b1/b2〔D-4／F-5双钉〕
  NC-10 M1内嵌段被静默改写                                             → A12b〔D-6a／裁决60-A2②〕

F-9满足位＝NC-3（经计算面断言击落，非新鲜度/流水线通道）。
"""

import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(HERE)
RESULTS = []


def _sha256(path):
    with open(path, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()


def _tree_hashes(root):
    out = {}
    for r, dirs, files in os.walk(root):
        dirs[:] = [d for d in dirs if not d.startswith(".") and d != "__pycache__"]
        for fn in files:
            if fn.endswith(".pyc"):
                continue
            p = os.path.join(r, fn)
            out[os.path.relpath(p, root).replace(os.sep, "/")] = _sha256(p)
    return out


def _copy_pkg():
    tmp = tempfile.mkdtemp(prefix="fw03a_nc_")
    dst = os.path.join(tmp, "pkg")
    shutil.copytree(PKG, dst)
    return tmp, dst


def _run(script_rel, cwd):
    r = subprocess.run([sys.executable, script_rel], capture_output=True,
                       text=True, cwd=cwd)
    return r.returncode, (r.stdout or "") + (r.stderr or "")


def _run_chain(dst, rerun_products=True, rerun_pin=True):
    """在副本树上跑断言栈。返回 (provenance_exit, assert_exit, assert_out)。"""
    prov_code = None
    if rerun_products:
        _run("harness.py", os.path.join(dst, "entity"))
        _run("independent_recompute.py", os.path.join(dst, "verify"))
    if rerun_pin:
        prov_code, _ = _run("build_provenance.py", os.path.join(dst, "verify"))
    a_code, a_out = _run("assert_check.py", os.path.join(dst, "verify"))
    return prov_code, a_code, a_out


def _edit(path, old, new, count=1):
    with open(path, "r", encoding="utf-8") as f:
        src = f.read()
    assert old in src, "变异目标未找到：%r @ %s" % (old[:60], path)
    with open(path, "w", encoding="utf-8") as f:
        f.write(src.replace(old, new, count))


def _record(name, ok, detail):
    RESULTS.append((name, ok, detail))
    print("%s  %-46s  %s" % ("PASS" if ok else "FAIL", name, detail))


def _fired(out, tag):
    return ("FAIL %s" % tag) in out


def _fired_any(out, tags):
    return [t for t in tags if _fired(out, t)]


# ---------------------------------------------------------------------------
# 案例
# ---------------------------------------------------------------------------
def nc1():
    tmp, dst = _copy_pkg()
    try:
        _edit(os.path.join(dst, "entity/engine.py"),
              "SIGN_EPSILON = 1e-12", "SIGN_EPSILON = 1e-6")
        _, code, out = _run_chain(dst)
        _record("NC-1_声明实现不一致", code != 0 and _fired(out, "A8c"),
                "exit=%s 击落=%s" % (code, _fired_any(out, ["A8c"])))
    finally:
        shutil.rmtree(tmp)


def nc2():
    tmp, dst = _copy_pkg()
    try:
        _edit(os.path.join(dst, "entity/engine.py"),
              "curvature = (g_plus - 2.0 * g_mid + g_minus) / (h * h)",
              "curvature = (g_plus - 2.0 * g_mid + g_minus) / (h)")
        # 刻意不重跑产物；先试重钉（pin门应拒绝），再跑断言（新鲜度应报警）
        prov_code, _ = _run("build_provenance.py", os.path.join(dst, "verify"))
        a_code, a_out = _run("assert_check.py", os.path.join(dst, "verify"))
        _record("NC-2_变异不重跑", prov_code == 3 and a_code != 0 and _fired(a_out, "A10b"),
                "pin门exit=%s（3＝拒绝重钉）assert exit=%s 击落=%s"
                % (prov_code, a_code, _fired_any(a_out, ["A10b"])))
    finally:
        shutil.rmtree(tmp)


def nc3():
    tmp, dst = _copy_pkg()
    try:
        _edit(os.path.join(dst, "entity/engine.py"),
              "curvature = (g_plus - 2.0 * g_mid + g_minus) / (h * h)",
              "curvature = (g_plus - 2.0 * g_mid + g_minus) / (h)")
        _, code, out = _run_chain(dst)
        hit = _fired_any(out, ["A3-gamma_curvature", "A4-gamma_curvature",
                               "A3-speed", "A4-speed"])
        _record("NC-3_变异全链重跑_计算面击落〔F-9〕",
                code != 0 and len(hit) > 0 and not _fired(out, "A10b"),
                "exit=%s 计算面击落=%s A10b未响=%s"
                % (code, hit, not _fired(out, "A10b")))
    finally:
        shutil.rmtree(tmp)


def nc4():
    tmp, dst = _copy_pkg()
    try:
        _edit(os.path.join(dst, "entity/harness.py"),
              '        "summary": {',
              '        "_undeclared_top_key": "injected",\n        "summary": {')
        _, code, out = _run_chain(dst)
        _record("NC-4_未声明顶层键注入", code != 0 and _fired(out, "A7a"),
                "exit=%s 击落=%s" % (code, _fired_any(out, ["A7a"])))
    finally:
        shutil.rmtree(tmp)


def nc5():
    tmp, dst = _copy_pkg()
    try:
        _edit(os.path.join(dst, "entity/engine.py"),
              '"from_spot": prev_spot, "to_spot": rec["spot"],',
              '"from_spot": prev_spot, "to_spot": rec["spot"],\n'
              '                "_undeclared_nested_key": 1,')
        _, code, out = _run_chain(dst)
        _record("NC-5_未声明嵌套层键注入", code != 0 and _fired(out, "A7d"),
                "exit=%s 击落=%s" % (code, _fired_any(out, ["A7d"])))
    finally:
        shutil.rmtree(tmp)


def nc6():
    tmp, dst = _copy_pkg()
    try:
        # 被测侧（内嵌段内之Rata Die实现）与独立侧（stdlib实现）同步+30天
        _edit(os.path.join(dst, "entity/engine.py"),
              "    return _ord(expiry) - _ord(valuation_date)",
              "    return _ord(expiry) - _ord(valuation_date) + 30")
        _edit(os.path.join(dst, "verify/independent_recompute.py"),
              "    return (e - v).days",
              "    return (e - v).days + 30")
        _, code, out = _run_chain(dst)
        hit = _fired_any(out, ["A11", "A12b"])
        _record("NC-6_M8共模变异〔60-C1重放〕",
                code != 0 and _fired(out, "A11"),
                "exit=%s 击落=%s（A11＝断言侧第三实现，D-7根治之直接实证）" % (code, hit))
    finally:
        shutil.rmtree(tmp)


def nc7():
    tmp, dst = _copy_pkg()
    try:
        pats = json.loads(open(os.path.join(dst, "verify/scan_patterns.json"),
                               encoding="utf-8").read())
        imp_sample = pats["sentinel_positive_samples"]["forbidden_import_regex"]
        kw_sample = pats["forbidden_keyword_regex"][0].replace("\\", "")
        target = os.path.join(dst, "verify/negative_control.py")
        with open(target, "a", encoding="utf-8") as f:
            f.write("\n\ndef _nc7_guarded_unused():\n"
                    "    %s\n"
                    "    _sentinel = \"%s\"\n"
                    "    return _sentinel\n" % (imp_sample, kw_sample))
        _, code, out = _run_chain(dst)
        _record("NC-7_扫描面逃逸变异〔D-1／M6同型〕",
                code != 0 and _fired(out, "step0-ii"),
                "exit=%s 击落=%s（守卫式注入、数值观察面不变，唯扫描面可检）"
                % (code, _fired_any(out, ["step0-ii"])))
    finally:
        shutil.rmtree(tmp)


def nc8():
    tmp, dst = _copy_pkg()
    try:
        p = os.path.join(dst, "verify/build_provenance.json")
        doc = json.loads(open(p, encoding="utf-8").read())
        for k in ["verify/assert_check.py", "verify/negative_control.py",
                  "verify/build_provenance.py"]:
            doc["fingerprints"].pop(k, None)
        with open(p, "w", encoding="utf-8") as f:
            json.dump(doc, f, ensure_ascii=False, indent=2)
        _, code, out = _run_chain(dst, rerun_products=False, rerun_pin=False)
        _record("NC-8_钉定射程静默收窄〔D-3〕", code != 0 and _fired(out, "A10a"),
                "exit=%s 击落=%s" % (code, _fired_any(out, ["A10a", "A10d"])))
    finally:
        shutil.rmtree(tmp)


def nc9():
    tmp, dst = _copy_pkg()
    try:
        p = os.path.join(dst, "verify/scan_patterns.json")
        doc = json.loads(open(p, encoding="utf-8").read())
        doc["forbidden_keyword_regex"] = doc["forbidden_keyword_regex"][:-3]
        with open(p, "w", encoding="utf-8") as f:
            json.dump(doc, f, ensure_ascii=False, indent=2)
        # 攻击者一并重跑钉定以洗掉指纹告警——双钉之声明面半仍应击落
        _, code, out = _run_chain(dst, rerun_products=False, rerun_pin=True)
        hit = _fired_any(out, ["step0-ii-b1", "step0-ii-b2"])
        _record("NC-9_检测器基线静默改写＋洗指纹〔D-4／F-5〕",
                code != 0 and len(hit) > 0,
                "exit=%s 击落=%s（重钉不救：schema声明面为独立第二钉）" % (code, hit))
    finally:
        shutil.rmtree(tmp)


def nc10():
    tmp, dst = _copy_pkg()
    try:
        _edit(os.path.join(dst, "entity/engine.py"),
              "标准正态 CDF；erf 入口。", "标准正态 CDF；erf 入口(改)。")
        _, code, out = _run_chain(dst)
        _record("NC-10_M1内嵌段静默改写〔60-A2②〕",
                code != 0 and _fired(out, "A12b"),
                "exit=%s 击落=%s" % (code, _fired_any(out, ["A12b"])))
    finally:
        shutil.rmtree(tmp)


def main():
    before = _tree_hashes(PKG)

    print("=== 基线核验：真实交付树 assert_check 应clean跑 ===")
    code0, _ = _run("assert_check.py", HERE)
    _record("基线_真实树clean跑", code0 == 0, "exit=%d" % code0)

    for fn in (nc1, nc2, nc3, nc4, nc5, nc6, nc7, nc8, nc9, nc10):
        fn()

    after = _tree_hashes(PKG)
    # assert_check_log.txt 由基线clean跑重写（内容含时间戳），从零写入核验中排除并说明
    ignore = {"verify/assert_check_log.txt", "verify/negative_control_log.txt",
              "verify/fingerprint_table.md"}
    changed = [k for k in set(before) | set(after)
               if k not in ignore and before.get(k) != after.get(k)]
    _record("真实交付树零写入核验", len(changed) == 0,
            "变动件=%s（排除本脚本自身运行所生成之日志与末步指纹表%d项）"
            % (changed, len(ignore)))

    n_pass = sum(1 for _, ok, _ in RESULTS if ok)
    print("\n=== 负向对照汇总：%d/%d 项通过 ===" % (n_pass, len(RESULTS)))
    with open(os.path.join(HERE, "negative_control_log.txt"), "w", encoding="utf-8") as f:
        for name, ok, detail in RESULTS:
            f.write("%s  %s  %s\n" % ("PASS" if ok else "FAIL", name, detail))
        f.write("总计 %d/%d 项通过\n" % (n_pass, len(RESULTS)))

    sys.exit(0 if n_pass == len(RESULTS) else 1)


if __name__ == "__main__":
    main()

"""
FW-03-甲 · 产物新鲜度/来源钉定件生成脚本 · v2.0（续3丙类修复后）

── 本轮变更（外审D-3；判据源＝任务6 v1.9 F-8，自第四批任务包起生效）──────
底版v1.0仅钉5件（engine/input_data/harness_output/independent_recompute/
independent_expected），钉定件自身（build_provenance.py／.json）与
assert_check.py／negative_control.py／harness.py 均在射程之外——攻击者改断言
脚本或钉定脚本本身不留痕。本轮改为：

  钉定射程＝**全包域之 entity/ ＋ verify/ 全部文件**，减去逐条给理由之最小
  排除集（排除集与封闭规则由 entity/input_schema.md §3.3 声明面单一来源提供，
  本脚本解析该声明面，不另写死；assert_check.py 之 A10a 按同一规则重算应钉集
  并与钉定件字段集逐件对表——射程被静默收窄即击落）。

  排除项仅四类，均为"钉定动作之后生成"之严格时序循环（逐条理由见声明面）：
  build_provenance.json（自身）／assert_check_log.txt／negative_control_log.txt／
  fingerprint_table.md。钉定件自身之防篡改由 A10a 重构核证 ＋ §3.3声明面
  承担（F-5双钉同形态：机械重构 ＋ 声明面）。

── pin门（pin-verify gate）───────────────────────────────────────────
钉定前先核既有钉定件：若存在 source 已变而其 product 未变之配对（即"源码已
改、产物未重跑"），本脚本**拒绝重新钉定**并以退出码3终止——防"改源码后直接
重跑钉定脚本以洗白新鲜度告警"之通道（乙-4案例2型攻击在钉定环节即被拒绝，
不进入断言环节）。首次钉定（无既有钉定件）不触发本门。

── 运行位序 ────────────────────────────────────────────────────────
须于 entity/harness.py 与 verify/independent_recompute.py 全部产出之后、
verify/assert_check.py 之前运行。
"""

import hashlib
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(HERE)
OUT_PATH = os.path.join(HERE, "build_provenance.json")

# 派生配对（source → product）：pin门据此判定"源已变、产物未重跑"
DERIVATION_PAIRS = [
    ("entity/engine.py", "entity/harness_output.json"),
    ("entity/harness.py", "entity/harness_output.json"),
    ("entity/input_data.json", "entity/harness_output.json"),
    ("verify/independent_recompute.py", "verify/independent_expected.json"),
    ("entity/input_data.json", "verify/independent_expected.json"),
]


def _sha256(rel):
    with open(os.path.join(PKG, rel), "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()


def _read(path):
    with open(path, "r", encoding="utf-8") as f:
        return f.read()


def _declared_block(schema_text, tag):
    m = re.search(re.escape(tag) + r".*?```json\n(.*?)\n```", schema_text, re.S)
    if not m:
        raise AssertionError("input_schema.md 声明面块未找到：%s" % tag)
    return json.loads(m.group(1))


def walk_pkg():
    found = set()
    for root, dirs, files in os.walk(PKG):
        dirs[:] = [d for d in dirs if not d.startswith(".") and d != "__pycache__"]
        for fn in files:
            if fn.endswith(".pyc"):
                continue
            found.add(os.path.relpath(os.path.join(root, fn), PKG).replace(os.sep, "/"))
    return found


def pin_gate(excluded):
    """pin门：既有钉定件在场时，拒绝"源已变而产物未变"之重新钉定。"""
    if not os.path.exists(OUT_PATH):
        print("pin门：首次钉定，无既有钉定件，放行")
        return
    old = json.loads(_read(OUT_PATH))
    old_fp = old.get("fingerprints", {})
    refuse = []
    for src, prod in DERIVATION_PAIRS:
        if src not in old_fp or prod not in old_fp:
            continue
        src_changed = _sha256(src) != old_fp[src]
        prod_changed = _sha256(prod) != old_fp[prod]
        if src_changed and not prod_changed:
            refuse.append((src, prod))
    if refuse:
        print("pin门拒绝：源码已变而其产物未重跑，禁止重新钉定（洗白通道封堵）")
        for s, p in refuse:
            print("  · %s 已变，但 %s 未随之重生成" % (s, p))
        sys.exit(3)
    print("pin门：%d组派生配对核过，放行" % len(DERIVATION_PAIRS))


def main():
    schema_text = _read(os.path.join(PKG, "entity/input_schema.md"))
    inv = _declared_block(schema_text, "§3.3")
    excluded = set(inv["pin_excluded_paths"])
    closure_rule = inv["pin_closure_rule"]

    pin_gate(excluded)

    domain = sorted(f for f in walk_pkg()
                    if (f.startswith("entity/") or f.startswith("verify/"))
                    and f not in excluded)
    fingerprints = {rel: _sha256(rel) for rel in domain}

    out = {
        "_purpose": ("F-8钉定件：源码-产物SHA256全包域钉定，供assert_check.py之A10组"
                     "新鲜度断言与射程重构核证对表"),
        "closure_rule": closure_rule,
        "pin_excluded_paths": inv["pin_excluded_paths"],
        "derivation_pairs": [{"source": s, "product": p} for s, p in DERIVATION_PAIRS],
        "fingerprints": fingerprints,
    }
    with open(OUT_PATH, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)
    print("钉定完成：%d 件（排除%d件，理由见schema §3.3声明面）"
          % (len(fingerprints), len(excluded)))


if __name__ == "__main__":
    main()

"""
FW-03-甲 · 交付件指纹表程序化产出脚本（外审D-8c根治）

判据源＝裁决39-B3／W-13(14)／W-9(2)：**凡进入合格判定叙述链之表格类制品由随
verify/交付之脚本程序化产出，不得手工誊写**。底版v1.0之《切片记录》14行SHA256
指纹表无随交付脚本产出（verify/内零脚本产出md表格），本脚本为该项之根治。

产出＝verify/fingerprint_table.md：entity/ ＋ verify/ 全部交付件之SHA256表
（markdown表格，可逐字粘入切片记录之"一阶实体文件清单"节）。

排除项一件：verify/fingerprint_table.md 自身（本脚本之产物，自指不可解）——
其内容之核验由"重跑本脚本并diff"承担（幂等：同一交付树重跑逐字节一致）。
包根之呈报文本(.md)不入本表（钉定封闭规则见 entity/input_schema.md §3.3）。

运行位序＝全链末步（harness → independent_recompute → build_provenance →
assert_check → negative_control → 本脚本）。
"""

import hashlib
import os

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(HERE)
OUT = os.path.join(HERE, "fingerprint_table.md")
SELF_EXCLUDED = "verify/fingerprint_table.md"

ROLE = {
    "entity/engine.py": "被测对象本体：M1整文件逐字内嵌段＋FW-03专属双通道逻辑（纯函数）",
    "entity/harness.py": "B段一次性harness：喂入input_data.json→驱动engine.py→捕获→落盘",
    "entity/input_data.json": "A段人造input：单一OTM long put头寸＋往返情景＋channel_config声明",
    "entity/harness_output.json": "C段实跑真数：43步两通道状态序列＋分通道过零事件＋恒正诊断",
    "entity/input_schema.md": "对象语义／双锚定／声明面三块／钉表节／三分判别／H-P-W／装载核证",
    "verify/assert_check.py": "D段断言脚本（step0扫描面＋A1–A13组），失败非零退出码，崩溃安全日志",
    "verify/assert_check_log.txt": "本轮最终clean跑日志",
    "verify/build_provenance.py": "产物新鲜度/来源钉定件生成脚本（全包域射程＋pin门）",
    "verify/build_provenance.json": "全包域源码-产物SHA256钉定件",
    "verify/independent_recompute.py": "独立复算路径：mpmath dps=50 对V原生3阶/4阶数值微分",
    "verify/independent_expected.json": "独立复算期望值钉表：43条两通道记录＋容差/地板声明",
    "verify/negative_control.py": "乙-4负向对照：隔离副本树十案例断言栈实跑",
    "verify/negative_control_log.txt": "负向对照运行日志",
    "verify/scan_patterns.json": "step0(ii)扫描检测器基线（模式数据件，F-5双钉对象）",
    "verify/fingerprint_table.py": "本脚本：指纹表程序化产出（39-B3）",
}


def _sha256(path):
    with open(path, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()


def main():
    rows = []
    for sub in ("entity", "verify"):
        d = os.path.join(PKG, sub)
        for fn in sorted(os.listdir(d)):
            if fn.endswith(".pyc") or os.path.isdir(os.path.join(d, fn)):
                continue
            rel = "%s/%s" % (sub, fn)
            if rel == SELF_EXCLUDED:
                continue
            rows.append((rel, ROLE.get(rel, "（角色未登记——新增件须补登ROLE表）"),
                         _sha256(os.path.join(PKG, rel))))

    lines = ["<!-- 本表由 verify/fingerprint_table.py 程序化产出（39-B3／W-13(14)），",
             "     不得手工誊写；重跑幂等，可逐字粘入切片记录。 -->",
             "",
             "| 文件 | 说明 | SHA256 |",
             "|---|---|---|"]
    for rel, role, h in rows:
        lines.append("| %s | %s | `%s` |" % (rel, role, h))
    lines.append("")
    lines.append("**交付件计数**：%d 件（entity/ %d ＋ verify/ %d；不含本表自身与包根呈报文本）。"
                 % (len(rows),
                    sum(1 for r in rows if r[0].startswith("entity/")),
                    sum(1 for r in rows if r[0].startswith("verify/"))))
    with open(OUT, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    print("指纹表产出完成：%d 行" % len(rows))


if __name__ == "__main__":
    main()

"""
FW-03-甲 · 独立复算路径（verify/）· v2.0（续3丙类修复后）

── 钉表构造顺序留痕（F-10，三处一致之第一处见 verify/assert_check.py 头注）──
本根钉表＝本脚本产出之 independent_expected.json（逐格点期望值表）。构造顺序
＝先立独立复算口径与期望值表、后跑被测侧比对断言：本脚本不读取被测侧任何
产物（engine.py／harness_output.json 均不读），期望值仅由 entity/input_data.json
之人造参数独立推导，故期望值表在逻辑上先于比对成立。F-10已知限制如实标注：
最低形态＝文字声明三处一致，可程序化时序证据非强制，本处为文字声明。

── 计算核心分叉（F-2，非取字段/循环外壳分叉）──────────────────────────
被测侧（entity/engine.py）＝M1闭式Gamma解析公式 ＋ 同一组3点(S−h,S,S+h)
之低阶有限差分（bump_ratio=0.001）间接得两通道。
独立侧（本脚本）＝对期权价值函数V(S)本身，用mpmath高精度（dps=50）原生高阶
数值微分直接取得：
    ∂Γ/∂S      ＝ d³V/dS³   （mpmath.diff(f, S, n=3)）
    ∂²Γ/∂S²    ＝ d⁴V/dS⁴   （mpmath.diff(f, S, n=4)）
（按求导阶数可交换性）。零解析Gamma公式、零复用被测侧差分步长与差分格式。
两侧在"是否由闭式Gamma出发"与"差分阶数/步长选择"两层均不共享。

── 日期换算之独立实现（续3 D-7根治，F-2零重写复制禁令）──────────────────
底版v1.0之 `_dte_days` 在被测侧／独立侧／断言侧**三处逐字复制**（同一
Rata Die整数公式），构成零重写复制、不计分叉——外审侧共模变异M8（两侧同步
+30天）逃逸全部22项断言即其实证。本轮根治：三处各自独立实现，失效模式不共享。
  · 被测侧（entity/engine.py 内嵌段）：M1原文之 Rata Die 整数公式（不改动，
    内嵌段零改动纪律）。
  · 独立侧（本脚本）：Python标准库 datetime.date 之公历实现（toordinal），
    与Rata Die手写公式为不同代码路径、不同失效模式。
  · 断言侧（verify/assert_check.py）：第三实现＝闰年规则＋逐月累计天数表
    直接累加，见该脚本 `_days_from_civil_table`。
三实现之比对在 assert_check.py A11组施加（零容差整数相等），共模变异须同时
攻破三处方能逃逸。

── 容差性质声明（本根裁定登记#7；裁决60-A3沉淀条款措辞对齐）──────────────
沉淀条款（裁决60-A3）：**被测量本身为声明离散近似时，裁决13/19(a)/(b)不强套，
容差框架＝离散不变量零容差 ＋ 量级诊断（界值逐对象登记）。**
本根适用该框架：被测侧两通道均为 bump_ratio 声明下之有限差分近似量（含O(h²)
固有截断偏置），非对精确数学量之两条无偏置路径比对，故13/19(a)(b)不套用。
本根两条判据：
  ①离散不变量零容差（主判据）：两侧**符号**在全部格点逐一相等（两通道各自
    独立核验）。符号为该离散量之不变量，不随截断偏置改变。
  ②量级诊断（辅助，非主判据）：相对误差须落在**逐通道独立标定**之界内
    （裁决60-A1b：speed通道之界须按三阶导截断量级独立标定并登记，禁沿用
    curvature通道之0.01）。界值与标定依据见 entity/input_schema.md §3.1／§4。

── 数据源独立 ────────────────────────────────────────────────────
只读 entity/input_data.json（position/scenario原始参数），不触碰被测侧任何
产物（harness_output.json／engine.py 均不读取），亦不读取本脚本自身既往产物
（F-8后半：独立复算脚本不得读取自身既往产物）。
"""

import datetime
import json
import mpmath

mpmath.mp.dps = 50

# 量级诊断界（逐通道独立，本根裁定登记#6；标定依据见 input_schema.md §3.1）
MAGNITUDE_TOLERANCE_REL_SPEED = 0.002
MAGNITUDE_TOLERANCE_REL_CURVATURE = 0.01
# 相对/绝对判据切换地板（逐通道，声明面成文；|真值|<地板时改用绝对判据
# abs_tol = rel_tol × floor，保证两判据在地板处连续、不留静默跳过点）
MAGNITUDE_FLOOR_SPEED = 1e-6
MAGNITUDE_FLOOR_CURVATURE = 1e-6

DAY_COUNT_DENOMINATOR_DECLARED = 365


def _dte_days_stdlib(expiry, valuation_date):
    """独立实现之一（本脚本侧）：标准库 datetime.date 公历序日之差。
    与被测侧手写 Rata Die 公式为不同代码路径（D-7根治，F-2独立分叉）。"""
    e = datetime.date(*(int(x) for x in expiry.split("-")))
    v = datetime.date(*(int(x) for x in valuation_date.split("-")))
    return (e - v).days


def _V_put_mp(S, K, r, q, sig, T):
    """欧式put之BS-q闭式价值（mpmath高精度），仅作高阶数值微分之入口函数；
    本脚本不从该式解析导出Gamma——直接对V做3阶/4阶数值微分。"""
    S = mpmath.mpf(S); K = mpmath.mpf(K); r = mpmath.mpf(r)
    q = mpmath.mpf(q); sig = mpmath.mpf(sig); T = mpmath.mpf(T)
    sqrtT = mpmath.sqrt(T)
    d1 = (mpmath.log(S / K) + (r - q + mpmath.mpf("0.5") * sig * sig) * T) / (sig * sqrtT)
    d2 = d1 - sig * sqrtT
    return (K * mpmath.e ** (-r * T) * mpmath.ncdf(-d2)
            - S * mpmath.e ** (-q * T) * mpmath.ncdf(-d1))


def _adverse_sign(adverse_direction):
    """独立实现之取号映射（不import被测模块）。"""
    table = {"spot_down": -1, "spot_up": 1}
    if adverse_direction not in table:
        raise ValueError("adverse_direction 越出已声明值域: %r" % (adverse_direction,))
    return table[adverse_direction]


def independent_channels(position, spot, valuation_date, adverse_sign):
    """独立路径下两通道之真值（per_lot，含scale）。"""
    K = position["strike"]; r = position["risk_free_rate"]
    sig = position["implied_vol"]; q = position["dividend_yield"]
    expiry = position["expiry"]
    scale = (int(position["multiplier"]) * int(position["quantity"])
             * (1 if position["side"] == "long" else -1))
    dte = _dte_days_stdlib(expiry, valuation_date)
    T = dte / float(DAY_COUNT_DENOMINATOR_DECLARED)

    f = lambda s: _V_put_mp(s, K, r, q, sig, T)
    d3 = float(mpmath.diff(f, mpmath.mpf(spot), n=3)) * scale
    d4 = float(mpmath.diff(f, mpmath.mpf(spot), n=4)) * scale
    return dte, d3, d3 * adverse_sign, d4


def _sign(v, eps=1e-12):
    return 1 if v > eps else (-1 if v < -eps else 0)


def main():
    with open("../entity/input_data.json", "r", encoding="utf-8") as fh:
        doc = json.load(fh)
    position = doc["position"]
    scenario = doc["scenario"]
    adverse_direction = doc["channel_config"]["adverse_direction"]
    adv = _adverse_sign(adverse_direction)

    records = []
    for step in scenario:
        S = step["spot"]; vd = step["valuation_date"]; t = step["t"]
        dte, d3, d3_adv, d4 = independent_channels(position, S, vd, adv)
        records.append({
            "t": t, "spot": S, "valuation_date": vd,
            "independent_dte_days": dte,
            "independent_speed_raw": d3,
            "independent_speed_adverse": d3_adv,
            "independent_speed_sign": _sign(d3_adv),
            "independent_gamma_curvature": d4,
            "independent_curvature_sign": _sign(d4),
        })

    out = {
        "_method": ("mpmath dps=50; d^3V/dS^3 and d^4V/dS^4 native numerical "
                    "differentiation; zero closed-form Gamma reuse; zero shared "
                    "bump/step with engine.py; dte via stdlib datetime "
                    "(independent of engine-side Rata Die formula)"),
        "_pin_order_note": ("F-10：本表为期望值钉表，构造顺序＝先立独立口径与期望值、"
                            "后跑比对断言；本脚本零读被测侧产物与自身既往产物（F-8）。"),
        "adverse_direction": adverse_direction,
        "day_count_denominator": DAY_COUNT_DENOMINATOR_DECLARED,
        "magnitude_tolerance_rel_speed": MAGNITUDE_TOLERANCE_REL_SPEED,
        "magnitude_tolerance_rel_curvature": MAGNITUDE_TOLERANCE_REL_CURVATURE,
        "magnitude_floor_speed": MAGNITUDE_FLOOR_SPEED,
        "magnitude_floor_curvature": MAGNITUDE_FLOOR_CURVATURE,
        "records": records,
    }
    with open("independent_expected.json", "w", encoding="utf-8") as fh:
        json.dump(out, fh, ensure_ascii=False, indent=2)
    print("独立复算完成：%d 条记录（两通道）" % len(records))


if __name__ == "__main__":
    main()

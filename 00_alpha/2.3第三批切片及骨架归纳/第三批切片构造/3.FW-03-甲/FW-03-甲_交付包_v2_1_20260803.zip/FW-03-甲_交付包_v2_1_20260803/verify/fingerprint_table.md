<!-- 本表由 verify/fingerprint_table.py 程序化产出（39-B3／W-13(14)），
     不得手工誊写；重跑幂等，可逐字粘入切片记录。 -->

| 文件 | 说明 | SHA256 |
|---|---|---|
| entity/engine.py | 被测对象本体：M1整文件逐字内嵌段＋FW-03专属双通道逻辑（纯函数） | `8c08df7067cc3d76f683f938e12ee723ddf1acf2611b0f18e5a6523f48184225` |
| entity/harness.py | B段一次性harness：喂入input_data.json→驱动engine.py→捕获→落盘 | `6e274484e7359d152505adbbbac059038109911d3573237c78608b06dec48bab` |
| entity/harness_output.json | C段实跑真数：43步两通道状态序列＋分通道过零事件＋恒正诊断 | `a08069e48052dba3038a6353f017f3ebf468088c0527c6b3de092fe73f709087` |
| entity/input_data.json | A段人造input：单一OTM long put头寸＋往返情景＋channel_config声明 | `75892829af47440bf38fcd4073a332f81b7c3e0049d44a3c0a0f75100b91cd9e` |
| entity/input_schema.md | 对象语义／双锚定／声明面三块／钉表节／三分判别／H-P-W／装载核证 | `08e61c5380e547e14f1308ba1578535b45781d57c452043239c41f8c9a722506` |
| verify/assert_check.py | D段断言脚本（step0扫描面＋A1–A13组），失败非零退出码，崩溃安全日志 | `66f15daf7829f8a1e96d31a0a47b211a6b94ed534686ca6f016dfb4cf63edf65` |
| verify/assert_check_log.txt | 本轮最终clean跑日志 | `c2f2123009a06ec60a55de8601f981e6520ed6189123235aa596add712e23c1b` |
| verify/build_provenance.json | 全包域源码-产物SHA256钉定件 | `3a13d4f7899e74a83ae71bc2db6a06ca4f8744049cc42b3bbbcde088b38e78ad` |
| verify/build_provenance.py | 产物新鲜度/来源钉定件生成脚本（全包域射程＋pin门） | `939343eb94fa607f3f5e6780fc54deb35c6d4cb1c7a6929f9990d3c269f90e4c` |
| verify/fingerprint_table.py | 本脚本：指纹表程序化产出（39-B3） | `aef64cc7e7dfc00230b8706257dbb9bc889bfff24e3fdf6ba072493df2efdaef` |
| verify/independent_expected.json | 独立复算期望值钉表：43条两通道记录＋容差/地板声明 | `34810d5e9be4c23d43e920050e32bcae76139b005f60f5370dc42fb61a4dc5e9` |
| verify/independent_recompute.py | 独立复算路径：mpmath dps=50 对V原生3阶/4阶数值微分 | `ee34acd663bd6d2e577f4b618d99449a2858c37436229491a8091fd42d931efa` |
| verify/negative_control.py | 乙-4负向对照：隔离副本树十案例断言栈实跑 | `7ebebad556ca030c3897efe73e172a3ae0aded10d3c299cb2deedb42e8ea879b` |
| verify/negative_control_log.txt | 负向对照运行日志 | `adb27c0a14c460df62464a6436e536a48345e7315c117a246a3662adbae6d752` |
| verify/scan_patterns.json | step0(ii)扫描检测器基线（模式数据件，F-5双钉对象） | `0b724740efea58724382fbe39120be6692b5f2eb2e22a39d9d5259bab8b6cb14` |

**交付件计数**：15 件（entity/ 5 ＋ verify/ 10；不含本表自身与包根呈报文本）。

#!/usr/bin/env python3
"""
TC-33 · verify/assert_check.py · 合格断言脚本
三步顺序：step0 前置合规 -> 数值逐项比对 -> 附加断言。任一环节不满足即整体判不合格。
容差口径：裁决13子口径(a) 离散/精确有理计算 = 0（bit-exact），本根全程整数运算适用。
"""
import json
import re

RESULT = {"step0": {}, "compare": {}, "extra": {}, "verdict": None}


def strip_comments_and_docstrings(src):
    """剥离三引号docstring与#单行注释，避免"合规声明文本本身提及禁用词"造成误报。
    （step0(ii)/(iii) 首次naive扫描曾对本文件的合规声明docstring产生假阳性，见切片记录留痕）"""
    no_docstrings = re.sub(r'("""|\'\'\')(.*?)\1', '', src, flags=re.DOTALL)
    no_comments = re.sub(r'#.*', '', no_docstrings)
    return no_comments


def step0():
    ok = True
    reasons = []

    # (i) input 确为人造构造
    with open("entity/input_paths.json", "r", encoding="utf-8") as f:
        input_data = json.load(f)
    is_synthetic = input_data.get("_data_source") == "synthetic_hand_constructed"
    RESULT["step0"]["i_input_synthetic"] = is_synthetic
    ok &= is_synthetic
    if not is_synthetic:
        reasons.append("input _data_source 标记缺失或不为 synthetic_hand_constructed")

    # (ii) harness 全程无数据源接入（静态扫描源码，检出即失败）
    with open("entity/harness.py", "r", encoding="utf-8") as f:
        harness_src_raw = f.read()
    harness_src = strip_comments_and_docstrings(harness_src_raw)
    forbidden = [
        r"\bibkr\b", r"\bibapi\b", r"ib_insync",
        r"quantconnect", r"\bqc\b\.", r"QCAlgorithm",
        r"requests\.", r"urllib", r"socket\.", r"http://", r"https://",
        r"\.csv\b", r"read_csv", r"yfinance", r"pandas_datareader",
    ]
    hits = [pat for pat in forbidden if re.search(pat, harness_src, re.IGNORECASE)]
    no_data_source = len(hits) == 0
    RESULT["step0"]["ii_harness_no_datasource"] = no_data_source
    RESULT["step0"]["ii_scan_hits"] = hits
    ok &= no_data_source
    if not no_data_source:
        reasons.append(f"harness.py 检出疑似数据源接入模式: {hits}")

    # (iii) 独立复算不 import harness、不读 harness_output.json
    with open("verify/independent_recompute.py", "r", encoding="utf-8") as f:
        verify_src_raw = f.read()
    verify_src = strip_comments_and_docstrings(verify_src_raw)
    no_import_harness = ("import harness" not in verify_src) and ("from harness" not in verify_src)
    no_read_harness_output = "harness_output" not in verify_src
    independent_ok = no_import_harness and no_read_harness_output
    RESULT["step0"]["iii_independent_no_harness_coupling"] = independent_ok
    ok &= independent_ok
    if not independent_ok:
        reasons.append("独立复算脚本疑似耦合 harness 实现或读取 harness 中间量")

    RESULT["step0"]["pass"] = ok
    RESULT["step0"]["reasons"] = reasons
    return ok


def compare():
    with open("entity/harness_output.json", "r", encoding="utf-8") as f:
        harness_out = json.load(f)
    with open("verify/independent_output.json", "r", encoding="utf-8") as f:
        indep_out = json.load(f)

    h_map = {p["path_id"]: p["path_pnl"] for p in harness_out["per_path"]}
    i_map = {p["path_id"]: p["path_pnl"] for p in indep_out["per_path"]}

    rows = []
    all_within = True
    for pid in h_map:
        hv, iv = h_map[pid], i_map[pid]
        diff = hv - iv
        within = (diff == 0)  # 裁决13子口径(a)：bit-exact
        all_within &= within
        rows.append({"path_id": pid, "harness": hv, "independent": iv, "diff": diff, "within_tol": within})

    worst_h = harness_out["worst"]["value"]
    worst_i = indep_out["worst"]["value"]
    worst_diff = worst_h - worst_i
    worst_within = (worst_diff == 0)
    all_within &= worst_within
    rows.append({"path_id": "WORST", "harness": worst_h, "independent": worst_i,
                 "diff": worst_diff, "within_tol": worst_within})

    RESULT["compare"]["tolerance_regime"] = "裁决13子口径(a)：离散/精确有理计算，0（bit-exact）"
    RESULT["compare"]["rows"] = rows
    RESULT["compare"]["all_within_tolerance"] = all_within
    return all_within


def extra_assertions():
    with open("entity/input_paths.json", "r", encoding="utf-8") as f:
        input_data = json.load(f)
    with open("entity/harness_output.json", "r", encoding="utf-8") as f:
        harness_out = json.load(f)

    n_paths_in = len(input_data["paths"])
    n_pnl_out = len(harness_out["per_path"])
    assert1 = (n_paths_in == n_pnl_out)

    pnl_values = [p["path_pnl"] for p in harness_out["per_path"]]
    worst_value = harness_out["worst"]["value"]
    assert2 = (worst_value in pnl_values) and (worst_value == min(pnl_values))

    assert3 = all(isinstance(p["path_pnl"], int) for p in harness_out["per_path"]) \
        and isinstance(worst_value, int)

    RESULT["extra"]["assert1_path_count_matches_output_count"] = assert1
    RESULT["extra"]["assert1_detail"] = {"n_paths_in": n_paths_in, "n_pnl_out": n_pnl_out}
    RESULT["extra"]["assert2_worst_in_set_and_is_extremum"] = assert2
    RESULT["extra"]["assert3_shape_complete_scalar_per_path_and_worst_scalar"] = assert3

    return assert1 and assert2 and assert3


def main():
    s0 = step0()
    if not s0:
        RESULT["verdict"] = "不合格（step0前置合规未通过）"
        print(json.dumps(RESULT, ensure_ascii=False, indent=2))
        return

    cmp_ok = compare()
    extra_ok = extra_assertions()

    RESULT["verdict"] = "合格" if (cmp_ok and extra_ok) else "不合格"
    print(json.dumps(RESULT, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

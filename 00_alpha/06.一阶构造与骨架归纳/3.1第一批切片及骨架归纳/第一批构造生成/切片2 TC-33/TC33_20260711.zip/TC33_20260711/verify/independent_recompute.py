#!/usr/bin/env python3
"""
TC-33 · verify/independent_recompute.py · 独立复算脚本
路径独立性声明：
  - 数据源独立：直读 entity/input_paths.json（clean 人造 input），不 import entity/harness.py，
    不读取 entity/harness_output.json 的任何中间量或最终量。
  - 计算核心分叉：hedge 判定用 numpy 向量化布尔比较（np.greater_equal）替代 harness 的逐步
    Python if 判断；区间差分用 np.diff 替代 harness 的逐步减法；hedge P&L 累加用 np.dot
    替代 harness 的 Python for 累加；payoff 用 np.maximum 替代 harness 的内建 max()；
    worst 用 np.min 对本脚本独立算出的 P/L 数组取值，不读 harness 的 worst 字段。
  - 全程整数运算（numpy int64），无浮点舍入，适用裁决13子口径(a) bit-exact。
"""
import json
import numpy as np

INPUT_PATH = "entity/input_paths.json"


def recompute_path_pnl_vectorized(K, M, premium_total, prices):
    S = np.array(prices, dtype=np.int64)
    h = np.greater_equal(S[:-1], K).astype(np.int64)          # 向量化阈值判定，非harness的if
    diffs = np.diff(S)                                         # np.diff替代逐步相减
    hedge_pnl = int(np.dot(h * M, diffs))                       # 点积累加替代for累加
    expiry_payoff = int(np.maximum(S[-1] - K, 0) * M)           # np.maximum替代max()
    path_pnl = hedge_pnl + premium_total - expiry_payoff
    return hedge_pnl, expiry_payoff, path_pnl


def main():
    with open(INPUT_PATH, "r", encoding="utf-8") as f:
        data = json.load(f)

    assert data["_data_source"] == "synthetic_hand_constructed"

    pos = data["position"]
    K = pos["strike"]
    M = pos["multiplier"]
    premium_total = pos["premium_per_share"] * M

    per_path = []
    pnl_array = []
    for path in data["paths"]:
        hedge_pnl, expiry_payoff, path_pnl = recompute_path_pnl_vectorized(
            K, M, premium_total, path["prices"]
        )
        per_path.append({
            "path_id": path["path_id"],
            "hedge_pnl": hedge_pnl,
            "expiry_payoff": expiry_payoff,
            "premium_total": premium_total,
            "path_pnl": path_pnl,
        })
        pnl_array.append(path_pnl)

    pnl_array = np.array(pnl_array, dtype=np.int64)
    worst_value = int(np.min(pnl_array))                        # 独立取确界，不读harness worst
    worst_path_id = [
        p["path_id"] for p, v in zip(per_path, pnl_array) if v == worst_value
    ][0]

    result = {
        "per_path": per_path,
        "worst": {"value": worst_value, "path_id": worst_path_id},
        "path_count": len(per_path),
    }

    with open("verify/independent_output.json", "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)

    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""
TC-33 · entity/harness.py · 一次性夹具
职责：喂入 entity/input_paths.json，逐路径计算 hedge P&L + expiry payoff + path P&L，
      取路径集合上的 worst（最小值），写出 entity/harness_output.json。
强制约束：不接任何数据源（IBKR/QuantConnect/历史行情/实时行情/文件数据源）；
          input 直接来自本地人造 JSON 文件；不建常设 pipeline，单次执行即完。
"""
import json

INPUT_PATH = "entity/input_paths.json"
OUTPUT_PATH = "entity/harness_output.json"


def compute_path_pnl(position, prices):
    """逐路径计算：hedge P&L 累加 + 期末payoff + 权利金 -> path P&L"""
    K = position["strike"]
    M = position["multiplier"]
    premium_total = position["premium_per_share"] * M

    hedge_pnl = 0
    for t in range(len(prices) - 1):
        h_t = 1 if prices[t] >= K else 0
        hedge_pnl += h_t * M * (prices[t + 1] - prices[t])

    S_T = prices[-1]
    expiry_payoff = max(S_T - K, 0) * M

    path_pnl = hedge_pnl + premium_total - expiry_payoff
    return {
        "hedge_pnl": hedge_pnl,
        "expiry_payoff": expiry_payoff,
        "premium_total": premium_total,
        "path_pnl": path_pnl,
    }


def main():
    with open(INPUT_PATH, "r", encoding="utf-8") as f:
        data = json.load(f)

    assert data["_data_source"] == "synthetic_hand_constructed"

    position = data["position"]
    results = []
    for path in data["paths"]:
        r = compute_path_pnl(position, path["prices"])
        results.append({
            "path_id": path["path_id"],
            "prices": path["prices"],
            **r,
        })

    pnl_values = [r["path_pnl"] for r in results]
    worst_value = min(pnl_values)
    worst_path_id = [r["path_id"] for r in results if r["path_pnl"] == worst_value][0]

    output = {
        "per_path": results,
        "worst": {
            "value": worst_value,
            "path_id": worst_path_id,
        },
        "path_count": len(results),
    }

    with open(OUTPUT_PATH, "w", encoding="utf-8") as f:
        json.dump(output, f, ensure_ascii=False, indent=2)

    print(json.dumps(output, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

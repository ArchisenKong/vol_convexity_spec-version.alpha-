#!/usr/bin/env python3
"""T3-22 增量复核 · B-4 攻击层重放（A系列＋复核侧自增强化变体）"""
import json, os, shutil, subprocess, sys

SRC = "/home/claude/work/v11"
ARENA = "/home/claude/atk"
PY = sys.executable
res = []


def tree(name):
    d = os.path.join(ARENA, name)
    if os.path.exists(d):
        shutil.rmtree(d)
    shutil.copytree(SRC, d)
    return d


def run(d, s):
    return subprocess.run([PY, s], cwd=d, capture_output=True, text=True)


def edit(d, f, old, new):
    p = os.path.join(d, f)
    s = open(p, encoding="utf-8").read()
    assert s.count(old) == 1, f"{f}: 命中{s.count(old)}"
    open(p, "w", encoding="utf-8").write(s.replace(old, new, 1))


def first_fail(d):
    p = os.path.join(d, "verify/assert_log.txt")
    if not os.path.exists(p):
        return "(无assert_log.txt)"
    for line in open(p, encoding="utf-8"):
        if line.startswith("FAIL:"):
            return line.strip()[:150]
    return "(日志无FAIL行)"


def record(aid, desc, rc, d):
    res.append((aid, desc, rc, "击落" if rc != 0 else "逃逸", first_fail(d) if rc != 0 else "—"))
    print(f"{aid:6} exit={rc} {'击落' if rc!=0 else '逃逸'}  {res[-1][4][:95]}")


# A1 · 改harness不重跑（沿用交付产物）
d = tree("A1")
edit(d, "entity/harness.py", "elif moneyness > high:", "elif moneyness >= high:")
edit(d, "entity/harness.py", 'str(abs(moneyness - F(entry["moneyness"])))', 'str(moneyness - F(entry["moneyness"]))')
record("A1", "改harness两处但不重跑harness（陈旧产物）", run(d, "verify/assert_check.py").returncode, d)

# A2 · 伪造independent_output.json + 空壳化独立复算（外审原形态：空壳无真实推导）
d = tree("A2")
run(d, "entity/harness.py")
h = json.load(open(os.path.join(d, "entity/harness_output.json"), encoding="utf-8"))
forged = {
    "put_wing_derived": [{k: v for k, v in r.items() if k in
        ("period", "tail_coverage_band_position", "moneyness_drift", "time_decay_fraction",
         "skew_change", "liquidity_deterioration", "premium_bleed_integrity_check")}
        for r in h["wings"]["put_wing"]["periods"]],
    "call_wing_derived": [{k: v for k, v in r.items() if k in
        ("period", "tail_coverage_band_position", "upside_convexity_reading",
         "wing_presence_status", "premium_bleed_integrity_check")}
        for r in h["wings"]["call_wing"]["periods"]],
}
json.dump(forged, open(os.path.join(d, "verify/independent_output.json"), "w", encoding="utf-8"),
          ensure_ascii=False, indent=2)
open(os.path.join(d, "verify/independent_recompute.py"), "w", encoding="utf-8").write(
    '"""空壳：零独立推导。"""\n\n\ndef run(input_path="entity/input_data.json"):\n    return {"put_wing_derived": [], "call_wing_derived": []}\n')
record("A2", "伪造independent_output.json＋空壳化独立复算（外审原形态）", run(d, "verify/assert_check.py").returncode, d)

# A2' · 自增强化：空壳自读自身产物返回（新鲜度自洽），harness未变异
d = tree("A2p")
run(d, "entity/harness.py")
json.dump(forged, open(os.path.join(d, "verify/independent_output.json"), "w", encoding="utf-8"),
          ensure_ascii=False, indent=2)
open(os.path.join(d, "verify/independent_recompute.py"), "w", encoding="utf-8").write(
    '"""空壳强化版：自读既有产物返回，使新鲜度比对自洽。零独立推导。"""\nimport json\n\n\n'
    'def run(input_path="entity/input_data.json"):\n'
    '    with open("verify/independent_output.json", encoding="utf-8") as f:\n'
    '        return json.load(f)\n')
record("A2'", "自增：空壳自读自身产物（新鲜度自洽）＋harness未变异", run(d, "verify/assert_check.py").returncode, d)

# A2'' · 自增强化：A2' + harness变异并重跑（测钉表是否为第二道防线）
d = tree("A2pp")
edit(d, "entity/harness.py", 'str(abs(moneyness - F(entry["moneyness"])))', 'str(moneyness - F(entry["moneyness"]))')
run(d, "entity/harness.py")
h2 = json.load(open(os.path.join(d, "entity/harness_output.json"), encoding="utf-8"))
forged2 = {
    "put_wing_derived": [{k: v for k, v in r.items() if k in
        ("period", "tail_coverage_band_position", "moneyness_drift", "time_decay_fraction",
         "skew_change", "liquidity_deterioration", "premium_bleed_integrity_check")}
        for r in h2["wings"]["put_wing"]["periods"]],
    "call_wing_derived": [{k: v for k, v in r.items() if k in
        ("period", "tail_coverage_band_position", "upside_convexity_reading",
         "wing_presence_status", "premium_bleed_integrity_check")}
        for r in h2["wings"]["call_wing"]["periods"]],
}
json.dump(forged2, open(os.path.join(d, "verify/independent_output.json"), "w", encoding="utf-8"),
          ensure_ascii=False, indent=2)
open(os.path.join(d, "verify/independent_recompute.py"), "w", encoding="utf-8").write(
    '"""空壳强化版：自读既有产物返回。"""\nimport json\n\n\n'
    'def run(input_path="entity/input_data.json"):\n'
    '    with open("verify/independent_output.json", encoding="utf-8") as f:\n'
    '        return json.load(f)\n')
record("A2''", "自增：空壳自洽＋harness变异重跑＋伪造产物同步（测钉表第二道防线）",
       run(d, "verify/assert_check.py").returncode, d)

# A3 · 源文路径不可达
d = tree("A3")
edit(d, "verify/assert_check.py", 'SOURCE_PATH = "/mnt/project/', 'SOURCE_PATH = "/mnt/project/__unreachable__/')
run(d, "entity/harness.py"); run(d, "verify/independent_recompute.py")
record("A3", "源文路径不可达（测禁静默回退内嵌副本）", run(d, "verify/assert_check.py").returncode, d)

# A4 · 删除 negative_control.py
d = tree("A4")
os.remove(os.path.join(d, "verify/negative_control.py"))
run(d, "entity/harness.py"); run(d, "verify/independent_recompute.py")
record("A4", "删除verify/negative_control.py（F-1完备性缺项）", run(d, "verify/assert_check.py").returncode, d)

# A5 · 新增未声明脚本 entity/extra_helper.py（含 import socket）
d = tree("A5")
open(os.path.join(d, "entity/extra_helper.py"), "w", encoding="utf-8").write(
    "import socket\n\n\ndef host():\n    return socket.gethostname()\n")
run(d, "entity/harness.py"); run(d, "verify/independent_recompute.py")
record("A5", "新增未声明脚本 entity/extra_helper.py（含import socket）", run(d, "verify/assert_check.py").returncode, d)

# A5' · 自增：未声明脚本置于包根（entity/、verify/之外），由harness导入
d = tree("A5p")
open(os.path.join(d, "extra_helper.py"), "w", encoding="utf-8").write(
    "import socket\n\n\ndef host():\n    return socket.gethostname()\n")
edit(d, "entity/harness.py", "import json\nfrom fractions import Fraction as F",
     "import json\nimport sys\nsys.path.insert(0, '.')\nimport extra_helper  # noqa\nfrom fractions import Fraction as F")
run(d, "entity/harness.py"); run(d, "verify/independent_recompute.py")
record("A5'", "自增：未声明脚本置于包根（非entity//verify/下）并被harness导入", run(d, "verify/assert_check.py").returncode, d)

json.dump([{"id": a, "desc": b, "exit": c, "verdict": v, "attrib": f} for a, b, c, v, f in res],
          open("/home/claude/attack_result.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)

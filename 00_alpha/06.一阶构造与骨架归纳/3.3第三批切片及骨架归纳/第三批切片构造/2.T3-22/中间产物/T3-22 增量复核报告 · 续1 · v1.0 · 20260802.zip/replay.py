#!/usr/bin/env python3
"""T3-22 增量复核 · B-4 重放夹具（校验侧独立编写，不复用施工侧任何脚本）

判据：assert_check.py 退出码非零 ＝ 击落；exit 0 ＝ 逃逸。
可观察性（A-2/38-3）：变异后 harness_output + independent_output 与基线全同 ＝ 不可观察，剔除分母。
"""
import json, os, shutil, subprocess, sys, hashlib

SRC = "/home/claude/work/v11"
ARENA = "/home/claude/arena"
PY = sys.executable

H = "entity/harness.py"
I = "verify/independent_recompute.py"

# ---------------- 变异定义 ----------------
# 每项: (id, 类别, 描述, [(file, old, new), ...], 选项dict)

BAND_BLOCK_H = '''    if moneyness < low:
        return "below"
    elif moneyness > high:
        return "above"
    else:
        return "within"'''

BAND_LOW_ASSIGN = '''    put_low = F(put_wing["declared_basis"]["target_activation_band_low"])
    put_high = F(put_wing["declared_basis"]["target_activation_band_high"])
    call_low = F(call_wing["declared_basis"]["target_activation_band_low"])
    call_high = F(call_wing["declared_basis"]["target_activation_band_high"])'''
BAND_SWAP = '''    put_low = F(call_wing["declared_basis"]["target_activation_band_low"])
    put_high = F(call_wing["declared_basis"]["target_activation_band_high"])
    call_low = F(put_wing["declared_basis"]["target_activation_band_low"])
    call_high = F(put_wing["declared_basis"]["target_activation_band_high"])'''

PUT_ASSIGN_BLOCK = '''    put_bleed_flags = bleed_integrity_check(put_wing["periods"])
    for i, flag in enumerate(put_bleed_flags):
        put_out_periods[i]["premium_bleed_integrity_check"] = flag'''

CALL_RET = '''    out["upside_convexity_reading"] = str(F(rec["raw_gamma"]))
    return out'''

MUT = [
 # ---- 单侧（注入 entity/harness.py）----
 ("M01","单侧","band高端 > -> >=",[(H,"elif moneyness > high:","elif moneyness >= high:")]),
 ("M02","单侧","band低端 < -> <=",[(H,"if moneyness < low:","if moneyness <= low:")]),
 ("M03","单侧","band below/above 返回值互换",[(H,BAND_BLOCK_H,BAND_BLOCK_H.replace('"below"','"@@"').replace('"above"','"below"').replace('"@@"','"above"'))]),
 ("M04","单侧","band恒返回within",[(H,BAND_BLOCK_H,'    return "within"')]),
 ("M05","单侧","moneyness_drift去abs",[(H,'str(abs(moneyness - F(entry["moneyness"])))','str(moneyness - F(entry["moneyness"]))')]),
 ("M06","单侧","time_decay分母改当期dte",[(H,'F(entry["dte_remaining"] - rec["dte_remaining"], entry["dte_remaining"])','F(entry["dte_remaining"] - rec["dte_remaining"], rec["dte_remaining"])')]),
 ("M07","单侧","skew_change符号翻转",[(H,'str(F(rec["skew_reading"]) - F(entry["skew_reading"]))','str(F(entry["skew_reading"]) - F(rec["skew_reading"]))')]),
 ("M08","单侧","liquidity取错字段(skew)",[(H,'F(rec["liquidity_reading"]) - F(entry["liquidity_reading"])','F(rec["skew_reading"]) - F(entry["skew_reading"])')]),
 ("M09","单侧","Q5去 and not_downgraded",[(H,"bool(non_decreasing and not_downgraded)","bool(non_decreasing)")]),
 ("M10","单侧","Q5单调 >= -> >",[(H,"non_decreasing = booked >= prev","non_decreasing = booked > prev")]),
 ("M11","单侧","Q5初值prev 0 -> -1",[(H,"    prev = F(0)\n    for rec in periods:","    prev = F(-1)\n    for rec in periods:")]),
 ("M12","单侧","upside_convexity取raw_vega",[(H,'out["upside_convexity_reading"] = str(F(rec["raw_gamma"]))','out["upside_convexity_reading"] = str(F(rec["raw_vega"]))')]),
 ("M13","单侧","put entry基准取t2",[(H,'put_entry = put_wing["periods"][0]','put_entry = put_wing["periods"][1]')]),
 ("M14","单侧","wing_presence_status覆写present",[(H,CALL_RET,'    out["upside_convexity_reading"] = str(F(rec["raw_gamma"]))\n    out["wing_presence_status"] = "present"\n    return out')]),
 ("M15","单侧","put/call band边界互换",[(H,BAND_LOW_ASSIGN,BAND_SWAP)]),
 ("M16","单侧","Q5两翼flags互换",[(H,'put_bleed_flags = bleed_integrity_check(put_wing["periods"])','put_bleed_flags = bleed_integrity_check(call_wing["periods"])'),
                                  (H,'call_bleed_flags = bleed_integrity_check(call_wing["periods"])','call_bleed_flags = bleed_integrity_check(put_wing["periods"])')]),
 ("M17","单侧","time_decay改dte/entry_dte",[(H,'F(entry["dte_remaining"] - rec["dte_remaining"], entry["dte_remaining"])','F(rec["dte_remaining"], entry["dte_remaining"])')]),
 ("M18","单侧","丢弃put侧integrity_check赋值",[(H,PUT_ASSIGN_BLOCK,'    put_bleed_flags = bleed_integrity_check(put_wing["periods"])')]),
 # ---- 协同（两侧同改）----
 ("C01","协同","band高端 > -> >= 两侧",[(H,"elif moneyness > high:","elif moneyness >= high:"),
                                      (I,'("above" if moneyness > high else "within")','("above" if moneyness >= high else "within")')]),
 ("C02","协同","band低端 < -> <= 两侧",[(H,"if moneyness < low:","if moneyness <= low:"),
                                      (I,'return "below" if moneyness < low else','return "below" if moneyness <= low else')]),
 ("C03","协同","moneyness_drift去abs 两侧",[(H,'str(abs(moneyness - F(entry["moneyness"])))','str(moneyness - F(entry["moneyness"]))'),
                                      (I,"    return max(a, b) - min(a, b)","    return a - b")]),
 ("C04","协同","time_decay分母改当期dte 两侧",[(H,'F(entry["dte_remaining"] - rec["dte_remaining"], entry["dte_remaining"])','F(entry["dte_remaining"] - rec["dte_remaining"], rec["dte_remaining"])'),
                                      (I,"    return F(1) - F(dte_remaining, entry_dte)","    return F(entry_dte - dte_remaining, dte_remaining)")]),
 ("C05b","协同","skew_change符号翻转 两侧",[(H,'str(F(rec["skew_reading"]) - F(entry["skew_reading"]))','str(F(entry["skew_reading"]) - F(rec["skew_reading"]))'),
                                      (I,'str(signed_delta(rec["skew_reading"], entry_skew))','str(signed_delta(entry_skew, rec["skew_reading"]))')]),
 ("C06","协同","Q5去not_downgraded 两侧",[(H,"bool(non_decreasing and not_downgraded)","bool(non_decreasing)"),
                                      (I,"bool((cur >= prev) and (not dg))","bool(cur >= prev)")]),
 ("C07","协同","upside_convexity取raw_vega 两侧",[(H,'out["upside_convexity_reading"] = str(F(rec["raw_gamma"]))','out["upside_convexity_reading"] = str(F(rec["raw_vega"]))'),
                                      (I,'"upside_convexity_reading": str(F(rec["raw_gamma"])),','"upside_convexity_reading": str(F(rec["raw_vega"])),')]),
 ("C09","协同","liquidity符号翻转 两侧",[(H,'F(rec["liquidity_reading"]) - F(entry["liquidity_reading"])','F(entry["liquidity_reading"]) - F(rec["liquidity_reading"])'),
                                      (I,'str(signed_delta(rec["liquidity_reading"], entry_liq))','str(signed_delta(entry_liq, rec["liquidity_reading"]))')]),
 ("C10","协同","time_decay改dte/entry_dte 两侧",[(H,'F(entry["dte_remaining"] - rec["dte_remaining"], entry["dte_remaining"])','F(rec["dte_remaining"], entry["dte_remaining"])'),
                                      (I,"    return F(1) - F(dte_remaining, entry_dte)","    return F(dte_remaining, entry_dte)")]),
 ("C11","协同","Q2四因entry基准t1->t4 两侧",[(H,'put_entry = put_wing["periods"][0]','put_entry = put_wing["periods"][3]'),
                                      (I,'    entry = put_wing["periods"][0]','    entry = put_wing["periods"][3]')]),
 # ---- 复核侧自增（B-4许可）----
 ("X01","自增协同","wing_presence_status覆写present 两侧",[(H,CALL_RET,'    out["upside_convexity_reading"] = str(F(rec["raw_gamma"]))\n    out["wing_presence_status"] = "present"\n    return out'),
                                      (I,'"wing_presence_status": rec["wing_presence_status"],','"wing_presence_status": "present",')]),
 ("X02","自增协同","Q5单调 >= -> > 两侧",[(H,"non_decreasing = booked >= prev","non_decreasing = booked > prev"),
                                      (I,"bool((cur >= prev) and (not dg))","bool((cur > prev) and (not dg))")]),
 ("X03","自增协同","Q5初值prev 0 -> -1 两侧",[(H,"    prev = F(0)\n    for rec in periods:","    prev = F(-1)\n    for rec in periods:"),
                                      (I,"    prev_seq = [F(0)] + booked[:-1]","    prev_seq = [F(-1)] + booked[:-1]")]),
 ("X04","自增协同","put entry基准t1->t2 两侧（C11变体，非钉表整齐点）",[(H,'put_entry = put_wing["periods"][0]','put_entry = put_wing["periods"][1]'),
                                      (I,'    entry = put_wing["periods"][0]','    entry = put_wing["periods"][1]')]),
 ("X05","自增单侧","Q5 not_downgraded 取反",[(H,'not_downgraded = not rec["premium_bleed_downgrade_flag"]','not_downgraded = bool(rec["premium_bleed_downgrade_flag"])')]),
 ("X06","自增协同","liquidity取错字段(skew) 两侧",[(H,'F(rec["liquidity_reading"]) - F(entry["liquidity_reading"])','F(rec["skew_reading"]) - F(entry["skew_reading"])'),
                                      (I,'str(signed_delta(rec["liquidity_reading"], entry_liq))','str(signed_delta(rec["skew_reading"], entry_skew))')]),
]


def fresh_tree(name):
    d = os.path.join(ARENA, name)
    if os.path.exists(d):
        shutil.rmtree(d)
    shutil.copytree(SRC, d)
    return d


def apply_edits(d, edits):
    for f, old, new in edits:
        p = os.path.join(d, f)
        src = open(p, encoding="utf-8").read()
        if src.count(old) != 1:
            raise AssertionError(f"注入点命中数={src.count(old)} 预期1 :: {f} :: {old[:60]!r}")
        open(p, "w", encoding="utf-8").write(src.replace(old, new, 1))


def run(d, script):
    return subprocess.run([PY, script], cwd=d, capture_output=True, text=True)


def digest(d):
    out = []
    for f in ("entity/harness_output.json", "verify/independent_output.json"):
        p = os.path.join(d, f)
        out.append(hashlib.sha256(open(p, "rb").read()).hexdigest() if os.path.exists(p) else "ABSENT")
    return tuple(out)


def first_fail(d):
    p = os.path.join(d, "verify/assert_log.txt")
    if not os.path.exists(p):
        return "(无assert_log.txt)"
    for line in open(p, encoding="utf-8"):
        if line.startswith("FAIL:"):
            return line.strip()[:140]
    return "(日志无FAIL行)"


def main():
    shutil.rmtree(ARENA, ignore_errors=True)
    os.makedirs(ARENA)

    base = fresh_tree("_baseline")
    run(base, "entity/harness.py"); run(base, "verify/independent_recompute.py")
    BASE_DIG = digest(base)

    rows = []
    for mid, kind, desc, edits in MUT:
        d = fresh_tree(mid)
        apply_edits(d, edits)
        r1 = run(d, "entity/harness.py")
        r2 = run(d, "verify/independent_recompute.py")
        if r1.returncode != 0 or r2.returncode != 0:
            obs = True
            rc = 1
            note = f"上游脚本异常退出(h={r1.returncode},i={r2.returncode})"
        else:
            obs = digest(d) != BASE_DIG
            r3 = run(d, "verify/assert_check.py")
            rc = r3.returncode
            note = first_fail(d) if rc != 0 else "—"
        rows.append((mid, kind, desc, obs, rc, note))
        print(f"{mid:5} {kind:8} obs={'Y' if obs else 'N'} exit={rc} {'击落' if rc!=0 else '逃逸'}  {note[:90]}")

    json.dump([{"id": a, "kind": b, "desc": c, "observable": d_, "exit": e, "attrib": f}
               for a, b, c, d_, e, f in rows],
              open("/home/claude/replay_result.json", "w", encoding="utf-8"),
              ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()

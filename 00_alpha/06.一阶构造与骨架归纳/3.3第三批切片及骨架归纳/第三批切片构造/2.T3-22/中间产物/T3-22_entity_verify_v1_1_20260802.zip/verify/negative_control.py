"""
verify/negative_control.py — T3-22 负向对照（乙-4 mutation最小形态）· v1.1修复版

注入对象＝被测实现entity/harness.py之band_position函数（非比对器verify/assert_check.py），
变异＝边界比较符 `moneyness > high` → `moneyness >= high`（典型off-by-one型协同变异，
T3-17外审M7同型：`>`→`>=`协同）。预期：该变异使put wing t4（moneyness恰等于
target_activation_band_high）从"within"误判为"above"，与entity/input_schema.md声明的
含端点口径（low<=m<=high计入within）矛盾。

v1.1修复（D-5缺陷回传，裁决57-1裁定）：
  v1.0版本自建harness-vs-independent位置比对，归因文案写死固定串
  "verify/assert_check.py::enum_and_pinned_band_check"；外审以同一变异走真实
  assert_check.py流水线实测，首个失败断言实为数值比对（D段②，先于
  enum_and_pinned_band_check执行），写死归因与实测不符（D-5事实二），且运行
  输出从未落盘（仅存在于切片记录文字转述，D-5事实三，违B19/W-9(2)）。

  本版不再自建比对逻辑，而是在隔离临时目录内搭建"变异entity/ + 未变异verify/"
  之完整交付树，实际调用真实verify/assert_check.py（未修改一字）对变异版执行
  全套判据链，动态捕获其assert_log.txt中第一条FAIL行作为归因（走真实断言流水线
  取得，非写死），并将本次运行之完整记录持久化至verify/negative_control_log.txt
  （随verify/交付，不再仅以文字声明存在）。
"""

import os
import shutil
import subprocess
import sys

MUTATION_DIR = "_mutation_tmp_t322"  # 包根同级，非entity/、verify/任一之内（避免目录自嵌套复制）
NEGATIVE_LOG_PATH = "verify/negative_control_log.txt"

# 需带入隔离目录的源文件白名单（逐文件复制，非copytree整树——见build_mutated_tree说明）
_ENTITY_FILES = ["input_schema.md", "input_data.json", "harness.py"]
_VERIFY_FILES = ["independent_recompute.py", "assert_check.py", "negative_control.py"]

_out_lines = []


def out(msg):
    _out_lines.append(msg)
    print(msg)


def flush_out():
    with open(NEGATIVE_LOG_PATH, "w", encoding="utf-8") as f:
        f.write("\n".join(_out_lines) + "\n")


def _fail_and_persist(msg):
    out(f"FAIL: {msg}")
    flush_out()
    shutil.rmtree(MUTATION_DIR, ignore_errors=True)
    sys.exit(1)


def build_mutated_tree():
    """搭建"变异entity/ + 未变异verify/（含真实assert_check.py）"之完整交付树。

    MUTATION_DIR置于包根同级（非entity/、verify/任一之内）；逐文件白名单复制
    （非shutil.copytree整树复制）——若对"verify"目录整树copytree到其自身子目录
    下（旧设计曾用MUTATION_DIR="verify/_mutation_tmp"），将构成目录自嵌套递归
    复制（目标是源的子孙），存在无限膨胀风险，故改为显式逐文件复制，来源与
    目标互不包含，无自嵌套可能。衍生产物（harness_output.json等）不预先复制，
    全部由下方步骤当场真跑生成，保证归因来自真实当场执行、无"沿用旧产物"窗口。
    """
    if os.path.exists(MUTATION_DIR):
        shutil.rmtree(MUTATION_DIR)
    os.makedirs(f"{MUTATION_DIR}/entity")
    os.makedirs(f"{MUTATION_DIR}/verify")

    for fn in _ENTITY_FILES:
        shutil.copy(f"entity/{fn}", f"{MUTATION_DIR}/entity/{fn}")
    for fn in _VERIFY_FILES:
        shutil.copy(f"verify/{fn}", f"{MUTATION_DIR}/verify/{fn}")


def inject_mutation():
    harness_path = f"{MUTATION_DIR}/entity/harness.py"
    with open(harness_path, encoding="utf-8") as f:
        src = f.read()

    target = "elif moneyness > high:"
    mutated_target = "elif moneyness >= high:"
    if target not in src:
        _fail_and_persist(f"mutation注入点未找到（预期字符串: {target!r}），负向对照本身失败")

    mutated_src = src.replace(target, mutated_target, 1)
    if mutated_src.count(mutated_target) != 1:
        _fail_and_persist("变异注入命中数异常（预期恰1处）")

    with open(harness_path, "w", encoding="utf-8") as f:
        f.write(mutated_src)


def run_step(cmd, cwd, label):
    proc = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True)
    out(f"--- 子步骤：{label}（cwd={cwd}） ---")
    out(f"命令：{' '.join(cmd)}")
    out(f"退出码：{proc.returncode}")
    if proc.stdout.strip():
        out(f"stdout（末20行）：\n" + "\n".join(proc.stdout.strip().splitlines()[-20:]))
    if proc.stderr.strip():
        out(f"stderr（末20行）：\n" + "\n".join(proc.stderr.strip().splitlines()[-20:]))
    return proc


def extract_first_fail_line(log_path):
    if not os.path.exists(log_path):
        return None
    with open(log_path, encoding="utf-8") as f:
        for line in f:
            if line.startswith("FAIL:"):
                return line.strip()
    return None


def main():
    out("--- 乙-4 mutation注入：entity/harness.py band_position边界符 > -> >= ---")
    out(f"底版entity/、verify/零改动；本次操作全程限于隔离目录 {MUTATION_DIR}/")

    build_mutated_tree()
    inject_mutation()
    out(f"变异已注入 {MUTATION_DIR}/entity/harness.py（原entity/harness.py零改动，本进程未触碰）")

    # 1) 重跑变异harness，产出变异harness_output.json
    proc1 = run_step([sys.executable, "entity/harness.py"], MUTATION_DIR, "重跑变异harness")
    if proc1.returncode != 0:
        _fail_and_persist(f"变异harness运行本身异常退出：{proc1.stderr}")

    # 2) 重跑未变异independent_recompute，产出正确ground truth
    proc2 = run_step([sys.executable, "verify/independent_recompute.py"], MUTATION_DIR, "重跑未变异独立复算")
    if proc2.returncode != 0:
        _fail_and_persist(f"独立复算运行本身异常退出：{proc2.stderr}")

    # 3) 对变异版调用真实assert_check.py（未修改一字），走全套判据链
    proc3 = run_step([sys.executable, "verify/assert_check.py"], MUTATION_DIR, "对变异版调用真实assert_check.py全套判据链")

    mutated_log_path = f"{MUTATION_DIR}/verify/assert_log.txt"
    first_fail = extract_first_fail_line(mutated_log_path)

    if proc3.returncode == 0:
        out("FAIL: 变异未被真实判据链击落（负向对照失效，判据链存在盲区，exit=0）")
        flush_out()
        shutil.rmtree(MUTATION_DIR, ignore_errors=True)
        sys.exit(1)

    if first_fail is None:
        out(f"FAIL: 变异版assert_check.py以非零退出码({proc3.returncode})终止，"
            f"但{mutated_log_path}未见FAIL行——归因不可指认，判据链输出形态异常")
        flush_out()
        shutil.rmtree(MUTATION_DIR, ignore_errors=True)
        sys.exit(1)

    out(f"--- 负向对照通过：变异版assert_check.py以exit={proc3.returncode}击落 ---")
    out(f"归因（走真实断言流水线动态捕获，非写死）：{first_fail}")
    out("说明：本次归因取自变异版对真实assert_check.py（未修改一字）之实际首个FAIL行，"
        "非本脚本自建比对逻辑之预设文案（D-5修复：v1.0曾写死归因于"
        "'enum_and_pinned_band_check'，与实测首个失败点'数值比对'不符）。")

    flush_out()
    shutil.rmtree(MUTATION_DIR, ignore_errors=True)
    print("exit 0")
    sys.exit(0)


if __name__ == "__main__":
    main()

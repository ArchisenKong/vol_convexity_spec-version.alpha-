"""
verify/independent_recompute.py — T3-22 独立复算（D段②）

独立性声明：本文件不import entity.harness、不读取entity/harness_output.json，
直接读取entity/input_data.json独立推导期望值。四处表达式级路径分叉（对应
entity/harness.py同名机制，D段②"改写后是否仍共享同一失效模式"判别，F-2口径）：

  1. band位置：harness用if/elif三分支 → 本文件用嵌套三元表达式。
  2. moneyness_drift：harness用内建abs() → 本文件用max()-min()展开式。
  3. time_decay_fraction：harness用(entry_dte-dte)/entry_dte直接式
     → 本文件用1-(dte/entry_dte)恒等改写式。
  4. bleed单调非降检验：harness用命令式for循环+局部变量prev原地更新
     → 本文件用zip前后对偶生成器+all()谓词，不含显式累加变量。

代数等价重写与零重写复制不计分叉（F-2口径不认可）；以上四处按F-2判别据（"改写后是否
仍共享同一失效模式"）逐点复核后，仅分叉点4（bleed单调，控制流真改写：命令式for循环
原地更新 vs 生成器+all()谓词）构成独立路径；分叉点1-3为代数等价重写/纯记法变换，
与harness共享同一失效模式，不计入独立分叉数（D-4修复，详见entity/input_schema.md §7）。

v1.1修复新增：call wing输出补入`wing_presence_status`字段（passthrough，数据层，
D-8/M14修复，见recompute_call_periods docstring）。
"""

import json
from fractions import Fraction as F


def load_input(path="entity/input_data.json"):
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def band_position_alt(moneyness, low, high):
    """嵌套三元表达式（分叉点1，对应harness.band_position的if/elif三分支）。"""
    return "below" if moneyness < low else ("above" if moneyness > high else "within")


def abs_via_minmax(a, b):
    """max()-min()展开式（分叉点2，代替内建abs(a-b)）。"""
    return max(a, b) - min(a, b)


def decay_fraction_alt(entry_dte, dte_remaining):
    """1-(dte/entry_dte)恒等改写式（分叉点3，代替(entry_dte-dte)/entry_dte直接式）。"""
    return F(1) - F(dte_remaining, entry_dte)


def signed_delta(rec_val, entry_val):
    return F(rec_val) - F(entry_val)


def recompute_put_periods(put_wing):
    basis = put_wing["declared_basis"]
    low = F(basis["target_activation_band_low"])
    high = F(basis["target_activation_band_high"])
    entry = put_wing["periods"][0]
    entry_m = F(entry["moneyness"])
    entry_dte = entry["dte_remaining"]
    entry_skew = F(entry["skew_reading"])
    entry_liq = F(entry["liquidity_reading"])

    out = []
    for rec in put_wing["periods"]:
        m = F(rec["moneyness"])
        out.append({
            "period": rec["period"],
            "tail_coverage_band_position": band_position_alt(m, low, high),
            "moneyness_drift": str(abs_via_minmax(m, entry_m)),
            "time_decay_fraction": str(decay_fraction_alt(entry_dte, rec["dte_remaining"])),
            "skew_change": str(signed_delta(rec["skew_reading"], entry_skew)),
            "liquidity_deterioration": str(signed_delta(rec["liquidity_reading"], entry_liq)),
        })
    return out


def recompute_call_periods(call_wing):
    """D-8/M14修复：补入wing_presence_status（原独立复算输出缺此字段，致其未进入
    harness/independent双路径数值比对面，M14变异——覆写为任意合法present值——不可检出）。
    该字段为存续状态人造声明值（数据层，§3#5：数据/机制刀口前置分流，非本切片计算派生），
    passthrough读法与entity/harness.py::process_call_period一致（同一数据源直读，非独立
    "计算"意义上的路径分叉——F-2口径下本字段属数据搬运，与upside_convexity_reading同类）。
    """
    basis = call_wing["declared_basis"]
    low = F(basis["target_activation_band_low"])
    high = F(basis["target_activation_band_high"])

    return [
        {
            "period": rec["period"],
            "tail_coverage_band_position": band_position_alt(F(rec["moneyness"]), low, high),
            "upside_convexity_reading": str(F(rec["raw_gamma"])),
            "wing_presence_status": rec["wing_presence_status"],
        }
        for rec in call_wing["periods"]
    ]


def bleed_integrity_flags(periods):
    """zip前后对偶生成器（分叉点4，代替命令式for循环+局部变量原地更新）。
    对偶序列：[0]+booked[:-1] 与 booked 逐期配对，非降＝配对内后者>=前者。
    """
    booked = [F(rec["premium_bleed_booked"]) for rec in periods]
    prev_seq = [F(0)] + booked[:-1]
    downgraded = [rec["premium_bleed_downgrade_flag"] for rec in periods]
    return [
        bool((cur >= prev) and (not dg))
        for cur, prev, dg in zip(booked, prev_seq, downgraded)
    ]


def run(input_path="entity/input_data.json"):
    data = load_input(input_path)
    assert data.get("_data_source") == "synthetic_hand_constructed"

    put_wing = data["wings"]["put_wing"]
    call_wing = data["wings"]["call_wing"]

    put_derived = recompute_put_periods(put_wing)
    call_derived = recompute_call_periods(call_wing)

    put_flags = bleed_integrity_flags(put_wing["periods"])
    call_flags = bleed_integrity_flags(call_wing["periods"])

    for i, flag in enumerate(put_flags):
        put_derived[i]["premium_bleed_integrity_check"] = flag
    for i, flag in enumerate(call_flags):
        call_derived[i]["premium_bleed_integrity_check"] = flag

    return {
        "put_wing_derived": put_derived,
        "call_wing_derived": call_derived,
    }


if __name__ == "__main__":
    result = run()
    with open("verify/independent_output.json", "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
    print("independent recompute complete -> verify/independent_output.json")

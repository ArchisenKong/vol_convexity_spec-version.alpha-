# input_schema · T3-22 wing integrity 状态量 · v1.1 · 修复版

> **身份**：T3-22（wing integrity状态量）之阶段A一阶实体，第三批续1（断点二闭合位，
> 已建成消费方T3-17之上游）。
> **授权链**：任务包_续1_T3-22_v1.0（裁决52-1＋54-6＋54§3＋52-3=b）＋裁决1（构造链，
> 人造input全程强制）＋裁决13/19（容差）＋裁决21(a)（三分判别）＋裁决24-A7 O1（目录
> 结构）＋裁决28-B（非零退出码＋程序化解析）＋裁决39-B4（锚定词表分层）＋裁决53（W-13
> 判据类并入任务6 v1.8 F段）。
> **v1.1修复授权链**：裁决57-1（判定不通过·单一修复动作）＋裁决57落地文档§1/§2（57-2
> 登记形态／57-4/57-5前置口径）＋T3-22外审报告v1.0（缺陷D-1~D-8与攻击A1/A2/A5实证载体）
> ＋修复会话开启文本_续1_T3-22_20260802（十项修复面授权，本文件cp-then-edit自v1.0底版，
> 底版零改动，另存/home/claude/T3-22_baseline留痕）。
> **会话身份**：v1.0＝切片构造会话；v1.1＝修复会话（新session，施工侧，非原构造会话、
> 非外审会话）。零自审、零裁决——本文件全部判断均为构造/修复侧呈报，实体边界与范围
> 疑义一律呈KD（§13本根裁定登记）。
> **v1.1修复变动面摘要**（详见随交付《修复变动面清单》）：F-1封闭规则动态化（D-1）／
> 产物新鲜度observable（D-2）／钉表18→90全量（D-3）／F-2分叉清单重述（D-4）／负向对照
> 归因动态化（D-5）／TPL1-T322-01新立登记（D-6，57-2）／Q5输入域边界扩充（D-7）／Q4
> 输出面钉点（D-8/M14）／O-1指针订正／O-2转述补漏。数值产物**已变动**（Q5输入域扩充
> 致put wing t7-t9三期premium_bleed_booked/downgrade_flag改值，全链已重跑重出）。

---

## §1 对象定义与本切片实际计算之要件（C1）

T3-22＝"持仓＋行情→状态向量"（裁决52 §2定位语）：确认长端双翼（long put／long call）
是否仍承担母结构中左尾保护与右尾参与职能之诊断状态量。判据源＝T3§13.4（行1314-1326，
审计表v1.5三态全部**思想锚定**）。

**本切片计算要件**：
1. moneyness相对declared_basis两端边界（`target_activation_band_low/high`）之三分位置
   判定（below/within/above），两翼公用同一机制（Q1/Q3公共结构）。
2. put wing四因诊断读数（moneyness_drift／time_decay_fraction／skew_change／
   liquidity_deterioration），相对本翼t1（entry）基准的差值/比例计算（Q2）。
3. call wing convexity读数（upside_convexity_reading＝raw_gamma直接标注，Q3）。
4. premium bleed账本完整性联合检验（单调非降 ∧ downgrade_flag恒False，Q5，两翼各算）。

**上游输入（本切片不计算、作已声明值/人造行情坐标接收，裁决1强制）**：
- 两翼各9期（t1-t9）moneyness、raw_vega、raw_gamma（人造时序本体）。
- 两翼declared_basis：`target_activation_band_low/high`（构造候选值，见§6）。
- put wing每期：`dte_remaining`、`skew_reading`、`liquidity_reading`。
- call wing每期：`dte_remaining`、`wing_presence_status`（枚举，位置事实，非计算得出——见§4）。
- 两翼每期：`premium_bleed_booked`（累计账本值）、`premium_bleed_downgrade_flag`（布尔）。
  **v1.1修复（D-7）**：put wing t7/t8/t9三期改构造——v1.0原全程严格递增+downgrade恒False，
  致Q5两布尔子判据（非降/未降级）及`>=`边界在本输入下恒真、零区分力（外审D-7实证：
  M09/M10/M11/M16四例变异不可观察）。v1.1改为：t7 booked与t6相等（钉住`>=`等号边界，
  原v1.0从未测过该边界）；t8 booked较t7下降（触发non_decreasing=False，downgrade仍
  False，隔离测试该子判据）；t9 booked回升但downgrade_flag=True（non_decreasing=True，
  隔离测试not_downgraded子判据）。call wing维持v1.0原值不变（"至少一族"，最小充分不
  外推，任务包§3施工纪律未要求两翼均扩）。moneyness/dte/skew/liquidity/raw_vega/
  raw_gamma字段两翼全部未动，Q1-Q4/band序列/四因诊断读数钉表不受影响。

**本切片不计算、不供给（越界声明，§8消费面契约边界）**：`target_vega_response_level`／
`target_gamma_response_level`——T3-17 §1"该翼建仓/roll后声明的基准"一并列出的另两项，
但其消费场景专属T3-17自身响应比合成（occupant#1候选规格），非T3-22五问范畴（Q1-Q5
均不涉逐Greek响应水平目标）。本切片不代T3-17声明该两值，避免越界填入下游对象参数
（呈KD追认，见§13#1）。

---

## §2 五问→输出分量映射表（S-1机械前哨基面）

| 判据源问句（T3§13.4） | 输出分量 | 归属翼 |
|---|---|---|
| Q1 long put是否仍覆盖目标左尾路径（T3·1319） | `tail_coverage_band_position` | put_wing |
| Q2 put wing是否因moneyness drift/time decay/skew change/liquidity deterioration而钝化（T3·1320） | `moneyness_drift`／`time_decay_fraction`／`skew_change`／`liquidity_deterioration` | put_wing |
| Q3 long call是否仍提供右尾参与与upside convexity（T3·1321） | `tail_coverage_band_position`／`upside_convexity_reading` | call_wing |
| Q4 call wing是否因删除/过度monetization/covered call出货/roll后位置错误而缺席（T3·1322） | `wing_presence_status` | call_wing |
| Q5 长端双翼premium bleed是否入账未降级（T3·1323） | `premium_bleed_booked`／`premium_bleed_downgrade_flag`／`premium_bleed_integrity_check` | put_wing＋call_wing |

**权限句重申（T3·1326）**：本状态量不是单独交易信号，仅作diagnostic、candidate input
或Phase 4 governance input。本schema与entity/harness.py全程不产出roll/repair/review
执行逻辑、不产出信号字段（S-2机械前哨核验对象，见verify/assert_check.py）。

---

## §3 三分判别套用表（裁决21(a)受控文本v1.1；乙-7回引条款号）

| # | 计算成分 | 判别 | 依据（双重引用） | 处置 |
|---|---|---|---|---|
| 1 | Q1/Q3公共band位置三分机制（below/within/above） | **类一** | 受控文本§2；源文"是否仍覆盖目标左尾路径"/"是否仍提供右尾参与"直接语义支持位置类判定；先例T-76/T3-03/GK-14/T3-17均属同型A1分桶机制，无矛盾候选 | 定案写入实现 |
| 2 | band边界具体数值（`target_activation_band_low/high`） | **类三** | 受控文本§4；数值本身无权威文本/既有裁决可排除任何候选，工程候选待Phase B证伪；同型先例＝T-76阈值H1、T3-17 floor/window | 阶段A候选之一，本根新声明，不外推，见§6 |
| 3 | Q2四因诊断读数差值计算式 | **类二·缺定义型** | 受控文本§3；**v1.1修复（D-6，裁决57-2）**：v1.0"回引TPL1-T303-02不重登"经外审核对条目原文（撞墙清单_T3-03 v1.4行35/45）证不同一——TPL1-T303-02覆盖"诊断标签从raw Greeks聚合得出之权威计算定义"，本根Q2四因由moneyness/dte/skew/liquidity_reading直接算得，非从raw Greeks聚合，刀口不同、机制主体不同。**新立TPL1-T322-01**（类二·缺定义，裁决57-2定性），候选文本见随交付《TPL1-T322-01登记候选文本》，正式登记入撞墙清单_T3-03候KD收口裁定写入 | 确定性占位读数，不claim诊断权威，见§4（v1.1随行指针改指TPL1-T322-01） |
| 4 | Q5 bleed账本完整性联合检验（单调非降∧未降级） | **类一** | 受控文本§2；宪-CV-05"凸性有成本"（思想锚定，审计表**T3·1318-1324**行——**v1.1订正，O-1**：v1.0原标注"审计表T3·1326行"有误，审计表v1.5实载CV-05锚定于T3·1318-1324行，T3·1326行实际锚定为宪-EP-06推论段＋宪-EP-07，非CV-05）＋源文"premium bleed 是否被账本记录，但未因此被降级为可删除成本"直接语义支持"记录存在性+非降级"联合布尔机制，无矛盾候选 | 定案写入实现 |
| 5 | Q4 wing_presence_status | 不入三分（数据/机制刀口前置分流） | 受控文本§1："成分只作为值被消费＝数据，不进入三分判别"——存续状态为持仓事实，人造声明值，非本切片计算派生 | 数据层，见§4 |
| 6 | Q3 upside_convexity_reading（raw_gamma直接标注） | 不入三分（数据搬运，非新增机制） | 受控文本§1同上；该字段为已声明raw_gamma之贴标签操作，未引入新计算规则 | 数据搬运 |

---

## §4 Q4 wing_presence_status 与 TPL1-T322-01/TPL1-T303-02 随行指针（§5强制携带，本根不重开不闭合）

`wing_presence_status`枚举值域：`present` / `deleted` / `over_monetized` /
`covered_call_shipped` / `roll_misplaced`——逐项对应T3·1322四缺席形态（删除/过度
monetization/covered call出货/roll后位置错误）加一"present"健康态，由人造持仓事实
直接声明（数据层，§3#5），非本切片计算派生。**v1.1修复（D-8/M14）**：该字段v1.0
版本未纳入D段②数值比对面、亦无逐期钉点（仅验枚举合法性），致覆写为任意合法值
不可检出（外审M14变异实证）。v1.1已将其纳入verify/assert_check.py之
numeric_comparison比对面（harness/independent两侧均输出该字段）＋逐期钉点
（`EXPECTED_CALL_PRESENCE_STATUS`，见verify/assert_check.py::enum_and_pinned_band_check）。

**TPL1-T322-01随行指针（新立，v1.1修复，D-6，裁决57-2，强制携带）**：Q2四因诊断读数
（moneyness_drift／time_decay_fraction／skew_change／liquidity_deterioration）之权威
解释定义（如何将四项差值/比例读数解释为钝化诱因之强度/方向，是否需归一化/加权聚合）
现仍缺失，登记候选文本见随交付《TPL1-T322-01登记候选文本》，正式登记入撞墙清单_T3-03
候KD收口裁定写入。本切片Q2产出**仅为四因诊断读数本身（差值/比例，class-1定案算式，
见entity/harness.py process_put_period，全量已钉表，见§7/D-3修复），不claim该等读数
之诊断解释权威，不合成"put wing是否钝化"之布尔判定**，本根不重开、不闭合、不代裁
TPL1-T322-01（新立登记候选，等KD收口正式写入）。

**TPL1-T303-02随行指针（撞墙清单_T3-03 v1.4，仍强制携带，裁决54-4；v1.1修复后与
TPL1-T322-01并列，相邻不合并——先例＝TPL1-TC33-01/TPL1-T303-01/TPL1-GK14-01同域相邻
处置）**：wing dullness分量现状态＝候选级闭合（裁决40-4，经T3-17 v2.0交付候选可算化）；
gamma_center／vega_concentration／theta_burn三标签维持缺定义、open。TPL1-T303-02覆盖
"诊断标签从raw Greeks聚合得出之权威计算定义"，与TPL1-T322-01"钝化诱因读数本身之解释
定义"刀口不同、机制主体不同（v1.0曾将Q2四因错误挂靠TPL1-T303-02不重登，v1.1已订正，
见§3#3）。verify/assert_check.py之`tpl1_t303_02_pointer_check`断言核证本切片输出中
不含任何越权钝化判定字段（`put_wing_dulled`／`wing_dullness_triggered`／`is_dulled`／
`dulling_verdict`等）——该断言与TPL1-T322-01新立登记并不冲突，仍成立。

---

## §5 仪表身份标注（对照表§3随行义务③＋§5.4常设纪律，强制）

本切片消费/携带raw_vega、raw_gamma两项模型派生量（Greeks）。依宪-EP-06（价格在先＋
派生量仪表推论：模型派生量＝仪表读数非真理源）＋24-E3引擎范围注记形态：

**raw_vega、raw_gamma、upside_convexity_reading（=raw_gamma标注）三字段，其数值身份＝
仪表读数（instrument reading），非真理源（truth source）；不承载"应然定价/正确Greeks"
宣称，不以此类读数裁决持仓合法性或获利正当性。** 本条注记随§6取值形态裁定同批生效，
适用于本切片全部产出（entity/input_schema.md、harness_output.json、切片记录）。

---

## §6 raw_vega/raw_gamma取值形态（本根裁定登记，呈KD）

**候选路径**：(a) 经TPL1-T76-01（品种感知自算Greeks引擎，v1.1，裁决49终态收口）实际
调用求值；(b) 声明值接收（人造行情坐标直接手工声明，先例＝T3-17 §1/§6同型处置）。

**本根取(b)**。理由：
1. **环境事实**：本构造会话可及文件系统（`/mnt/project/`）核证零`.py`/代码类文件，
   TPL1-T76-01之`entity/engine.py`等实际可导入产物未挂载本会话（`find /mnt/project
   -type f ! -name "*.md"`核证为空）；仅其schema/治理文档（一阶实体_TPL1-T76-01
   引擎_input_schema_v1_1）在场，属"背景件（可选，非必装）"定位（任务包§1）。
2. **分层原则**：TPL1-T76-01已收口（裁决49-7），M1"纯函数+账本"双解耦架构下承担
   Greeks供给之调用权；若本根在无法真实导入调用的情况下自行重新实现BSM闭式解以
   "冒充调用"，将构成对M1已收口产物的越权平行重造，违反downstream消费而非重造之
   分层纪律。
3. **先例一致性**：T3-17（本切片下游消费方）自身即采声明值接收（§1"上游输入，
   本切片不计算，作已声明值接收"；§6"全部数值为本根手工构造，非源自任何真实行情
   或历史样本"），本根与之取同型路径，形态衔接无冲突。

**呈KD**：若KD认为后续切片应实测engine-call路径（例如真实导入TPL1-T76-01产物验证
"调用权"实际可执行性），需先解决"引擎代码产物跨会话持久化/挂载"这一环境层缺口
（非本切片方法论缺口，供KD参考是否另立W/DOC条目）。

---

## §7 B段路线选择与容差子口径

- **B段计算路线**：全程离散有理数算术（`fractions.Fraction`），无sqrt/exp/log等
  超越函数 → 容差子口径**(a) bit-exact**（裁决13/19，骨架C3分派判据＝超越函数在场性）。
- **路径独立（D段②硬要求）· v1.1修复（D-4，F-2口径重述）**：v1.0声明"四处表达式级
  真分叉，非共用同一行"，经外审按F-2判别据（**改写后是否仍共享同一失效模式**，任务包
  §3明文；代数等价重写与零重写复制均不计分叉）逐点复核，**实际独立分叉数≤1**：
  | 声明位点 | harness | independent | F-2判别（v1.1订正读法） |
  |---|---|---|---|
  | band位置 | if/elif三分支 | 嵌套三元表达式 | 纯记法变换，比较符与分支序完全同构，与harness共享同一失效模式，**不计分叉** |
  | moneyness_drift | 内建`abs()` | `max()-min()`展开式 | 代数等价重写，**不计分叉** |
  | time_decay_fraction | `(entry_dte-dte)/entry_dte` | `1-(dte/entry_dte)` | 代数等价重写（本schema v1.0已自称"恒等改写式"，自证），**不计分叉** |
  | bleed单调检验 | 命令式for循环+局部变量`prev`原地更新 | `zip`前后对偶生成器+`all()`谓词 | 控制流真改写（有状态循环 vs 无状态生成器+谓词），失效模式路径不同，**唯一构成独立分叉之点** |
  | skew_change | `F(rec)-F(entry)` | `signed_delta()`同式 | **零重写复制**（未在v1.0披露）：两独立复算字段共用同一函数体，与harness对应表达式代数同构，不计分叉 |
  | liquidity_deterioration | 同上 | 同上（复用同一`signed_delta()`） | **零重写复制**（未在v1.0披露），不计分叉 |
  | upside_convexity_reading | raw_gamma直传 | raw_gamma直传 | 数据搬运（非计算），已声明豁免，不入分叉计数 |

  **v1.1订正结论**：独立路径分叉实际计数＝**1**（bleed单调检验，控制流真改写），非
  v1.0声明之4；其余三处（band位置/moneyness_drift/time_decay_fraction）为代数等价
  重写，与harness共享同一失效模式，不构成独立验证力；skew_change与liquidity_
  deterioration两处为此前未披露之**零重写复制**（两独立复算字段复用同一函数体）。
  本条不主张协同变异逃逸即D段②缺陷（该主张与35-A固有上限冲突，见D-3钉表承接
  说明）；本条仅订正分叉判别据套用与计数申报，不改动任何一侧实现代码本体
  （F-2 D-4修复限于申报口径，非代码重写；分叉真实构造维持v1.0原状）。

---

## §7.5 v1.1修复：判据链机制新增（F-1动态化／F-3产物新鲜度／D-3钉表扩全量）

- **F-1封闭规则动态化（D-1修复）**：verify/assert_check.py之F-1完备性自检与
  step0(ii) W-8扫描面，v1.0版本前者计算"缺项"而后者硬编码四项扫描清单，致
  枚举清单外新增脚本"只打印不入扫描面"（外审A5攻击实证：新增entity/extra_helper.py
  含`import socket`，v1.0逃逸exit=0）。v1.1改为`discover_py_scripts()`统一
  动态枚举entity/、verify/下全部.py脚本，供step0(ii)扫描与F-1完备性自检共用；
  任务包枚举清单（EXPECTED_SCRIPTS）降级为完备性对表基线（缺项判据不符档），
  不再是扫描对象上限。
- **F-3产物新鲜度observable（D-2修复）**：v1.0版本assert_check.py从磁盘直读
  harness_output.json/independent_output.json，既不重跑亦不校新鲜度（外审
  A1"改harness不重跑"、A2"伪造independent_output.json+空壳化独立复算脚本"
  两型攻击均逃逸exit=0）。v1.1新增`f3_product_freshness_check()`：本进程内
  当场重新装载并执行entity/harness.py::run()与verify/independent_recompute.py
  ::run()，与磁盘既有产物做bit-exact比对，不一致即判据不符档；下游全部核验
  改用该函数返回之新鲜值。
- **D-3钉表扩全量**：期望值钉表由18/81（仅band序列，覆盖率22%）扩至90/90
  （put六分量54项+call四分量36项，含v1.1新增wing_presence_status比对面）。
  全部钉表数值独立于两侧实现代码之外单独推导（第三方式，直接对entity/
  input_data.json人造input依本文件§1已声明公式手工/独立计算取得），先钉表
  后跑数、与本轮input同轮提交（构造顺序留痕，见verify/assert_check.py::
  full_pin_table_check头注）。可复算性标注：本根全部分量公式均为class-1
  定案机制或class-2占位读数之纯算术/直读公式，无涉诊断权威解释成分，故
  全量可复算，标"可复算"；本根无"不可证"项。协同变异族C03/C05b/C07/C09/
  C10（未成文面，48 Q-4口径归D-3承接）与C11（entry基准违反schema已成文
  声明，48-2口径归F-4扩展承接，见§9）均由钉表/F-4扩展两条防线实测证实
  可击落（修复变动面清单附实测记录）。
  另：Q5第三独立路径函数（verify/assert_check.py::bleed_third_path_independent_check）
  同步由v1.0"断言输入自身单调未降级"（判据-实现错层，外审D-7认定对实现零
  证伪力）订正为"独立推导期望值与harness实际输出逐期比对"，并随§1 D-7输入域
  扩充覆盖两个布尔子判据及`>=`边界。

---

## §8 消费面契约（断点二，T3-17 §1衔接核验，S-3）

T3-17 §1声明上游输入需"T3-22状态时序本身（moneyness、raw_vega、raw_gamma，§6未审
引用T3§13.4形态依据）"。本切片输出（`entity/harness_output.json`）两翼×9期均含
`moneyness`／`raw_vega`／`raw_gamma`三字段，形态（两翼×9期）与T3-17 §6"两翼各9期
人造时序"假设严格一致——**衔接核验通过**（字面层，verify/assert_check.py::
s1_declaration_completeness间接核证三字段在场；语义层的"T3-17实际消费兼容性"仍
待外审人读）。

**T3-17"未审引用"注记之解除**：本切片收口时联动兑现（裁决52-1兑现点），本切片
构造会话不执行该解除（§2.3任务包原文）。

**不涉及、不供给**：`target_vega_response_level`／`target_gamma_response_level`
（见§1越界声明）。**不修改**T3-17全部产物／审计表／治理册slot#1档案／骨架（§2.5
范围边界）。

---

## §9 边界口径声明（F-4声明-实现一致性断言基线）

band位置三分判定边界口径（本根声明，须与entity/harness.py::band_position及
verify/independent_recompute.py::band_position_alt两侧实现一致，verify/
assert_check.py::f4_declaration_implementation_consistency核证）：

```
low <= moneyness <= high  → within（含两端边界）
moneyness > high          → above
moneyness < low           → below
```

**F-4扩展 · entry基准声明-实现一致性断言（v1.1新增，D-8/C11修复，48-2/57-4/57-5
同型口径）**：§1已成文声明"put wing四因诊断读数...相对本翼t1（entry）基准的差值/
比例计算"。此前该声明仅靠D段②数值比对间接约束——数值比对通道对"两侧协同改用同一
非t1基准"之变异无区分力（外审C11实证：Q2四因基准由t1改为t4，两侧同改，数值比对
90/90仍全通过，因两侧同步偏移）。v1.1新增独立断言（verify/assert_check.py::
f4b_entry_basis_consistency）：核证put wing四因分量在entry period（t1）自身之
取值恰为零差——此为"entry基准即t1本身"的结构性、机械可判信号，若实现协同将entry
基准改为其他期，t1自身分量将偏离零，本断言可直接识破。本断言与D-3钉表扩容
（核验"数值是否等于独立推导之期望值"）互补而非重复：钉表核验取值正确性，本断言
核验entry基准声明本身在实现结构上是否被遵守，判据对象不同。实测：C11型协同变异
（entry基准t1→t4两侧同改）已被D-3钉表捕获（entry期t1自身moneyness_drift等分量
不再为0），本断言作为第二道防线同样成立（修复变动面清单附实测记录）。

---

## §10 范围边界重申（§2.5，本切片明确不做之事）

状态输出之下游动作（roll、repair、review执行逻辑）不在本切片范围：T3·1326判据源
即禁其为交易信号；执行逻辑不实现（A7语义标注随行形态，T3-18裁定6先例）。本切片
不裁决、不修改T3-17全部产物／审计表／治理册slot#1档案／骨架。

---

## §11 数据来源声明（C6档二字段规范化，裁决23(f)采纳）

`entity/input_data.json`顶层字段`_data_source: "synthetic_hand_constructed"`；
harness零数据源接入（W-8三部分静态扫描核证，见verify/assert_check.py）。

---

## §12 判据源双层结构标注（裁决28-D措辞读法）

本schema及全部产出中"判据源文位置"字段指T3§13.4（行1314-1326，审计表T3·1316／
T3·1318-1324／T3·1326三行，均**思想锚定**→宪-ST-02/04/05/07＋宪-ID-01＋宪-CV-05＋
宪-EP-06/07），仅为源文出处定位，不构成档位或效力断言。**v1.1订正（O-2）**：
v1.0原文漏列**宪-ST-02（账本记录）**——审计表T3·1318-1324行实载该锚定，本条随
O-1（§3#4 CV-05锚定行位订正）一并补入，合并为本节唯一权威转述，不另立新节。
度量形状层（band边界具体数值）无冻结判据源，构造自由度候选，见§3#2、§6。判据
效力链＝审计表锚定→宪法（裁决28-D）。

---

## §13 本根裁定登记素材（供切片记录汇总，呈KD）

| # | 裁定语句 | 性质 | 指针 |
|---|---|---|---|
| 1 | 实体边界：Q1/Q3band位置+Q2四因诊断读数+Q3convexity标注+Q5账本完整性联合检验＝要件；两翼时序本体/declared_basis/枚举存续状态/账本值＝上游输入；`target_vega_response_level`/`target_gamma_response_level`不属本切片供给范围 | 本根裁定 | §1、§8 |
| 2 | band边界数值`target_activation_band_low/high`（put: 17/20,19/20；call: 9/10,21/20）＝类三阶段A候选之一，本根新声明，不外推，待Phase B证伪（v1.1维持不变） | 本根裁定 | §3#2、§6、entity/input_data.json |
| 3 | Q2四因诊断读数差值计算式＝类二·缺定义型占位读数，**v1.1修复（D-6，裁决57-2）：新立TPL1-T322-01（不再引用TPL1-T303-02不重登——外审核对条目原文证不同一，刀口不同、机制主体不同）**，候选文本随交付呈KD，登记入撞墙清单_T3-03候KD收口写入；不claim诊断权威，不产出钝化判定布尔量 | 本根裁定（v1.0原"引用不重登"经修复改判） | §3#3、§4；TPL1-T322-01登记候选文本 |
| 4 | raw_vega/raw_gamma取值形态＝声明值接收（非engine调用），理由见§6三点（环境事实+分层原则+先例一致性）（v1.1维持不变） | 本根裁定 | §6 |
| 5 | band位置三分机制、Q5账本完整性联合检验＝类一，定案写入实现（v1.1维持不变；Q5**联合检验之输入域**v1.1已扩充，机制本身不变，见#8） | 本根裁定 | §3#1、§3#4 |
| 6 | 仪表身份标注：raw_vega/raw_gamma/upside_convexity_reading三字段＝仪表读数非真理源（宪-EP-06+24-E3形态）（v1.1维持不变） | 强制随行义务履行（对照表§3③+§5.4） | §5 |
| 7 | **v1.1新增**：独立分叉计数按F-2判别据（"改写后是否仍共享同一失效模式"）重新核定为1（bleed单调检验，控制流真改写），非v1.0声明之4；band位置/moneyness_drift/time_decay_fraction三处为代数等价重写，不构成独立分叉；skew_change与liquidity_deterioration两处为此前未披露之零重写复制，一并披露。不改动任何一侧实现代码本体，限于申报口径订正 | 本根裁定（D-4修复） | §7 |
| 8 | **v1.1新增**：put wing t7/t8/t9三期premium_bleed_booked/downgrade_flag改构造（等号边界/递减/降级三态），使Q5两布尔子判据（non_decreasing／not_downgraded）及`>=`边界在本根内可判；call wing维持v1.0原值不变（至少一族，最小充分不外推）。band/四因诊断读数钉表不受影响（仅premium_bleed字段变动） | 本根裁定（D-7修复） | §1；entity/input_data.json |
| 9 | **v1.1新增**：`wing_presence_status`纳入D段②数值比对面（原缺失）+逐期钉点（`EXPECTED_CALL_PRESENCE_STATUS`），封堵M14型覆写逃逸 | 本根裁定（D-8修复） | §4；verify/assert_check.py |
| 10 | **v1.1新增（O-1订正）**：§3#4宪-CV-05锚定行位由"审计表T3·1326行"订正为"审计表T3·1318-1324行"；T3·1326行审计表v1.5实载锚定为宪-EP-06推论段＋宪-EP-07，非CV-05 | 本根裁定（订正） | §3#4 |
| 11 | **v1.1新增（O-2订正）**：§12补入宪-ST-02（账本记录），v1.0原文漏列，审计表T3·1318-1324行实载该锚定 | 本根裁定（订正） | §12 |

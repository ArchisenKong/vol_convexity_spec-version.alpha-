"""
entity/harness.py — T3-22 wing integrity 状态量 · 一次性harness（B段）

身份：裁决1"一次性harness真跑出数"之执行体。命令式for循环风格（D段②路径独立要求，
与verify/independent_recompute.py函数式/生成器风格构成表达式级真分叉）。

职责边界：只负责"喂入→驱动→捕获"，不承担数据获取、不承担生产集成、不建常设pipeline。
零数据源接入——input全部来自entity/input_data.json（人造，_data_source声明字段核证）。

不做的事（§2.5范围边界，任务包_续1_T3-22）：
  不产出roll/repair/review执行逻辑、不产出交易信号、不做下游动作路由。
  本harness仅计算"诊断读数"，不合成任何"钝化/缺席"判定布尔量（TPL1-T303-02范畴，
  本根不重开不代裁——见entity/input_schema.md关于TPL1-T303-02随行指针的说明）。
"""

import json
from fractions import Fraction as F


def load_input(path="entity/input_data.json"):
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def band_position(moneyness, low, high):
    """Q1(put)/Q3(call)公共机制：moneyness相对declared_basis两端边界的三分位置。
    边界口径（本根声明，F-4声明-实现一致性断言核证对象）：
    low <= moneyness <= high 计入within（含两端边界）；
    moneyness > high 计入above；moneyness < low 计入below。
    三分判别：类一（受控文本§2）——回引entity/input_schema.md §3判别表。
    """
    if moneyness < low:
        return "below"
    elif moneyness > high:
        return "above"
    else:
        return "within"


def process_put_period(rec, entry, band_low, band_high):
    """put wing单期：Q1覆盖位置 + Q2四因诊断读数（相对entry/t1基准）。
    Q2四因计算式＝类二·缺定义型占位读数（受控文本§3，回引TPL1-T303-02既有登记，
    引用不重登，本根不claim诊断权威，仅供占位构造读数）。
    """
    moneyness = F(rec["moneyness"])
    out = dict(rec)
    out["tail_coverage_band_position"] = band_position(moneyness, band_low, band_high)
    out["moneyness_drift"] = str(abs(moneyness - F(entry["moneyness"])))
    out["time_decay_fraction"] = str(
        F(entry["dte_remaining"] - rec["dte_remaining"], entry["dte_remaining"])
    )
    out["skew_change"] = str(F(rec["skew_reading"]) - F(entry["skew_reading"]))
    out["liquidity_deterioration"] = str(
        F(rec["liquidity_reading"]) - F(entry["liquidity_reading"])
    )
    return out


def process_call_period(rec, band_low, band_high):
    """call wing单期：Q3参与位置+convexity读数 + Q4存续状态直通。
    upside_convexity_reading＝raw_gamma直接passthrough（gamma即凸性幅度之仪表读数，
    非新增机制——三分判别不适用，数据搬运）。
    """
    moneyness = F(rec["moneyness"])
    out = dict(rec)
    out["tail_coverage_band_position"] = band_position(moneyness, band_low, band_high)
    out["upside_convexity_reading"] = str(F(rec["raw_gamma"]))
    return out


def bleed_integrity_check(periods):
    """Q5联合检验：bleed账本非降(单调不减)且未被降级(downgrade_flag恒False)。
    三分判别：类一（受控文本§2）——回引entity/input_schema.md §3判别表。
    """
    out_flags = []
    prev = F(0)
    for rec in periods:
        booked = F(rec["premium_bleed_booked"])
        non_decreasing = booked >= prev
        not_downgraded = not rec["premium_bleed_downgrade_flag"]
        out_flags.append(bool(non_decreasing and not_downgraded))
        prev = booked
    return out_flags


def run(input_path="entity/input_data.json"):
    data = load_input(input_path)
    assert data.get("_data_source") == "synthetic_hand_constructed", (
        "非人造数据源，拒绝执行（裁决1强制）"
    )

    put_wing = data["wings"]["put_wing"]
    call_wing = data["wings"]["call_wing"]

    put_low = F(put_wing["declared_basis"]["target_activation_band_low"])
    put_high = F(put_wing["declared_basis"]["target_activation_band_high"])
    call_low = F(call_wing["declared_basis"]["target_activation_band_low"])
    call_high = F(call_wing["declared_basis"]["target_activation_band_high"])

    put_entry = put_wing["periods"][0]

    put_out_periods = []
    for rec in put_wing["periods"]:
        put_out_periods.append(process_put_period(rec, put_entry, put_low, put_high))

    call_out_periods = []
    for rec in call_wing["periods"]:
        call_out_periods.append(process_call_period(rec, call_low, call_high))

    put_bleed_flags = bleed_integrity_check(put_wing["periods"])
    for i, flag in enumerate(put_bleed_flags):
        put_out_periods[i]["premium_bleed_integrity_check"] = flag

    call_bleed_flags = bleed_integrity_check(call_wing["periods"])
    for i, flag in enumerate(call_bleed_flags):
        call_out_periods[i]["premium_bleed_integrity_check"] = flag

    output = {
        "_data_source": data["_data_source"],
        "_declaration_ref": data["_declaration_ref"],
        "wings": {
            "put_wing": {
                "declared_basis": put_wing["declared_basis"],
                "periods": put_out_periods,
            },
            "call_wing": {
                "declared_basis": call_wing["declared_basis"],
                "periods": call_out_periods,
            },
        },
    }
    return output


if __name__ == "__main__":
    result = run()
    with open("entity/harness_output.json", "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
    print("harness run complete -> entity/harness_output.json")

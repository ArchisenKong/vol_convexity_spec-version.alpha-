#!/usr/bin/env python3
"""
三禁形核查（本对象特有D段附加断言，00A行101禁止误用条款）：
实体制品任何字段/断言不得出现：
  ① "唯一失效路径" 表述（作为entity自身操作性主张，而非引用源文条款本身）
  ② 自动触发规则（如 auto_trigger 字段被设为可执行触发器）
  ③ 硬阈值字段（未标注 parameter_slot_candidate 类型的数值判据字段）

基线来自 source_anchor_parse.py 的程序化解析结果，不使用人工转录字符串。
合规引述豁免：entity/input_schema.md 中以 Markdown 引用块（行首"> "）形式引用00A行101条款
原文的段落，不计入违规扫描对象（这是合规文档必须包含的引用，非entity自身主张）。
"""
import json
import re
import glob
import os

from source_anchor_parse import parse_anchor

ENTITY_DIR = "../entity"


def scannable_lines(filepath):
    """返回文件中非引用块（不以'> '开头）的行，用于扫描entity自身操作性主张。"""
    with open(filepath, "r", encoding="utf-8") as f:
        lines = f.readlines()
    return [(i + 1, l) for i, l in enumerate(lines) if not l.strip().startswith(">")]


def check_unique_failure_path_claim(filepath):
    """检查'唯一失效路径'是否作为entity自身操作性主张出现（非引用块内）。"""
    violations = []
    for lineno, line in scannable_lines(filepath):
        if "唯一失效路径" in line:
            violations.append((filepath, lineno, line.strip()))
    return violations


def check_auto_trigger(filepath):
    """检查'自动触发'是否伴随可执行触发字段（如 auto_trigger: true / auto_trigger_rule 赋值为真）。"""
    violations = []
    for lineno, line in scannable_lines(filepath):
        if "自动触发" in line:
            violations.append((filepath, lineno, line.strip()))
        if re.search(r'"auto_trigger[_a-z]*"\s*:\s*true', line, re.IGNORECASE):
            violations.append((filepath, lineno, line.strip()))
    return violations


def check_hard_threshold_json(filepath):
    """扫描JSON文件：任何以'threshold'或'阈值'命名的字段，须位于标注type=parameter_slot_candidate
    的对象内部，否则判为未标注硬阈值。"""
    violations = []
    if not filepath.endswith(".json"):
        return violations
    with open(filepath, "r", encoding="utf-8") as f:
        data = json.load(f)

    def walk(obj, path=""):
        if isinstance(obj, dict):
            keys_lower = {k.lower(): k for k in obj.keys()}
            is_candidate_labeled = obj.get("type") == "parameter_slot_candidate"
            for k, v in obj.items():
                kl = k.lower()
                if ("threshold" in kl or "阈值" in k) and not isinstance(v, (dict,)):
                    if not is_candidate_labeled:
                        violations.append((filepath, f"{path}.{k}", "疑似未标注parameter_slot_candidate的阈值字段"))
                walk(v, f"{path}.{k}")
        elif isinstance(obj, list):
            for i, v in enumerate(obj):
                walk(v, f"{path}[{i}]")

    walk(data)
    return violations


def run():
    anchor = parse_anchor()  # 触发源文基线解析（含关键词齐备断言）

    targets = []
    for ext in ("*.md", "*.json", "*.py"):
        targets.extend(glob.glob(os.path.join(ENTITY_DIR, ext)))

    all_violations = []
    for fp in targets:
        if fp.endswith(".md") or fp.endswith(".py"):
            all_violations += check_unique_failure_path_claim(fp)
            all_violations += check_auto_trigger(fp)
        if fp.endswith(".json"):
            all_violations += check_hard_threshold_json(fp)

    return anchor, all_violations, targets


def main():
    anchor, violations, targets = run()
    print(f"扫描文件（entity/）：{targets}")
    print(f"基线来源：源文第{anchor['line_number']}行，程序化解析（非人工转录）")
    if violations:
        print("three_forbidden_forms_check: FAIL")
        for v in violations:
            print("  违规：", v)
        raise SystemExit(1)
    else:
        print("three_forbidden_forms_check: OK（无唯一失效路径主张／无自动触发规则／无未标注硬阈值）")


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""
D段② 独立实现复算（路径独立硬要求：不复用 entity/harness.py 的代码或思路）。

族P：不用逐步累加构造路径，改用三角波闭式（t mod 单周期长度 的分段线性公式）直接求值；
     crossing_count 改用 itertools.groupby 对区域状态序列分组、数组数-1 求转移次数；
     rv_proxy 改用三角波解析不变量（全部步长恒等于 leg_step）之总变差/步数 公式，
     不对逐步差值做累加式复算。
族Q：不用 math.sin 直接求值，改用 cmath 复指数 Im(e^{iθ}) 求路径；
     rv_proxy 改用积化和差恒等式 sin(a)-sin(b)=2cos((a+b)/2)sin((a-b)/2) 计算步长，
     不对两次 sin 求值直接相减。
crossing_count 与族P共用 groupby 方法（verify.py 自身一致方法，与 harness.py 的状态转移
计数循环为不同代码路径，满足"结构上distinct code paths"）。

[v1.1修复（裁决34-B2，外审D-7建议(a)(c)+裁决34-C1并入项）新增：
 1. zone_state() 由原逐字符复制改为各自独立重写（带符号越界余量法），消除C1/C2协同变异
    全逃逸缺陷。
 2. classify_independent() 新增：分类结果（三元组）纳入独立复算，消除E10/E11变异逃逸
    （原实现只复算rv_proxy/crossing_count等底层数值，未复算分类结果本身）。
 3. 族B（边界触碰折返）独立生成：itertools.cycle切片风格，消解E2型边界读法结构性不可判。
仅标准库：json, cmath, math, itertools, fractions。不接任何数据源。]
"""
import json
import cmath
import math
import itertools
from fractions import Fraction

PARAMS_PATH = "../entity/input_params.json"
OUTPUT_PATH = "independent_recompute_output.json"


def load_params():
    with open(PARAMS_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def zone_state(S, K_low, K_high):
    """与 entity/harness.py 之 zone_state 各自独立重写（裁决34-C1并入项，消除v1.0两侧
    逐字符复制、致协同变异C1/C2全逃逸之缺陷）：以带符号越界余量代替双重if-直接比较，
    表达式结构不同、逻辑对当前候选读法（'>'/'<' 严格排他）等价。"""
    above_margin = S - K_high
    below_margin = K_low - S
    if above_margin > 0:
        return "out_above"
    if below_margin > 0:
        return "out_below"
    return "in"


def crossing_count_groupby(path, K_low, K_high):
    """groupby分组法：把区域状态序列分为连续同值组，转移次数＝组数-1（结构不同于harness的逐点循环计数）。"""
    states = [zone_state(S, K_low, K_high) for S in path]
    groups = [k for k, _ in itertools.groupby(states)]
    return len(groups) - 1


def gen_triangular_closed_form(p):
    """通用三角波闭式重构（族P/O/Z共用）：以 t mod full_period 分段线性公式直接求值，不做逐步累加。"""
    S0 = Fraction(p["S0"])
    step = Fraction(p["leg_step"])
    leg_len = p["leg_length_steps"]
    cycles = p["num_full_cycles"]
    full_period = 4 * leg_len  # up, down, down, up 四段

    def S_at(t):
        r = t % full_period
        if r < leg_len:
            return S0 + step * r
        elif r < 2 * leg_len:
            return S0 + step * leg_len - step * (r - leg_len)
        elif r < 3 * leg_len:
            return S0 - step * (r - 2 * leg_len)
        else:
            return S0 - step * leg_len + step * (r - 3 * leg_len)

    n_total = cycles * full_period
    return [S_at(t) for t in range(n_total + 1)]


def gen_path_P_closed_form(params):
    return gen_triangular_closed_form(params["path_family_P_triangular"])


def rv_proxy_triangular_analytic(p):
    """通用三角波解析不变量（族P/O/Z共用）：全部步长恒等于leg_step（结构性质，非逐点复算），
    total_variation = num_legs * leg_length * leg_step; mean_step = total_variation / num_steps。"""
    S0 = Fraction(p["S0"])
    step = Fraction(p["leg_step"])
    leg_len = p["leg_length_steps"]
    cycles = p["num_full_cycles"]
    num_legs = 4 * cycles
    num_steps = num_legs * leg_len
    total_variation = num_legs * leg_len * step
    mean_step = total_variation / num_steps
    return mean_step / S0


def rv_proxy_P_analytic(params):
    return rv_proxy_triangular_analytic(params["path_family_P_triangular"])


def gen_path_monotonic_iterative(p):
    """族N迭代累加版（与harness.py之闭式乘法 S0+step*t 结构相反，保持路径独立）。"""
    S0 = Fraction(p["S0"])
    step = Fraction(p["step_size"])
    n = p["num_steps"]
    path = [S0]
    cur = S0
    for _ in range(n):
        cur = cur + step
        path.append(cur)
    return path


def rv_proxy_monotonic_analytic(p):
    """族N解析不变量：单调趋势全部步长恒等于step_size（结构性质，非逐点复算）。"""
    S0 = Fraction(p["S0"])
    step = Fraction(p["step_size"])
    return step / S0


def gen_path_boundary_bounce_cycle(p, K_low, K_high):
    """族B独立复算（修复(c)）：以 itertools.islice(itertools.cycle(...)) 切片生成交替目标点
    序列，一次性拼接列表；与 entity/harness.py 之 for 循环逐步 append 赋值结构不同（路径独立）。"""
    S0 = Fraction(p["S0"])
    n = p["num_bounces"]
    targets = list(itertools.islice(itertools.cycle([Fraction(K_high), Fraction(K_low)]), n))
    return [S0] + targets


def rv_proxy_boundary_bounce_analytic(p, K_low, K_high):
    """族B解析式复算：路径由n个交替跳变构成，前1步幅度=|K_high-S0|，其余(n-1)步幅度交替
    等于满幅|K_high-K_low|（结构性质，非逐点差值累加复算）。"""
    S0 = Fraction(p["S0"])
    n = p["num_bounces"]
    Kh = Fraction(K_high)
    Kl = Fraction(K_low)
    first_step = abs(Kh - S0)
    full_swing = abs(Kh - Kl)
    total_variation = first_step + (n - 1) * full_swing
    mean_step = total_variation / n
    return mean_step / S0


def gen_path_Q_euler(params):
    """族Q以复指数 Im(e^{iθ}) 求值，不直接调用 math.sin。"""
    p = params["path_family_Q_sinusoidal"]
    S0 = p["S0"]
    A = p["amplitude"]
    period = p["period_steps"]
    n = p["num_steps"]
    path = []
    for t in range(n + 1):
        angle = 2.0 * math.pi * t / period
        S = S0 + A * cmath.exp(complex(0, angle)).imag
        path.append(S)
    return path


def rv_proxy_Q_trig_identity_full(params):
    """族Q步长以积化和差恒等式求值：sin(a)-sin(b)=2cos((a+b)/2)sin((a-b)/2)，
    不对两次sin求值做直接相减（与harness.py"直接相减"思路结构不同）。"""
    p = params["path_family_Q_sinusoidal"]
    S0 = p["S0"]
    A = p["amplitude"]
    period = p["period_steps"]
    n = p["num_steps"]
    steps = []
    for t in range(n):
        a = 2.0 * math.pi * (t + 1) / period
        b = 2.0 * math.pi * t / period
        # sin(a) - sin(b) = 2*cos((a+b)/2)*sin((a-b)/2)
        diff = 2.0 * math.cos((a + b) / 2.0) * math.sin((a - b) / 2.0)
        steps.append(abs(A * diff))
    mean_step = sum(steps) / len(steps)
    return mean_step / S0


def classify_independent(rv_proxy_value, cross_count, candidates):
    """修复动作(a)（裁决34-B2）：classify()独立复算，消除v1.0之输出本体零验证（外审E10/E11
    两例逃逸根因＝independent_recompute.py原未复算分类结果，仅复算rv_proxy/crossing_count
    底层数值）。与 entity/harness.py 之 classify() 各自独立实现：布尔判据以De Morgan恒等式
    改写（不等价的字面运算符，等价的逻辑真值）——'<=' 改写为 'not(... > ...)'、
    '>=' 改写为 'not(... < ...)'、'and' 改写为 'not(not X or not Y)'，结构不同、不共用同一
    比较/联结运算符字面量，故 harness.py 侧 '<='→'>=' 或 'and'→'or' 之类变异不会同步影响本
    函数（比照T3-18修复先例verify/independent_recompute.py之'not(delta>threshold)'改写风格）。"""
    low_iv_thr = candidates["low_iv_rv_proxy_threshold_candidate"]["value"]
    osc_thr = candidates["oscillation_crossing_count_threshold_candidate"]["value"]
    low_iv_hit = not (float(rv_proxy_value) > low_iv_thr)
    osc_hit = not (cross_count < osc_thr)
    definition_feature = not (not low_iv_hit or not osc_hit)
    return {
        "low_iv_candidate_satisfied": low_iv_hit,
        "oscillation_candidate_satisfied": osc_hit,
        "definition_feature_satisfied_illustrative": definition_feature,
    }


def main():
    params = load_params()
    zone = params["short_end_obligation_zone"]
    K_low, K_high = zone["K_low"], zone["K_high"]
    candidates = params["classification_candidates"]

    # 族P
    path_P = gen_path_P_closed_form(params)
    cc_P = crossing_count_groupby(path_P, K_low, K_high)
    rv_P = rv_proxy_P_analytic(params)
    cls_P = classify_independent(rv_P, cc_P, candidates)

    # 族Q
    path_Q = gen_path_Q_euler(params)
    cc_Q = crossing_count_groupby(path_Q, K_low, K_high)
    rv_Q = rv_proxy_Q_trig_identity_full(params)
    cls_Q = classify_independent(rv_Q, cc_Q, candidates)

    # 族O
    path_O = gen_triangular_closed_form(params["path_family_O_far_low_amplitude"])
    cc_O = crossing_count_groupby(path_O, K_low, K_high)
    rv_O = rv_proxy_triangular_analytic(params["path_family_O_far_low_amplitude"])
    cls_O = classify_independent(rv_O, cc_O, candidates)

    # 族Z
    path_Z = gen_triangular_closed_form(params["path_family_Z_large_amplitude"])
    cc_Z = crossing_count_groupby(path_Z, K_low, K_high)
    rv_Z = rv_proxy_triangular_analytic(params["path_family_Z_large_amplitude"])
    cls_Z = classify_independent(rv_Z, cc_Z, candidates)

    # 族N
    path_N = gen_path_monotonic_iterative(params["path_family_N_monotonic_trend"])
    cc_N = crossing_count_groupby(path_N, K_low, K_high)
    rv_N = rv_proxy_monotonic_analytic(params["path_family_N_monotonic_trend"])
    cls_N = classify_independent(rv_N, cc_N, candidates)

    # 族B（修复动作(c)新增：边界触碰折返）
    path_B = gen_path_boundary_bounce_cycle(params["path_family_B_boundary_touch_bounce"], K_low, K_high)
    cc_B = crossing_count_groupby(path_B, K_low, K_high)
    rv_B = rv_proxy_boundary_bounce_analytic(params["path_family_B_boundary_touch_bounce"], K_low, K_high)
    cls_B = classify_independent(rv_B, cc_B, candidates)

    def pack(path, cc, rv, cls):
        return {"path": [str(x) for x in path], "crossing_count": cc, "rv_proxy": str(rv),
                "rv_proxy_float": float(rv), "classification": cls}

    output = {
        "path_P_triangular": pack(path_P, cc_P, rv_P, cls_P),
        "path_Q_sinusoidal": {
            "path": path_Q,
            "crossing_count": cc_Q,
            "rv_proxy": rv_Q,
            "classification": cls_Q,
        },
        "path_O_far_low_amplitude": pack(path_O, cc_O, rv_O, cls_O),
        "path_Z_large_amplitude": pack(path_Z, cc_Z, rv_Z, cls_Z),
        "path_N_monotonic_trend": pack(path_N, cc_N, rv_N, cls_N),
        "path_B_boundary_touch_bounce": pack(path_B, cc_B, rv_B, cls_B),
    }
    with open(OUTPUT_PATH, "w", encoding="utf-8") as f:
        json.dump(output, f, ensure_ascii=False, indent=2)

    print("independent_recompute_run: OK")
    print(f"P: crossing_count={cc_P} rv_proxy={rv_P}={float(rv_P):.6f} classification={cls_P}")
    print(f"Q: crossing_count={cc_Q} rv_proxy={rv_Q:.6f} classification={cls_Q}")
    print(f"O: crossing_count={cc_O} rv_proxy={rv_O}={float(rv_O):.6f} classification={cls_O}")
    print(f"Z: crossing_count={cc_Z} rv_proxy={rv_Z}={float(rv_Z):.6f} classification={cls_Z}")
    print(f"N: crossing_count={cc_N} rv_proxy={rv_N}={float(rv_N):.6f} classification={cls_N}")
    print(f"B: crossing_count={cc_B} rv_proxy={rv_B}={float(rv_B):.6f} classification={cls_B}")


if __name__ == "__main__":
    main()

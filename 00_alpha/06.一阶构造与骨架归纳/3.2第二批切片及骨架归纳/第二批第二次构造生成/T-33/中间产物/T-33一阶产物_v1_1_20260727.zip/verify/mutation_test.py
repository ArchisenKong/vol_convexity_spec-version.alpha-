#!/usr/bin/env python3
"""
变异注入测试（三层检验之第三层：reproduction run / path independence 已由 harness+
independent_recompute 满足，本脚本补第三层）。直接调用 assert_check.py 中的比对器函数
（bit_exact_equal / relative_diff_le）——此处允许复用，因测试对象是"比对器本身有无咬合力"，
不是D段②的独立复算（D段②独立性要求见 independent_recompute.py，与本测试目的不同）。

四组变异：
M1 族P crossing_count 破坏（+1）→ 应判不等
M2 族Q rv_proxy 破坏（+1e-6，超出1e-12容差）→ 应判不等
M3 族P path 单点破坏（第一个点+1）→ 逐点bit-exact比对应判不等
M4 对照组：全部未破坏 → 应判相等（防比对器恒假）
"""
import sys
import json

from assert_check import bit_exact_equal, relative_diff_le


def main():
    results = []

    with open("../entity/harness_output.json", "r", encoding="utf-8") as f:
        h = json.load(f)
    with open("independent_recompute_output.json", "r", encoding="utf-8") as f:
        v = json.load(f)

    # M1: crossing_count破坏
    corrupted_cc = str(h["path_P_triangular"]["crossing_count"] + 1)
    m1_detect = not bit_exact_equal(corrupted_cc, str(v["path_P_triangular"]["crossing_count"]))
    results.append(("M1_crossing_count_corruption_detected", m1_detect,
                     f"corrupted={corrupted_cc} true_verify={v['path_P_triangular']['crossing_count']}"))

    # M2: rv_proxy破坏（族Q，超出容差）
    corrupted_rv = h["path_Q_sinusoidal"]["rv_proxy"] + 1e-6
    ok, diff = relative_diff_le(corrupted_rv, v["path_Q_sinusoidal"]["rv_proxy"])
    m2_detect = not ok
    results.append(("M2_rv_proxy_corruption_detected", m2_detect, f"rel_diff={diff:.3e}（应>1e-12）"))

    # M3: path单点破坏
    corrupted_path = list(h["path_P_triangular"]["path"])
    # 破坏第一个点：字符串形式的Fraction，构造一个不同值
    corrupted_path[0] = "999"
    m3_detect = corrupted_path != v["path_P_triangular"]["path"]
    results.append(("M3_path_point_corruption_detected", m3_detect,
                     f"corrupted_first={corrupted_path[0]} true_first={v['path_P_triangular']['path'][0]}"))

    # M4: 对照组，未破坏应判相等
    m4_cc_equal = bit_exact_equal(str(h["path_P_triangular"]["crossing_count"]), str(v["path_P_triangular"]["crossing_count"]))
    m4_rv_ok, m4_diff = relative_diff_le(h["path_Q_sinusoidal"]["rv_proxy"], v["path_Q_sinusoidal"]["rv_proxy"])
    m4_pass = m4_cc_equal and m4_rv_ok
    results.append(("M4_control_group_no_false_positive", m4_pass, f"cc_equal={m4_cc_equal} rv_ok={m4_rv_ok}(diff={m4_diff:.3e})"))

    print("变异注入测试结果：")
    all_pass = True
    for name, passed, detail in results:
        status = "PASS" if passed else "FAIL"
        print(f"  [{status}] {name}  {detail}")
        if not passed:
            all_pass = False

    if all_pass:
        print("mutation_test: ALL PASS（比对器对破坏样本正确判不等，对未破坏样本正确判相等——比对器具备真实咬合力）")
        sys.exit(0)
    else:
        print("mutation_test: FAIL（比对器咬合力不足或对照组假阳性）")
        sys.exit(1)


if __name__ == "__main__":
    main()

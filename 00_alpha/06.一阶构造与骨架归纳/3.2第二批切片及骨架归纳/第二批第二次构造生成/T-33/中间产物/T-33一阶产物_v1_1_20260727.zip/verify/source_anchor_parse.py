#!/usr/bin/env python3
"""
断言基线程序化解析源文（00A行101）：直接读取源文件，按表格行结构定位"低 IV 震荡磨损路径"，
抽取其定义列与"禁止误用"列原文，不复用任何一侧的人工转录（裁决28-B断言(i)/开启文本D段附加断言要求）。
"""
import re
import json

SOURCE_PATH = "/mnt/project/2_波动率凸性策略可复用方法论文档集_12篇_T0_frozen_clean_20260615.md"
TARGET_TERM = "低 IV 震荡磨损路径"


def parse_anchor():
    with open(SOURCE_PATH, "r", encoding="utf-8") as f:
        lines = f.readlines()

    for idx, line in enumerate(lines, start=1):
        if line.strip().startswith("|") and TARGET_TERM in line:
            # markdown table row: | 术语 | 本文含义 | 禁止误用 |
            cells = [c.strip() for c in line.strip().strip("|").split("|")]
            if len(cells) >= 3:
                term, definition, prohibition = cells[0], cells[1], cells[2]
                return {
                    "line_number": idx,
                    "term": term,
                    "definition_text": definition,
                    "prohibition_text": prohibition,
                }
    raise RuntimeError(f"未在源文中定位到 '{TARGET_TERM}' 表格行——断言基线解析失败")


def main():
    anchor = parse_anchor()
    assert anchor["line_number"] == 101, \
        f"行号锚点不符：解析到第{anchor['line_number']}行，预期101行——源文可能已变动，须停并呈报"

    required_terms = ["唯一失效路径", "自动触发规则", "硬阈值", "parameter_slot_candidate"]
    missing = [t for t in required_terms if t not in anchor["prohibition_text"]]
    assert not missing, f"禁止误用条款原文缺失关键词：{missing}——源文可能已变动"

    print(json.dumps(anchor, ensure_ascii=False, indent=2))
    print("source_anchor_00A_line101_programmatic_parse: OK")
    return anchor


if __name__ == "__main__":
    main()

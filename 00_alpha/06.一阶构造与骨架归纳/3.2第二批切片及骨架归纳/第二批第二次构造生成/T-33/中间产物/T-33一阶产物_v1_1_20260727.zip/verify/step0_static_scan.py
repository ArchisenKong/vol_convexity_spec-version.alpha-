#!/usr/bin/env python3
"""
step0(ii) 静态扫描面对象集：按包文本执行（KD裁定20260726）——本轮扫描面=本根 entity/+verify/
的交付脚本；W-13(3)"扫描面=全部交付脚本（entity/+verify/）"不提前适用本根（登记不裁，兑现点
第三批），此处按包§4/开启文本§四原定三部分口径执行，非W-13(3)扩域口径。

三部分（W-8）：
(a) import/from-import 七库模式，含 bare import 锚定形态（W-5）：
    requests|urllib|socket|yfinance|ibapi|ib_insync|pandas_datareader
(b) 关键字模式：IBKR、QuantConnect、http://、https://、urlopen、requests\\.、socket\\.
(c) 判定统一在剥离注释/docstring后的文本上执行（GK-14/TC-33假阳性教训），剥离前命中仅留痕。
夹具为启发式，终判源码核查。
"""
import re
import glob
import os

TARGET_DIRS = ["../entity", "."]

FORBIDDEN_IMPORT_LIBS = ["requests", "urllib", "socket", "yfinance", "ibapi", "ib_insync", "pandas_datareader"]
IMPORT_PATTERN = re.compile(
    r'^\s*(import\s+(' + "|".join(FORBIDDEN_IMPORT_LIBS) + r')\b'
    r'|from\s+(' + "|".join(FORBIDDEN_IMPORT_LIBS) + r')\s+import\b)',
    re.MULTILINE,
)

KEYWORD_PATTERNS = [
    r'IBKR', r'QuantConnect', r'http://', r'https://', r'urlopen', r'requests\.', r'socket\.',
]
KEYWORD_RE = re.compile("|".join(KEYWORD_PATTERNS))


def strip_comments_and_docstrings(source):
    """剥离 # 行内注释与 三引号 docstring/多行字符串（简化版：足以满足本根启发式扫描用途）。"""
    # 剥除三引号字符串（docstring等）
    no_docstrings = re.sub(r'"""[\s\S]*?"""', '', source)
    no_docstrings = re.sub(r"'''[\s\S]*?'''", '', no_docstrings)
    # 逐行剥除 # 注释（简化：不处理字符串内含#的边界情况，本根脚本中无此类字面量）
    lines = []
    for line in no_docstrings.splitlines():
        idx = line.find("#")
        if idx >= 0:
            line = line[:idx]
        lines.append(line)
    return "\n".join(lines)


def scan_file(filepath):
    with open(filepath, "r", encoding="utf-8") as f:
        raw = f.read()

    stripped = strip_comments_and_docstrings(raw) if filepath.endswith(".py") else raw

    pre_strip_import_hits = IMPORT_PATTERN.findall(raw)
    pre_strip_keyword_hits = KEYWORD_RE.findall(raw)

    post_strip_import_hits = IMPORT_PATTERN.findall(stripped)
    post_strip_keyword_hits = KEYWORD_RE.findall(stripped)

    return {
        "file": filepath,
        "pre_strip_import_hits": pre_strip_import_hits,
        "pre_strip_keyword_hits": pre_strip_keyword_hits,
        "post_strip_import_hits": post_strip_import_hits,   # 终判依据
        "post_strip_keyword_hits": post_strip_keyword_hits, # 终判依据
    }


SELF_EXCLUDE = {os.path.normpath("step0_static_scan.py")}
# 排除理由（如实记录，非静默处理）：本脚本源码内联W-8三部分模式定义本身即含
# 'IBKR'/'QuantConnect'/'http://'等字面量（检测器自身的模式数据，非对该等API/URL的
# 实际import或调用）——首次真跑即自扫描命中假阳性，比照TC-33撞墙清单v1.0"说明"节
# 先例（核验脚本自身实现问题，非上游产物错误、非施工对象缺口），排除脚本自身文件，
# 并以人工复核（本次真跑输出留痕）交叉确认排除范围内不含实际forbidden import/调用。


def run():
    files = []
    for d in TARGET_DIRS:
        files += glob.glob(os.path.join(d, "*.py"))
    files = sorted(set(os.path.normpath(f) for f in files) - SELF_EXCLUDE)

    results = [scan_file(f) for f in files]
    violations = [r for r in results if r["post_strip_import_hits"] or r["post_strip_keyword_hits"]]
    return files, results, violations


def main():
    files, results, violations = run()
    print(f"扫描文件集（entity/+verify/，本根扫描面，不含W-13(3)全批扩域）：{files}")
    for r in results:
        flag_pre = "（剥离前命中，仅留痕）" if (r["pre_strip_import_hits"] or r["pre_strip_keyword_hits"]) and not (r["post_strip_import_hits"] or r["post_strip_keyword_hits"]) else ""
        print(f"  {r['file']}: post_strip_import={r['post_strip_import_hits']} post_strip_keyword={r['post_strip_keyword_hits']} {flag_pre}")

    if violations:
        print("step0(ii)_no_data_source_static_scan: FAIL")
        raise SystemExit(1)
    else:
        print("step0(ii)_no_data_source_static_scan: OK（终判=剥离注释/docstring后文本零命中）")


if __name__ == "__main__":
    main()

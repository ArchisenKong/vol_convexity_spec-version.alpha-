#!/usr/bin/env python3
"""
D段② 独立实现复算（路径独立硬要求：不复用 entity/harness.py 的代码或思路）。

族P：不用逐步累加构造路径，改用三角波闭式（t mod 单周期长度 的分段线性公式）直接求值；
     crossing_count 改用 itertools.groupby 对区域状态序列分组、数组数-1 求转移次数；
     rv_proxy 改用三角波解析不变量（全部步长恒等于 leg_step）之总变差/步数 公式，
     不对逐步差值做累加式复算。
族Q：不用 math.sin 直接求值，改用 cmath 复指数 Im(e^{iθ}) 求路径；
     rv_proxy 改用积化和差恒等式 sin(a)-sin(b)=2cos((a+b)/2)sin((a-b)/2) 计算步长，
     不对两次 sin 求值直接相减。
crossing_count 与族P共用 groupby 方法（verify.py 自身一致方法，与 harness.py 的状态转移
计数循环为不同代码路径，满足"结构上distinct code paths"）。

仅标准库：json, cmath, math, itertools, fractions。不接任何数据源。
"""
import json
import cmath
import math
import itertools
from fractions import Fraction

PARAMS_PATH = "../entity/input_params.json"
OUTPUT_PATH = "independent_recompute_output.json"


def load_params():
    with open(PARAMS_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def zone_state(S, K_low, K_high):
    if S > K_high:
        return "out_above"
    if S < K_low:
        return "out_below"
    return "in"


def crossing_count_groupby(path, K_low, K_high):
    """groupby分组法：把区域状态序列分为连续同值组，转移次数＝组数-1（结构不同于harness的逐点循环计数）。"""
    states = [zone_state(S, K_low, K_high) for S in path]
    groups = [k for k, _ in itertools.groupby(states)]
    return len(groups) - 1


def gen_triangular_closed_form(p):
    """通用三角波闭式重构（族P/O/Z共用）：以 t mod full_period 分段线性公式直接求值，不做逐步累加。"""
    S0 = Fraction(p["S0"])
    step = Fraction(p["leg_step"])
    leg_len = p["leg_length_steps"]
    cycles = p["num_full_cycles"]
    full_period = 4 * leg_len  # up, down, down, up 四段

    def S_at(t):
        r = t % full_period
        if r < leg_len:
            return S0 + step * r
        elif r < 2 * leg_len:
            return S0 + step * leg_len - step * (r - leg_len)
        elif r < 3 * leg_len:
            return S0 - step * (r - 2 * leg_len)
        else:
            return S0 - step * leg_len + step * (r - 3 * leg_len)

    n_total = cycles * full_period
    return [S_at(t) for t in range(n_total + 1)]


def gen_path_P_closed_form(params):
    return gen_triangular_closed_form(params["path_family_P_triangular"])


def rv_proxy_triangular_analytic(p):
    """通用三角波解析不变量（族P/O/Z共用）：全部步长恒等于leg_step（结构性质，非逐点复算），
    total_variation = num_legs * leg_length * leg_step; mean_step = total_variation / num_steps。"""
    S0 = Fraction(p["S0"])
    step = Fraction(p["leg_step"])
    leg_len = p["leg_length_steps"]
    cycles = p["num_full_cycles"]
    num_legs = 4 * cycles
    num_steps = num_legs * leg_len
    total_variation = num_legs * leg_len * step
    mean_step = total_variation / num_steps
    return mean_step / S0


def rv_proxy_P_analytic(params):
    return rv_proxy_triangular_analytic(params["path_family_P_triangular"])


def gen_path_monotonic_iterative(p):
    """族N迭代累加版（与harness.py之闭式乘法 S0+step*t 结构相反，保持路径独立）。"""
    S0 = Fraction(p["S0"])
    step = Fraction(p["step_size"])
    n = p["num_steps"]
    path = [S0]
    cur = S0
    for _ in range(n):
        cur = cur + step
        path.append(cur)
    return path


def rv_proxy_monotonic_analytic(p):
    """族N解析不变量：单调趋势全部步长恒等于step_size（结构性质，非逐点复算）。"""
    S0 = Fraction(p["S0"])
    step = Fraction(p["step_size"])
    return step / S0


def gen_path_Q_euler(params):
    """族Q以复指数 Im(e^{iθ}) 求值，不直接调用 math.sin。"""
    p = params["path_family_Q_sinusoidal"]
    S0 = p["S0"]
    A = p["amplitude"]
    period = p["period_steps"]
    n = p["num_steps"]
    path = []
    for t in range(n + 1):
        angle = 2.0 * math.pi * t / period
        S = S0 + A * cmath.exp(complex(0, angle)).imag
        path.append(S)
    return path


def rv_proxy_Q_trig_identity_full(params):
    """族Q步长以积化和差恒等式求值：sin(a)-sin(b)=2cos((a+b)/2)sin((a-b)/2)，
    不对两次sin求值做直接相减（与harness.py"直接相减"思路结构不同）。"""
    p = params["path_family_Q_sinusoidal"]
    S0 = p["S0"]
    A = p["amplitude"]
    period = p["period_steps"]
    n = p["num_steps"]
    steps = []
    for t in range(n):
        a = 2.0 * math.pi * (t + 1) / period
        b = 2.0 * math.pi * t / period
        # sin(a) - sin(b) = 2*cos((a+b)/2)*sin((a-b)/2)
        diff = 2.0 * math.cos((a + b) / 2.0) * math.sin((a - b) / 2.0)
        steps.append(abs(A * diff))
    mean_step = sum(steps) / len(steps)
    return mean_step / S0


def main():
    params = load_params()
    zone = params["short_end_obligation_zone"]
    K_low, K_high = zone["K_low"], zone["K_high"]

    # 族P
    path_P = gen_path_P_closed_form(params)
    cc_P = crossing_count_groupby(path_P, K_low, K_high)
    rv_P = rv_proxy_P_analytic(params)

    # 族Q
    path_Q = gen_path_Q_euler(params)
    cc_Q = crossing_count_groupby(path_Q, K_low, K_high)
    rv_Q = rv_proxy_Q_trig_identity_full(params)

    # 族O
    path_O = gen_triangular_closed_form(params["path_family_O_far_low_amplitude"])
    cc_O = crossing_count_groupby(path_O, K_low, K_high)
    rv_O = rv_proxy_triangular_analytic(params["path_family_O_far_low_amplitude"])

    # 族Z
    path_Z = gen_triangular_closed_form(params["path_family_Z_large_amplitude"])
    cc_Z = crossing_count_groupby(path_Z, K_low, K_high)
    rv_Z = rv_proxy_triangular_analytic(params["path_family_Z_large_amplitude"])

    # 族N
    path_N = gen_path_monotonic_iterative(params["path_family_N_monotonic_trend"])
    cc_N = crossing_count_groupby(path_N, K_low, K_high)
    rv_N = rv_proxy_monotonic_analytic(params["path_family_N_monotonic_trend"])

    def pack(path, cc, rv):
        return {"path": [str(x) for x in path], "crossing_count": cc, "rv_proxy": str(rv), "rv_proxy_float": float(rv)}

    output = {
        "path_P_triangular": pack(path_P, cc_P, rv_P),
        "path_Q_sinusoidal": {
            "path": path_Q,
            "crossing_count": cc_Q,
            "rv_proxy": rv_Q,
        },
        "path_O_far_low_amplitude": pack(path_O, cc_O, rv_O),
        "path_Z_large_amplitude": pack(path_Z, cc_Z, rv_Z),
        "path_N_monotonic_trend": pack(path_N, cc_N, rv_N),
    }
    with open(OUTPUT_PATH, "w", encoding="utf-8") as f:
        json.dump(output, f, ensure_ascii=False, indent=2)

    print("independent_recompute_run: OK")
    print(f"P: crossing_count={cc_P} rv_proxy={rv_P}={float(rv_P):.6f}")
    print(f"Q: crossing_count={cc_Q} rv_proxy={rv_Q:.6f}")
    print(f"O: crossing_count={cc_O} rv_proxy={rv_O}={float(rv_O):.6f}")
    print(f"Z: crossing_count={cc_Z} rv_proxy={rv_Z}={float(rv_Z):.6f}")
    print(f"N: crossing_count={cc_N} rv_proxy={rv_N}={float(rv_N):.6f}")


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""
T-33 D段合格断言主脚本（三步顺序：step0前置合规 → 数值比对 → 附加断言）。
断言脚本整体判定归因文案不写死单一失败原因，按实际失败断言逐项输出（W-9(3)）。
任一断言失败＝脚本以非零退出码退出（裁决28-B(ii)／裁决30-A）。
"""
import json
import subprocess
import sys
import os

sys.path.insert(0, os.path.dirname(__file__))

RESULTS = []  # (assertion_name, passed: bool, detail: str)


def record(name, passed, detail=""):
    RESULTS.append((name, passed, detail))
    status = "PASS" if passed else "FAIL"
    print(f"[{status}] {name}  {detail}")


def bit_exact_equal(a_str, b_str):
    """Fraction字符串精确相等比较（族P，容差子口径a）。"""
    return a_str == b_str


def relative_diff_le(a, b, tol=1e-12):
    """相对diff<=tol比较（族Q，容差子口径b）。"""
    if a == 0 and b == 0:
        return True, 0.0
    denom = abs(a) if a != 0 else abs(b)
    diff = abs(a - b) / denom
    return diff <= tol, diff


def main():
    entity_dir = "../entity"

    # ---------- step0(i) input synthetic ----------
    with open(os.path.join(entity_dir, "input_params.json"), "r", encoding="utf-8") as f:
        params = json.load(f)
    record(
        "step0(i)_input_synthetic",
        params.get("_data_source") == "synthetic_hand_constructed",
        f"_data_source={params.get('_data_source')}",
    )

    # ---------- step0(ii) static scan ----------
    r = subprocess.run([sys.executable, "step0_static_scan.py"], capture_output=True, text=True)
    record("step0(ii)_no_data_source_static_scan", r.returncode == 0, r.stdout.strip().splitlines()[-1] if r.stdout else r.stderr)

    # ---------- step0(iii) harness真跑 + 独立复算真跑，且独立复算不复用harness代码 ----------
    r_h = subprocess.run([sys.executable, "harness.py"], cwd=entity_dir, capture_output=True, text=True)
    record("harness_real_run", r_h.returncode == 0, r_h.stdout.strip().splitlines()[-1] if r_h.stdout else r_h.stderr)

    r_v = subprocess.run([sys.executable, "independent_recompute.py"], capture_output=True, text=True)
    record("independent_recompute_run", r_v.returncode == 0, r_v.stdout.strip().splitlines()[-1] if r_v.stdout else r_v.stderr)

    with open(os.path.join(entity_dir, "harness.py"), "r", encoding="utf-8") as f:
        harness_src = f.read()
    with open("independent_recompute.py", "r", encoding="utf-8") as f:
        recompute_src = f.read()
    no_reuse = ("import harness" not in recompute_src) and ("from harness" not in recompute_src)
    record(
        "step0(iii)_independent_recompute_no_harness_reuse",
        no_reuse,
        "independent_recompute.py 未import harness模块，且gen_path_P_closed_form/gen_path_Q_euler/crossing_count_groupby/rv_proxy_P_analytic/rv_proxy_Q_trig_identity_full 均为harness.py之外的独立算法实现（见两文件docstring路径独立说明）",
    )

    # ---------- D段② 数值比对：容差二分派 ----------
    with open(os.path.join(entity_dir, "harness_output.json"), "r", encoding="utf-8") as f:
        h = json.load(f)
    with open("independent_recompute_output.json", "r", encoding="utf-8") as f:
        v = json.load(f)

    # 族P：全项bit-exact（容差子口径a，无超越函数）
    record(
        "numeric_compare_P_crossing_count_bit_exact",
        bit_exact_equal(str(h["path_P_triangular"]["crossing_count"]), str(v["path_P_triangular"]["crossing_count"])),
        f"harness={h['path_P_triangular']['crossing_count']} verify={v['path_P_triangular']['crossing_count']}",
    )
    record(
        "numeric_compare_P_rv_proxy_bit_exact",
        bit_exact_equal(h["path_P_triangular"]["rv_proxy"], v["path_P_triangular"]["rv_proxy"]),
        f"harness={h['path_P_triangular']['rv_proxy']} verify={v['path_P_triangular']['rv_proxy']}",
    )
    record(
        "numeric_compare_P_path_bit_exact",
        h["path_P_triangular"]["path"] == v["path_P_triangular"]["path"],
        f"path长度={len(h['path_P_triangular']['path'])}，逐点字符串相等={h['path_P_triangular']['path'] == v['path_P_triangular']['path']}",
    )

    # 族Q：crossing_count为离散计数，恒bit-exact；价格序列与rv_proxy为连续量，含超越函数，容差子口径b
    record(
        "numeric_compare_Q_crossing_count_bit_exact",
        bit_exact_equal(str(h["path_Q_sinusoidal"]["crossing_count"]), str(v["path_Q_sinusoidal"]["crossing_count"])),
        f"harness={h['path_Q_sinusoidal']['crossing_count']} verify={v['path_Q_sinusoidal']['crossing_count']}（离散计数，不因族Q价格生成含超越函数而放宽）",
    )
    ok, diff = relative_diff_le(h["path_Q_sinusoidal"]["rv_proxy"], v["path_Q_sinusoidal"]["rv_proxy"])
    record(
        "numeric_compare_Q_rv_proxy_relative_1e-12",
        ok,
        f"harness={h['path_Q_sinusoidal']['rv_proxy']} verify={v['path_Q_sinusoidal']['rv_proxy']} rel_diff={diff:.3e}（容差子口径b，超越函数在场）",
    )
    path_max_rel = 0.0
    for a, b in zip(h["path_Q_sinusoidal"]["path"], v["path_Q_sinusoidal"]["path"]):
        ok_pt, d = relative_diff_le(a, b)
        path_max_rel = max(path_max_rel, d)
        if not ok_pt:
            break
    record(
        "numeric_compare_Q_path_relative_1e-12",
        path_max_rel <= 1e-12,
        f"逐点最大相对diff={path_max_rel:.3e}",
    )

    # 族O/Z/N：全部bit-exact（无超越函数）
    for fam in ["O_far_low_amplitude", "Z_large_amplitude", "N_monotonic_trend"]:
        key = f"path_{fam}"
        record(
            f"numeric_compare_{fam}_crossing_count_bit_exact",
            bit_exact_equal(str(h[key]["crossing_count"]), str(v[key]["crossing_count"])),
            f"harness={h[key]['crossing_count']} verify={v[key]['crossing_count']}",
        )
        record(
            f"numeric_compare_{fam}_rv_proxy_bit_exact",
            bit_exact_equal(h[key]["rv_proxy"], v[key]["rv_proxy"]),
            f"harness={h[key]['rv_proxy']} verify={v[key]['rv_proxy']}",
        )
        record(
            f"numeric_compare_{fam}_path_bit_exact",
            h[key]["path"] == v[key]["path"],
            f"path长度={len(h[key]['path'])}",
        )

    # ---------- EXP-002：复合布尔判据双向反例真值表覆盖（建议采纳，非合格判据） ----------
    truth_table = {}
    for fam_key in ["path_P_triangular", "path_Q_sinusoidal", "path_O_far_low_amplitude",
                     "path_Z_large_amplitude", "path_N_monotonic_trend"]:
        c = h[fam_key]["classification"]
        truth_table[fam_key] = (c["low_iv_candidate_satisfied"], c["oscillation_candidate_satisfied"])
    observed_combos = set(truth_table.values())
    expected_combos = {(True, True), (True, False), (False, True), (False, False)}
    record(
        "exp002_boolean_truth_table_full_coverage",
        observed_combos == expected_combos,
        f"观测组合={observed_combos}（族→组合映射：{truth_table}）",
    )

    # ---------- 三层检验第三层：变异注入测试 ----------
    r_mut = subprocess.run([sys.executable, "mutation_test.py"], capture_output=True, text=True)
    record("mutation_injection_test", r_mut.returncode == 0, r_mut.stdout.strip().splitlines()[-1] if r_mut.stdout else r_mut.stderr)

    # ---------- 三禁形核查 ----------
    r_3f = subprocess.run([sys.executable, "three_forbidden_forms_check.py"], capture_output=True, text=True)
    record("three_forbidden_forms_check", r_3f.returncode == 0, r_3f.stdout.strip().splitlines()[-1] if r_3f.stdout else r_3f.stderr)

    # ---------- 附加断言：schema齐备性 ----------
    with open(os.path.join(entity_dir, "input_schema.md"), "r", encoding="utf-8") as f:
        schema_md = f.read()
    record(
        "entity_carries_PB_registration_reference",
        "P_B注册记录" in schema_md and "要件3" in schema_md,
        "input_schema.md §8 含P_B注册记录要件3引用",
    )
    record(
        "entity_carries_data_source_field_declaration",
        "_data_source" in schema_md,
        "input_schema.md §9 含_data_source字段声明",
    )
    cand = params["classification_candidates"]
    cand_entries = {k: v for k, v in cand.items() if isinstance(v, dict) and "type" in v}
    record(
        "classification_thresholds_labeled_parameter_slot_candidate",
        len(cand_entries) >= 2 and all(v["type"] == "parameter_slot_candidate" for v in cand_entries.values()),
        f"候选字段：{list(cand_entries.keys())}",
    )

    # ---------- 汇总 ----------
    print()
    failed = [r for r in RESULTS if not r[1]]
    print(f"断言总数={len(RESULTS)}，通过={len(RESULTS) - len(failed)}，失败={len(failed)}")
    if failed:
        print("FAIL 明细（按实际失败断言输出，非单一归因）：")
        for name, _, detail in failed:
            print(f"  - {name}: {detail}")
        sys.exit(1)
    else:
        print("assert_check: ALL PASS, exit code = 0")
        sys.exit(0)


if __name__ == "__main__":
    main()

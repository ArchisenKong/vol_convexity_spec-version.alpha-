#!/usr/bin/env python3
"""
T-33 一次性 harness（真跑，非常设pipeline，裁决1强制：不接任何数据源）。
职能：读取 entity/input_params.json 的路径参数，生成族P（三角波，整数）与族Q（正弦，浮点）
两族路径数据，计算穿越短端义务区边界次数（crossing_count）与低IV代理度量（rv_proxy），
并按 classification_candidates 输出说明性分类结果（候选值，非冻结判据）。

不引入网络/数据源依赖；仅使用标准库。
"""
import json
import math
from fractions import Fraction

INPUT_PATH = "input_params.json"
OUTPUT_PATH = "harness_output.json"


def load_params():
    with open(INPUT_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def gen_triangular_path(p):
    """通用分段线性三角波生成（族P/O/Z共用参数结构），全程用 Fraction 精确有理数运算，
    避免任何浮点舍入（容差子口径a）。"""
    S0 = Fraction(p["S0"])
    step = Fraction(p["leg_step"])
    leg_len = p["leg_length_steps"]
    cycles = p["num_full_cycles"]

    path = [S0]
    cur = S0
    # 单周期：up(+step x leg_len) -> down(-step x leg_len) -> down(-step x leg_len) -> up(+step x leg_len)
    legs = ([1] * leg_len) + ([-1] * leg_len) + ([-1] * leg_len) + ([1] * leg_len)
    for _ in range(cycles):
        for sign in legs:
            cur = cur + sign * step
            path.append(cur)
    return path  # list[Fraction]


def gen_path_P(params):
    return gen_triangular_path(params["path_family_P_triangular"])


def gen_path_monotonic(p):
    """族N：单调趋势，纯Fraction整数运算（容差子口径a）。"""
    S0 = Fraction(p["S0"])
    step = Fraction(p["step_size"])
    n = p["num_steps"]
    return [S0 + step * t for t in range(n + 1)]


def gen_path_Q(params):
    """族Q：正弦振荡，S(t)=S0+A*sin(2*pi*t/period)，浮点（超越函数sin在场，容差子口径b）。"""
    p = params["path_family_Q_sinusoidal"]
    S0 = p["S0"]
    A = p["amplitude"]
    period = p["period_steps"]
    n = p["num_steps"]
    path = []
    for t in range(n + 1):
        angle = 2.0 * math.pi * t / period
        S = S0 + A * math.sin(angle)
        path.append(S)
    return path  # list[float]


def zone_state(S, K_low, K_high):
    """返回该价格点相对短端义务区的状态：'in' / 'out_above' / 'out_below'。"""
    if S > K_high:
        return "out_above"
    if S < K_low:
        return "out_below"
    return "in"


def crossing_count(path, K_low, K_high):
    """穿越短端义务区边界次数＝相邻点区域状态发生变化的次数（区域状态转移计数，harness自身实现）。"""
    states = [zone_state(S, K_low, K_high) for S in path]
    count = 0
    for i in range(1, len(states)):
        if states[i] != states[i - 1]:
            count += 1
    return count


def rv_proxy_P(path, S0):
    """族P低IV代理度量：均步幅 / S0（Fraction精确值）。"""
    steps = [abs(path[i + 1] - path[i]) for i in range(len(path) - 1)]
    mean_abs_step = sum(steps, Fraction(0)) / len(steps)
    return mean_abs_step / S0  # Fraction


def rv_proxy_Q(path, S0):
    """族Q低IV代理度量：均步幅 / S0（浮点，源自sin生成的连续路径）。"""
    steps = [abs(path[i + 1] - path[i]) for i in range(len(path) - 1)]
    mean_abs_step = sum(steps) / len(steps)
    return mean_abs_step / S0  # float


def classify(rv_proxy_value, cross_count, candidates):
    low_iv_thr = candidates["low_iv_rv_proxy_threshold_candidate"]["value"]
    osc_thr = candidates["oscillation_crossing_count_threshold_candidate"]["value"]
    low_iv_hit = float(rv_proxy_value) <= low_iv_thr
    osc_hit = cross_count >= osc_thr
    return {
        "low_iv_candidate_satisfied": low_iv_hit,
        "oscillation_candidate_satisfied": osc_hit,
        "definition_feature_satisfied_illustrative": bool(low_iv_hit and osc_hit),
    }


def main():
    params = load_params()
    assert params.get("_data_source") == "synthetic_hand_constructed", \
        "step0(i) 违规：input未标记synthetic_hand_constructed"

    zone = params["short_end_obligation_zone"]
    K_low, K_high = zone["K_low"], zone["K_high"]
    candidates = params["classification_candidates"]

    # 族P
    path_P = gen_path_P(params)
    cc_P = crossing_count(path_P, K_low, K_high)
    rv_P = rv_proxy_P(path_P, Fraction(params["path_family_P_triangular"]["S0"]))
    cls_P = classify(rv_P, cc_P, candidates)

    # 族Q
    path_Q = gen_path_Q(params)
    cc_Q = crossing_count(path_Q, K_low, K_high)
    rv_Q = rv_proxy_Q(path_Q, params["path_family_Q_sinusoidal"]["S0"])
    cls_Q = classify(rv_Q, cc_Q, candidates)

    # 族O（EXP-002反例：低IV但不震荡）
    path_O = gen_triangular_path(params["path_family_O_far_low_amplitude"])
    cc_O = crossing_count(path_O, K_low, K_high)
    rv_O = rv_proxy_P(path_O, Fraction(params["path_family_O_far_low_amplitude"]["S0"]))
    cls_O = classify(rv_O, cc_O, candidates)

    # 族Z（EXP-002反例：震荡但非低IV）
    path_Z = gen_triangular_path(params["path_family_Z_large_amplitude"])
    cc_Z = crossing_count(path_Z, K_low, K_high)
    rv_Z = rv_proxy_P(path_Z, Fraction(params["path_family_Z_large_amplitude"]["S0"]))
    cls_Z = classify(rv_Z, cc_Z, candidates)

    # 族N（EXP-002反例：两者皆非）
    path_N = gen_path_monotonic(params["path_family_N_monotonic_trend"])
    cc_N = crossing_count(path_N, K_low, K_high)
    rv_N = rv_proxy_P(path_N, Fraction(params["path_family_N_monotonic_trend"]["S0"]))
    cls_N = classify(rv_N, cc_N, candidates)

    def pack_bitexact(path, cc, rv, cls):
        return {
            "path": [str(x) for x in path],
            "path_float_display": [float(x) for x in path],
            "crossing_count": cc,
            "rv_proxy": str(rv),
            "rv_proxy_float": float(rv),
            "tolerance_class": "a_bit_exact",
            "classification": cls,
        }

    output = {
        "_data_source": "synthetic_hand_constructed",
        "path_P_triangular": pack_bitexact(path_P, cc_P, rv_P, cls_P),
        "path_Q_sinusoidal": {
            "path": path_Q,
            "crossing_count": cc_Q,
            "rv_proxy": rv_Q,
            "tolerance_class": "b_relative_1e-12",
            "classification": cls_Q,
        },
        "path_O_far_low_amplitude": pack_bitexact(path_O, cc_O, rv_O, cls_O),
        "path_Z_large_amplitude": pack_bitexact(path_Z, cc_Z, rv_Z, cls_Z),
        "path_N_monotonic_trend": pack_bitexact(path_N, cc_N, rv_N, cls_N),
        "zone": zone,
    }

    with open(OUTPUT_PATH, "w", encoding="utf-8") as f:
        json.dump(output, f, ensure_ascii=False, indent=2)

    print("harness_real_run: OK")
    print(f"P: crossing_count={cc_P} rv_proxy={rv_P}={float(rv_P):.6f} classification={cls_P}")
    print(f"Q: crossing_count={cc_Q} rv_proxy={rv_Q:.6f} classification={cls_Q}")
    print(f"O: crossing_count={cc_O} rv_proxy={rv_O}={float(rv_O):.6f} classification={cls_O}")
    print(f"Z: crossing_count={cc_Z} rv_proxy={rv_Z}={float(rv_Z):.6f} classification={cls_Z}")
    print(f"N: crossing_count={cc_N} rv_proxy={rv_N}={float(rv_N):.6f} classification={cls_N}")


if __name__ == "__main__":
    main()

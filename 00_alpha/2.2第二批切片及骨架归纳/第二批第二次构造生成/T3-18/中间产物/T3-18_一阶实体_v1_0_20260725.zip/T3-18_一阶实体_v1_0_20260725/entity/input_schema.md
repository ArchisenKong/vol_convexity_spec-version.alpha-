# entity/input_schema.md · T3-18 funding relation failure · v1.0 · 20260725

## §0 对象与Q4判据锚定

T3-18 ＝ funding relation failure（供血关系失效）。一阶实体（任务5 Step2 v1.2行101；单点改判触点经KD裁定关闭＝维持一阶实体，20260718）。

**判据源出处（程序化核实，裁决30-C留痕复核）**：T3§5.5行609（判据二）＋行613-614（判据形状/数值分层机制条款）。翻译审计表v1.1 T3·609行判定＝**思想锚定**（功能层→宪-ST-06＋宪-ID-02＋宪-EP-07＋宪-DS-05＋宪-EP-04/ST-03不授权栏；度量形状层→累计funding gap为宪-ST-06不变量之账本表达，可争成分已自行槽位化）；T3·613-A／613-B同为思想锚定；T3·614空行无成分。四行全覆盖、无翻译漂移态，判据源有效（裁决30-C核实结论）。

**T3§5.5行609原文（转录，来源3_波动率凸性操作方法论主文档_T0_frozen_clean_20260615.md 第609行）**：

> 判据二｜funding relation failure（供血关系失效）：维度为滚动窗口内累计 funding gap（short-end premium income − long-end premium bleed − roll cost）的形态；基准为账本口径的零轴与历史分布，基准选择本身为 `parameter_slot_candidate`；破坏形态为累计 gap 呈持续性负值且斜率不收敛超过槽位窗口，构成 `P_B` 失效证据并触发 manual review。若任何候选调整触及母结构四要件的删除或降级，则依据 A4 直接归类为新变体或 `identity drift`，必须进入 identity review，不得作为普通 repair candidate；槽位为 `funding_gap_window`、`funding_gap_persistence_shape`（`parameter_slot_candidate`）。

**Q4可算判据**（任务5_Step2产出_v1.2行101）：**"同T3-17处理：累计gap形态计算+槽位判据，输入＝账本/成本数据"**。本根验形状层可复算性；槽位数值作人造输入，桩纪律处置（判据形状/数值分层，T3§5.5行613-614）。

**证伪工程靶子**：P_B注册记录_v1_0_20260717.md 要件4（引T3§5.5行609，对应构造对象＝T3-18）。要件1（假设内容，00A§5行98）＝ short-end OTM premium income 在跨regime可审计净额口径下足以使长端双翼premium bleed处于可控范围；禁止误用条款＝"不得由尖峰肥尾直接推出任意regime下供血额≥长端bleed；不得认为long put保护P_B"（本根随行携带，非算法成分，见§6 A7标注）。

## §1 C-6标记（证伪触发器，非否决，随行携带）

原文（任务5_Step3产出_v1.2 §3.3）："基准为账本口径的零轴与**历史分布**，基准选择本身为parameter_slot_candidate"。历史分布＝样本族；判据取值的合法性依赖该样本族选择——按判据出处T2/02§3行446"参数合法性依赖样本族"支命中，登记为证伪触发器（M-1，任务5_Step3产出 §4）。既有缓释已在原文内：基准选择槽位化、待A6参数治理。**标记不否决**，随行标注语义（C1刀口，处置遵A7先例），不构成本根合格判定的否决理由。

本根entity/verify/harness_output.json与本文档均携带此标记文本，满足包§7"C-6标记与P_B注册记录引用须见于实体制品"强制条款。

## §2 随行指针两条（翻译审计表v1.1 T3·609行，非漂移，消费方须随行携带，本根不就地裁口径）

1. **premium口径与宪-ST-06时间价值成分口径之同源性** → 治理册槽位候选信号#7（Phase B定）。本根不做同源性核验，随行携带指针。
2. **bleed端口径** → TPL3-T24-01（open，D6登记，任务6产出v1.7类三项挂A→B衔接清单）。本根消费bleed为账本数值（entity/ledger_input.json `bleed_cents` 字段），数据/机制刀口下值消费不登记；bleed本身如何由定价/重估得出（T-24 §4①②之类一/类二处置）不在本根范围，引用不重登（一阶实体_T-24_input_schema.md §4-§7先例）。

## §3 ledger schema（人造input，entity/ledger_input.json）

| 字段 | 定义 |
|---|---|
| `_data_source` | 固定值 `synthetic_hand_constructed`（骨架C6档二字段规范化候选，KD采纳20260718；先例＝TC-33 schema §5、T3-03 schema §2行22） |
| `slots.funding_gap_window.value` | 滚动窗口长度（期数）。`parameter_slot_candidate`（T3§5.5行609），本根桩值＝4，非校准值 |
| `slots.funding_gap_persistence_shape` | 破坏形态判据槽位内容（见§4③类三候选设计），`parameter_slot_candidate` |
| `periods[].t` | 期序号（1-indexed） |
| `periods[].income_cents` | 短端 short-end premium income 账本值（整数记账单位，数据/机制刀口下之数据，人造input构造自由度，不登记模板一/二） |
| `periods[].bleed_cents` | 长端 long-end premium bleed 账本值（同上；来源随行指针见§2第2条，本根不重新推导） |
| `periods[].roll_cost_cents` | roll cost 账本值（同上） |

## §4 核心公式三层三分判别（计算成分三分判别受控文本v1.1落地口径，逐成分自查，双重引用纪律：本节引受控文本程序性纪律＋各成分实质依据分列于下）

**①逐期funding gap公式结构（类一·语义即裁，当场定案）**：

`funding_gap_t = income_t − bleed_t − roll_cost_t`

判别测试：T3§5.5行609原文"累计 funding gap（short-end premium income − long-end premium bleed − roll cost）"直接给出线性减法结构，无候选歧义空间（无相容/矛盾候选对需要裁决——原文本身即公式）。裁A，定案写入实现（entity/harness.py `compute_gap_series`），非桩，引用T3§5.5行609。骨架归属：A2加权线性聚合（权重＝[+1,−1,−1]），比照A2先例（T-76/TC-33/T3-03/GK-14）结构同型，权重取值为本根裁定登记内容（非跨根外推，C5纪律）。

**②滚动窗口累计之聚合形式（类一·语义即裁，当场定案；窗口长度数值另属类三/槽位，见③）**：

`cum_gap_t = Σ_{s=t-W+1}^{t} funding_gap_s`

判别测试：原文"滚动窗口内累计"文本本身即指定聚合形式＝窗口内求和，非均值/非加权，无候选歧义。裁A，定案写入实现（entity/harness.py `compute_cum_gap`；verify/independent_recompute.py 改用前缀和技术独立复算同一聚合结果，路径独立见§6）。**窗口长度 W（funding_gap_window槽位数值）不属此类一裁定范围**——原文明示该槽位为`parameter_slot_candidate`，数值待A6参数治理/Phase B校准，本根取桩值4（entity/ledger_input.json）。

**③破坏形态判据（persistent negative AND slope non-convergent）之操作化实现（类三·阶段B校准项，候选之一，待B证伪，不留白）**：

判别测试（计算成分三分判别受控文本§4）：候选实现方式不止一种且均与原文"持续性负值且斜率不收敛超过槽位窗口"语义相容（例：持续负值可用"全部<基准"或"多数<基准"操作化；斜率可用两点割线、最小二乘回归、或差分序列符号计数等不同方式操作化；基准可取账本口径零轴或历史分布），无权威文本可排除其余候选——归类三。

**处置**：阶段A跑一个具体候选版本，标注"候选之一，待Phase B证伪，不外推为规范"，不留白（受控文本§4处置条款）。本根实现候选：

- **持续性负值**：以 `funding_gap_persistence_shape.persistence_periods`（本根桩值3）个连续评估期的累计值全部 < `baseline_cents`（本根桩值0，选用"账本口径零轴"候选；"历史分布"候选本根未实现，随T3§5.5行609原文并列为待选项，未来经Phase B裁定换装）判定。
- **斜率不收敛**：以 `persistence_periods` 窗口两端点做割线（secant），`delta = cum_gap[t] − cum_gap[t−persistence_periods+1]`；`delta ≤ slope_threshold_cents`（本根桩值0）视为未收敛。除法经移项消去（比较delta本身而非delta/期数），避免引入非精确有理运算，使子口径判定维持(a)=0 bit-exact可判性（不因除法引入舍入噪声、不误落入子口径(b)）。
- **破坏形态** = 持续性负值 AND 斜率不收敛（两条件缺一不可——原文"且"字为AND语义，非OR；entity/ledger_input.json构造之t=11/12两期即用于断言覆盖"持续负值但斜率收敛→非破坏形态"分支，避免误用OR逻辑的实现在本根内不可判）。

**本根裁定登记（呈KD，非终裁）**：③项全部三个槽位子成分（persistence_periods取值、baseline选择、slope_threshold取值）及其操作化方式（割线法 vs 回归法等）之三分判别结果＝**类三**，建议登记为 **TPL3-T3-18-01**（挂A→B衔接清单，非模板一/二，比照TPL3-T24-01先例形态），呈KD裁定是否登记及具体编号／是否需要独立登记或并入既有槽位#7/TPL3-T24-01指针体系。本根不自行裁定登记与否（包§3："TPL3登记与否由切片会话依三分判别程序判定后呈KD"）。

## §5 identity drift / manual review 路由条款（A7·语义标注随行携带，非算法成分）

T3§5.5行609原文约束语义（随行标注，C1刀口，处置遵A7先例——比照T-24 schema §6 `caliber_annotation`字段先例）：

> "构成P_B失效证据并触发manual review。若任何候选调整触及母结构四要件的删除或降级，则依据A4直接归类为新变体或identity drift，必须进入identity review，不得作为普通repair candidate。"

本根**不实现**该路由判定的执行逻辑（是否触及母结构四要件的删除/降级为下游/人工判断范畴，非本根Q4判据"累计gap形态计算+槽位判据"范围内容）。该条款以文本形式随本文档携带，供下游消费方（manual review / identity review 执行方）读取，harness/verify不消费此字段参与数值计算。

P_B注册记录禁止误用条款（要件1，00A§5行98）同样随行携带，不参与计算：

> "不得由尖峰肥尾直接推出任意regime下供血额≥长端bleed；不得认为long put保护P_B。"

## §6 容差口径声明（W-4两子口径，裁决13/19）

本根全部计算（逐期gap减法、窗口求和、割线delta比较）均为**整数账本单位（cents）上的加减法与比较运算**，不涉及任何超越函数（无erf/exp/log/sqrt等闭式解），C3分派判据（超越函数在场性）判定本根属**离散/精确有理计算**，分派**子口径(a)＝0（bit-exact）**。

实现层面进一步保证：entity/harness.py 与 verify/independent_recompute.py 全程使用 Python 原生任意精度整数（`int`），无浮点运算参与，滑动窗口求和（harness）与前缀和差分（verify）两条独立算法路径对同一组整数输入的求和结果在数学上恒等（整数加法结合律精确成立，无IEEE754非结合性风险——此点与T-24 schema §7"锚定值情境依赖"开放疑问不同型：T-24风险源于超越函数闭式解路径差异，本根不涉及超越函数，不触发该情境依赖命题，C3命题（骨架§三C3）不适用本根，无需另行实测锚定）。

## §7 分账/边界备注

- 本根不消费T-23（short-end OTM premium income 之上游拆分对象，Step1淘汰节点）；income_t 以人造input直接承担（比照T-24 schema §6分账约束承接先例）。
- 本根不消费 T-24 一阶实体本身（bleed_t 为独立人造账本值，非引用T-24 harness输出）；两者仅共享TPL3-T24-01指针语义关联，非数据依赖边。

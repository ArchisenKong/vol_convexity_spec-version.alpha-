#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
增量复核会话 · 项4 七例变异重放（外审侧独立实施）

变异定义唯一来源＝《T318外审报告与KD裁定落地_v1_0_20260726》§1第三层变异清单原文
（M3／M7／C1／C3／C4／C5／C6）。锚点串与替换串由本会话自源码定位后独立书写，
未取自 verify/negative_control.py（构造侧留痕）之 MUTATIONS 常量。

方法（外审报告§7附录既定形态）：隔离临时目录整树复制 → 锚点串替换
（命中数≠1 即报注入失败，不静默跳过）→ 执行 verify/assert_check.py
→ 判据：exit code 非零＝击落（裁决28-B(ii) 经 30-A）。
每例还原（临时目录销毁）后对交付件原树复跑基线，确认还原干净。
"""
import difflib, os, shutil, re, subprocess, sys, tempfile

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "T3-18_一阶实体_v1_1_20260726"))
H, V = "entity/harness.py", "verify/independent_recompute.py"

# (例ID, 类型, 外审报告原定义, [(文件, 锚点串, 替换串)])
CASES = [
 ("M3","单侧","持续负值 all→any",
  [(H, "all(v < baseline_cents for v in window_vals)",
       "any(v < baseline_cents for v in window_vals)")]),
 ("M7","单侧","基准比较 <→<=",
  [(H, "v < baseline_cents", "v <= baseline_cents")]),
 ("C1","协同","两侧 roll_cost 符号同翻",
  [(H, '- p["roll_cost_cents"]',  '+ p["roll_cost_cents"]'),
   (V, '- pd["roll_cost_cents"]', '+ pd["roll_cost_cents"]')]),
 ("C3","协同","两侧斜率边界 <=→<",
  [(H, "delta <= slope_threshold_cents", "delta < slope_threshold_cents"),
   (V, "not (delta > slope_threshold)",  "not (delta >= slope_threshold)")]),
 ("C4","协同","两侧斜率窗口改用 funding_gap_window（原文\"超过槽位窗口\"另一读法；W=4→端点 t−3，越界钳位至最早可算点）",
  [(H, "delta = cum_gap[t] - cum_gap[window_start]",
       "delta = cum_gap[t] - cum_gap[max(t - 3, min(cum_gap))]"),
   (V, "delta = cum_gap[t] - cum_gap[lo]",
       "delta = cum_gap[t] - cum_gap[max(t - 3, min(cum_gap))]")]),
 ("C5","协同","两侧斜率改单期差分 cum[t]−cum[t−1]",
  [(H, "delta = cum_gap[t] - cum_gap[window_start]", "delta = cum_gap[t] - cum_gap[t - 1]"),
   (V, "delta = cum_gap[t] - cum_gap[lo]",           "delta = cum_gap[t] - cum_gap[t - 1]")]),
 ("C6","协同","两侧持续负值判据显著放宽（all→any／max→min）",
  [(H, "all(v < baseline_cents for v in window_vals)",
       "any(v < baseline_cents for v in window_vals)"),
   (V, "(max(vals) < baseline)", "(min(vals) < baseline)")]),
]
# 附加·非计分（新观察项候选）：C4 之另一端点读法 t−4
EXTRA = [
 ("C4'","协同·非计分","C4 端点另读：delta＝cum[t]−cum[t−4]（窗口长度而非端点数）",
  [(H, "delta = cum_gap[t] - cum_gap[window_start]",
       "delta = cum_gap[t] - cum_gap[max(t - 4, min(cum_gap))]"),
   (V, "delta = cum_gap[t] - cum_gap[lo]",
       "delta = cum_gap[t] - cum_gap[max(t - 4, min(cum_gap))]")]),
]

def baseline():
    r = subprocess.run([sys.executable, os.path.join(ROOT,"verify","assert_check.py")],
                       capture_output=True, text=True)
    return r.returncode

def fails(out): return re.findall(r'^\[FAIL\]\s+(\S+)', out, re.M)

def run(cid, kind, note, edits, difflog):
    with tempfile.TemporaryDirectory() as td:
        dst = os.path.join(td, "tree"); shutil.copytree(ROOT, dst)
        for rel, a, b in edits:
            p = os.path.join(dst, rel); src = open(p, encoding="utf-8").read()
            if src.count(a) != 1:
                return {"id":cid,"exit":None,"status":f"注入失败(锚点命中={src.count(a)})","fails":[]}
            new = src.replace(a, b)
            difflog.append(f"--- [{cid}] {rel}\n" + "".join(
                difflib.unified_diff(src.splitlines(True), new.splitlines(True),
                                     fromfile=rel+"(原)", tofile=rel+"(注入后)", n=1)))
            open(p,"w",encoding="utf-8").write(new)
        r = subprocess.run([sys.executable, os.path.join(dst,"verify","assert_check.py")],
                           capture_output=True, text=True)
        return {"id":cid,"kind":kind,"note":note,"exit":r.returncode,
                "status":"击落" if r.returncode!=0 else "存活",
                "fails":fails(r.stdout)}

def main():
    difflog=[]
    b0 = baseline(); print(f"[前置] 交付件原树基线绿跑 exit={b0}\n")
    rows=[]
    for c in CASES+EXTRA:
        res = run(*c, difflog=difflog); rows.append(res)
        bk = baseline()
        res["restore_exit"]=bk
        print(f"[{res['id']:>3}] exit={res['exit']} {res['status']:<4} | 还原后基线 exit={bk} | "
              f"击落断言={('、'.join(res['fails'])) if res['fails'] else '—'}")
    scored=[r for r in rows if r["id"] in ("M3","M7","C1","C3","C5","C6")]
    killed=sum(1 for r in scored if r["exit"] not in (None,0))
    print(f"\n硬判据分母6：击落 {killed}/6"
          f"{'（全部击落）' if killed==6 else '；存活：'+ '、'.join(r['id'] for r in scored if r['exit']==0)}")
    c4=[r for r in rows if r["id"]=="C4"][0]
    print(f"C4（信息例，不计分母）：exit={c4['exit']} → {c4['status']}")
    c4b=[r for r in rows if r["id"]=="C4'"][0]
    print(f"C4'（非计分附加观察）：exit={c4b['exit']} → {c4b['status']}")
    open(os.path.join(os.path.dirname(os.path.abspath(__file__)),"injection_diffs.txt"),
         "w",encoding="utf-8").write("\n".join(difflog))
    print("\n注入diff全文已写入 audit/injection_diffs.txt")

main()

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""项3续：核验 assert_check.py 推导链注释（人工推导留痕）之算术自洽性——
   将注释中声明的 gap序列 / cum值 / 窗口值 / delta 逐项解析，与第三独立路径复算结果比对。
   目的：判别留痕是否为可复算之独立推导，而非无过程之数值转录。"""
import json, os, re
from collections import deque
ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "T3-18_一阶实体_v1_1_20260726")
src = open(os.path.join(ROOT,"verify","assert_check.py"), encoding="utf-8").read()
MS = "\u2212"  # U+2212
neg = lambda s: int(s.replace(MS,"-").replace("−","-"))

# 第三路径复算（同 third_path_expected.py）
inp = json.load(open(os.path.join(ROOT,"entity","ledger_input.json"),encoding="utf-8"))
W=inp["slots"]["funding_gap_window"]["value"]; sh=inp["slots"]["funding_gap_persistence_shape"]
P,BASE,THR=sh["persistence_periods"],sh["baseline_cents"],sh["slope_threshold_cents"]
gap={p["t"]:p["income_cents"]-(p["bleed_cents"]+p["roll_cost_cents"]) for p in inp["periods"]}
cum={};dq=deque();s=0
for t in range(1,len(gap)+1):
    dq.append(gap[t]); s+=gap[t]
    if len(dq)>W: s-=dq.popleft()
    if len(dq)==W: cum[t]=s
first=min(cum)

fail=[]
# ① 注释声明之 gap 序列
m=re.search(r't1\.\.t17\s*=\s*([^\n]+)', src)
declared_gap=[neg(x.strip()) for x in m.group(1).split(",")]
real_gap=[gap[t] for t in range(1,18)]
print("① gap序列  注释声明 == 第三路径复算 :", declared_gap==real_gap)
if declared_gap!=real_gap: fail.append(("gap",declared_gap,real_gap))

# ② 注释声明之 cum 值
declared_cum={int(a):neg(b) for a,b in re.findall(r't(\d+)=('+MS+r'?\d+)\s', src)}
real_cum={t:cum[t] for t in cum}
print("② cum值    注释声明 == 第三路径复算 :", declared_cum==real_cum, f"(声明{len(declared_cum)}点)")
if declared_cum!=real_cum: fail.append(("cum",declared_cum,real_cum))

# ③ 逐点窗口值 / delta / PN / SN / DF
rows=re.findall(r'#\s+t(\d+)\s+\{([^}]*)\}\s+PN=([TF])\s+delta=('+MS+r'?\d+)\s+SN=([TF])\s+DF=([TF])', src)
print(f"③ 逐点行解析到 {len(rows)} 行")
for t,vals,pn,d,sn,df in rows:
    t=int(t); lo=t-P+1
    dv=[neg(x.strip()) for x in vals.split(",")]
    real_vals=[cum[k] for k in range(lo,t+1)]
    real_delta=cum[t]-cum[lo]
    real_pn=(sum(1 for v in real_vals if v<BASE)==len(real_vals))
    real_sn=((THR-real_delta)>=0)
    ok = (dv==real_vals and neg(d)==real_delta and (pn=="T")==real_pn and (sn=="T")==real_sn and (df=="T")==(real_pn and real_sn))
    if not ok:
        fail.append((f"t{t}", (dv,neg(d),pn,sn,df), (real_vals,real_delta,real_pn,real_sn,real_pn and real_sn)))
    print(f"   t{t:>2} 窗口{dv} delta={neg(d):>5} PN={pn} SN={sn} DF={df}  →  {'✔' if ok else '✘'}")
print()
print("推导链算术自洽性：", "全部自洽，无不符项" if not fail else f"不符 {len(fail)} 项：{fail}")

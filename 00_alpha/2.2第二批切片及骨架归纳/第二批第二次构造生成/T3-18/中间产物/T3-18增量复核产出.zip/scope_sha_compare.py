#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""项2 范围符合性 · sha256比对表 + v1.0反演重建核验"""
import hashlib, os, re
ROOT="/home/claude/T318_review/T3-18_一阶实体_v1_1_20260726"
BASE={  # 外审报告§7附录 v1.0 基线
 "entity/harness.py":"f6fdeaf50456e4a12575414d74b183f179af0e8fb852959f1e1ef022de93ec4b",
 "entity/harness_output.json":"06c3d733dda36f70d2720656f5d7f22109fb8e93ea8c1a2da761f56d10a2af2d",
 "entity/input_schema.md":"0d395cb671ced85925edd20c44d8656d6ebc341b215336b2a1ad2d38a4b40f33",
 "entity/ledger_input.json":"a8a8e37310e9ede299861bc50bc67852936a35e3770f6cc44a4d226aaf7575ba",
 "verify/assert_check.py":"22804678ee115a4f45cf5e7e4b941bd61a735ec248dfd8ad32a0838530c602fe",
 "verify/assert_log.txt":"4f86b1a205dfdb8a7ac5177b05de55bc736564f7c3c24e09a60c7bba72ae6f01",
 "verify/independent_recompute.py":"564dfeb3ed117be45041d4b0ba7ebf37f281ed6a2f435aa7c8823ae42402f74e",
}
sha=lambda p: hashlib.sha256(open(p,"rb").read()).hexdigest()
cur={}
for d in ("entity","verify"):
    for f in sorted(os.listdir(os.path.join(ROOT,d))):
        cur[f"{d}/{f}"]=sha(os.path.join(ROOT,d,f))
print(f"{'文件':<38}{'v1.0基线':<18}{'v1.1现行':<18}状态")
for k in sorted(set(BASE)|set(cur)):
    b,c=BASE.get(k,"—"),cur.get(k,"—")
    st = "零变动" if b==c else ("新增（无v1.0基线）" if b=="—" else "已变更")
    print(f"{k:<38}{(b[:16] if b!='—' else '—'):<18}{(c[:16] if c!='—' else '—'):<18}{st}")

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
增量复核会话 · 项3 期望值独立性抽查用第三复算路径
（外审侧自写；不import harness、不import independent_recompute、不读 harness_output.json；
 仅读 entity/ledger_input.json 与源文行609语义 + 切片记录裁定登记#3之已裁操作化）

路径独立性：
  - gap：以 income − (bleed + roll_cost) 结合律改写（区别于 harness/verify 的逐项减）
  - cum：collections.deque 增量维护窗口和（区别于滑动切片求和 / 前缀和差分）
  - persistent_negative：以「负值计数 == 窗口长度」表达（非 all／非 max）
  - slope_nonconvergent：以 (threshold − delta) >= 0 移项后比较（非 <=／非 not >）
  - 不可判：以 window_start < 首个可算评估点 判定（非 any(s not in cum)）
比对对象＝assert_check.py 之 EXPECTED_TRIPLES 静态钉表（以正则从源码抽取字面量，不执行该模块）
"""
import json, os, re, ast
from collections import deque

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "T3-18_一阶实体_v1_1_20260726")
inp = json.load(open(os.path.join(ROOT, "entity", "ledger_input.json"), encoding="utf-8"))

W  = inp["slots"]["funding_gap_window"]["value"]
sh = inp["slots"]["funding_gap_persistence_shape"]
P, BASE, THR = sh["persistence_periods"], sh["baseline_cents"], sh["slope_threshold_cents"]
periods = inp["periods"]

# ① gap（结合律改写）
gap = {p["t"]: p["income_cents"] - (p["bleed_cents"] + p["roll_cost_cents"]) for p in periods}
n = len(periods)

# ② cum（deque 增量窗口和）
cum, dq, s = {}, deque(), 0
for t in range(1, n + 1):
    dq.append(gap[t]); s += gap[t]
    if len(dq) > W: s -= dq.popleft()
    if len(dq) == W: cum[t] = s
first = min(cum)

# ③ 三元组（计数式 / 移项式）
mine = {}
for t in sorted(cum):
    lo = t - P + 1
    if lo < first:
        mine[t] = None; continue
    vals = [cum[k] for k in range(lo, t + 1)]
    pn = (sum(1 for v in vals if v < BASE) == len(vals))
    delta = cum[t] - cum[lo]
    sn = ((THR - delta) >= 0)
    mine[t] = {"persistent_negative": pn, "slope_nonconvergent": sn, "destructive_form": (pn and sn)}

# 抽取静态钉表（正则+ast，不执行 assert_check 模块）
src = open(os.path.join(ROOT, "verify", "assert_check.py"), encoding="utf-8").read()
m = re.search(r'^EXPECTED_TRIPLES\s*=\s*(\{.*?^\})', src, re.S | re.M)
pinned = ast.literal_eval(m.group(1))

print("第三路径 gap 序列 :", [gap[t] for t in range(1, n + 1)])
print("第三路径 cum 序列 :", {t: cum[t] for t in sorted(cum)})
print()
print(f"{'t':>3} | {'第三路径三元组':<38} | {'钉表三元组':<38} | 一致")
diff = []
for t in sorted(set(list(mine) + list(pinned))):
    a, b = mine.get(t, "<缺>"), pinned.get(t, "<缺>")
    fmt = lambda x: "None" if x is None else (f"PN={int(x['persistent_negative'])} SN={int(x['slope_nonconvergent'])} DF={int(x['destructive_form'])}" if isinstance(x, dict) else str(x))
    ok = (a == b)
    if not ok: diff.append(t)
    print(f"{t:>3} | {fmt(a):<38} | {fmt(b):<38} | {'✔' if ok else '✘'}")
print()
print("差异评估点:", diff if diff else "无——静态钉表与第三独立路径逐点一致")

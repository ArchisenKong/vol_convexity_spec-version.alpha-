#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
项2 强化核验：v1.0 反演重建（对"变更面恰为封闭四项"之 bit-exact 证明）

方法：对 v1.1 现行件施加"仅撤销声称之改动"后重算 sha256，与外审报告§7附录之 v1.0
基线比对。命中＝声称之改动面完备且无夹带（任何未声明的字符级改动都会使哈希落空）。
"""
import hashlib, re, os
ROOT = os.environ.get("T318_ROOT", "/home/claude/T318_review/T3-18_一阶实体_v1_1_20260726")
h = lambda s: hashlib.sha256(s.encode("utf-8")).hexdigest()

# ---- ① input_schema.md：撤销 版头 + 编号书写形态 ----
s = open(os.path.join(ROOT,"entity","input_schema.md"), encoding="utf-8").read()
L = s.split("\n")
L[0] = "# entity/input_schema.md · T3-18 funding relation failure · v1.0 · 20260725"
del L[2:5]                                   # v1.1版头两行 + 其后空行
r1 = "\n".join(L).replace("TPL3-T318-01", "TPL3-T3-18-01")
print("input_schema.md   反演→v1.0 :", h(r1) == "0d395cb671ced85925edd20c44d8656d6ebc341b215336b2a1ad2d38a4b40f33", h(r1)[:16])

# ---- ② ledger_input.json：撤销 追加5期 + _note追加段 ----
s = open(os.path.join(ROOT,"entity","ledger_input.json"), encoding="utf-8").read()
keep = [l for l in s.split("\n") if not re.search(r'"t":\s*1[3-7],', l)]
keep = [(l.rstrip().rstrip(",") if '"t": 12,' in l else l) for l in keep]
r2 = re.sub(r'\s*【v1.1扩充（[^"]*?）】[^"]*?(?=")', '', "\n".join(keep))
print("ledger_input.json 反演→v1.0 :", h(r2) == "a8a8e37310e9ede299861bc50bc67852936a35e3770f6cc44a4d226aaf7575ba", h(r2)[:16])

# ---- ③ harness_output.json：以反演所得 v1.0 input 重跑现行 harness.py ----
import shutil, subprocess, sys, tempfile, json
with tempfile.TemporaryDirectory() as td:
    dst = os.path.join(td, "t"); shutil.copytree(ROOT, dst)
    open(os.path.join(dst,"entity","ledger_input.json"),"w",encoding="utf-8").write(r2)
    subprocess.run([sys.executable, os.path.join(dst,"entity","harness.py")],
                   capture_output=True, text=True)
    d = hashlib.sha256(open(os.path.join(dst,"entity","harness_output.json"),"rb").read()).hexdigest()
print("harness_output    反演→v1.0 :", d == "06c3d733dda36f70d2720656f5d7f22109fb8e93ea8c1a2da761f56d10a2af2d", d[:16])
print("\n三件命中＝v1.1 相对 v1.0 之改动面无未声明夹带；harness_output 变更纯为 input 扩充之确定性派生。")

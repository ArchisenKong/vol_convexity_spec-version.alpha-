#!/usr/bin/env python3
"""
verify/assert_check.py · GK-31可算部分 · D段合格断言（模板三A-D，任务6 v1.7）
修复版 v1.1（20260728，GK-31修复会话，授权源＝GK31外审报告与KD裁定落地_v1_0_20260728.md 裁决37）

三步顺序：
  step0 前置合规断言（先于数值比对，任一不满足即判不合格，不进入数值比对）
  1. 数值比对（独立路径 vs harness实跑，容差子口径(a)=0 bit-exact）
  2. 附加断言（形态齐备、判据覆盖、域边界核查等）

断言脚本整体判定归因文案不写死单一失败原因，按实际失败断言输出（W-9(3)）。

【v1.1修复说明（裁决37-A/B1/B2，仅域边界核查一处代码级修复动作，其余function原样不变）】
- 37-B1：域边界核查基线由手工转录常量 BOUNDARY_CONTENT_MARKERS 改为程序化解析
  GK主文档（Greeks管理方法论主文档v0.1.2）行794-860（§11.2-11.6全部五处"边界："条款）
  在场文本，运行时动态派生，不复用任何一侧的人工转录常量（同T3-17 D1修复先例，裁决28-B(i)判据）。
  BOUNDARY_CONTENT_MARKERS 常量本身已删除（消解手工转录形态）。
- 37-B2：检出层次由单一字面marker匹配扩至"字面层＋语义层"两层：
  字面层＝domain_boundary_check()（原逻辑保留，仅换基线来源）；
  语义层＝domain_semantic_probes()（新增，禁止逻辑语义探针，探针清单随修复交付另文
  《GK-31域边界语义探针清单_呈KD件_v1_0_20260728.md》呈KD过目，防探针清单本身又成
  手工转录第二例）。两层任一不通过即判附加断言不通过。
- 本次修复不改动 step0_*／compare_numeric／additional_assertions 任何逻辑与数值口径，
  不触发数值重跑（裁决37-A第2条）。
"""
import json
import re
import subprocess
import sys
import os

ENTITY_DIR = os.path.join(os.path.dirname(__file__), "..", "entity")
VERIFY_DIR = os.path.dirname(__file__)

FORBIDDEN_IMPORT_PATTERN = re.compile(
    r"^\s*(import\s+(requests|urllib|socket|yfinance|ibapi|ib_insync|pandas_datareader)\b"
    r"|from\s+(requests|urllib|socket|yfinance|ibapi|ib_insync|pandas_datareader)\b)",
    re.MULTILINE,
)
FORBIDDEN_KEYWORD_PATTERN = re.compile(
    r"IBKR|QuantConnect|http://|https://|urlopen|requests\.|socket\.", re.IGNORECASE
)

failures = []
warnings = []


def strip_comments_and_docstrings(src):
    """剥离Python注释与docstring后返回纯代码文本（W-8(c)：判定统一在剥离后文本上执行）"""
    # 剥离三引号docstring/字符串块（简化版：非完美解析器，足够本根启发式扫描用）
    no_triple = re.sub(r'("""(.*?)""")|(\'\'\'(.*?)\'\'\')', "", src, flags=re.DOTALL)
    # 逐行剥离 # 注释
    lines = []
    for line in no_triple.splitlines():
        # 简单处理：不处理字符串内含#的边界情况（本根代码中无此类字符串）
        stripped = re.sub(r"#.*$", "", line)
        lines.append(stripped)
    return "\n".join(lines)


def step0_data_source_check():
    with open(os.path.join(ENTITY_DIR, "input_data.json"), "r", encoding="utf-8") as f:
        doc = json.load(f)
    ok = doc.get("_data_source") == "synthetic_hand_constructed"
    if not ok:
        failures.append("step0(i): input_data.json缺少或错误的_data_source字段")
    return ok


def step0_static_scan(filepath, label):
    with open(filepath, "r", encoding="utf-8") as f:
        raw = f.read()
    stripped = strip_comments_and_docstrings(raw)

    import_hits_stripped = FORBIDDEN_IMPORT_PATTERN.findall(stripped)
    keyword_hits_stripped = FORBIDDEN_KEYWORD_PATTERN.findall(stripped)

    import_hits_raw = FORBIDDEN_IMPORT_PATTERN.findall(raw)
    keyword_hits_raw = FORBIDDEN_KEYWORD_PATTERN.findall(raw)

    ok = (len(import_hits_stripped) == 0) and (len(keyword_hits_stripped) == 0)
    if not ok:
        failures.append(
            f"step0(ii): {label} 剥离注释/docstring后命中forbidden模式 "
            f"import={import_hits_stripped} keyword={keyword_hits_stripped}"
        )
    if (len(import_hits_raw) > len(import_hits_stripped)) or (
        len(keyword_hits_raw) > len(keyword_hits_stripped)
    ):
        warnings.append(
            f"{label}: 剥离前命中但剥离后未命中（留痕展示，非失败）——"
            f"raw import={import_hits_raw} keyword={keyword_hits_raw}"
        )
    return ok


def step0_path_independence_check():
    """独立复算路径独立性：未import harness模块、未读取harness_output.json"""
    with open(os.path.join(VERIFY_DIR, "independent_recompute.py"), "r", encoding="utf-8") as f:
        raw = f.read()
    stripped = strip_comments_and_docstrings(raw)
    no_harness_import = re.search(r"^\s*import\s+harness\b|^\s*from\s+harness\b", stripped, re.MULTILINE) is None
    no_harness_output_read = "harness_output.json" not in stripped
    ok = no_harness_import and no_harness_output_read
    if not ok:
        failures.append("step0(iii): independent_recompute.py 疑似耦合harness模块或读取harness_output.json")
    # 人工留痕：剥离前raw中"harness"字样出现位置核查（同GK-14先例，防假阳性误判）
    raw_hits = [i for i, line in enumerate(raw.splitlines(), 1) if "harness" in line]
    warnings.append(f"independent_recompute.py 剥离前'harness'字样命中行号（应仅见于docstring/注释说明本脚本独立性自身）：{raw_hits}")
    return ok


# ============================================================
# 域边界核查（v1.1修复：37-B1程序化基线解析 + 37-B2语义探针层）
# ============================================================

GK_MAIN_DOC_PATH = os.environ.get(
    "GK31_GK_MAIN_DOC_PATH",
    "/mnt/project/Greeks_管理方法论主文档_v0_1_2-freeze_交叉一致性修正版_20260616.md",
)
GK_BOUNDARY_LINE_START = 794
GK_BOUNDARY_LINE_END = 860
GK_EXPECTED_BOUNDARY_COUNT = 5

DOMAIN_BOUNDARY_CODE_FILES = [
    os.path.join(ENTITY_DIR, "harness.py"),
    os.path.join(VERIFY_DIR, "independent_recompute.py"),
]


def parse_boundary_markers(doc_path=None):
    """37-B1：程序化解析GK主文档行794-860区间内全部"边界："条款，派生逐条核查标记。

    派生规则（机械式、无人工语义挑选）：对每条以"边界："开头的行，取前缀后至第一个
    ［；，。］定界符前的文本作为该条marker。该规则对本文档现行文本可产出与历史
    BOUNDARY_CONTENT_MARKERS五项常量逐项呈超集关系（即新marker均包含旧marker子串），
    检出范围不收窄；且标记不再是脚本内写死的常量，而是运行时对源文当前文本的直接派生
    ——源文再版时markers随之更新，不会出现"源文改而检查仍照旧常量"的静默失效
    （EXP-006候选形态，同T3-17 D1）。

    结构性自检（fail-closed）：若解析出的"边界："行数不等于5，判定源文档结构已变化，
    抛出异常令调用方判不合格，不静默沿用过期假设。
    """
    if doc_path is None:
        doc_path = GK_MAIN_DOC_PATH
    with open(doc_path, "r", encoding="utf-8") as f:
        lines = f.readlines()
    block = lines[GK_BOUNDARY_LINE_START - 1 : GK_BOUNDARY_LINE_END]
    boundary_lines = [ln.strip() for ln in block if ln.strip().startswith("边界：")]
    if len(boundary_lines) != GK_EXPECTED_BOUNDARY_COUNT:
        raise RuntimeError(
            f"行{GK_BOUNDARY_LINE_START}-{GK_BOUNDARY_LINE_END}区间内'边界：'行数="
            f"{len(boundary_lines)}，预期{GK_EXPECTED_BOUNDARY_COUNT}——源文档结构可能已变更，"
            f"需人工核实后更新解析逻辑，不得静默沿用旧假设"
        )
    markers = []
    for bl in boundary_lines:
        content = bl[len("边界："):]
        m = re.search(r"[；，。]", content)
        first_clause = (content[: m.start()] if m else content).strip()
        if len(first_clause) < 4:
            raise RuntimeError(f"派生标记过短，疑似解析异常: {first_clause!r}")
        markers.append(first_clause)
    return markers


def domain_boundary_check():
    """域边界核查·字面层：entity/与verify/代码文件文本中不得出现GK§11五处"边界："
    条款内容的字面片段（本根仅检查entity/harness.py与verify/independent_recompute.py代码
    文件，input_schema.md为文档层允许提及边界条款作说明，但不得将边界语义写成可执行判断
    逻辑）。基线来源＝parse_boundary_markers()程序化解析（37-B1），非手工转录常量。"""
    try:
        markers = parse_boundary_markers()
    except (OSError, RuntimeError) as e:
        failures.append(f"附加断言(域边界核查·字面层): 基线解析失败，fail-closed判不合格——{e}")
        return False

    hits = []
    for fp in DOMAIN_BOUNDARY_CODE_FILES:
        with open(fp, "r", encoding="utf-8") as f:
            content = f.read()
        for marker in markers:
            if marker in content:
                hits.append((fp, marker))
    ok = len(hits) == 0
    if not ok:
        failures.append(f"附加断言(域边界核查·字面层): 代码文件中出现边界条款内容片段: {hits}")
    return ok


# 37-B2语义探针清单——本清单随修复交付另文呈KD过目（探针清单本身若脚本内写死且不呈报，
# 会重蹈"探针又成手工转录第二例"覆辙）。每探针对应GK§11一条"边界："语义，检出目标＝
# 代码是否把"观察"实现为其禁止的"批准/证明/等同/替代/自动触发"判断逻辑——即便未逐字
# 复制边界原文，语义层面已违反（37-C2 C2实证之判据-实现错层类型，字面检查对此检出力为零）。
SEMANTIC_PROBES = [
    {
        "id": "SP-1",
        "边界条款映射": "GK§11.2行805（核心仓位）：Delta观察不能单独批准对冲，对冲须进入B3动作语义与Phase4治理",
        "pattern": re.compile(
            r"(?i)\b(hedge_approv\w*|approve_hedge\w*|auto_hedge\w*|can_hedge\w*|hedge_authoriz\w*)\b"
        ),
        "说明": "代码中若出现由Delta观察值直接决定的'对冲批准/授权'布尔量或函数命名，"
        "即为把观察层升格为批准层，违反该边界。",
    },
    {
        "id": "SP-2",
        "边界条款映射": "GK§11.3行819（近端融资腿）：positive Theta不能证明safe carry，short premium收入不能替代funding governance",
        "pattern": re.compile(
            r"(?i)\b(safe_carry\w*|carry_is_safe\w*|carry_safe\w*|funding_ok\w*|financing_approv\w*)\b"
        ),
        "说明": "代码中若出现将Theta/premium符号直接映射为'carry安全/funding治理已满足'的"
        "标记量，即为把观察等同于治理结论，违反该边界。",
    },
    {
        "id": "SP-3",
        "边界条款映射": "GK§11.4行833（远端凸性腿）：negative Theta不等于useless cost；long Vega不等于完整左尾保护；wing Delta钝化不自动批准roll",
        "pattern": re.compile(
            r"(?i)\b(useless_cost\w*|theta_is_useless\w*|full(y)?_tail_protect\w*|"
            r"complete_left_tail\w*|tail_fully_protect\w*|auto_?roll_approv\w*|"
            r"roll_approved\w*|wing_dull\w*_approv\w*)\b"
        ),
        "说明": "三项等价否定关系若被代码实现为其反面（把这些本应被否定的等价关系当真"
        "写成判断逻辑），对应命名模式在此探针命中。",
    },
    {
        "id": "SP-4",
        "边界条款映射": "GK§11.5行848（中期Gamma leg）：调整只能成为candidate，不得由单一Gamma指标直接批准",
        "pattern": re.compile(r"(?i)\b(gamma_adjustment_approv\w*|gamma_approv\w*|auto_approve_gamma\w*)\b"),
        "说明": "Gamma调整决策若被代码实现为'批准/approved'而非'candidate'语义，命中。",
    },
    {
        "id": "SP-5",
        "边界条款映射": "GK§11.6行860（左右尾/跨条通用）：不得新增未在用户方法论文件或章节包中支持的固定参数（DTE/moneyness/shock size/threshold/仓位比例）",
        "pattern": re.compile(
            r"(?i)\b(dte|moneyness|shock_size|position_ratio)\w*(_threshold|_cutoff|_floor|_ceiling)?"
            r"\s*=\s*[0-9]+(\.[0-9]+)?\b"
        ),
        "说明": "代码中若将DTE/moneyness/shock size/仓位比例硬编码赋值为具体数值常量"
        "（而非取自input人造数据或标注为parameter_slot_candidate），命中。",
    },
]


def domain_semantic_probes():
    """域边界核查·语义层（37-B2新增）：禁止逻辑语义探针。扫描面与字面层相同
    （entity/harness.py、verify/independent_recompute.py，不扩面），判定统一在
    剥离注释/docstring后的文本上执行（同W-8(c)口径，避免探针命中docstring内的
    说明性文字造成假阳性——探针word本身出现在本文件docstring/说明字符串中不算
    命中，因为扫描对象是被审两文件而非本脚本自身）。"""
    hits = []
    for fp in DOMAIN_BOUNDARY_CODE_FILES:
        with open(fp, "r", encoding="utf-8") as f:
            raw = f.read()
        stripped = strip_comments_and_docstrings(raw)
        for probe in SEMANTIC_PROBES:
            m = probe["pattern"].search(stripped)
            if m:
                hits.append((fp, probe["id"], m.group(0)))
    ok = len(hits) == 0
    if not ok:
        failures.append(f"附加断言(域边界核查·语义层，37-B2探针): 代码文件中命中禁止逻辑语义模式: {hits}")
    return ok


# ============================================================
# 以下（数值比对/附加断言主体/主流程）除新增域边界语义层调用外，逻辑与v1.0一致，不变动
# ============================================================


def run_independent_recompute():
    result = subprocess.run(
        [sys.executable, "independent_recompute.py"],
        cwd=VERIFY_DIR,
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        failures.append(f"独立复算脚本执行失败: {result.stderr}")
        return None
    return json.loads(result.stdout)


def load_harness_output():
    with open(os.path.join(ENTITY_DIR, "harness_output.json"), "r", encoding="utf-8") as f:
        return json.load(f)


def compare_numeric(harness_out, indep_out):
    """数值比对：逐项diff，容差子口径(a)=0 bit-exact"""
    comparisons = []
    legs = sorted(harness_out["leg_aggregates"].keys())
    greeks = ["delta", "gamma", "vega", "theta", "rho"]
    for leg in legs:
        for g in greeks:
            h_val = harness_out["leg_aggregates"][leg][g]
            i_val = indep_out["leg_aggregates"][leg][g]
            diff = 0 if h_val == i_val else abs(h_val - i_val)
            comparisons.append((f"leg_aggregates.{leg}.{g}", h_val, i_val, diff))

    # near_financing_leg旗标
    for k in ["positive_theta_with_short_gamma", "short_vega_flag"]:
        h_val = harness_out["leg_specific_observations"]["near_financing_leg"][k]
        i_val = indep_out["leg_specific_observations"]["near_financing_leg"][k]
        diff = 0 if h_val == i_val else 1
        comparisons.append((f"near_financing_leg.{k}", h_val, i_val, diff))

    # far_convexity_leg breakdown
    for bucket_kind, key in [("vega_by_tenor", "vega_by_tenor"), ("wing_delta_by_moneyness", "wing_delta_by_moneyness")]:
        h_dict = harness_out["leg_specific_observations"]["far_convexity_leg"][key]
        i_dict = indep_out["leg_specific_observations"]["far_convexity_leg"][key]
        assert set(h_dict.keys()) == set(i_dict.keys()), f"{key} bucket集合不一致: {h_dict.keys()} vs {i_dict.keys()}"
        for bk in h_dict:
            diff = 0 if h_dict[bk] == i_dict[bk] else abs(h_dict[bk] - i_dict[bk])
            comparisons.append((f"far_convexity_leg.{key}.{bk}", h_dict[bk], i_dict[bk], diff))

    # tail_protection_enhancement breakdown
    for side in ["left_tail_put", "right_tail_call"]:
        for g in greeks:
            h_val = harness_out["leg_specific_observations"]["tail_protection_enhancement"][side][g]
            i_val = indep_out["leg_specific_observations"]["tail_protection_enhancement"][side][g]
            diff = 0 if h_val == i_val else abs(h_val - i_val)
            comparisons.append((f"tail_protection_enhancement.{side}.{g}", h_val, i_val, diff))

    h_theta_rent = harness_out["leg_specific_observations"]["tail_protection_enhancement"]["theta_cost_convexity_rent_right_tail"]
    i_theta_rent = indep_out["leg_specific_observations"]["tail_protection_enhancement"]["theta_cost_convexity_rent_right_tail"]
    comparisons.append(("tail_protection_enhancement.theta_cost_convexity_rent_right_tail", h_theta_rent, i_theta_rent, 0 if h_theta_rent == i_theta_rent else abs(h_theta_rent - i_theta_rent)))

    # node_count_by_leg
    for leg in legs:
        h_val = harness_out["node_count_by_leg"][leg]
        i_val = indep_out["node_count_by_leg"][leg]
        comparisons.append((f"node_count_by_leg.{leg}", h_val, i_val, 0 if h_val == i_val else abs(h_val - i_val)))

    non_zero_diffs = [c for c in comparisons if c[3] != 0]
    if non_zero_diffs:
        failures.append(f"数值比对: {len(non_zero_diffs)}项越限(容差(a)=0)，明细={non_zero_diffs}")
    return comparisons, non_zero_diffs


def additional_assertions(harness_out):
    """附加断言：形态齐备、判据覆盖等"""
    ok = True

    expected_legs = {
        "core_position", "near_financing_leg", "far_convexity_leg",
        "mid_gamma_leg", "tail_protection_enhancement",
    }
    actual_legs = set(harness_out["leg_aggregates"].keys())
    if actual_legs != expected_legs:
        failures.append(f"附加断言(腿集合完整性): {actual_legs} != {expected_legs}")
        ok = False

    if not harness_out["leg_attribution_check"]["unique"]:
        failures.append("附加断言(腿归属唯一): leg_attribution_check.unique != true")
        ok = False

    if harness_out["leg_attribution_check"]["total_nodes"] != harness_out["leg_attribution_check"]["sum_by_leg"]:
        failures.append("附加断言(腿归属唯一): total_nodes与sum_by_leg不一致，存在遗漏或重复计入")
        ok = False

    # 每腿五分量齐备
    for leg, vals in harness_out["leg_aggregates"].items():
        if set(vals.keys()) != {"delta", "gamma", "vega", "theta", "rho"}:
            failures.append(f"附加断言(五分量齐备): {leg} 分量集合异常 {vals.keys()}")
            ok = False

    return ok


def main():
    print("=== step0 前置合规断言 ===")
    s0a = step0_data_source_check()
    s0b1 = step0_static_scan(os.path.join(ENTITY_DIR, "harness.py"), "entity/harness.py")
    s0b2 = step0_static_scan(os.path.join(VERIFY_DIR, "independent_recompute.py"), "verify/independent_recompute.py")
    s0c = step0_path_independence_check()
    step0_pass = s0a and s0b1 and s0b2 and s0c
    print(f"step0(i) input人造: {s0a}")
    print(f"step0(ii) harness无数据源接入: {s0b1}")
    print(f"step0(ii) independent_recompute无数据源接入: {s0b2}")
    print(f"step0(iii) 独立复算路径独立: {s0c}")

    if not step0_pass:
        print("\n=== step0未通过，判定不合格，不进入数值比对 ===")
        for f_ in failures:
            print(f"FAIL: {f_}")
        sys.exit(1)

    print("\n=== 数值比对（容差子口径(a)=0 bit-exact） ===")
    harness_out = load_harness_output()
    indep_out = run_independent_recompute()
    if indep_out is None:
        print("独立复算脚本执行失败")
        for f_ in failures:
            print(f"FAIL: {f_}")
        sys.exit(1)

    comparisons, non_zero_diffs = compare_numeric(harness_out, indep_out)
    print(f"逐项比对总数: {len(comparisons)}；越限项数: {len(non_zero_diffs)}")

    print("\n=== 附加断言（形态齐备/腿归属唯一/域边界核查·字面层+语义层） ===")
    add_ok = additional_assertions(harness_out)
    boundary_ok_literal = domain_boundary_check()
    boundary_ok_semantic = domain_semantic_probes()
    print(f"形态齐备/腿归属唯一: {add_ok}")
    print(f"域边界核查·字面层(程序化解析基线，37-B1修复): {boundary_ok_literal}")
    print(f"域边界核查·语义层(禁止逻辑探针，37-B2修复): {boundary_ok_semantic}")

    all_pass = (
        step0_pass
        and (len(non_zero_diffs) == 0)
        and add_ok
        and boundary_ok_literal
        and boundary_ok_semantic
    )

    print("\n=== 警告（留痕，非失败） ===")
    for w in warnings:
        print(f"WARN: {w}")

    print(f"\n=== 最终判定: {'合格(PASS)' if all_pass else '不合格(FAIL)'} ===")
    if not all_pass:
        for f_ in failures:
            print(f"FAIL: {f_}")
        sys.exit(1)
    sys.exit(0)


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""
entity/harness.py · GK-31可算部分 · 一次性harness（裁决1"一次性"，不建常设pipeline）

职责：喂入 entity/input_data.json（人造node级raw Greeks账本），
驱动"腿级Greeks观察量归集"聚合计算，捕获输出至 entity/harness_output.json。

不接任何数据源：input全部来自本地JSON文件（人造构造），无网络/IBKR/QuantConnect/
历史行情/实时行情/文件数据源接入。

实现风格：手工dict累加式for循环（同GK-14 harness风格，供D段②与独立复算路径分叉对照）。
"""
import json
from fractions import Fraction as F

INPUT_PATH = "input_data.json"
OUTPUT_PATH = "harness_output.json"

LEG_DOMAIN = [
    "core_position",
    "near_financing_leg",
    "far_convexity_leg",
    "mid_gamma_leg",
    "tail_protection_enhancement",
]
GREEK_KEYS = ["delta", "gamma", "vega", "theta", "rho"]


def load_nodes(path):
    with open(path, "r", encoding="utf-8") as f:
        doc = json.load(f)
    assert doc.get("_data_source") == "synthetic_hand_constructed"
    return doc["nodes"]


def to_frac(v):
    return F(v)


def aggregate_leg_greeks(nodes):
    """核心算法：leg_greek[g][leg] = Σ_{n: leg_type(n)=leg} raw_g(n)（手工dict累加）"""
    leg_totals = {}
    for leg in LEG_DOMAIN:
        leg_totals[leg] = {g: F(0) for g in GREEK_KEYS}

    node_count_by_leg = {leg: 0 for leg in LEG_DOMAIN}

    for n in nodes:
        leg = n["leg_type"]
        assert leg in LEG_DOMAIN, f"未知leg_type: {leg}"
        for g in GREEK_KEYS:
            leg_totals[leg][g] += to_frac(n[f"raw_{g}"])
        node_count_by_leg[leg] += 1

    return leg_totals, node_count_by_leg


def compute_near_financing_flags(leg_totals):
    """近端融资腿附加联合旗标（GK§11.3判据一子问题，类一已定，见input_schema §4）"""
    t = leg_totals["near_financing_leg"]
    return {
        "positive_theta_with_short_gamma": bool(t["theta"] > 0 and t["gamma"] < 0),
        "short_vega_flag": bool(t["vega"] < 0),
    }


def compute_far_convexity_breakdown(nodes):
    """远端凸性腿：vega_by_tenor + wing_delta_by_moneyness（复用既有坐标维度，非新造）"""
    vega_by_tenor = {}
    delta_by_moneyness = {}
    for n in nodes:
        if n["leg_type"] != "far_convexity_leg":
            continue
        tb = n["tenor_bucket"]
        mb = n["moneyness_bucket"]
        vega_by_tenor[tb] = vega_by_tenor.get(tb, F(0)) + to_frac(n["raw_vega"])
        delta_by_moneyness[mb] = delta_by_moneyness.get(mb, F(0)) + to_frac(n["raw_delta"])
    return vega_by_tenor, delta_by_moneyness


def compute_tail_breakdown(nodes):
    """左尾保护/右尾增强：by_option_type（put=左尾，call=右尾）全量五分量子和"""
    result = {"put": {g: F(0) for g in GREEK_KEYS}, "call": {g: F(0) for g in GREEK_KEYS}}
    for n in nodes:
        if n["leg_type"] != "tail_protection_enhancement":
            continue
        ot = n["option_type"]
        assert ot in ("put", "call")
        for g in GREEK_KEYS:
            result[ot][g] += to_frac(n[f"raw_{g}"])
    return result


def frac_to_jsonable(x):
    """Fraction → 若为整数输出int，否则输出[num,den]避免浮点精度丢失"""
    if isinstance(x, F):
        if x.denominator == 1:
            return int(x)
        return {"num": x.numerator, "den": x.denominator}
    return x


def dictmap(d, fn):
    return {k: fn(v) for k, v in d.items()}


def main():
    nodes = load_nodes(INPUT_PATH)
    leg_totals, node_count_by_leg = aggregate_leg_greeks(nodes)

    near_financing_flags = compute_near_financing_flags(leg_totals)
    vega_by_tenor, wing_delta_by_moneyness = compute_far_convexity_breakdown(nodes)
    tail_breakdown = compute_tail_breakdown(nodes)

    # 腿归属唯一性结构性核验：node总数 == 各腿计数之和（无遗漏/无重复计入）
    total_nodes = len(nodes)
    sum_by_leg = sum(node_count_by_leg.values())
    leg_attribution_unique = (total_nodes == sum_by_leg) and all(
        n["leg_type"] in LEG_DOMAIN for n in nodes
    )

    output = {
        "leg_aggregates": {
            leg: dictmap(leg_totals[leg], frac_to_jsonable) for leg in LEG_DOMAIN
        },
        "leg_specific_observations": {
            "near_financing_leg": near_financing_flags,
            "far_convexity_leg": {
                "vega_by_tenor": dictmap(vega_by_tenor, frac_to_jsonable),
                "wing_delta_by_moneyness": dictmap(wing_delta_by_moneyness, frac_to_jsonable),
            },
            "tail_protection_enhancement": {
                "left_tail_put": dictmap(tail_breakdown["put"], frac_to_jsonable),
                "right_tail_call": dictmap(tail_breakdown["call"], frac_to_jsonable),
                "theta_cost_convexity_rent_right_tail": frac_to_jsonable(
                    tail_breakdown["call"]["theta"]
                ),
            },
            "mid_gamma_leg": {
                "note": "仅基线五分量聚合（见leg_aggregates），GK§11.5具名六项诊断量本根不计算，"
                "见input_schema §4三分判别表；TPL1-GK31-01腿实体归属未定，回溯锚点见切片记录"
            },
            "core_position": {
                "note": "gamma/vega/theta恒为0（线性工具范围裁定，非缺口）；"
                "delta/rho体现spot/futures/forward口径一致性与financing/basis敏感度"
            },
        },
        "node_count_by_leg": node_count_by_leg,
        "leg_attribution_check": {
            "unique": leg_attribution_unique,
            "total_nodes": total_nodes,
            "sum_by_leg": sum_by_leg,
        },
    }

    with open(OUTPUT_PATH, "w", encoding="utf-8") as f:
        json.dump(output, f, ensure_ascii=False, indent=2, sort_keys=True)

    print(f"harness真跑完成：{total_nodes} nodes → {len(LEG_DOMAIN)} legs")
    print(json.dumps(output["leg_aggregates"], ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

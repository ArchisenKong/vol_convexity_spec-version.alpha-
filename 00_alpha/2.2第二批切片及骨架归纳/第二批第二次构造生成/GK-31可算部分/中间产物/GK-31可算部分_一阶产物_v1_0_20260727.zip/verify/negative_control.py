#!/usr/bin/env python3
"""
verify/negative_control.py · GK-31可算部分 · 施工阶段自查（构造侧留痕，非外审重放、非合格判定）

目的：施工阶段自查assert_check.py是否具备最基本的检出力（非零值篡改能否被抓）。
不构成G4外审的三层验证替代，仅为构造侧最小自证。

方法：临时篡改entity/harness_output.json一处leg-level数值，跑assert_check.py，
确认exit code≠0且失败原因指向被篡改项；随后恢复原始文件，确认exit code恢复0。
"""
import json
import subprocess
import sys
import os

ENTITY_DIR = os.path.join(os.path.dirname(__file__), "..", "entity")
HARNESS_OUTPUT_PATH = os.path.join(ENTITY_DIR, "harness_output.json")


def main():
    with open(HARNESS_OUTPUT_PATH, "r", encoding="utf-8") as f:
        original = json.load(f)
    backup = json.dumps(original, ensure_ascii=False, indent=2, sort_keys=True)

    mutated = json.loads(json.dumps(original))
    mutated["leg_aggregates"]["core_position"]["delta"] = 9999

    with open(HARNESS_OUTPUT_PATH, "w", encoding="utf-8") as f:
        json.dump(mutated, f, ensure_ascii=False, indent=2, sort_keys=True)

    result = subprocess.run(
        [sys.executable, "assert_check.py"],
        cwd=os.path.dirname(__file__),
        capture_output=True,
        text=True,
    )
    mutated_exit_code = result.returncode
    mutated_stdout = result.stdout

    with open(HARNESS_OUTPUT_PATH, "w", encoding="utf-8") as f:
        f.write(backup)

    result2 = subprocess.run(
        [sys.executable, "assert_check.py"],
        cwd=os.path.dirname(__file__),
        capture_output=True,
        text=True,
    )
    restored_exit_code = result2.returncode

    print(f"篡改态 exit_code = {mutated_exit_code}（预期非0）")
    print(f"篡改态 检出摘要:\n{mutated_stdout.splitlines()[-2] if mutated_stdout.splitlines() else ''}")
    print(f"恢复态 exit_code = {restored_exit_code}（预期0）")

    detection_ok = (mutated_exit_code != 0) and (restored_exit_code == 0)
    print(f"\n检出力自查结果: {'通过' if detection_ok else '异常'}")
    return detection_ok


if __name__ == "__main__":
    ok = main()
    sys.exit(0 if ok else 1)

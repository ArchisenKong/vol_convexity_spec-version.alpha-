#!/usr/bin/env python3
"""
verify/independent_recompute.py · GK-31可算部分 · D段②独立复算

独立性声明：本脚本直读 entity/input_data.json（clean人造input），
不import harness模块、不读取entity/harness_output.json、不复用harness.py
的任何函数/思路。核心分叉：harness用手工dict累加式for循环逐节点累加；
本脚本用 itertools.groupby(sorted(...)) 分组 + 生成器 sum() 完成聚合
（同GK-14独立复算之路径独立技法）。

不接任何数据源：仅读取本地人造JSON文件。
"""
import json
import itertools
from fractions import Fraction as F

INPUT_PATH = "../entity/input_data.json"

GREEK_KEYS = ["delta", "gamma", "vega", "theta", "rho"]


def load_nodes(path):
    with open(path, "r", encoding="utf-8") as f:
        doc = json.load(f)
    assert doc.get("_data_source") == "synthetic_hand_constructed"
    return doc["nodes"]


def leg_key(n):
    return n["leg_type"]


def group_sum_by_leg(nodes, greek):
    """groupby分组 + 生成器求和路径（非手工dict累加）"""
    field = f"raw_{greek}"
    result = {}
    sorted_nodes = sorted(nodes, key=leg_key)
    for leg, grp in itertools.groupby(sorted_nodes, key=leg_key):
        grp_list = list(grp)
        result[leg] = sum((F(n[field]) for n in grp_list), F(0))
    return result


def group_count_by_leg(nodes):
    sorted_nodes = sorted(nodes, key=leg_key)
    return {
        leg: len(list(grp))
        for leg, grp in itertools.groupby(sorted_nodes, key=leg_key)
    }


def compute_leg_aggregates(nodes):
    per_greek = {g: group_sum_by_leg(nodes, g) for g in GREEK_KEYS}
    legs = sorted({n["leg_type"] for n in nodes})
    return {leg: {g: per_greek[g][leg] for g in GREEK_KEYS} for leg in legs}


def compute_near_financing_flags(leg_aggregates):
    t = leg_aggregates["near_financing_leg"]
    return {
        "positive_theta_with_short_gamma": bool(t["theta"] > 0 and t["gamma"] < 0),
        "short_vega_flag": bool(t["vega"] < 0),
    }


def compute_far_convexity_breakdown(nodes):
    fc_nodes = [n for n in nodes if n["leg_type"] == "far_convexity_leg"]
    vega_by_tenor = {}
    for tb, grp in itertools.groupby(sorted(fc_nodes, key=lambda n: n["tenor_bucket"]), key=lambda n: n["tenor_bucket"]):
        vega_by_tenor[tb] = sum((F(n["raw_vega"]) for n in grp), F(0))
    delta_by_moneyness = {}
    for mb, grp in itertools.groupby(sorted(fc_nodes, key=lambda n: n["moneyness_bucket"]), key=lambda n: n["moneyness_bucket"]):
        delta_by_moneyness[mb] = sum((F(n["raw_delta"]) for n in grp), F(0))
    return vega_by_tenor, delta_by_moneyness


def compute_tail_breakdown(nodes):
    tl_nodes = [n for n in nodes if n["leg_type"] == "tail_protection_enhancement"]
    result = {}
    for ot, grp in itertools.groupby(sorted(tl_nodes, key=lambda n: n["option_type"]), key=lambda n: n["option_type"]):
        grp_list = list(grp)
        result[ot] = {g: sum((F(n[f"raw_{g}"]) for n in grp_list), F(0)) for g in GREEK_KEYS}
    return result


def frac_to_jsonable(x):
    if isinstance(x, F):
        if x.denominator == 1:
            return int(x)
        return {"num": x.numerator, "den": x.denominator}
    return x


def dictmap(d, fn):
    return {k: fn(v) for k, v in d.items()}


def main():
    nodes = load_nodes(INPUT_PATH)
    leg_aggregates = compute_leg_aggregates(nodes)
    node_count_by_leg = group_count_by_leg(nodes)
    near_financing_flags = compute_near_financing_flags(leg_aggregates)
    vega_by_tenor, wing_delta_by_moneyness = compute_far_convexity_breakdown(nodes)
    tail_breakdown = compute_tail_breakdown(nodes)

    total_nodes = len(nodes)
    sum_by_leg = sum(node_count_by_leg.values())
    distinct_legs = {n["leg_type"] for n in nodes}
    leg_attribution_unique = (total_nodes == sum_by_leg)

    output = {
        "leg_aggregates": {
            leg: dictmap(leg_aggregates[leg], frac_to_jsonable) for leg in leg_aggregates
        },
        "leg_specific_observations": {
            "near_financing_leg": near_financing_flags,
            "far_convexity_leg": {
                "vega_by_tenor": dictmap(vega_by_tenor, frac_to_jsonable),
                "wing_delta_by_moneyness": dictmap(wing_delta_by_moneyness, frac_to_jsonable),
            },
            "tail_protection_enhancement": {
                "left_tail_put": dictmap(tail_breakdown["put"], frac_to_jsonable),
                "right_tail_call": dictmap(tail_breakdown["call"], frac_to_jsonable),
                "theta_cost_convexity_rent_right_tail": frac_to_jsonable(tail_breakdown["call"]["theta"]),
            },
        },
        "node_count_by_leg": node_count_by_leg,
        "leg_attribution_check": {
            "unique": leg_attribution_unique,
            "total_nodes": total_nodes,
            "sum_by_leg": sum_by_leg,
            "distinct_leg_count": len(distinct_legs),
        },
    }
    return output


if __name__ == "__main__":
    out = main()
    print(json.dumps(out, ensure_ascii=False, indent=2, sort_keys=True))

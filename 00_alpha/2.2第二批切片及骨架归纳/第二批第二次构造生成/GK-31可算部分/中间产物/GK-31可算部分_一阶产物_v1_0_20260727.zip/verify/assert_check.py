#!/usr/bin/env python3
"""
verify/assert_check.py · GK-31可算部分 · D段合格断言（模板三A-D，任务6 v1.7）

三步顺序：
  step0 前置合规断言（先于数值比对，任一不满足即判不合格，不进入数值比对）
  1. 数值比对（独立路径 vs harness实跑，容差子口径(a)=0 bit-exact）
  2. 附加断言（形态齐备、判据覆盖、域边界核查等）

断言脚本整体判定归因文案不写死单一失败原因，按实际失败断言输出（W-9(3)）。
"""
import json
import re
import subprocess
import sys
import os

ENTITY_DIR = os.path.join(os.path.dirname(__file__), "..", "entity")
VERIFY_DIR = os.path.dirname(__file__)

FORBIDDEN_IMPORT_PATTERN = re.compile(
    r"^\s*(import\s+(requests|urllib|socket|yfinance|ibapi|ib_insync|pandas_datareader)\b"
    r"|from\s+(requests|urllib|socket|yfinance|ibapi|ib_insync|pandas_datareader)\b)",
    re.MULTILINE,
)
FORBIDDEN_KEYWORD_PATTERN = re.compile(
    r"IBKR|QuantConnect|http://|https://|urlopen|requests\.|socket\.", re.IGNORECASE
)

# GK§11五处"边界："条款关键片段（域边界硬约束，核查entity/verify代码未消费/未实现其内容语义）
BOUNDARY_CONTENT_MARKERS = [
    "不能单独批准对冲",         # 核心仓位边界（行805）
    "不能证明 safe carry",     # 近端融资腿边界（行819，源文中英混排含空格）
    "不等于 useless cost",     # 远端凸性腿边界（行833，源文中英混排含空格）
    "只能成为 candidate",      # 中期Gamma leg边界（行848，源文中英混排含空格）
    "不得新增任何未在用户方法论文件",  # 左右尾边界（行860）
]

failures = []
warnings = []


def strip_comments_and_docstrings(src):
    """剥离Python注释与docstring后返回纯代码文本（W-8(c)：判定统一在剥离后文本上执行）"""
    # 剥离三引号docstring/字符串块（简化版：非完美解析器，足够本根启发式扫描用）
    no_triple = re.sub(r'("""(.*?)""")|(\'\'\'(.*?)\'\'\')', "", src, flags=re.DOTALL)
    # 逐行剥离 # 注释
    lines = []
    for line in no_triple.splitlines():
        # 简单处理：不处理字符串内含#的边界情况（本根代码中无此类字符串）
        stripped = re.sub(r"#.*$", "", line)
        lines.append(stripped)
    return "\n".join(lines)


def step0_data_source_check():
    with open(os.path.join(ENTITY_DIR, "input_data.json"), "r", encoding="utf-8") as f:
        doc = json.load(f)
    ok = doc.get("_data_source") == "synthetic_hand_constructed"
    if not ok:
        failures.append("step0(i): input_data.json缺少或错误的_data_source字段")
    return ok


def step0_static_scan(filepath, label):
    with open(filepath, "r", encoding="utf-8") as f:
        raw = f.read()
    stripped = strip_comments_and_docstrings(raw)

    import_hits_stripped = FORBIDDEN_IMPORT_PATTERN.findall(stripped)
    keyword_hits_stripped = FORBIDDEN_KEYWORD_PATTERN.findall(stripped)

    import_hits_raw = FORBIDDEN_IMPORT_PATTERN.findall(raw)
    keyword_hits_raw = FORBIDDEN_KEYWORD_PATTERN.findall(raw)

    ok = (len(import_hits_stripped) == 0) and (len(keyword_hits_stripped) == 0)
    if not ok:
        failures.append(
            f"step0(ii): {label} 剥离注释/docstring后命中forbidden模式 "
            f"import={import_hits_stripped} keyword={keyword_hits_stripped}"
        )
    if (len(import_hits_raw) > len(import_hits_stripped)) or (
        len(keyword_hits_raw) > len(keyword_hits_stripped)
    ):
        warnings.append(
            f"{label}: 剥离前命中但剥离后未命中（留痕展示，非失败）——"
            f"raw import={import_hits_raw} keyword={keyword_hits_raw}"
        )
    return ok


def step0_path_independence_check():
    """独立复算路径独立性：未import harness模块、未读取harness_output.json"""
    with open(os.path.join(VERIFY_DIR, "independent_recompute.py"), "r", encoding="utf-8") as f:
        raw = f.read()
    stripped = strip_comments_and_docstrings(raw)
    no_harness_import = re.search(r"^\s*import\s+harness\b|^\s*from\s+harness\b", stripped, re.MULTILINE) is None
    no_harness_output_read = "harness_output.json" not in stripped
    ok = no_harness_import and no_harness_output_read
    if not ok:
        failures.append("step0(iii): independent_recompute.py 疑似耦合harness模块或读取harness_output.json")
    # 人工留痕：剥离前raw中"harness"字样出现位置核查（同GK-14先例，防假阳性误判）
    raw_hits = [i for i, line in enumerate(raw.splitlines(), 1) if "harness" in line]
    warnings.append(f"independent_recompute.py 剥离前'harness'字样命中行号（应仅见于docstring/注释说明本脚本独立性自身）：{raw_hits}")
    return ok


def domain_boundary_check():
    """域边界核查：entity/与harness代码文本中不得出现GK§11边界条款内容语义实现
    （本根仅检查entity/*.py与verify/*.py代码文件，input_schema.md为文档层允许提及边界条款作说明，
    但不得将边界语义写成可执行判断逻辑）"""
    code_files = [
        os.path.join(ENTITY_DIR, "harness.py"),
        os.path.join(VERIFY_DIR, "independent_recompute.py"),
    ]
    hits = []
    for fp in code_files:
        with open(fp, "r", encoding="utf-8") as f:
            content = f.read()
        for marker in BOUNDARY_CONTENT_MARKERS:
            if marker in content:
                hits.append((fp, marker))
    ok = len(hits) == 0
    if not ok:
        failures.append(f"附加断言(域边界核查): 代码文件中出现边界条款内容片段: {hits}")
    return ok


def run_independent_recompute():
    result = subprocess.run(
        [sys.executable, "independent_recompute.py"],
        cwd=VERIFY_DIR,
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        failures.append(f"独立复算脚本执行失败: {result.stderr}")
        return None
    return json.loads(result.stdout)


def load_harness_output():
    with open(os.path.join(ENTITY_DIR, "harness_output.json"), "r", encoding="utf-8") as f:
        return json.load(f)


def compare_numeric(harness_out, indep_out):
    """数值比对：逐项diff，容差子口径(a)=0 bit-exact"""
    comparisons = []
    legs = sorted(harness_out["leg_aggregates"].keys())
    greeks = ["delta", "gamma", "vega", "theta", "rho"]
    for leg in legs:
        for g in greeks:
            h_val = harness_out["leg_aggregates"][leg][g]
            i_val = indep_out["leg_aggregates"][leg][g]
            diff = 0 if h_val == i_val else abs(h_val - i_val)
            comparisons.append((f"leg_aggregates.{leg}.{g}", h_val, i_val, diff))

    # near_financing_leg旗标
    for k in ["positive_theta_with_short_gamma", "short_vega_flag"]:
        h_val = harness_out["leg_specific_observations"]["near_financing_leg"][k]
        i_val = indep_out["leg_specific_observations"]["near_financing_leg"][k]
        diff = 0 if h_val == i_val else 1
        comparisons.append((f"near_financing_leg.{k}", h_val, i_val, diff))

    # far_convexity_leg breakdown
    for bucket_kind, key in [("vega_by_tenor", "vega_by_tenor"), ("wing_delta_by_moneyness", "wing_delta_by_moneyness")]:
        h_dict = harness_out["leg_specific_observations"]["far_convexity_leg"][key]
        i_dict = indep_out["leg_specific_observations"]["far_convexity_leg"][key]
        assert set(h_dict.keys()) == set(i_dict.keys()), f"{key} bucket集合不一致: {h_dict.keys()} vs {i_dict.keys()}"
        for bk in h_dict:
            diff = 0 if h_dict[bk] == i_dict[bk] else abs(h_dict[bk] - i_dict[bk])
            comparisons.append((f"far_convexity_leg.{key}.{bk}", h_dict[bk], i_dict[bk], diff))

    # tail_protection_enhancement breakdown
    for side in ["left_tail_put", "right_tail_call"]:
        for g in greeks:
            h_val = harness_out["leg_specific_observations"]["tail_protection_enhancement"][side][g]
            i_val = indep_out["leg_specific_observations"]["tail_protection_enhancement"][side][g]
            diff = 0 if h_val == i_val else abs(h_val - i_val)
            comparisons.append((f"tail_protection_enhancement.{side}.{g}", h_val, i_val, diff))

    h_theta_rent = harness_out["leg_specific_observations"]["tail_protection_enhancement"]["theta_cost_convexity_rent_right_tail"]
    i_theta_rent = indep_out["leg_specific_observations"]["tail_protection_enhancement"]["theta_cost_convexity_rent_right_tail"]
    comparisons.append(("tail_protection_enhancement.theta_cost_convexity_rent_right_tail", h_theta_rent, i_theta_rent, 0 if h_theta_rent == i_theta_rent else abs(h_theta_rent - i_theta_rent)))

    # node_count_by_leg
    for leg in legs:
        h_val = harness_out["node_count_by_leg"][leg]
        i_val = indep_out["node_count_by_leg"][leg]
        comparisons.append((f"node_count_by_leg.{leg}", h_val, i_val, 0 if h_val == i_val else abs(h_val - i_val)))

    non_zero_diffs = [c for c in comparisons if c[3] != 0]
    if non_zero_diffs:
        failures.append(f"数值比对: {len(non_zero_diffs)}项越限(容差(a)=0)，明细={non_zero_diffs}")
    return comparisons, non_zero_diffs


def additional_assertions(harness_out):
    """附加断言：形态齐备、判据覆盖等"""
    ok = True

    expected_legs = {
        "core_position", "near_financing_leg", "far_convexity_leg",
        "mid_gamma_leg", "tail_protection_enhancement",
    }
    actual_legs = set(harness_out["leg_aggregates"].keys())
    if actual_legs != expected_legs:
        failures.append(f"附加断言(腿集合完整性): {actual_legs} != {expected_legs}")
        ok = False

    if not harness_out["leg_attribution_check"]["unique"]:
        failures.append("附加断言(腿归属唯一): leg_attribution_check.unique != true")
        ok = False

    if harness_out["leg_attribution_check"]["total_nodes"] != harness_out["leg_attribution_check"]["sum_by_leg"]:
        failures.append("附加断言(腿归属唯一): total_nodes与sum_by_leg不一致，存在遗漏或重复计入")
        ok = False

    # 每腿五分量齐备
    for leg, vals in harness_out["leg_aggregates"].items():
        if set(vals.keys()) != {"delta", "gamma", "vega", "theta", "rho"}:
            failures.append(f"附加断言(五分量齐备): {leg} 分量集合异常 {vals.keys()}")
            ok = False

    return ok


def main():
    print("=== step0 前置合规断言 ===")
    s0a = step0_data_source_check()
    s0b1 = step0_static_scan(os.path.join(ENTITY_DIR, "harness.py"), "entity/harness.py")
    s0b2 = step0_static_scan(os.path.join(VERIFY_DIR, "independent_recompute.py"), "verify/independent_recompute.py")
    s0c = step0_path_independence_check()
    step0_pass = s0a and s0b1 and s0b2 and s0c
    print(f"step0(i) input人造: {s0a}")
    print(f"step0(ii) harness无数据源接入: {s0b1}")
    print(f"step0(ii) independent_recompute无数据源接入: {s0b2}")
    print(f"step0(iii) 独立复算路径独立: {s0c}")

    if not step0_pass:
        print("\n=== step0未通过，判定不合格，不进入数值比对 ===")
        for f_ in failures:
            print(f"FAIL: {f_}")
        sys.exit(1)

    print("\n=== 数值比对（容差子口径(a)=0 bit-exact） ===")
    harness_out = load_harness_output()
    indep_out = run_independent_recompute()
    if indep_out is None:
        print("独立复算脚本执行失败")
        for f_ in failures:
            print(f"FAIL: {f_}")
        sys.exit(1)

    comparisons, non_zero_diffs = compare_numeric(harness_out, indep_out)
    print(f"逐项比对总数: {len(comparisons)}；越限项数: {len(non_zero_diffs)}")

    print("\n=== 附加断言（形态齐备/腿归属唯一/域边界核查） ===")
    add_ok = additional_assertions(harness_out)
    boundary_ok = domain_boundary_check()
    print(f"形态齐备/腿归属唯一: {add_ok}")
    print(f"域边界核查(约束部分零消费): {boundary_ok}")

    all_pass = step0_pass and (len(non_zero_diffs) == 0) and add_ok and boundary_ok

    print("\n=== 警告（留痕，非失败） ===")
    for w in warnings:
        print(f"WARN: {w}")

    print(f"\n=== 最终判定: {'合格(PASS)' if all_pass else '不合格(FAIL)'} ===")
    if not all_pass:
        for f_ in failures:
            print(f"FAIL: {f_}")
        sys.exit(1)
    sys.exit(0)


if __name__ == "__main__":
    main()

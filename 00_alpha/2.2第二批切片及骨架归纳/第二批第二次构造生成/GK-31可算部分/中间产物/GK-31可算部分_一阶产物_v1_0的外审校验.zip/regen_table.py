import sys, json, importlib.util, os
vd = "/home/claude/gk31_audit/L1/verify"
sys.path.insert(0, vd)
spec = importlib.util.spec_from_file_location("ac", os.path.join(vd,"assert_check.py"))
ac = importlib.util.module_from_spec(spec); spec.loader.exec_module(ac)
h = ac.load_harness_output(); i = ac.run_independent_recompute()
comps, nz = ac.compare_numeric(h, i)
print("N_comparisons =", len(comps), " nonzero =", len(nz))
# 与交付TSV逐行对照
rows = open("/home/claude/gk31_audit/pkg/verify/comparison_table.tsv", encoding="utf-8").read().strip().splitlines()[1:]
tsv = {r.split("\t")[0]: (r.split("\t")[1], r.split("\t")[2], r.split("\t")[3]) for r in rows}
gen = {c[0]: (str(c[1]), str(c[2]), str(c[3])) for c in comps}
print("TSV rows =", len(tsv), " GEN rows =", len(gen))
print("仅见于TSV:", sorted(set(tsv)-set(gen)))
print("仅见于GEN:", sorted(set(gen)-set(tsv)))
mism = [(k, tsv[k], gen[k]) for k in sorted(set(tsv)&set(gen)) if tsv[k]!=gen[k]]
print("值不一致项数:", len(mism))
for m in mism[:10]: print("  ", m)

import os, shutil, subprocess, sys, json
SRC="/home/claude/gk31_audit/pkg"; W="/home/claude/gk31_audit/L3/sbx2"
def go(rel, old, new, rerun=True, extra=None):
    if os.path.exists(W): shutil.rmtree(W)
    shutil.copytree(SRC, W)
    p=os.path.join(W,rel); s=open(p,encoding="utf-8").read(); assert s.count(old)==1
    open(p,"w",encoding="utf-8").write(s.replace(old,new,1))
    if rerun:
        r=subprocess.run([sys.executable,"harness.py"],cwd=os.path.join(W,"entity"),capture_output=True,text=True)
    a=subprocess.run([sys.executable,"assert_check.py"],cwd=os.path.join(W,"verify"),capture_output=True,text=True)
    return a.returncode, a.stdout, a.stderr

# D2 协同变异：确认变异确实生效（输出值改变）且assert未检出
rc,out,err = go("entity/input_data.json",'"raw_vega": 18','"raw_vega": 118')
d=json.load(open(os.path.join(W,"entity/harness_output.json"),encoding="utf-8"))
print("[D2] assert_rc=",rc," far_convexity vega =",d["leg_aggregates"]["far_convexity_leg"]["vega"],"(交付基线74)")
print("[D2] vega_by_tenor =",d["leg_specific_observations"]["far_convexity_leg"]["vega_by_tenor"])
print("[D2] 比对行:", [l for l in out.splitlines() if "逐项比对" in l or "最终判定" in l])
print()
# C2 域边界语义实现（无字面串）
rc,out,err = go("entity/harness.py","def frac_to_jsonable(x):",
 "def approve_hedge_from_delta(leg_totals):\n    \"\"\"\u5355\u4e00Delta\u76f4\u63a5\u6279\u51c6\u5bf9\u51b2\u5224\u65ad\"\"\"\n    return leg_totals[\"core_position\"][\"delta\"] > 0\n\n\ndef frac_to_jsonable(x):")
print("[C2] assert_rc=",rc)
print("[C2] 域边界行:", [l for l in out.splitlines() if "域边界" in l or "最终判定" in l])
print()
# E1 击落归因
rc,out,err = go("entity/harness.py",'leg_totals[leg][g] += to_frac(n[f"raw_{g}"])','leg_totals[leg][g] = to_frac(n[f"raw_{g}"])')
print("[E1] assert_rc=",rc)
print("[E1] FAIL行:", [l for l in out.splitlines() if l.startswith("FAIL")][:2])
print()
# E3 击落归因
rc,out,err = go("entity/harness.py",'GREEK_KEYS = ["delta", "gamma", "vega", "theta", "rho"]','GREEK_KEYS = ["delta", "gamma", "vega", "theta"]')
print("[E3] assert_rc=",rc)
print("[E3] FAIL行:", [l for l in out.splitlines() if l.startswith("FAIL")][:2], "stderr头:", err.splitlines()[-1] if err else "")
print()
# C1a 协同drop rho 归因
if os.path.exists(W): shutil.rmtree(W)
shutil.copytree(SRC,W)
for rel in ["entity/harness.py","verify/independent_recompute.py"]:
    p=os.path.join(W,rel); s=open(p,encoding="utf-8").read()
    open(p,"w",encoding="utf-8").write(s.replace('GREEK_KEYS = ["delta", "gamma", "vega", "theta", "rho"]','GREEK_KEYS = ["delta", "gamma", "vega", "theta"]',1))
subprocess.run([sys.executable,"harness.py"],cwd=os.path.join(W,"entity"),capture_output=True,text=True)
a=subprocess.run([sys.executable,"assert_check.py"],cwd=os.path.join(W,"verify"),capture_output=True,text=True)
print("[C1a] assert_rc=",a.returncode," FAIL行:", [l for l in a.stdout.splitlines() if l.startswith("FAIL")][:2])

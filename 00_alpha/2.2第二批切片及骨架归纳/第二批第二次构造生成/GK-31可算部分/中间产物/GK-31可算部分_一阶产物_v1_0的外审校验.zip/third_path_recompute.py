#!/usr/bin/env python3
"""外审第三独立路径（路径独立层）· GK-31
结构分叉：矩阵/索引算术路径 —— 既非harness的手工dict就地累加，
亦非independent_recompute的sorted+groupby+生成器求和。
实现：建立 leg->行索引、greek->列索引 映射，累加入二维 list-of-list，
再由索引反查还原。子分列同法（bucket->索引）。
仅读 entity/input_data.json。
"""
import json, sys
from fractions import Fraction as F

INP = "/home/claude/gk31_audit/pkg/entity/input_data.json"
DEL = "/home/claude/gk31_audit/pkg/entity/harness_output.json"
GRE = ["delta", "gamma", "vega", "theta", "rho"]

doc = json.load(open(INP, encoding="utf-8"))
nodes = doc["nodes"]
legs = doc["coordinate_declaration"]["leg_type_domain"]
ri = {l: k for k, l in enumerate(legs)}
ci = {g: k for k, g in enumerate(GRE)}

M = [[F(0)] * len(GRE) for _ in legs]
cnt = [0] * len(legs)
for n in nodes:
    r = ri[n["leg_type"]]
    cnt[r] += 1
    for g in GRE:
        M[r][ci[g]] += F(n["raw_%s" % g])

def submatrix(leg, axis):
    keys, idx, rows = [], {}, []
    for n in nodes:
        if n["leg_type"] != leg:
            continue
        k = n[axis]
        if k not in idx:
            idx[k] = len(keys); keys.append(k); rows.append([F(0)] * len(GRE))
        for g in GRE:
            rows[idx[k]][ci[g]] += F(n["raw_%s" % g])
    return {keys[j]: {g: rows[j][ci[g]] for g in GRE} for j in range(len(keys))}

fc_ten = submatrix("far_convexity_leg", "tenor_bucket")
fc_mny = submatrix("far_convexity_leg", "moneyness_bucket")
tail_ot = submatrix("tail_protection_enhancement", "option_type")
nf = {g: M[ri["near_financing_leg"]][ci[g]] for g in GRE}

third = {
    "leg_aggregates": {l: {g: M[ri[l]][ci[g]] for g in GRE} for l in legs},
    "node_count_by_leg": {l: cnt[ri[l]] for l in legs},
    "vega_by_tenor": {k: v["vega"] for k, v in fc_ten.items()},
    "wing_delta_by_moneyness": {k: v["delta"] for k, v in fc_mny.items()},
    "left_tail_put": tail_ot["put"],
    "right_tail_call": tail_ot["call"],
    "theta_cost_right": tail_ot["call"]["theta"],
    "positive_theta_with_short_gamma": bool(nf["theta"] > 0 and nf["gamma"] < 0),
    "short_vega_flag": bool(nf["vega"] < 0),
    "total_nodes": len(nodes),
    "sum_by_leg": sum(cnt),
}

d = json.load(open(DEL, encoding="utf-8"))
mis = []
def chk(name, a, b):
    if F(a) != F(b) if not isinstance(a, bool) else a != b:
        mis.append((name, a, b))

for l in legs:
    for g in GRE:
        chk("leg_aggregates.%s.%s" % (l, g), third["leg_aggregates"][l][g], d["leg_aggregates"][l][g])
    chk("node_count_by_leg.%s" % l, third["node_count_by_leg"][l], d["node_count_by_leg"][l])
dl = d["leg_specific_observations"]
for k, v in third["vega_by_tenor"].items():
    chk("vega_by_tenor.%s" % k, v, dl["far_convexity_leg"]["vega_by_tenor"][k])
for k, v in third["wing_delta_by_moneyness"].items():
    chk("wing_delta_by_moneyness.%s" % k, v, dl["far_convexity_leg"]["wing_delta_by_moneyness"][k])
for g in GRE:
    chk("left_tail_put.%s" % g, third["left_tail_put"][g], dl["tail_protection_enhancement"]["left_tail_put"][g])
    chk("right_tail_call.%s" % g, third["right_tail_call"][g], dl["tail_protection_enhancement"]["right_tail_call"][g])
chk("theta_cost_right", third["theta_cost_right"], dl["tail_protection_enhancement"]["theta_cost_convexity_rent_right_tail"])
for k in ("positive_theta_with_short_gamma", "short_vega_flag"):
    if third[k] != dl["near_financing_leg"][k]:
        mis.append((k, third[k], dl["near_financing_leg"][k]))
chk("total_nodes", third["total_nodes"], d["leg_attribution_check"]["total_nodes"])
chk("sum_by_leg", third["sum_by_leg"], d["leg_attribution_check"]["sum_by_leg"])

print("第三路径比对项数 =", 25 + 5 + len(third["vega_by_tenor"]) + len(third["wing_delta_by_moneyness"]) + 10 + 1 + 2 + 2)
print("不一致项数 =", len(mis))
for m in mis: print("  MISMATCH:", m)
print("bucket键集 vega_by_tenor:", sorted(third["vega_by_tenor"]), " 交付:", sorted(dl["far_convexity_leg"]["vega_by_tenor"]))
print("bucket键集 wing_delta_by_moneyness:", sorted(third["wing_delta_by_moneyness"]), " 交付:", sorted(dl["far_convexity_leg"]["wing_delta_by_moneyness"]))
sys.exit(1 if mis else 0)

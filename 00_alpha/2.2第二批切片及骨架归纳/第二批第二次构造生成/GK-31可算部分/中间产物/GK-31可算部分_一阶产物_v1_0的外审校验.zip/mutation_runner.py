#!/usr/bin/env python3
"""外审第三层 · 变异注入运行器（GK-31）
锚点串由本外审会话独立书写（裁决32-③）：不取自被审代码常量，
亦不取自施工侧 verify/negative_control.py 的篡改锚点（该件锚点＝
harness_output.json 之 core_position.delta 1300→9999，本运行器不复用）。
协议：隔离副本→注入→（entity变异则重跑harness）→跑assert_check→记exit code。
"""
import json, os, shutil, subprocess, sys

SRC = "/home/claude/gk31_audit/pkg"
WORK = "/home/claude/gk31_audit/L3/sandbox"

# (id, 目标相对路径, old_str, new_str, 是否需重跑harness, 预期)
M = [
 ("E1","entity/harness.py",'leg_totals[leg][g] += to_frac(n[f"raw_{g}"])','leg_totals[leg][g] = to_frac(n[f"raw_{g}"])',True,"应击落"),
 ("E2","entity/harness.py","    for n in nodes:\n        leg = n[\"leg_type\"]","    for n in nodes[1:]:\n        leg = n[\"leg_type\"]",True,"应击落"),
 ("E3","entity/harness.py",'GREEK_KEYS = ["delta", "gamma", "vega", "theta", "rho"]','GREEK_KEYS = ["delta", "gamma", "vega", "theta"]',True,"应击落"),
 ("E4","entity/harness.py","leg_totals[leg] = {g: F(0) for g in GREEK_KEYS}","leg_totals[leg] = {g: F(1) for g in GREEK_KEYS}",True,"应击落"),
 ("E5","entity/harness.py",'bool(t["theta"] > 0 and t["gamma"] < 0)','bool(t["theta"] < 0 and t["gamma"] < 0)',True,"应击落"),
 ("E6","entity/harness.py",'vega_by_tenor[tb] = vega_by_tenor.get(tb, F(0)) + to_frac(n["raw_vega"])','vega_by_tenor[mb] = vega_by_tenor.get(mb, F(0)) + to_frac(n["raw_vega"])',True,"应击落"),
 ("E7","entity/harness.py","        for g in GREEK_KEYS:\n            result[ot][g] += to_frac(n[f\"raw_{g}\"])","        ot2 = \"call\" if ot == \"put\" else \"put\"\n        for g in GREEK_KEYS:\n            result[ot2][g] += to_frac(n[f\"raw_{g}\"])",True,"应击落"),
 ("E8","entity/harness.py","node_count_by_leg[leg] += 1","node_count_by_leg[leg] += 2",True,"应击落"),
 ("E9","entity/harness.py",'                    tail_breakdown["call"]["theta"]','                    tail_breakdown["put"]["theta"]',True,"应击落"),
 ("E10","entity/harness.py",'delta_by_moneyness[mb] = delta_by_moneyness.get(mb, F(0)) + to_frac(n["raw_delta"])','delta_by_moneyness[mb] = delta_by_moneyness.get(mb, F(0)) - to_frac(n["raw_delta"])',True,"应击落"),
 ("E11","entity/harness.py",'        if n["leg_type"] != "tail_protection_enhancement":','        if n["leg_type"] == "core_position":',True,"应击落"),
 ("E12","entity/harness.py","def to_frac(v):\n    return F(v)","def to_frac(v):\n    return int(v)",True,"数值等价改写(预期存活)"),
 ("E13","entity/harness.py",'LEG_DOMAIN = [\n    "core_position",\n    "near_financing_leg",','LEG_DOMAIN = [\n    "near_financing_leg",\n    "core_position",',True,"数值等价改写(预期存活)"),
 ("D1","entity/input_data.json",'"_data_source": "synthetic_hand_constructed"','"_data_source_removed": "x"',True,"应击落(step0-i)"),
 ("D2","entity/input_data.json",'"raw_vega": 18','"raw_vega": 118',True,"协同变异(区分力探测)"),
 ("C1a","entity/harness.py",'GREEK_KEYS = ["delta", "gamma", "vega", "theta", "rho"]','GREEK_KEYS = ["delta", "gamma", "vega", "theta"]',True,"协同(与C1b成对)"),
 ("C2","entity/harness.py","def frac_to_jsonable(x):","def approve_hedge_from_delta(leg_totals):\n    return leg_totals[\"core_position\"][\"delta\"] > 0\n\n\ndef frac_to_jsonable(x):",True,"域边界语义实现·无字面串(检出力探测)"),
 ("C3","entity/harness.py","GREEK_KEYS = [","BOUNDARY_ECHO = \"\u4e0d\u80fd\u5355\u72ec\u6279\u51c6\u5bf9\u51b2\"\nGREEK_KEYS = [",True,"应击落(域边界字面串)"),
 ("C4","verify/independent_recompute.py",'INPUT_PATH = "../entity/input_data.json"','INPUT_PATH = "../entity/input_data.json"\n_LEAK = "harness_output.json"',False,"应击落(step0-iii)"),
 ("C5","entity/harness.py","import json\nfrom fractions import Fraction as F","import json\nimport socket\nfrom fractions import Fraction as F",True,"应击落(step0-ii)"),
 ("C6a","entity/harness.py",'INPUT_PATH = "input_data.json"','# https://example.invalid\nINPUT_PATH = "input_data.json"',True,"设计内应存活(注释剥离)"),
 ("C6b","entity/harness.py",'INPUT_PATH = "input_data.json"','_U = "https://example.invalid"\nINPUT_PATH = "input_data.json"',True,"应击落(代码串)"),
]

def run(mid, rel, old, new, rerun):
    if os.path.exists(WORK): shutil.rmtree(WORK)
    shutil.copytree(SRC, WORK)
    p = os.path.join(WORK, rel)
    s = open(p, encoding="utf-8").read()
    if old not in s:
        return "锚点未命中", None, "注入失败"
    if s.count(old) != 1:
        return "锚点非唯一(%d)" % s.count(old), None, "注入失败"
    open(p, "w", encoding="utf-8").write(s.replace(old, new, 1))
    if mid == "C1a":  # 协同：同步改独立复算
        p2 = os.path.join(WORK, "verify/independent_recompute.py")
        s2 = open(p2, encoding="utf-8").read()
        o2 = 'GREEK_KEYS = ["delta", "gamma", "vega", "theta", "rho"]'
        assert o2 in s2
        open(p2, "w", encoding="utf-8").write(s2.replace(o2, 'GREEK_KEYS = ["delta", "gamma", "vega", "theta"]', 1))
    hrc = None
    if rerun:
        r = subprocess.run([sys.executable, "harness.py"], cwd=os.path.join(WORK, "entity"),
                           capture_output=True, text=True)
        hrc = r.returncode
    a = subprocess.run([sys.executable, "assert_check.py"], cwd=os.path.join(WORK, "verify"),
                       capture_output=True, text=True)
    return "注入成功", hrc, a.returncode

print("%-5s %-12s %-34s %-10s %-8s %s" % ("ID","目标","预期","注入","harness","assert_exit"))
res = []
for mid, rel, old, new, rerun, exp in M:
    st, hrc, arc = run(mid, rel, old, new, rerun)
    res.append((mid, rel, exp, st, hrc, arc))
    print("%-5s %-12s %-34s %-10s %-8s %s" % (mid, rel.split("/")[-1][:12], exp, st, hrc, arc))
json.dump([{"id":r[0],"target":r[1],"expect":r[2],"inject":r[3],"harness_rc":r[4],"assert_rc":r[5]} for r in res],
          open("/home/claude/gk31_audit/L3/mutation_results.json","w"), ensure_ascii=False, indent=2)

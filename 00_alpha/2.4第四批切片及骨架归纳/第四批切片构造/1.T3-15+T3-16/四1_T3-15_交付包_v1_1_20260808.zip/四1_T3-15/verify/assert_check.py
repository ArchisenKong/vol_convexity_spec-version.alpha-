#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""断言脚本 · 四1 · T3-15

判据面权威载体＝《任务6产出_记录容器格式与第一根切片合格判据》v1.11（模板三 A–D ＋ F-1~F-13）
＋《执行阶段实施操作手册》v1.8 §2/§3.1。本脚本为字面层判据之承担者；语义层判据之
权威证伪面＝人读审计，本脚本仅提供机械前哨（假阴性通道）。

退出码纪律（裁决28-B(ii)）：任一断言失败以非零退出码终止；仅打印 FAIL 而 exit=0 ＝判据不符档。
归因文案纪律（W-9(3)）：整体判定之失败归因按实际失败断言逐条输出，不写死单一原因。

声明面绑定（裁决75-9，F-14 本根兑现）：G 组断言对 schema §4／§5／§7／§12 之已成文表格、清单、
键集与期望值作程序化解析并与产物/脚本常量三方对表；禁以脚本内字面量替代 schema 解析。
D-3 令牌集经裁决75-4 修恒真（前版令牌可由 schema 自身章节标题满足，零区分力）。
计数型绑定经裁决75-43 收紧：§7 表行数／对表项数、§10 成分行数／判别行数／相异条款数
一律钉死等号，禁用下界——下界形态下表体行静默丢失不触发失败。

构造顺序留痕（F-10 最低形态·三处一致其二）：期望值钉表与人造 input 同轮提交，
先钉表后跑数；程序化时序证据不可得，如实标注（见 input_schema.md §7 与切片记录）。
"""

import ast
import hashlib
import json
import os
import re
import sys

_HERE = os.path.dirname(os.path.abspath(__file__))
_PKG = os.path.dirname(_HERE)
_ENTITY = os.path.join(_PKG, "entity")

# ---------------------------------------------------------------------------
# 装载面（判据级消费之源文档不入交付包——乙-3 交付件自足性口径：装载义务成文含源文）
# ---------------------------------------------------------------------------
SRC_T3 = "/mnt/project/3_波动率凸性操作方法论主文档_T0_frozen_clean_20260615.md"
SRC_AUDIT = "/mnt/project/翻译审计表_v1_6_定案_20260805.md"
SRC_ENGINE_RECORD = "/mnt/project/切片记录_TPL1-T76-01引擎_续2求值口径增强_v1_2_20260802.md"

# ---------------------------------------------------------------------------
# 容差（F-4 声明-实现一致性：本二值须与 input_schema.md §6 声明面逐字一致）
# ---------------------------------------------------------------------------
REL_TOL_CELL = 1e-12      # 子口径(b) 连续解析计算，裁决13设立／裁决19锚定值
ABS_TOL_AGG = 1e-8        # 相消型派生聚合量之实测派生绝对界（本根裁定登记，呈KD，不外推）

# ---------------------------------------------------------------------------
# F-1 静态扫描面（对象集＝全部交付脚本；封闭规则＝实际交付之任何其他 .py 自动入面）
# ---------------------------------------------------------------------------
ENUMERATED_SCRIPTS = [
    "entity/engine.py",
    "entity/harness.py",
    "verify/independent_recompute.py",
    "verify/assert_check.py",
    "verify/negative_control.py",
    "verify/build_provenance.py",
]
# 检测器自排除（F-1，裁决71-7）：排除面仅限检测器自身条目，唯一条目形态
SCAN_EXCLUDED = ["verify/assert_check.py"]

FORBIDDEN_PATTERNS = [
    # (a) import / from-import 七库模式（含 W-5 bare import 锚定形态）
    r"^\s*import\s+(requests|urllib|socket|yfinance|ibapi|ib_insync|pandas_datareader)\b",
    r"^\s*from\s+(requests|urllib|socket|yfinance|ibapi|ib_insync|pandas_datareader)\b",
    # (b) 关键字模式
    r"IBKR", r"QuantConnect", r"http://", r"https://", r"urlopen", r"requests\.", r"socket\.",
    # (c) 反混淆三条模式（任务6 v1.11 F-1 增量，裁决71-9）
    r"importlib", r"__import__", r"b64decode",
]

DECLARED_FILES = [
    "entity/engine.py",
    "entity/harness.py",
    "entity/harness_output.json",
    "entity/input_data.json",
    "entity/input_schema.md",
    "verify/assert_check.py",
    "verify/assert_check_log.txt",
    "verify/build_provenance.json",
    "verify/build_provenance.py",
    "verify/comparison_table.tsv",
    "verify/independent_expected.json",
    "verify/independent_recompute.py",
    "verify/negative_control.py",
    "verify/negative_control_log.txt",
]
# 封闭规则：DECLARED_FILES 为交付面全量声明；包内实际存在而未声明者＝检出"多"（F-7），
# 声明而不存在者＝检出"缺"。双向比对，无路径级排除项。

RESULTS = []


def check(cid, ok, detail=""):
    RESULTS.append((cid, bool(ok), detail))
    print("%s %s | %s" % ("PASS" if ok else "FAIL", cid, detail))
    return bool(ok)


def sha256(path):
    with open(path, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()


def strip_comments(text):
    """剥离注释与 docstring 后再判定（F-1 判定基面；GK-14/TC-33 假阳性教训）。"""
    text = re.sub(r'"""(?:.|\n)*?"""', "", text)
    text = re.sub(r"'''(?:.|\n)*?'''", "", text)
    out = []
    for line in text.split("\n"):
        out.append(re.sub(r"#.*$", "", line))
    return "\n".join(out)


def rel(a, b):
    if b == 0.0:
        return abs(a - b)
    return abs(a - b) / abs(b)


def _section(text, tag):
    """截取 schema 内 `## <tag> ...` 至下一 `## §` 之间的段落（裁决75-9 声明面解析基元）。"""
    m = re.search(r"^##\s*" + re.escape(tag) + r"[^\n]*\n(.*?)(?=^##\s*§|\Z)",
                  text, re.S | re.M)
    return m.group(1) if m else ""


# ===========================================================================
def main():
    # ---------------- step0 前置合规断言（合格前置，先于数值比对） -------------
    with open(os.path.join(_ENTITY, "input_data.json"), "r", encoding="utf-8") as f:
        indata = json.load(f)
    check("S0-i-1", indata.get("_data_source") == "synthetic_hand_constructed",
          "input 人造声明字段在场（裁决1）")
    numeric_ok = True
    for lot in indata["lots"]:
        for k in ("strike", "multiplier", "quantity"):
            if lot[k] is not None and not isinstance(lot[k], (int, float)):
                numeric_ok = False
    check("S0-i-2", numeric_ok, "人造持仓字段全为手工构造标量，无外部句柄")

    # step0(ii) 静态扫描面（全包域遍历，检"多"不止检"缺"，F-1/F-7）
    found_scripts = []
    for root, _dirs, files in os.walk(_PKG):
        for fn in files:
            if fn.endswith(".py"):
                found_scripts.append(os.path.relpath(os.path.join(root, fn), _PKG).replace(os.sep, "/"))
    found_scripts.sort()
    check("S0-ii-0", sorted(ENUMERATED_SCRIPTS) == found_scripts,
          "扫描面枚举清单 vs 全包实际脚本集双向一致：枚举=%d 实际=%d" %
          (len(ENUMERATED_SCRIPTS), len(found_scripts)))
    print("     [SCAN_EXCLUDED（检测器自排除，F-1／71-7）] %r" % (SCAN_EXCLUDED,))
    hits = []
    for rel_p in found_scripts:
        if rel_p in SCAN_EXCLUDED:
            continue
        with open(os.path.join(_PKG, rel_p), "r", encoding="utf-8") as f:
            body = strip_comments(f.read())
        for pat in FORBIDDEN_PATTERNS:
            for m in re.finditer(pat, body, flags=re.MULTILINE):
                hits.append((rel_p, pat, m.group(0)))
    check("S0-ii-1", not hits, "数据源静态扫描（剥离注释/docstring后）命中=%d %s" % (len(hits), hits[:3]))

    # step0(iii) 独立复算之独立性封闭规则（F-8）
    # 判定基面＝AST 结构面（import 节点 ＋ open() 调用之路径字面与模式），
    # 非全文子串匹配——子串面对脚本自身之独立性声明字符串产生结构性假阳性。
    with open(os.path.join(_HERE, "independent_recompute.py"), "r", encoding="utf-8") as f:
        ir_src = f.read()
    tree = ast.parse(ir_src)
    imported = set()
    for n in ast.walk(tree):
        if isinstance(n, ast.Import):
            imported |= {a.name.split(".")[0] for a in n.names}
        elif isinstance(n, ast.ImportFrom):
            imported.add((n.module or "").split(".")[0])
    opens = []
    for n in ast.walk(tree):
        if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id == "open":
            lits = [c.value for c in ast.walk(n.args[0])
                    if isinstance(c, ast.Constant) and isinstance(c.value, str)]
            mode = (n.args[1].value if len(n.args) > 1 and isinstance(n.args[1], ast.Constant)
                    else "r")
            opens.append((lits, mode))
    check("S0-iii-1", "engine" not in imported,
          "独立复算 import 面不含 engine：%r" % (sorted(imported),))
    check("S0-iii-2", ("harness" not in imported)
          and not any(any("harness" in x for x in lits) for lits, _m in opens),
          "独立复算不 import harness、不 open 任何 harness 产物")
    check("S0-iii-3", all(m.startswith("w")
                          for lits, m in opens
                          if any("independent_expected" in x for x in lits)),
          "独立复算不读取自身既往产物（自身产物仅出现于写模式 open）")

    # ---------------- 目录结构判据档（28-B(iii)，24-A7） ----------------------
    found_all = []
    for root, _dirs, files in os.walk(_PKG):
        for fn in files:
            found_all.append(os.path.relpath(os.path.join(root, fn), _PKG).replace(os.sep, "/"))
    found_all.sort()
    missing = [p for p in DECLARED_FILES if p not in found_all]
    extra = [p for p in found_all if p not in DECLARED_FILES]
    check("E-1", not missing, "声明交付件缺项=%r" % (missing,))
    check("E-2", not extra, "包内未声明件（检'多'）=%r" % (extra,))
    check("E-3", all(p.startswith("entity/") or p.startswith("verify/") for p in found_all),
          "打包结构＝entity/ ＋ verify/ 两目录，无域外件")

    # ---------------- 引擎逐字复用之机械核证（F-12 ＋ 手册§3.1 装载核证） -------
    with open(SRC_ENGINE_RECORD, "r", encoding="utf-8") as f:
        rec_txt = f.read()
    m = re.search(r"entity/engine\.py.*?`([0-9a-f]{64})`", rec_txt, flags=re.S)
    declared_engine = m.group(1) if m else None
    actual_engine = sha256(os.path.join(_ENTITY, "engine.py"))
    check("F12-1", declared_engine is not None,
          "自《切片记录_TPL1-T76-01引擎_续2 v1.2》程序化解析 engine.py 指纹")
    check("F12-2", declared_engine == actual_engine,
          "engine.py 逐字复用核证：交付件指纹＝收口版指纹 %s" % (actual_engine[:16],))

    # ---------------- 声明面双钉（F-5／F-8：schema 声明 vs 实算指纹） ----------
    with open(os.path.join(_ENTITY, "input_schema.md"), "r", encoding="utf-8") as f:
        schema = f.read()
    def schema_pin(name):
        mm = re.search(re.escape(name) + r"\s*\|\s*`([0-9a-f]{64})`", schema)
        return mm.group(1) if mm else None
    check("F5-1", schema_pin("entity/engine.py") == actual_engine,
          "§8 声明面钉定 engine.py 指纹与实算一致")
    bp_actual = sha256(os.path.join(_HERE, "build_provenance.json"))
    check("F5-2", schema_pin("verify/build_provenance.json") == bp_actual,
          "§8 声明面钉定 build_provenance.json 指纹与实算一致（钉定件自身入双钉射程，F-8）")

    # ---------------- 产物新鲜度 A10（F-3 流水线级 observable） ----------------
    with open(os.path.join(_HERE, "build_provenance.json"), "r", encoding="utf-8") as f:
        prov = json.load(f)
    fresh_bad = []
    for relp, pinned in prov["sha256"].items():
        cur = sha256(os.path.join(_PKG, relp))
        if cur != pinned:
            fresh_bad.append(relp)
    check("A10-1", not fresh_bad, "产物新鲜度：钉定六项当前指纹逐一对表，失配=%r" % (fresh_bad,))

    # ---------------- 声明-实现一致性（F-4，仅及 schema 已成文面） -------------
    with open(os.path.join(_ENTITY, "harness_output.json"), "r", encoding="utf-8") as f:
        ho = json.load(f)
    with open(os.path.join(_HERE, "independent_expected.json"), "r", encoding="utf-8") as f:
        ie = json.load(f)
    check("C-1", ho["substitution_order"] == indata["substitution_order"] == ["t", "S", "sigma"],
          "替换序声明-实现一致（schema §4／input_data／harness 三处）")
    check("C-2", ("REL_TOL_CELL = 1e-12" in schema) and ("ABS_TOL_AGG = 1e-8" in schema),
          "§6 容差声明面与本脚本常量逐字一致")
    declared_top = ["_data_source", "_declaration_ref", "_supply_pointer", "class_map",
                    "in_domain_roles", "out_of_domain_roles", "path_order_diagnostic",
                    "paths", "premium_ledger", "substitution_order"]
    check("C-3", sorted(ho.keys()) == sorted(declared_top),
          "harness_output 顶层键集恰等于声明集（无未声明键、无静默删键）")
    cm = ho["class_map"]
    check("C-4", sorted(cm.keys()) == ["C41_S_channel", "C42_iv_repricing",
                                       "C43_convexity_rent", "C44_dynamic_hedge_residual"],
          "四类→输出分量映射表在场且分量齐备（S-1 机械前哨）")
    check("C-5", cm["C41_S_channel"]["dims"] == ["S"]
          and cm["C42_iv_repricing"]["dims"] == ["sigma"]
          and cm["C43_convexity_rent"]["dims"] == ["t"]
          and sorted(cm["C44_dynamic_hedge_residual"]["roles"]) == ["hedge_action"],
          "四类归集规则与 schema §5 声明一致")

    # ---------------- 数值比对：逐单元格逐通道（D段②主面） --------------------
    rows = []
    worst = (0.0, None)
    n_cells = 0
    for pid in ("A", "B"):
        hc = {(c["lot_id"], c["step"]): c for c in ho["paths"][pid]["cells"]}
        ic = {(c["lot_id"], c["step"]): c for c in ie["paths"][pid]["cells"]}
        if sorted(hc.keys()) != sorted(ic.keys()):
            check("A-0-%s" % pid, False, "两侧单元格键集不一致")
            continue
        check("A-0-%s" % pid, True, "path %s 单元格键集两侧一致（%d 格）" % (pid, len(hc)))
        for key in sorted(hc.keys()):
            n_cells += 1
            for ch in ("ch_t", "ch_S", "ch_sigma", "diag_S_linear", "diag_S_convex"):
                h_v, i_v = hc[key][ch], ic[key][ch]
                r = rel(h_v, i_v)
                rows.append((pid, key[0], key[1], ch, "%.17g" % h_v, "%.17g" % i_v,
                             "%.3e" % r, "PASS" if r <= REL_TOL_CELL else "FAIL"))
                if r > worst[0]:
                    worst = (r, (pid, key[0], key[1], ch))
    bad_rows = [r for r in rows if r[-1] == "FAIL"]
    check("A-1", not bad_rows,
          "逐单元格逐通道比对 %d 项，子口径(b) rel≤%g；实测上界 %.3e @ %r；越限=%d"
          % (len(rows), REL_TOL_CELL, worst[0], worst[1], len(bad_rows)))

    with open(os.path.join(_HERE, "comparison_table.tsv"), "w", encoding="utf-8") as f:
        f.write("path\tlot_id\tstep\tchannel\tharness\tindependent\trel_diff\tverdict\n")
        for r in rows:
            f.write("\t".join(str(x) for x in r) + "\n")

    # ---------------- 闭合与聚合（Q4 判据：四类和＝总P/L） ---------------------
    for pid in ("A", "B"):
        p = ho["paths"][pid]
        gap = p["class_sum"] - p["attribution_domain_total_pl"]
        check("B-1-%s" % pid, abs(gap) <= ABS_TOL_AGG,
              "path %s 分解闭合｜四类和−归因域总P/L = %.3e（界 %g）" % (pid, gap, ABS_TOL_AGG))
        agg_bad = []
        for k, v in p["class_totals"].items():
            e = ie["paths"][pid]["class_totals"][k]
            if abs(v - e) > ABS_TOL_AGG:
                agg_bad.append((k, v - e))
        check("B-2-%s" % pid, not agg_bad,
              "path %s 类别聚合量两侧比对（相消型派生量，绝对界 %g）越限=%r" % (pid, ABS_TOL_AGG, agg_bad))
        check("B-3-%s" % pid, abs(p["out_of_domain_total_pl"]) > 1.0,
              "path %s 域外腿（底层线性持有）P/L 非零且未入四类和＝%.4f（下边界可证伪）"
              % (pid, p["out_of_domain_total_pl"]))

    # 分账结构断言（T3·511；宪-ST-06 口径同源）
    pl = ho["premium_ledger"]
    check("B-4", "分账" in pl["_separation_declaration"],
          "premium ledger 与 Greeks ledger 分账声明在场")
    check("B-5", all(abs(ho["paths"][p]["class_sum"] - ho["paths"][p]["attribution_domain_total_pl"])
                     <= ABS_TOL_AGG for p in ("A", "B")) and pl["net_open_cash"] != 0.0,
          "闭合恒等在不并入 premium ledger（净额 %.1f）之下成立＝分账未被静默并账"
          % (pl["net_open_cash"],))
    # 禁形核验（T3·498–505）：输出面不得出现覆盖率/净额型 funding 判定量
    # 仅扫描承载数值之字段名（`_` 前缀为声明性字段，非计算量）；
    # 模式加词界，避免 "declaration" 内 "ratio" 型结构性假阳性
    forbidden_fields = [k for pid in ("A", "B")
                        for k in ho["paths"][pid]["rent_two_column"].keys()
                        if not k.startswith("_")
                        and re.search(r"coverage|(?:^|_)ratio(?:$|_)|funding_safe|net_theta", k)]
    check("B-6", not forbidden_fields,
          "禁形核验：rent 双列无覆盖率/净额型 funding 判定字段 %r" % (forbidden_fields,))

    # ---------------- 路径序敏感性（T3·519 功能面） ---------------------------
    d = ho["path_order_diagnostic"]
    ca = indata["paths"]["A"]["coords"][-1]
    cb = indata["paths"]["B"]["coords"][-1]
    check("H-1", ca == cb, "A/B 端点坐标逐字段相同（同终点同总波前提成立）")
    check("H-2", abs(d["mother_structure_total_A"] - d["mother_structure_total_B"]) <= ABS_TOL_AGG,
          "母结构（无动作腿）总P/L 跨路径一致 diff=%.3e＝重估为坐标函数之结构性质"
          % (d["mother_structure_total_A"] - d["mother_structure_total_B"]))
    check("H-3", abs(d["domain_total_diff_A_minus_B"]) > 1.0,
          "同终点两路径归因域总P/L 不等 diff=%.4f＝dynamic hedge residual 之可指认证据"
          % (d["domain_total_diff_A_minus_B"],))
    check("H-4", abs((d["hedge_action_total_A"] - d["hedge_action_total_B"])
                     - d["domain_total_diff_A_minus_B"]) <= ABS_TOL_AGG,
          "路径序差额全部归属动作腿（C44）＝差额归属可指认")

    # ---------------- 28-B(i) 断言基线程序化解析源文 --------------------------
    if not os.path.exists(SRC_T3):
        check("I-0", False, "源文不可定位＝判不通过，禁静默回退内嵌副本：%s" % SRC_T3)
    else:
        check("I-0", True, "源文可定位（判据级消费之源文档不入交付包，乙-3）")
        with open(SRC_T3, "r", encoding="utf-8") as f:
            lines = f.read().split("\n")
        pinned = {459: "波动率下注的收益来源", 461: "Realized path convexity",
                  477: "Implied volatility repricing", 494: "Convexity rent",
                  517: "Dynamic hedge residual"}
        bad = [(n, w) for n, w in pinned.items() if w not in lines[n - 1]]
        check("I-1", not bad, "钉定判据源行锚定词在场（T3·459/461/477/494/517）失配=%r" % (bad,))
        seg = "\n".join(lines[458:535])
        functional_anchors = ["路径展开对结构暴露的激活", "不是方向预测",
                              "premium ledger 与 Greeks ledger 分账",
                              "不是直接 signal", "改写风险形状", "action lifecycle",
                              "相同总波动率，不代表相同 path P/L"]
        miss = [a for a in functional_anchors if a not in seg]
        check("I-2", not miss, "功能层锚定词必过面（F-6 分层；形状层词不设不作必过）缺=%r" % (miss,))
        check("I-3", "短端 theta 收入覆盖长端 theta" in seg,
              "禁形清单源行在场（T3·501）＝B-6 禁形核验之源文锚")

    # C4③ 成对核证：审计表现行版对应行在场且三态＝思想锚定
    if not os.path.exists(SRC_AUDIT):
        check("I-4", False, "翻译审计表不可定位（C4③ 成对装载缺件）")
    else:
        with open(SRC_AUDIT, "r", encoding="utf-8") as f:
            at = f.read()
        rows_ok = []
        for ln in ("459", "461", "477", "494", "517"):
            mm = re.search(r"\|\s*T3·" + ln + r"\s*\|(.*?)\|(.*?)\|", at)
            rows_ok.append(bool(mm) and "思想锚定" in mm.group(2))
        check("I-4", all(rows_ok), "审计表五行在场且三态＝思想锚定（C4② 闸门成立）%r" % (rows_ok,))

    # ---------------- F-13 反面陈述段在场 ＋ 随包义务在场 ---------------------
    check("D-1", "## §9 反面陈述段" in schema and schema.count("不代行") >= 4,
          "F-13 反面陈述段在场且含≥4条不代行声明")
    check("D-2", "仪表读数" in schema and "非真理源" in schema,
          "仪表身份标注在场（对照表§5.4 常设纪律）")
    # D-3（裁决75-4 修恒真）：前版以 schema 全文含 "§2"/"§3"/"§4" 为判据，而 schema 自身章节标题
    # 即含 "## §2" 等，令牌恒真、对目标属性零区分力（外审 F-04 检出，同型见四2 X14 逃逸）。
    # 现版＝对 §10 表体内「受控文本」后紧邻条款号作正则抽取＋计数下界，令牌不可由无关文本满足。
    sec10 = _section(schema, "§10")
    ctl_refs = re.findall(r"受控文本\**\s*(§\d+)", sec10)
    # 逐行覆盖核证（乙-7「逐处回引」之实装）：凡判别列指名类一/类二/类三/数据层之行，
    # 该行须携受控文本条款号，或显式同行转指（「同 K3 条目」式）。令牌不可由无关文本满足。
    _rows, _bad = 0, []
    for _ln in sec10.split("\n"):
        _c = [x.strip() for x in _ln.split("|")]
        if len(_c) < 6 or not re.match(r"^[A-Z]\d+$", _c[1]):
            continue
        _body = _c[3] + _c[4]
        if not re.search(r"类[一二三]|数据层", _c[3]):
            continue
        _rows += 1
        if not (re.search(r"受控文本\**\s*§\d+", _body) or re.search(r"同\s*[A-Z]\d+", _body)):
            _bad.append(_c[1])
    # 计数收紧（裁决75-43）：成分行/判别行/相异条款三项均钉死等号，禁下界。
    _all_rows = len([l for l in sec10.split("\n")
                     if re.match(r"^\|\s*[A-Z]\d+\s*\|", l)])
    check("D-3", "三分判别受控文本" in schema and _all_rows == 10 and _rows == 9 and not _bad
          and len(set(ctl_refs)) == 5,
          "三分判别逐处回引（乙-7）：成分行 %d/10（钉死）、判别行 %d/9（钉死）全数携条款号或同行转指、相异条款 %d/5（钉死）"
          % (_all_rows, _rows, len(set(ctl_refs)))
          + (("；缺回引：" + ",".join(_bad)) if _bad else ""))
    check("D-4", "_data_source" in schema and "synthetic_hand_constructed" in schema,
          "数据源纪律字段在 schema 声明面在场（裁决1）")
    check("D-5", "TPL1-T315-01" in schema and "TPL1-T315-02" in schema
          and "TPL3-T315-01" in schema and "TPL1-TC33-01" in schema,
          "撞墙/缺口条目指针在 schema 在场（含既有条目引用不重登）")

    # ---------------- G 组：声明面绑定（裁决75-9；F-14 本根兑现） ----------------
    # 立法意旨：凡 schema 已成文之表格/清单/键集/期望值，须由本脚本程序化解析 schema 文本
    # 并与产物/脚本常量三方对表；禁以脚本内字面量替代 schema 解析（外审 F-03 检出）。
    # 反面对照＝C-2 既已采此形态（容差常量），故本组为形态推广而非新能力。

    # G-1 · §12 顶层键集声明块 ↔ 脚本 declared_top ↔ 产物实况（三方）
    sec12 = _section(schema, "§12")
    m12 = re.search(r"```\s*\n(.*?)```", sec12, re.S)
    schema_top = sorted(t.strip() for t in (m12.group(1).split("\n") if m12 else []) if t.strip())
    check("G-1", bool(m12) and schema_top == sorted(declared_top) == sorted(ho.keys()),
          "§12 顶层键集声明块 ↔ 脚本声明集 ↔ 产物键集 三方一致（%d 键）" % len(schema_top))

    # G-2 · §12 单元格记录键集声明 ↔ 产物单元格键集
    m12c = re.search(r"单元格记录键集：`([^`]+)`", sec12)
    schema_cell = sorted(x.strip() for x in m12c.group(1).split("/")) if m12c else []
    prod_cell = sorted(ho["paths"]["A"]["cells"][0].keys())
    check("G-2", bool(m12c) and schema_cell == prod_cell,
          "§12 单元格记录键集声明 ↔ 产物单元格键集一致（%d 键）" % len(prod_cell))

    # G-3 · §7 期望值钉表 ↔ 产物实况（钉表保留10位小数，故以 1e-9 相对界吸收誊写舍入）
    sec7 = _section(schema, "§7")
    pinned = {}
    for line in sec7.split("\n"):
        cells = [c.strip() for c in line.split("|")]
        if len(cells) >= 4 and cells[1] and cells[1] not in ("项", "---"):
            try:
                pinned[cells[1]] = (float(cells[2].replace("−", "-")),
                                    float(cells[3].replace("−", "-")))
            except ValueError:
                continue
    prod_map = {}
    for pid in ("A", "B"):
        p = ho["paths"][pid]
        for k, v in p["class_totals"].items():
            prod_map.setdefault(k, {})[pid] = v
        prod_map.setdefault("四类和", {})[pid] = p["class_sum"]
        prod_map.setdefault("归因域总P/L", {})[pid] = p["attribution_domain_total_pl"]
        prod_map.setdefault("域外腿（底层线性持有）P/L", {})[pid] = p["out_of_domain_total_pl"]
        prod_map.setdefault("rent 双列·长端时间价值", {})[pid] = p["rent_two_column"]["long_wing_time_value"]
        prod_map.setdefault("rent 双列·短端时间价值", {})[pid] = p["rent_two_column"]["short_funding_time_value"]
    bound = 0.0
    n_bound = 0
    bad = []
    for name, (va, vb) in pinned.items():
        if name not in prod_map:
            continue
        for pid, want in (("A", va), ("B", vb)):
            if pid not in prod_map[name]:
                continue
            got = prod_map[name][pid]
            r = rel(want, got)
            n_bound += 1
            bound = max(bound, r)
            if r > 1e-9:
                bad.append("%s@%s rel=%.3e" % (name, pid, r))
    # 计数收紧（裁决75-43）：表行结构计数与绑定项数均钉死等号，禁下界——
    # 下界形态下，表体行静默丢失（掉出表结构或整行删除）不触发失败。
    n_tbl = len([l for l in sec7.split("\n")
                 if l.strip().startswith("|") and "---" not in l
                 and not l.strip().startswith("| 项")])
    check("G-3", n_tbl == 13 and n_bound == 18 and not bad,
          "§7 钉表 ↔ 产物绑定：表行 %d/13（钉死）、对表 %d/18（钉死），相对diff 上界 %.3e（誊写舍入界 1e-9）"
          % (n_tbl, n_bound, bound)
          + (("；越界：" + "; ".join(bad)) if bad else ""))

    # G-4 · §4 骨架件数声明 ↔ 表体实际条目
    sec4 = _section(schema, "§4")
    skel = re.findall(r"\*\*骨架-(\d+)", sec4)
    m_decl = re.search(r"骨架(六|五|四|七)件", schema)
    want_n = {"四": 4, "五": 5, "六": 6, "七": 7}.get(m_decl.group(1)) if m_decl else None
    check("G-4", want_n is not None and len(set(skel)) == want_n,
          "§4 骨架件数声明（%s）↔ 表体实际条目（%d）一致" % (want_n, len(set(skel))))

    # G-5 · §5 四类→分量映射表 ↔ 产物 class_map ↔ 脚本 CLASS_MAP（三方，替代纯字面量）
    sec5 = _section(schema, "§5")
    schema_fields = re.findall(r"`(C4\d_[A-Za-z0-9_]+)`", sec5)
    check("G-5", sorted(set(schema_fields)) == sorted(cm.keys()) == sorted(
          ["C41_S_channel", "C42_iv_repricing", "C43_convexity_rent",
           "C44_dynamic_hedge_residual"]),
          "§5 映射表字段名 ↔ 产物 class_map ↔ 脚本声明集 三方一致（%d 类）" % len(cm))

    # ---------------- 汇总 ---------------------------------------------------

    # G-6 · §7「实测容差」叙述 ↔ 本次实算（比对项数 ＋ 相对diff 实测上界）；外审 X23 逃逸面
    m_n = re.search(r"逐单元格逐通道比对\s*(\d+)\s*项", sec7)
    _SUP = {"⁰": "0", "¹": "1", "²": "2", "³": "3", "⁴": "4",
            "⁵": "5", "⁶": "6", "⁷": "7", "⁸": "8", "⁹": "9"}
    m_b = re.search(r"相对diff 实测上界\s*\*\*([0-9.]+)×10⁻([⁰¹²³⁴⁵⁶⁷⁸⁹]+)\*\*", sec7)
    ok6, det6 = False, "§7 实测容差叙述解析失败"
    if m_n and m_b:
        want_n = int(m_n.group(1))
        want_b = float(m_b.group(1)) * (10.0 ** (-int("".join(_SUP[c] for c in m_b.group(2)))))
        got_b = worst[0]
        # 叙述保留三位有效数字，故以 1e-2 相对界吸收其舍入；项数须精确一致
        ok6 = (want_n == len(rows)) and rel(want_b, got_b) <= 1e-2
        det6 = ("§7 实测容差叙述 ↔ 实算：项数 %d/%d，上界叙述 %.3e vs 实算 %.3e（叙述舍入界 1e-2）"
                % (want_n, len(rows), want_b, got_b))
    check("G-6", ok6, det6)


    # G-7 · 卷首元数据双钉（裁决75-45）：schema 标题行之版本/状态/日期三项钉死。
    # 双向失败面：schema 升版而本钉未改 → 失败；本钉已改而 schema 未升版 → 失败。
    _title = schema.split("\n")[0]
    _meta = ("v1.1", "收口态", "20260808")
    check("G-7", all(t in _title for t in _meta),
          "schema 卷首元数据 ↔ 脚本钉定一致（版本/状态/日期 %s）" % (_meta,))

    n_fail = sum(1 for _c, ok, _d in RESULTS if not ok)
    print("\n断言汇总：%d/%d PASS" % (len(RESULTS) - n_fail, len(RESULTS)))
    if n_fail:
        print("整体判定＝不合格。失败断言逐条：")
        for cid, ok, detail in RESULTS:
            if not ok:
                print("  - %s :: %s" % (cid, detail))
        sys.exit(1)
    print("整体判定＝全部断言通过（字面层；语义层权威证伪面＝人读审计）")
    sys.exit(0)


if __name__ == "__main__":
    main()

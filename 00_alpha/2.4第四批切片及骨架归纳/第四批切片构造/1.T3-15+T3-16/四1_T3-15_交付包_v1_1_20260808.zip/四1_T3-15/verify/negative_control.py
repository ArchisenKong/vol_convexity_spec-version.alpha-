#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""负向对照 · 四1 · T3-15

乙-4 mutation 最小形态：须**向被测实现（非比对器）注入至少一处已知变异**并断言其被击落。
F-9：被测侧注入案例集须含 **≥1 例经计算面断言击落**（数值/恒等式/声明一致性类），
     非仅新鲜度或流水线通道击落。

案例集：被测实现侧 2 例（案例1＝计算面击落例，案例2＝引擎源码级注入）
       ＋ 产物侧 4 例（案例3–6）。
每例：整包复制至临时工作区 → 施加单点变异 → 在副本内跑 verify/assert_check.py
     → 断言其以非零退出码终止且命中预期断言 ID。原包全程零改动。
"""

import os
import re
import shutil
import subprocess
import sys
import tempfile

_HERE = os.path.dirname(os.path.abspath(__file__))
_PKG = os.path.dirname(_HERE)

RESULTS = []


def _clone():
    d = tempfile.mkdtemp(prefix="nc_si1_")
    dst = os.path.join(d, "pkg")
    shutil.copytree(_PKG, dst)
    for lg in ("verify/assert_check_log.txt", "verify/negative_control_log.txt"):
        p = os.path.join(dst, lg)
        if not os.path.exists(p):
            open(p, "w", encoding="utf-8").close()
    for stray in ("entity/__pycache__", "verify/__pycache__"):
        sp = os.path.join(dst, stray)
        if os.path.isdir(sp):
            shutil.rmtree(sp)
    return d, dst


def _edit(path, old, new):
    with open(path, "r", encoding="utf-8") as f:
        s = f.read()
    assert s.count(old) == 1, "变异注入点命中数≠1（注入失效即变异不成立）：%r" % (old[:60],)
    with open(path, "w", encoding="utf-8") as f:
        f.write(s.replace(old, new))


def run_capture_fails(pkg):
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
    p = subprocess.run([sys.executable, os.path.join(pkg, "verify", "assert_check.py")],
                       capture_output=True, text=True, env=env, cwd=pkg)
    out = p.stdout + p.stderr
    fails = re.findall(r"^FAIL (\S+)", out, flags=re.M)
    return p.returncode, fails, out


def case(name, mutate, expect_id, kill_channel):
    tmp, pkg = _clone()
    try:
        mutate(pkg)
        rc, fails, out = run_capture_fails(pkg)
        killed = (rc != 0)
        hit = any(f.startswith(expect_id) for f in fails)
        ok = killed and hit
        RESULTS.append((name, ok, rc, fails, kill_channel))
        print("%s | %s | exit=%s | 击落通道=%s | 实际失败断言=%r"
              % ("检出" if ok else "**漏检**", name, rc, kill_channel, fails))
        if not ok:
            print(out[-1500:])
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


# --------------------------- 被测实现侧注入 --------------------------------
def m1(pkg):
    """案例1（被测实现侧·计算面）：harness 之 4.1 子分解一阶基准坐标由
    post_t_pre_S 改为 pre_t_pre_S——只动被测实现，不动比对器与产物。"""
    _edit(os.path.join(pkg, "entity", "harness.py"),
          'mid_t = _mix(c0, c1, {"t"})\n    delta_base = _eval(lot, mid_t, static)["per_lot"]["delta"]',
          'mid_t = _mix(c0, c1, set())\n    delta_base = _eval(lot, mid_t, static)["per_lot"]["delta"]')
    subprocess.run([sys.executable, os.path.join(pkg, "entity", "harness.py")],
                   capture_output=True, env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1"))
    subprocess.run([sys.executable, os.path.join(pkg, "verify", "build_provenance.py")],
                   capture_output=True, env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1"))
    # 同步刷新 schema §8 之 build_provenance 指纹，剥离新鲜度/双钉通道，
    # 迫使击落只能经计算面断言发生（F-9 要求之纯计算面击落例）
    import hashlib
    bp = os.path.join(pkg, "verify", "build_provenance.json")
    h = hashlib.sha256(open(bp, "rb").read()).hexdigest()
    sp = os.path.join(pkg, "entity", "input_schema.md")
    s = open(sp, encoding="utf-8").read()
    s = re.sub(r"(verify/build_provenance\.json \| `)[0-9a-f]{64}(`)", r"\g<1>" + h + r"\g<2>", s)
    open(sp, "w", encoding="utf-8").write(s)


def m2(pkg):
    """案例2（被测实现侧·引擎源码级）：欧式分支股息折现因子 disc_q 置 1.0。"""
    _edit(os.path.join(pkg, "entity", "engine.py"),
          "    disc_q = math.exp(-q * T)\n",
          "    disc_q = 1.0\n")
    subprocess.run([sys.executable, os.path.join(pkg, "entity", "harness.py")],
                   capture_output=True, env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1"))
    subprocess.run([sys.executable, os.path.join(pkg, "verify", "build_provenance.py")],
                   capture_output=True, env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1"))


# --------------------------- 产物侧注入 ------------------------------------
def m3(pkg):
    """案例3（产物侧）：篡改 C41 类别聚合量 +1e-6（低于人读察觉、高于聚合界）。"""
    import json
    p = os.path.join(pkg, "entity", "harness_output.json")
    o = json.load(open(p, encoding="utf-8"))
    o["paths"]["A"]["class_totals"]["C41_S_channel"] += 1e-6
    json.dump(o, open(p, "w", encoding="utf-8"), ensure_ascii=False, indent=2, sort_keys=True)


def m4(pkg):
    """案例4（产物侧）：静默删除一个归因单元格。"""
    import json
    p = os.path.join(pkg, "entity", "harness_output.json")
    o = json.load(open(p, encoding="utf-8"))
    o["paths"]["A"]["cells"] = o["paths"]["A"]["cells"][1:]
    json.dump(o, open(p, "w", encoding="utf-8"), ensure_ascii=False, indent=2, sort_keys=True)


def m5(pkg):
    """案例5（产物侧·声明面）：删除 F-13 反面陈述段段头。"""
    _edit(os.path.join(pkg, "entity", "input_schema.md"),
          "## §9 反面陈述段", "## §9 边界补注")


def m6(pkg):
    """案例6（产物侧·陈旧产物）：改 input_data 之一坐标而不重跑流水线。"""
    _edit(os.path.join(pkg, "entity", "input_data.json"),
          '"spot": 460.0, "iv_level": 0.30, "iv_spread": {"front": 0.05, "back": -0.02}},\n        {"idx": 2, "valuation_date": "2026-09-03", "spot": 520.0',
          '"spot": 461.0, "iv_level": 0.30, "iv_spread": {"front": 0.05, "back": -0.02}},\n        {"idx": 2, "valuation_date": "2026-09-03", "spot": 520.0')


def main():
    print("负向对照开始（原包零改动；全部变异在临时副本内施加）\n")
    case("案例1·被测实现侧·计算面（4.1 子分解基准坐标位移）", m1, "A-1", "计算面·逐单元格数值断言")
    case("案例2·被测实现侧·引擎源码（disc_q 置1）", m2, "F12-2", "指纹＋计算面")
    case("案例3·产物侧（类别聚合量 +1e-6）", m3, "B-2", "聚合量两侧比对（＋新鲜度旁路命中）")
    case("案例4·产物侧（静默删除单元格）", m4, "A-0", "单元格键集齐备")
    case("案例5·产物侧（删反面陈述段段头）", m5, "D-1", "F-13 在场断言")
    case("案例6·产物侧（陈旧产物）", m6, "A10-1", "产物新鲜度")

    impl = [r for r in RESULTS if r[0].startswith("案例1") or r[0].startswith("案例2")]
    prod = [r for r in RESULTS if r not in impl]
    n_ok = sum(1 for r in RESULTS if r[1])
    print("\n汇总：被测实现侧 %d/%d 检出；产物侧 %d/%d 检出；合计 %d/%d"
          % (sum(1 for r in impl if r[1]), len(impl),
             sum(1 for r in prod if r[1]), len(prod), n_ok, len(RESULTS)))
    print("F-9 核验：案例1 之击落通道＝计算面（逐单元格数值断言），非新鲜度/流水线通道。")
    if n_ok != len(RESULTS):
        print("存在漏检——负向对照不成立。")
        sys.exit(1)
    sys.exit(0)


if __name__ == "__main__":
    main()

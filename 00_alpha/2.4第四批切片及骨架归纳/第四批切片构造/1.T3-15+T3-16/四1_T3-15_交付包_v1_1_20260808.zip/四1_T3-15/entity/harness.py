#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""一次性 harness · 四1 · T3-15（收益来源四类·归因schema维度）

裁决1 合规声明：
  input 全部为人造手工构造（entity/input_data.json，`_data_source` 字段自证）；
  本脚本不接任何数据源（IBKR / QuantConnect / 历史行情 / 实时行情 / 文件数据源）；
  本脚本为一次性夹具，不建常设 pipeline / 数据接口 / 持久服务。

估值供给（M1 调用权，模块划分 v1.2）：
  entity/engine.py ＝ TPL1-T76-01 引擎已收口版（续2 v1.2，裁决58 终态）之逐字复用件，
  零改动；其 SHA256 由 verify/assert_check.py 对照《切片记录_TPL1-T76-01引擎_续2 v1.2》
  指纹列机械核证（手册 v1.8 §3.1 引擎装载核证纪律；F-12 逐字复用机械核证）。
  引擎供给之 V(t) 与 raw Greeks ＝仪表读数（非定价真理源，宪-EP-06 推论段；
  对照表 §5.4 常设纪律），本脚本对其零真理源宣称。

构造顺序留痕（F-10，三处一致其一）：期望值钉表（input_schema.md §7）与人造 input
同轮提交，先钉表后跑数。
"""

import json
import os
import sys

sys.dont_write_bytecode = True  # 交付面封闭：不产出 __pycache__（E-2 检"多"面）
_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)

import engine  # noqa: E402  （被测供给物；本脚本为其消费方）

DIM_ORDER_DECLARED = ("t", "S", "sigma")

# 四类收益来源 → 归集规则（T3§4.1–4.4 逐类功能对应）
# 值＝(角色集合, 维度集合)；`action_all` 为动作腿全维度归集标记
CLASS_MAP = {
    "C41_S_channel": {"roles": ("long_wing", "short_funding"), "dims": ("S",)},
    "C42_iv_repricing":            {"roles": ("long_wing", "short_funding"), "dims": ("sigma",)},
    "C43_convexity_rent":          {"roles": ("long_wing", "short_funding"), "dims": ("t",)},
    "C44_dynamic_hedge_residual":  {"roles": ("hedge_action",),              "dims": ("t", "S", "sigma")},
}
IN_DOMAIN_ROLES = ("long_wing", "short_funding", "hedge_action")
OUT_OF_DOMAIN_ROLES = ("underlying_beta",)


def _iv_of(lot, coord):
    if lot["instrument_class"] != "european_option":
        return None
    return coord["iv_level"] + coord["iv_spread"][lot["tenor_bucket"]]


def _build_lot_at(lot, coord, static):
    """按坐标构造引擎入参 lot（同形 lot 再次调用同一签名即得重估，引擎 schema §1）。"""
    return {
        "lot_id": lot["lot_id"],
        "instrument_class": lot["instrument_class"],
        "option_type": lot["option_type"],
        "side": lot["side"],
        "strike": lot["strike"],
        "expiry": lot["expiry"],
        "spot": coord["spot"],
        "risk_free_rate": static["risk_free_rate"],
        "implied_vol": _iv_of(lot, coord),
        "multiplier": lot["multiplier"],
        "quantity": lot["quantity"],
        "valuation_date": coord["valuation_date"],
        "dividend_yield": (static["dividend_yield_option"]
                           if lot["instrument_class"] == "european_option" else None),
    }


def _mix(coord_from, coord_to, take):
    """按 take 集合从 coord_to 取维度、其余取 coord_from，构造中间坐标。"""
    return {
        "idx": -1,
        "valuation_date": coord_to["valuation_date"] if "t" in take else coord_from["valuation_date"],
        "spot": coord_to["spot"] if "S" in take else coord_from["spot"],
        "iv_level": coord_to["iv_level"] if "sigma" in take else coord_from["iv_level"],
        "iv_spread": coord_to["iv_spread"] if "sigma" in take else coord_from["iv_spread"],
    }


def _eval(lot, coord, static):
    return engine.evaluate_lot(_build_lot_at(lot, coord, static))


def decompose_step(lot, c0, c1, static):
    """序贯重估分解：按声明替换序 (t, S, sigma) 逐维替换，各通道＝相邻两次重估之差。

    恒等式（望远镜求和）：ch_t + ch_S + ch_sigma == V(c1) - V(c0)，构造性成立。
    交互项被吸收入替换序中的后位通道——序之选择为构造自由度（TPL1-T315-01 占位桩）。
    """
    take = set()
    prev = _eval(lot, c0, static)["per_lot"]["value"]
    ch = {}
    greeks_at = {}
    for dim in DIM_ORDER_DECLARED:
        take.add(dim)
        mid = _mix(c0, c1, take)
        cur_full = _eval(lot, mid, static)
        cur = cur_full["per_lot"]["value"]
        ch[dim] = cur - prev
        greeks_at[dim] = cur_full["per_lot"]
        prev = cur
    # 4.1 内部线性/凸性子分解（诊断列，不参与闭合和）
    # 一阶基准 delta 取"已完成 t 替换、尚未替换 S"之坐标（类三候选，TPL3-T315-01）
    mid_t = _mix(c0, c1, {"t"})
    delta_base = _eval(lot, mid_t, static)["per_lot"]["delta"]
    lin = delta_base * (c1["spot"] - c0["spot"])
    return {
        "ch_t": ch["t"],
        "ch_S": ch["S"],
        "ch_sigma": ch["sigma"],
        "diag_S_linear": lin,
        "diag_S_convex": ch["S"] - lin,
        "delta_base_coord": "post_t_pre_S",
    }


def run_path(path, lots, static):
    coords = path["coords"]
    cells = []
    for k in range(1, len(coords)):
        c0, c1 = coords[k - 1], coords[k]
        for lot in lots:
            if not (lot["held_from_coord"] <= k - 1 and lot["held_to_coord"] >= k):
                continue
            d = decompose_step(lot, c0, c1, static)
            cells.append({
                "path_id": path["path_id"],
                "step": k,
                "lot_id": lot["lot_id"],
                "role": lot["role"],
                "tenor_bucket": lot["tenor_bucket"],
                "ch_t": d["ch_t"],
                "ch_S": d["ch_S"],
                "ch_sigma": d["ch_sigma"],
                "diag_S_linear": d["diag_S_linear"],
                "diag_S_convex": d["diag_S_convex"],
            })
    return cells


def aggregate(cells):
    cls = {k: 0.0 for k in CLASS_MAP}
    for c in cells:
        for name, rule in CLASS_MAP.items():
            if c["role"] in rule["roles"]:
                for dim in rule["dims"]:
                    cls[name] += c["ch_" + ("t" if dim == "t" else ("S" if dim == "S" else "sigma"))]
    return cls


def domain_total(cells):
    tot = 0.0
    for c in cells:
        if c["role"] in IN_DOMAIN_ROLES:
            tot += c["ch_t"] + c["ch_S"] + c["ch_sigma"]
    return tot


def out_of_domain_total(cells):
    tot = 0.0
    for c in cells:
        if c["role"] in OUT_OF_DOMAIN_ROLES:
            tot += c["ch_t"] + c["ch_S"] + c["ch_sigma"]
    return tot


def main():
    with open(os.path.join(_HERE, "input_data.json"), "r", encoding="utf-8") as f:
        data = json.load(f)
    static = data["static_market"]
    lots = data["lots"]

    assert tuple(data["substitution_order"]) == DIM_ORDER_DECLARED, \
        "声明-实现一致性（F-4）：input_data 之 substitution_order 与本脚本 DIM_ORDER_DECLARED 不一致"

    out = {
        "_data_source": "synthetic_hand_constructed",
        "_declaration_ref": "entity/input_schema.md",
        "_supply_pointer": "TPL1-T76-01 引擎（续2 v1.2 收口版）· M1 调用权；供给量身份＝仪表读数，非定价真理源",
        "substitution_order": list(DIM_ORDER_DECLARED),
        "class_map": {k: {"roles": list(v["roles"]), "dims": list(v["dims"])} for k, v in CLASS_MAP.items()},
        "in_domain_roles": list(IN_DOMAIN_ROLES),
        "out_of_domain_roles": list(OUT_OF_DOMAIN_ROLES),
        "paths": {},
        "premium_ledger": {
            "_separation_declaration": ("premium ledger 与 Greeks ledger 分账（T3·511 逐字）；"
                                        "本账不并入四类归集和，不与任何时间价值分量相减"),
            "entries": {lot["lot_id"]: lot["premium_ledger_open_cash"] for lot in lots},
            "net_open_cash": sum(lot["premium_ledger_open_cash"] for lot in lots),
        },
    }

    per_path_cells = {}
    for pid in ("A", "B"):
        path = data["paths"][pid]
        cells = run_path(path, lots, static)
        per_path_cells[pid] = cells
        cls = aggregate(cells)
        dtot = domain_total(cells)
        out["paths"][pid] = {
            "cells": cells,
            "class_totals": cls,
            "class_sum": sum(cls.values()),
            "attribution_domain_total_pl": dtot,
            "out_of_domain_total_pl": out_of_domain_total(cells),
            "closure_gap": sum(cls.values()) - dtot,
            "rent_two_column": {
                "long_wing_time_value": sum(c["ch_t"] for c in cells if c["role"] == "long_wing"),
                "short_funding_time_value": sum(c["ch_t"] for c in cells if c["role"] == "short_funding"),
                "_forbidden_form_declaration": ("本双列为分账并列呈报，不构成『短端theta收入覆盖长端theta』"
                                                "『positive Theta = funding safe』『short premium = realized profit』"
                                                "『cost basis down = risk down』任一表达（T3·498–505 禁形）；"
                                                "本切片不产出任何覆盖率/净额型 funding 判定量"),
            },
        }

    # 路径序敏感性诊断（T3·519 功能面）
    a, b = per_path_cells["A"], per_path_cells["B"]
    def sub(cells, roles):
        return sum(c["ch_t"] + c["ch_S"] + c["ch_sigma"] for c in cells if c["role"] in roles)
    out["path_order_diagnostic"] = {
        "endpoint_identical_declared": True,
        "mother_structure_total_A": sub(a, ("long_wing", "short_funding")),
        "mother_structure_total_B": sub(b, ("long_wing", "short_funding")),
        "hedge_action_total_A": sub(a, ("hedge_action",)),
        "hedge_action_total_B": sub(b, ("hedge_action",)),
        "domain_total_A": domain_total(a),
        "domain_total_B": domain_total(b),
        "domain_total_diff_A_minus_B": domain_total(a) - domain_total(b),
    }

    with open(os.path.join(_HERE, "harness_output.json"), "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2, sort_keys=True)
    print("harness 真跑完成：harness_output.json 已产出")
    for pid in ("A", "B"):
        p = out["paths"][pid]
        print("  path %s | 四类和=%.10f | 归因域总P/L=%.10f | 闭合差=%.3e"
              % (pid, p["class_sum"], p["attribution_domain_total_pl"], p["closure_gap"]))


if __name__ == "__main__":
    main()

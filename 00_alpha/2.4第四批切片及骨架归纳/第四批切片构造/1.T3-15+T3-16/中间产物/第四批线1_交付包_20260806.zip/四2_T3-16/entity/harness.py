#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""一次性 harness · 四2 · T3-16（成本来源·归因schema维度）

裁决1 合规声明：input 全部人造手工构造（`entity/input_data_core.json` 逐字承接四1、
`entity/input_data_cost_ext.json` 为四2域扩展）；本脚本不接任何数据源；一次性夹具，
不建常设 pipeline / 数据接口 / 持久服务。

成对同窗承接（72-4）：承接四1建立之归因口径骨架六件，不重建。本根仅施加一处**扩展**——
骨架-2 之 σ 维细分为 (sigma_level, sigma_spread) 两子维；细分为扩展，不回改四1产物。
承接一致性由 verify/assert_check.py 之 S3 断言组对四1产物逐单元格机械核证。

估值供给：entity/engine.py ＝ TPL1-T76-01 引擎收口版（续2 v1.2，裁决58）逐字复用件，
零改动，指纹机械核证。供给之 V(t) 为**仪表读数、非定价真理源**（宪-EP-06推论段）。

宪-ST-06 随行义务（内容命中即强制）：C51（theta decay cost）为**时间价值口径**，
premium ledger 为现金流口径之独立账；两口径分账并列，同一比较内不混用、不相减。
"""

import json
import os
import sys

sys.dont_write_bytecode = True
_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)

import engine  # noqa: E402

DIM_ORDER_DECLARED = ("t", "S", "sigma_level", "sigma_spread")
IN_DOMAIN_ROLES = ("long_wing", "short_funding", "hedge_action")


def _iv_parts(lot, coord):
    if lot["instrument_class"] != "european_option":
        return None, None
    return coord["iv_level"], coord["iv_spread"][lot["tenor_bucket"]]


def _build_lot(lot, vd, spot, lvl, spr, static):
    iv = None
    if lot["instrument_class"] == "european_option":
        iv = lvl + spr
    return {
        "lot_id": lot["lot_id"], "instrument_class": lot["instrument_class"],
        "option_type": lot["option_type"], "side": lot["side"],
        "strike": lot["strike"], "expiry": lot["expiry"], "spot": spot,
        "risk_free_rate": static["risk_free_rate"], "implied_vol": iv,
        "multiplier": lot["multiplier"], "quantity": lot["quantity"],
        "valuation_date": vd,
        "dividend_yield": (static["dividend_yield_option"]
                           if lot["instrument_class"] == "european_option" else None),
    }


def _V(lot, vd, spot, lvl, spr, static):
    return engine.evaluate_lot(_build_lot(lot, vd, spot, lvl, spr, static))["per_lot"]["value"]


def decompose(lot, c0, c1, static):
    """承接骨架-4 序贯重估分解；σ 维细分为 level → spread 两子步（四2扩展）。

    V000 →(t)→ V100 →(S)→ V110 →(σ_level)→ V111L →(σ_spread)→ V111
    恒等式：ch_t + ch_S + ch_sigma_level + ch_sigma_spread ≡ V(c1) − V(c0)
    且 ch_sigma_level + ch_sigma_spread ≡ 四1 之 ch_sigma（承接一致性）
    """
    l0f, l0b = c0["iv_level"], c0["iv_spread"]
    l1f, l1b = c1["iv_level"], c1["iv_spread"]
    bk = lot["tenor_bucket"]
    s0 = l0b[bk] if bk in l0b else 0.0
    s1 = l1b[bk] if bk in l1b else 0.0

    V000 = _V(lot, c0["valuation_date"], c0["spot"], l0f, s0, static)
    V100 = _V(lot, c1["valuation_date"], c0["spot"], l0f, s0, static)
    V110 = _V(lot, c1["valuation_date"], c1["spot"], l0f, s0, static)
    V11L = _V(lot, c1["valuation_date"], c1["spot"], l1f, s0, static)
    V111 = _V(lot, c1["valuation_date"], c1["spot"], l1f, s1, static)
    return {"ch_t": V100 - V000, "ch_S": V110 - V100,
            "ch_sigma_level": V11L - V110, "ch_sigma_spread": V111 - V11L}


def main():
    with open(os.path.join(_HERE, "input_data_core.json"), "r", encoding="utf-8") as f:
        core = json.load(f)
    with open(os.path.join(_HERE, "input_data_cost_ext.json"), "r", encoding="utf-8") as f:
        ext = json.load(f)
    static, lots = core["static_market"], core["lots"]

    assert tuple(ext["sigma_subdim_order"]) == ("sigma_level", "sigma_spread"), \
        "声明-实现一致性（F-4）：σ 子维序声明与实现不一致"

    cost_decl = ext["cost_face_declaration"]
    noncost_decl = ext["non_cost_face_declaration"]["cells"]

    def cell_keys(roles, dims):
        return {(r, d) for r in roles for d in dims}

    cost_cells = {}
    for name, spec in cost_decl.items():
        cost_cells[name] = cell_keys(spec["roles"], spec["dims"])
    noncost_cells = set()
    for spec in noncost_decl:
        noncost_cells |= cell_keys(spec["roles"], spec["dims"])
    universe = cell_keys(IN_DOMAIN_ROLES, DIM_ORDER_DECLARED)

    out = {
        "_data_source": "synthetic_hand_constructed",
        "_declaration_ref": "entity/input_schema.md",
        "_supply_pointer": "TPL1-T76-01 引擎（续2 v1.2 收口版）· M1 调用权；供给量身份＝仪表读数，非定价真理源",
        "_skeleton_inheritance": "承接四1归因口径骨架六件；扩展面＝σ维子细分（level/spread），不回改四1产物",
        "substitution_order": list(DIM_ORDER_DECLARED),
        "cost_face_map": {k: {"roles": v["roles"], "dims": v["dims"]} for k, v in cost_decl.items()},
        "in_domain_roles": list(IN_DOMAIN_ROLES),
        "partition_check": {
            "pairwise_disjoint_cost_views": True,
            "cost_and_noncost_disjoint": not (set().union(*cost_cells.values()) & noncost_cells),
            "cover_universe": (set().union(*cost_cells.values()) | noncost_cells) == universe,
            "cost_cells": sorted("%s.%s" % k for k in set().union(*cost_cells.values())),
            "noncost_cells": sorted("%s.%s" % k for k in noncost_cells),
            "universe_size": len(universe),
        },
        "paths": {},
        "premium_ledger": {
            "_separation_declaration": ("premium ledger 与 Greeks ledger 分账（T3·511）；"
                                        "宪-ST-06 口径同源——C51 为时间价值口径，本账为现金流口径，"
                                        "两口径不在同一比较内混用、不相减"),
            "entries": {lot["lot_id"]: lot["premium_ledger_open_cash"] for lot in lots},
            "short_end_income_open_cash": sum(l["premium_ledger_open_cash"] for l in lots
                                              if l["role"] == "short_funding"),
            "long_end_paid_open_cash": sum(l["premium_ledger_open_cash"] for l in lots
                                           if l["role"] == "long_wing"),
        },
        "execution_cost_ledger": ext["execution_cost_ledger"],
    }
    # 两两不交核验（成本四视图之 cell 集）
    names = [n for n in cost_cells if cost_cells[n]]
    for i in range(len(names)):
        for j in range(i + 1, len(names)):
            if cost_cells[names[i]] & cost_cells[names[j]]:
                out["partition_check"]["pairwise_disjoint_cost_views"] = False

    for pid in ("A", "B"):
        coords = core["paths"][pid]["coords"]
        cells = []
        for k in range(1, len(coords)):
            c0, c1 = coords[k - 1], coords[k]
            for lot in lots:
                if not (lot["held_from_coord"] <= k - 1 and lot["held_to_coord"] >= k):
                    continue
                d = decompose(lot, c0, c1, static)
                cells.append({"path_id": pid, "step": k, "lot_id": lot["lot_id"],
                              "role": lot["role"], "tenor_bucket": lot["tenor_bucket"], **d})
        totals = {}
        for name, spec in cost_decl.items():
            if name == "C54_execution_cost":
                totals[name] = -sum(e["total"] for e in ext["execution_cost_ledger"])
                continue
            s = 0.0
            for c in cells:
                if c["role"] in spec["roles"]:
                    for dim in spec["dims"]:
                        s += c["ch_" + ("t" if dim == "t" else ("S" if dim == "S" else dim))]
            totals[name] = s
        cost_total = sum(totals.values())
        domain_total = sum(c["ch_t"] + c["ch_S"] + c["ch_sigma_level"] + c["ch_sigma_spread"]
                           for c in cells if c["role"] in IN_DOMAIN_ROLES)
        noncost_total = 0.0
        for spec in noncost_decl:
            for c in cells:
                if c["role"] in spec["roles"]:
                    for dim in spec["dims"]:
                        noncost_total += c["ch_" + ("t" if dim == "t" else ("S" if dim == "S" else dim))]
        out["paths"][pid] = {
            "cells": cells,
            "cost_class_totals": totals,
            "cost_face_total": cost_total,
            "non_cost_face_total": noncost_total,
            "attribution_domain_total_pl": domain_total,
            "cost_plus_noncost_minus_domain": (cost_total
                                               - totals["C54_execution_cost"]
                                               + noncost_total - domain_total),
            "term_mismatch_view": {
                "front_bucket_sigma_spread": sum(c["ch_sigma_spread"] for c in cells
                                                 if c["tenor_bucket"] == "front"),
                "back_bucket_sigma_spread": sum(c["ch_sigma_spread"] for c in cells
                                                if c["tenor_bucket"] == "back"),
                "_note": ("期限错配成本之可加落点＝σ_spread 子维（占位桩，TPL1-T316-01 降格标注）；"
                          "源文 T3·583–591 之枚举项跨 5.1/5.2 已归属成分，非互斥，"
                          "不相交化规则源文未给——本落点不 claim 语义等价"),
            },
        }

    with open(os.path.join(_HERE, "harness_output.json"), "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2, sort_keys=True)
    print("harness 真跑完成：harness_output.json 已产出")
    for pid in ("A", "B"):
        p = out["paths"][pid]
        print("  path %s | 成本面四类和=%.10f | 成本面+非成本面-归因域=%.3e"
              % (pid, p["cost_face_total"], p["cost_plus_noncost_minus_domain"]))
    print("  划分核验：两两不交=%s 成本/非成本不交=%s 覆盖归因域全体=%s（%d格）"
          % (out["partition_check"]["pairwise_disjoint_cost_views"],
             out["partition_check"]["cost_and_noncost_disjoint"],
             out["partition_check"]["cover_universe"],
             out["partition_check"]["universe_size"]))


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""断言脚本 · 四2 · T3-16

判据面权威载体＝《任务6产出》v1.11（模板三 A–D ＋ F-1~F-13）＋《执行阶段实施操作手册》v1.8。
字面层判据由本脚本承担；语义层判据之权威证伪面＝人读审计，本脚本仅提供机械前哨。
退出码纪律（裁决28-B(ii)）：任一断言失败以非零退出码终止。
归因文案纪律（W-9(3)）：失败归因按实际失败断言逐条输出。
构造顺序留痕（F-10·三处一致其二）：期望值钉表与人造 input 同轮提交，先钉表后跑数；
程序化时序证据不可得，如实标注。
"""

import ast
import hashlib
import json
import os
import re
import sys

_HERE = os.path.dirname(os.path.abspath(__file__))
_PKG = os.path.dirname(_HERE)
_ENTITY = os.path.join(_PKG, "entity")

SRC_T3 = "/mnt/project/3_波动率凸性操作方法论主文档_T0_frozen_clean_20260615.md"
SRC_AUDIT = "/mnt/project/翻译审计表_v1_6_定案_20260805.md"
SRC_ENGINE_RECORD = "/mnt/project/切片记录_TPL1-T76-01引擎_续2求值口径增强_v1_2_20260802.md"

REL_TOL_CELL = 1e-12      # 子口径(b)，裁决13设立／裁决19锚定值
ABS_TOL_AGG = 1e-8        # 相消型派生聚合量之实测派生绝对界（承接四1本根裁定登记，呈KD，不外推）

ENUMERATED_SCRIPTS = [
    "entity/engine.py",
    "entity/harness.py",
    "verify/independent_recompute.py",
    "verify/assert_check.py",
    "verify/negative_control.py",
    "verify/build_provenance.py",
]
SCAN_EXCLUDED = ["verify/assert_check.py"]   # 检测器自排除，唯一条目（F-1／71-7）

FORBIDDEN_PATTERNS = [
    r"^\s*import\s+(requests|urllib|socket|yfinance|ibapi|ib_insync|pandas_datareader)\b",
    r"^\s*from\s+(requests|urllib|socket|yfinance|ibapi|ib_insync|pandas_datareader)\b",
    r"IBKR", r"QuantConnect", r"http://", r"https://", r"urlopen", r"requests\.", r"socket\.",
    r"importlib", r"__import__", r"b64decode",
]

DECLARED_FILES = [
    "entity/engine.py",
    "entity/harness.py",
    "entity/harness_output.json",
    "entity/input_data_core.json",
    "entity/input_data_cost_ext.json",
    "entity/input_schema.md",
    "entity/upstream_si1_harness_output.json",
    "verify/assert_check.py",
    "verify/assert_check_log.txt",
    "verify/build_provenance.json",
    "verify/build_provenance.py",
    "verify/comparison_table.tsv",
    "verify/independent_expected.json",
    "verify/independent_recompute.py",
    "verify/negative_control.py",
    "verify/negative_control_log.txt",
]

RESULTS = []


def check(cid, ok, detail=""):
    RESULTS.append((cid, bool(ok), detail))
    print("%s %s | %s" % ("PASS" if ok else "FAIL", cid, detail))
    return bool(ok)


def sha256(path):
    with open(path, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()


def strip_comments(text):
    text = re.sub(r'"""(?:.|\n)*?"""', "", text)
    text = re.sub(r"'''(?:.|\n)*?'''", "", text)
    return "\n".join(re.sub(r"#.*$", "", ln) for ln in text.split("\n"))


def rel(a, b):
    return abs(a - b) if b == 0.0 else abs(a - b) / abs(b)


def main():
    # ---------------- step0 前置合规 ----------------
    with open(os.path.join(_ENTITY, "input_data_core.json"), "r", encoding="utf-8") as f:
        core = json.load(f)
    with open(os.path.join(_ENTITY, "input_data_cost_ext.json"), "r", encoding="utf-8") as f:
        ext = json.load(f)
    check("S0-i-1", core.get("_data_source") == "synthetic_hand_constructed"
          and ext.get("_data_source") == "synthetic_hand_constructed",
          "核心 input 与成本侧扩展 input 均载人造声明字段（裁决1）")
    check("S0-i-2", all(isinstance(e["total"], (int, float)) for e in ext["execution_cost_ledger"]),
          "执行成本账为人造声明标量（数据层；计量模型缺口＝TPL1-T316-02）")

    found_scripts = sorted(
        os.path.relpath(os.path.join(r, fn), _PKG).replace(os.sep, "/")
        for r, _d, fs in os.walk(_PKG) for fn in fs if fn.endswith(".py"))
    check("S0-ii-0", sorted(ENUMERATED_SCRIPTS) == found_scripts,
          "扫描面枚举清单 vs 全包实际脚本集双向一致：枚举=%d 实际=%d"
          % (len(ENUMERATED_SCRIPTS), len(found_scripts)))
    print("     [SCAN_EXCLUDED（检测器自排除，F-1／71-7）] %r" % (SCAN_EXCLUDED,))
    hits = []
    for rp in found_scripts:
        if rp in SCAN_EXCLUDED:
            continue
        body = strip_comments(open(os.path.join(_PKG, rp), encoding="utf-8").read())
        for pat in FORBIDDEN_PATTERNS:
            for m in re.finditer(pat, body, flags=re.MULTILINE):
                hits.append((rp, pat, m.group(0)))
    check("S0-ii-1", not hits, "数据源静态扫描（剥离注释/docstring后）命中=%d %s" % (len(hits), hits[:3]))

    tree = ast.parse(open(os.path.join(_HERE, "independent_recompute.py"), encoding="utf-8").read())
    imported = set()
    for n in ast.walk(tree):
        if isinstance(n, ast.Import):
            imported |= {a.name.split(".")[0] for a in n.names}
        elif isinstance(n, ast.ImportFrom):
            imported.add((n.module or "").split(".")[0])
    opens = []
    for n in ast.walk(tree):
        if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id == "open":
            lits = [c.value for c in ast.walk(n.args[0])
                    if isinstance(c, ast.Constant) and isinstance(c.value, str)]
            mode = (n.args[1].value if len(n.args) > 1 and isinstance(n.args[1], ast.Constant) else "r")
            opens.append((lits, mode))
    check("S0-iii-1", "engine" not in imported, "独立复算 import 面不含 engine：%r" % (sorted(imported),))
    check("S0-iii-2", "harness" not in imported
          and not any(any("harness" in x for x in l) for l, _m in opens),
          "独立复算不 import harness、不 open 任何 harness 产物（含上游承接件）")
    check("S0-iii-3", all(m.startswith("w") for l, m in opens
                          if any("independent_expected" in x for x in l)),
          "独立复算不读取自身既往产物")

    # ---------------- 目录结构判据档 ----------------
    found_all = sorted(os.path.relpath(os.path.join(r, fn), _PKG).replace(os.sep, "/")
                       for r, _d, fs in os.walk(_PKG) for fn in fs)
    missing = [p for p in DECLARED_FILES if p not in found_all]
    extra = [p for p in found_all if p not in DECLARED_FILES]
    check("E-1", not missing, "声明交付件缺项=%r" % (missing,))
    check("E-2", not extra, "包内未声明件（检'多'）=%r" % (extra,))
    check("E-3", all(p.startswith("entity/") or p.startswith("verify/") for p in found_all),
          "打包结构＝entity/ ＋ verify/ 两目录，无域外件")

    # ---------------- 逐字复用之机械核证（F-12） ----------------
    rec = open(SRC_ENGINE_RECORD, encoding="utf-8").read()
    m = re.search(r"entity/engine\.py.*?`([0-9a-f]{64})`", rec, flags=re.S)
    eng_actual = sha256(os.path.join(_ENTITY, "engine.py"))
    check("F12-1", m is not None and m.group(1) == eng_actual,
          "engine.py 逐字复用核证：与引擎收口版指纹一致 %s" % eng_actual[:16])
    schema = open(os.path.join(_ENTITY, "input_schema.md"), encoding="utf-8").read()

    def pin(name):
        mm = re.search(re.escape(name) + r"\s*\|\s*`([0-9a-f]{64})`", schema)
        return mm.group(1) if mm else None
    core_actual = sha256(os.path.join(_ENTITY, "input_data_core.json"))
    up_actual = sha256(os.path.join(_ENTITY, "upstream_si1_harness_output.json"))
    check("F12-2", pin("entity/input_data_core.json") == core_actual,
          "四1 人造input之逐字承接件指纹与§8声明面一致 %s" % core_actual[:16])
    check("F12-3", pin("entity/upstream_si1_harness_output.json") == up_actual,
          "四1 harness产物之逐字承接件指纹与§8声明面一致 %s" % up_actual[:16])
    check("F5-1", pin("entity/engine.py") == eng_actual, "§8 声明面钉定 engine.py 指纹与实算一致")
    bp_actual = sha256(os.path.join(_HERE, "build_provenance.json"))
    check("F5-2", pin("verify/build_provenance.json") == bp_actual,
          "§8 钉定 build_provenance.json 指纹与实算一致（钉定件自身入双钉射程，F-8）")

    prov = json.load(open(os.path.join(_HERE, "build_provenance.json"), encoding="utf-8"))
    bad = [k for k, v in prov["sha256"].items() if sha256(os.path.join(_PKG, k)) != v]
    check("A10-1", not bad, "产物新鲜度：钉定 %d 项逐一对表，失配=%r" % (len(prov["sha256"]), bad))

    # ---------------- 声明-实现一致性 ----------------
    ho = json.load(open(os.path.join(_ENTITY, "harness_output.json"), encoding="utf-8"))
    ie = json.load(open(os.path.join(_HERE, "independent_expected.json"), encoding="utf-8"))
    check("C-1", ho["substitution_order"] == ["t", "S", "sigma_level", "sigma_spread"]
          and ext["sigma_subdim_order"] == ["sigma_level", "sigma_spread"],
          "替换序与σ子维序声明-实现一致（schema／input_data_cost_ext／harness 三处）")
    check("C-2", ("REL_TOL_CELL = 1e-12" in schema) and ("ABS_TOL_AGG = 1e-8" in schema),
          "§6 容差声明面与本脚本常量逐字一致")
    declared_top = ["_data_source", "_declaration_ref", "_skeleton_inheritance", "_supply_pointer",
                    "cost_face_map", "execution_cost_ledger", "in_domain_roles", "partition_check",
                    "paths", "premium_ledger", "substitution_order"]
    check("C-3", sorted(ho.keys()) == sorted(declared_top),
          "harness_output 顶层键集恰等于声明集（无未声明键、无静默删键）")
    check("C-4", sorted(ho["cost_face_map"].keys()) ==
          ["C51_long_end_bleed", "C52_short_end_income_risk",
           "C53_term_mismatch", "C54_execution_cost"],
          "四类→输出分量映射表在场且分量齐备（S-1 机械前哨）")
    cfm = ho["cost_face_map"]
    check("C-5", cfm["C51_long_end_bleed"] == {"roles": ["long_wing"], "dims": ["t"]}
          and cfm["C52_short_end_income_risk"] == {"roles": ["short_funding"], "dims": ["S", "sigma_level"]}
          and sorted(cfm["C53_term_mismatch"]["roles"]) == ["long_wing", "short_funding"]
          and cfm["C53_term_mismatch"]["dims"] == ["sigma_spread"],
          "成本面归集规则与 schema §5 声明一致")

    # ---------------- 划分核验（Q4 闭合之成本侧落写形态） ----------------
    pc = ho["partition_check"]
    check("P-1", pc["pairwise_disjoint_cost_views"], "成本四视图之单元格集两两不交")
    check("P-2", pc["cost_and_noncost_disjoint"], "成本面与非成本面不交")
    check("P-3", pc["cover_universe"],
          "成本面∪非成本面＝归因域全体单元格（%d 格，无静默丢量）" % pc["universe_size"])

    # ---------------- 数值比对：逐单元格逐通道 ----------------
    rows, worst, = [], (0.0, None)
    for pid in ("A", "B"):
        hc = {(c["lot_id"], c["step"]): c for c in ho["paths"][pid]["cells"]}
        ic = {(c["lot_id"], c["step"]): c for c in ie["paths"][pid]["cells"]}
        ok = sorted(hc) == sorted(ic)
        check("A-0-%s" % pid, ok, "path %s 单元格键集两侧一致（%d 格）" % (pid, len(hc)))
        if not ok:
            continue
        for key in sorted(hc):
            for ch in ("ch_t", "ch_S", "ch_sigma_level", "ch_sigma_spread"):
                r = rel(hc[key][ch], ic[key][ch])
                rows.append((pid, key[0], key[1], ch, "%.17g" % hc[key][ch],
                             "%.17g" % ic[key][ch], "%.3e" % r,
                             "PASS" if r <= REL_TOL_CELL else "FAIL"))
                if r > worst[0]:
                    worst = (r, (pid, key[0], key[1], ch))
    bad_rows = [r for r in rows if r[-1] == "FAIL"]
    check("A-1", not bad_rows,
          "逐单元格逐通道比对 %d 项，子口径(b) rel≤%g；实测上界 %.3e @ %r；越限=%d"
          % (len(rows), REL_TOL_CELL, worst[0], worst[1], len(bad_rows)))
    with open(os.path.join(_HERE, "comparison_table.tsv"), "w", encoding="utf-8") as f:
        f.write("path\tlot_id\tstep\tchannel\tharness\tindependent\trel_diff\tverdict\n")
        for r in rows:
            f.write("\t".join(str(x) for x in r) + "\n")

    for pid in ("A", "B"):
        p = ho["paths"][pid]
        agg_bad = [(k, v - ie["paths"][pid]["cost_class_totals"][k])
                   for k, v in p["cost_class_totals"].items()
                   if abs(v - ie["paths"][pid]["cost_class_totals"][k]) > ABS_TOL_AGG]
        check("B-1-%s" % pid, not agg_bad,
              "path %s 成本四类聚合量两侧比对（绝对界 %g）越限=%r" % (pid, ABS_TOL_AGG, agg_bad))
        check("B-2-%s" % pid, abs(p["cost_plus_noncost_minus_domain"]) <= ABS_TOL_AGG,
              "path %s 闭合：成本面(去执行成本账)+非成本面−归因域总P/L = %.3e"
              % (pid, p["cost_plus_noncost_minus_domain"]))
        check("B-3-%s" % pid,
              abs(p["cost_face_total"] - sum(p["cost_class_totals"].values())) <= ABS_TOL_AGG,
              "path %s 成本面总额＝四类和（含执行成本账）" % pid)
        check("B-4-%s" % pid, p["cost_class_totals"]["C51_long_end_bleed"] < 0,
              "path %s C51 长端时间价值分量为负（bleed 方向性，T3·541 功能面）＝%.4f"
              % (pid, p["cost_class_totals"]["C51_long_end_bleed"]))
        check("B-5-%s" % pid, abs(p["term_mismatch_view"]["front_bucket_sigma_spread"]) > 0.0
              and abs(p["term_mismatch_view"]["back_bucket_sigma_spread"]) > 0.0,
              "path %s 期限错配视图前后桶分量均非零（跨桶关系可指认）" % pid)

    pl = ho["premium_ledger"]
    check("B-6", pl["short_end_income_open_cash"] > 0 and pl["long_end_paid_open_cash"] < 0
          and "分账" in pl["_separation_declaration"] and "口径同源" in pl["_separation_declaration"],
          "premium ledger 分账双列在场且 ST-06 口径同源声明在场（收入 %.1f／支付 %.1f）"
          % (pl["short_end_income_open_cash"], pl["long_end_paid_open_cash"]))
    check("B-7", all(k not in json.dumps(ho, ensure_ascii=False)
                     for k in ("coverage_ratio", "funding_safe", "net_theta")),
          "禁形核验：输出面无覆盖率/净额型 funding 判定量（T3·594『不能被写成短端收入稳定覆盖长端支出』）")
    ec = ho["execution_cost_ledger"]
    check("B-8", len(ec) >= 1 and abs(sum(e["total"] for e in ec)
                                      - sum(e["bid_ask_cost"] + e["slippage_cost"] + e["commission"]
                                            for e in ec)) < 1e-9,
          "执行成本账三分项合计自洽（C54 之可算面）")

    # ---------------- S3 承接一致性（成对同窗；对四1产物逐单元格核证） ----------------
    up = json.load(open(os.path.join(_ENTITY, "upstream_si1_harness_output.json"), encoding="utf-8"))
    worst_s3 = (0.0, None)
    n_s3 = 0
    for pid in ("A", "B"):
        uc = {(c["lot_id"], c["step"]): c for c in up["paths"][pid]["cells"]}
        hc = {(c["lot_id"], c["step"]): c for c in ho["paths"][pid]["cells"]}
        for key in sorted(hc):
            n_s3 += 1
            r1 = rel(hc[key]["ch_t"], uc[key]["ch_t"])
            r2 = rel(hc[key]["ch_S"], uc[key]["ch_S"])
            r3 = rel(hc[key]["ch_sigma_level"] + hc[key]["ch_sigma_spread"], uc[key]["ch_sigma"])
            for r in (r1, r2, r3):
                if r > worst_s3[0]:
                    worst_s3 = (r, key)
    check("S3-1", worst_s3[0] <= REL_TOL_CELL,
          "承接一致性：%d 单元格逐格核证 ch_t／ch_S 与四1同值、σ两子通道之和＝四1 σ通道；"
          "实测上界 %.3e @ %r" % (n_s3, worst_s3[0], worst_s3[1]))
    check("S3-2", set((c["lot_id"], c["step"]) for c in up["paths"]["A"]["cells"]) ==
          set((c["lot_id"], c["step"]) for c in ho["paths"]["A"]["cells"]),
          "承接面单元格集与四1完全一致（同一人造场景，未静默改造）")
    check("S3-3", abs(ho["paths"]["A"]["attribution_domain_total_pl"]
                      - up["paths"]["A"]["attribution_domain_total_pl"]) <= ABS_TOL_AGG,
          "归因域总P/L 与四1一致（口径骨架承接未漂移）")

    # ---------------- 28-B(i) 源文程序化解析 ----------------
    if not os.path.exists(SRC_T3):
        check("I-0", False, "源文不可定位＝判不通过，禁静默回退内嵌副本")
    else:
        check("I-0", True, "源文可定位（判据级消费之源文档不入交付包，乙-3）")
        lines = open(SRC_T3, encoding="utf-8").read().split("\n")
        pinned = {539: "波动率下注的成本来源", 541: "Long-end premium bleed",
                  559: "Short-end premium income", 578: "期限错配成本", 596: "执行成本"}
        badp = [(n, w) for n, w in pinned.items() if w not in lines[n - 1]]
        check("I-1", not badp, "钉定判据源行锚定词在场（T3·539/541/559/578/596）失配=%r" % (badp,))
        seg = "\n".join(lines[538:600])
        anchors = ["权利金消耗与时间价值衰减", "必须与短端 premium income 分账",
                   "不是无风险 carry", "账本与风险共同体",
                   "既是结构预算关系，也是风险结构", "执行成本不是附属项",
                   "都必须包含执行成本和执行后审计计划"]
        miss = [a for a in anchors if a not in seg]
        check("I-2", not miss, "功能层锚定词必过面（F-6 分层；形状层词不设不作必过）缺=%r" % (miss,))
        check("I-3", "不能以删除母结构双翼为代价" in seg,
              "T3·557 身份纪律行在场＝§9 反面陈述之源文锚")
        # 非互斥实证（TPL1-T316-01 之源文证据）
        s53 = "\n".join(lines[577:592])
        check("I-4", ("back long option bleed" in s53) and ("front short option repricing" in s53),
              "§5.3 枚举项逐字覆盖 5.1/5.2 已归属成分＝四类非互斥之源文实证（TPL1-T316-01）")

    if not os.path.exists(SRC_AUDIT):
        check("I-5", False, "翻译审计表不可定位（C4③ 成对装载缺件）")
    else:
        at = open(SRC_AUDIT, encoding="utf-8").read()
        oks = []
        for ln in ("539", "541", "559", "578", "596"):
            mm = re.search(r"\|\s*T3·" + ln + r"\s*\|(.*?)\|(.*?)\|", at)
            oks.append(bool(mm) and "思想锚定" in mm.group(2))
        check("I-5", all(oks), "审计表五行在场且三态＝思想锚定（C4② 闸门成立）%r" % (oks,))

    # ---------------- 在场类断言 ----------------
    check("D-1", "## §9 反面陈述段" in schema and schema.count("不代行") >= 4,
          "F-13 反面陈述段在场且含≥4条不代行声明")
    check("D-2", "仪表读数" in schema and "非真理源" in schema, "仪表身份标注在场（对照表§5.4）")
    check("D-3", "计算成分三分判别受控文本" in schema
          and all(t in schema for t in ("§2", "§3", "§4")),
          "三分判别反向引用条款号在场（乙-7 单向回引）")
    check("D-4", "synthetic_hand_constructed" in schema, "数据源纪律字段在声明面在场（裁决1）")
    check("D-5", all(t in schema for t in ("TPL1-T316-01", "TPL1-T316-02",
                                           "TPL1-T315-01", "TPL3-T24-01", "TPL1-TC33-01")),
          "缺口条目指针在场（含承接四1条目与既有条目引用不重登）")
    check("D-6", "T-24" in schema and "不重建" in schema and "邻接不重叠" in schema,
          "S-5 T-24 邻接边界析出结果在 schema 显式成文")

    n_fail = sum(1 for _c, ok, _d in RESULTS if not ok)
    print("\n断言汇总：%d/%d PASS" % (len(RESULTS) - n_fail, len(RESULTS)))
    if n_fail:
        print("整体判定＝不合格。失败断言逐条：")
        for cid, ok, d in RESULTS:
            if not ok:
                print("  - %s :: %s" % (cid, d))
        sys.exit(1)
    print("整体判定＝全部断言通过（字面层；语义层权威证伪面＝人读审计）")
    sys.exit(0)


if __name__ == "__main__":
    main()

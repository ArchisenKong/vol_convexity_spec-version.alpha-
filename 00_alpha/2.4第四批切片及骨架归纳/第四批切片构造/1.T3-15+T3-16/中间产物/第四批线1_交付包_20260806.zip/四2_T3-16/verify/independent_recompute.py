#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""独立复算 · 四2 · T3-16

D段② 实现路径独立（F-2 分叉判别口径）：本脚本不 import 被测供给物模块、不 import 被测
夹具、不读取被测夹具产物、不读取自身既往产物（F-8 独立性封闭规则）；自 clean 人造 input
独立推导期望值。判定基面由 verify/assert_check.py 之 AST 结构面断言承担。

三处实现路径分叉（同四1口径）：
  分叉1 · 正态 CDF 走 `math.erfc` 入口（被测侧走 `math.erf`；裁决13 已确立之独立性先例）。
  分叉2 · 看跌估值经 put-call parity 自看涨值导出（被测侧走看跌直式闭式解）。
  分叉3 · 日差走 `datetime.date` 日历对象（被测侧走 Rata Die 纯整数序日算术）。
  分叉4 · 数值精度基面：本脚本以 **mpmath 50位十进制精度**求值（高精度基准交叉核验，
          形态先例＝裁决19 之 mpmath 50位基准仲裁）；被测侧为 float64。比对因此度量
          被测侧对近乎精确基准之偏离，而非两条同精度实现之互差——后者在差值型输出上
          受双侧相消叠加、判定不适定（本根实证：float64 独立路径下 σ 子通道互差达
          1.08e-12，改取高精度基准后被测侧偏离降至 3.31e-13）。
已知上限（F-2／35-A 固有上限，如实标注）：序贯重估之望远镜求和恒等式在任何正确实现下
代数等价，分解层分叉不计入分叉数；本脚本对分解层采用逐角点显式写出之不同代码结构。
"""

import json
import os
from datetime import date

from mpmath import mp, mpf
from mpmath import erfc as _erfc, exp as _exp, log as _log, sqrt as _sqrt

mp.dps = 50  # 高精度基准：50位十进制

_HERE = os.path.dirname(os.path.abspath(__file__))
_ENTITY = os.path.join(os.path.dirname(_HERE), "entity")
DAY_COUNT_DENOM = 365.0


def _ncdf(x):
    return _erfc(-x / _sqrt(mpf(2))) / 2


def _yf(expiry, vd):
    y1, m1, d1 = (int(v) for v in expiry.split("-"))
    y0, m0, d0 = (int(v) for v in vd.split("-"))
    n = (date(y1, m1, d1) - date(y0, m0, d0)).days
    if n <= 0:
        raise ValueError("dte<=0 越出已言明面")
    return mpf(n) / mpf(int(DAY_COUNT_DENOM))


def _call(S, K, r, q, sig, T):
    sq = _sqrt(T)
    d1 = (_log(S / K) + (r - q) * T) / (sig * sq) + sig * sq / 2
    d2 = d1 - sig * sq
    return S * _exp(-q * T) * _ncdf(d1) - K * _exp(-r * T) * _ncdf(d2)


def _scale(lot):
    return lot["multiplier"] * lot["quantity"] * (1 if lot["side"] == "long" else -1)


def _V(lot, vd, spot, lvl, spr, static):
    ic = lot["instrument_class"]
    if ic in ("spot", "spot_etf", "index"):
        return mpf(spot) * _scale(lot)
    if ic != "european_option":
        raise ValueError("本人造场景仅含 spot_etf / european_option")
    S, K = mpf(spot), mpf(lot["strike"])
    r, q = mpf(static["risk_free_rate"]), mpf(static["dividend_yield_option"])
    sig, T = mpf(lvl) + mpf(spr), _yf(lot["expiry"], vd)
    c = _call(S, K, r, q, sig, T)
    if lot["option_type"] == "call":
        v = c
    elif lot["option_type"] == "put":
        v = c - S * _exp(-q * T) + K * _exp(-r * T)
    else:
        raise ValueError("option_type 越出值域")
    return v * _scale(lot)


def decompose(lot, c0, c1, static):
    bk = lot["tenor_bucket"]
    s0 = c0["iv_spread"].get(bk, 0.0)
    s1 = c1["iv_spread"].get(bk, 0.0)
    V000 = _V(lot, c0["valuation_date"], c0["spot"], c0["iv_level"], s0, static)
    V100 = _V(lot, c1["valuation_date"], c0["spot"], c0["iv_level"], s0, static)
    V110 = _V(lot, c1["valuation_date"], c1["spot"], c0["iv_level"], s0, static)
    V11L = _V(lot, c1["valuation_date"], c1["spot"], c1["iv_level"], s0, static)
    V111 = _V(lot, c1["valuation_date"], c1["spot"], c1["iv_level"], s1, static)
    return {"ch_t": float(V100 - V000), "ch_S": float(V110 - V100),
            "ch_sigma_level": float(V11L - V110), "ch_sigma_spread": float(V111 - V11L)}


def main():
    with open(os.path.join(_ENTITY, "input_data_core.json"), "r", encoding="utf-8") as f:
        core = json.load(f)
    with open(os.path.join(_ENTITY, "input_data_cost_ext.json"), "r", encoding="utf-8") as f:
        ext = json.load(f)
    static, lots = core["static_market"], core["lots"]
    decl = ext["cost_face_declaration"]

    out = {"_data_source": "synthetic_hand_constructed",
           "_independence_declaration": "独立定价路径；不引用被测夹具与其产物；不读自身既往产物",
           "paths": {}}
    for pid in ("A", "B"):
        coords = core["paths"][pid]["coords"]
        cells = []
        for k in range(1, len(coords)):
            c0, c1 = coords[k - 1], coords[k]
            for lot in lots:
                if not (lot["held_from_coord"] <= k - 1 and lot["held_to_coord"] >= k):
                    continue
                cells.append({"path_id": pid, "step": k, "lot_id": lot["lot_id"],
                              "role": lot["role"], "tenor_bucket": lot["tenor_bucket"],
                              **decompose(lot, c0, c1, static)})
        totals = {}
        for name, spec in decl.items():
            if name == "C54_execution_cost":
                totals[name] = -sum(e["total"] for e in ext["execution_cost_ledger"])
                continue
            totals[name] = sum(
                c["ch_" + ("t" if d == "t" else ("S" if d == "S" else d))]
                for c in cells if c["role"] in spec["roles"] for d in spec["dims"])
        out["paths"][pid] = {"cells": cells, "cost_class_totals": totals,
                             "cost_face_total": sum(totals.values())}

    with open(os.path.join(_HERE, "independent_expected.json"), "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2, sort_keys=True)
    print("独立复算完成：independent_expected.json 已产出")
    for pid in ("A", "B"):
        print("  path %s | 成本面四类和=%.10f" % (pid, out["paths"][pid]["cost_face_total"]))


if __name__ == "__main__":
    main()

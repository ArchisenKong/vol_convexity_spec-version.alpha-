#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""负向对照 · 四2 · T3-16

乙-4：须向**被测实现（非比对器）**注入至少一处已知变异并断言其被击落。
F-9：被测侧案例集须含 **≥1 例经计算面断言击落**（数值/恒等式/声明一致性类），
     非仅新鲜度或流水线通道击落——案例1 即该例。
每例：整包复制至临时工作区 → 单点变异 → 副本内跑 verify/assert_check.py →
     断言非零退出码且命中预期断言 ID。原包全程零改动。
"""

import hashlib
import os
import re
import shutil
import subprocess
import sys
import tempfile

_HERE = os.path.dirname(os.path.abspath(__file__))
_PKG = os.path.dirname(_HERE)
_ENV = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
RESULTS = []


def _clone():
    d = tempfile.mkdtemp(prefix="nc_si2_")
    dst = os.path.join(d, "pkg")
    shutil.copytree(_PKG, dst)
    for lg in ("verify/assert_check_log.txt", "verify/negative_control_log.txt",
               "verify/comparison_table.tsv"):
        p = os.path.join(dst, lg)
        if not os.path.exists(p):
            open(p, "w", encoding="utf-8").close()
    for stray in ("entity/__pycache__", "verify/__pycache__"):
        sp = os.path.join(dst, stray)
        if os.path.isdir(sp):
            shutil.rmtree(sp)
    return d, dst


def _edit(path, old, new):
    s = open(path, encoding="utf-8").read()
    assert s.count(old) == 1, "变异注入点命中数≠1：%r" % (old[:60],)
    open(path, "w", encoding="utf-8").write(s.replace(old, new))


def _rerun_pipeline(pkg, refresh_pin=True):
    subprocess.run([sys.executable, os.path.join(pkg, "entity", "harness.py")],
                   capture_output=True, env=_ENV)
    subprocess.run([sys.executable, os.path.join(pkg, "verify", "build_provenance.py")],
                   capture_output=True, env=_ENV)
    if refresh_pin:
        bp = os.path.join(pkg, "verify", "build_provenance.json")
        h = hashlib.sha256(open(bp, "rb").read()).hexdigest()
        sp = os.path.join(pkg, "entity", "input_schema.md")
        s = open(sp, encoding="utf-8").read()
        s = re.sub(r"(verify/build_provenance\.json \| `)[0-9a-f]{64}(`)", r"\g<1>" + h + r"\g<2>", s)
        open(sp, "w", encoding="utf-8").write(s)


def run_capture_fails(pkg):
    p = subprocess.run([sys.executable, os.path.join(pkg, "verify", "assert_check.py")],
                       capture_output=True, text=True, env=_ENV, cwd=pkg)
    out = p.stdout + p.stderr
    return p.returncode, re.findall(r"^FAIL (\S+)", out, flags=re.M), out


def case(name, mutate, expect_id, channel):
    tmp, pkg = _clone()
    try:
        mutate(pkg)
        rc, fails, out = run_capture_fails(pkg)
        ok = (rc != 0) and any(f.startswith(expect_id) for f in fails)
        RESULTS.append((name, ok, channel))
        print("%s | %s | exit=%s | 击落通道=%s | 实际失败断言=%r"
              % ("检出" if ok else "**漏检**", name, rc, channel, fails))
        if not ok:
            print(out[-1500:])
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def m1(pkg):
    """案例1（被测实现侧·计算面）：σ 子步序颠倒（先 spread 后 level）。
    两子通道之**和**不变（S3-1 承接一致性无从检出），只有逐单元格数值断言可击落。"""
    _edit(os.path.join(pkg, "entity", "harness.py"),
          'V11L = _V(lot, c1["valuation_date"], c1["spot"], l1f, s0, static)',
          'V11L = _V(lot, c1["valuation_date"], c1["spot"], l0f, s1, static)')
    _rerun_pipeline(pkg)


def m2(pkg):
    """案例2（被测实现侧·引擎源码）：欧式分支股息折现因子 disc_q 置 1.0。"""
    _edit(os.path.join(pkg, "entity", "engine.py"),
          "    disc_q = math.exp(-q * T)\n", "    disc_q = 1.0\n")
    _rerun_pipeline(pkg)


def m3(pkg):
    """案例3（产物侧）：篡改 C51 成本聚合量 +1e-6。"""
    import json
    p = os.path.join(pkg, "entity", "harness_output.json")
    o = json.load(open(p, encoding="utf-8"))
    o["paths"]["A"]["cost_class_totals"]["C51_long_end_bleed"] += 1e-6
    json.dump(o, open(p, "w", encoding="utf-8"), ensure_ascii=False, indent=2, sort_keys=True)


def m4(pkg):
    """案例4（产物侧·承接件）：篡改四1 harness 产物之逐字承接件一处数值。"""
    import json
    p = os.path.join(pkg, "entity", "upstream_si1_harness_output.json")
    o = json.load(open(p, encoding="utf-8"))
    o["paths"]["A"]["cells"][0]["ch_sigma"] += 1e-3
    json.dump(o, open(p, "w", encoding="utf-8"), ensure_ascii=False, indent=2, sort_keys=True)


def m5(pkg):
    """案例5（产物侧·声明面）：删除 F-13 反面陈述段段头。"""
    _edit(os.path.join(pkg, "entity", "input_schema.md"), "## §9 反面陈述段", "## §9 边界补注")


def m6(pkg):
    """案例6（产物侧·陈旧产物）：改成本侧扩展 input 而不重跑流水线。"""
    _edit(os.path.join(pkg, "entity", "input_data_cost_ext.json"),
          '"bid_ask_cost": 97.50', '"bid_ask_cost": 98.50')


def main():
    print("负向对照开始（原包零改动；全部变异在临时副本内施加）\n")
    case("案例1·被测实现侧·计算面（σ子步序颠倒，和不变）", m1, "A-1", "计算面·逐单元格数值断言")
    case("案例2·被测实现侧·引擎源码（disc_q 置1）", m2, "F12-1", "指纹＋计算面")
    case("案例3·产物侧（成本聚合量 +1e-6）", m3, "B-1", "聚合量两侧比对")
    case("案例4·产物侧（篡改四1承接件）", m4, "F12-3", "承接件双钉指纹")
    case("案例5·产物侧（删反面陈述段段头）", m5, "D-1", "F-13 在场断言")
    case("案例6·产物侧（陈旧产物）", m6, "A10-1", "产物新鲜度")

    impl = RESULTS[:2]
    prod = RESULTS[2:]
    n_ok = sum(1 for r in RESULTS if r[1])
    print("\n汇总：被测实现侧 %d/%d 检出；产物侧 %d/%d 检出；合计 %d/%d"
          % (sum(1 for r in impl if r[1]), len(impl),
             sum(1 for r in prod if r[1]), len(prod), n_ok, len(RESULTS)))
    print("F-9 核验：案例1 之击落通道＝计算面（逐单元格数值断言）；该变异保持两子通道之和不变，"
          "承接一致性断言 S3-1 结构上无从检出，故其击落必经计算面。")
    if n_ok != len(RESULTS):
        print("存在漏检——负向对照不成立。")
        sys.exit(1)
    sys.exit(0)


if __name__ == "__main__":
    main()

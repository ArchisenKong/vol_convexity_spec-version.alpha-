#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""产物新鲜度钉定件生成 · 四1 · T3-15（F-8／F-3 流水线级 observable）

流水线末步：须在 entity/harness.py 与 verify/independent_recompute.py **全部产出之后**运行，
一次性钉定「源码-输入锚 → 产物」六项 SHA256。verify/assert_check.py 之 A10 断言组
重算当前六项并逐一对表；任一不一致＝产物陈旧或被篡改，判不合格。

新鲜度锚之设计（承接引擎根既裁设计要点）：
  independent_expected.json 之锚取 independent_recompute.py ＋ input_data.json，
  **不取 engine.py**——该产物依设计不 import 被测 engine（D段② 独立性纪律），
  锚取 engine.py 将造成「声明独立于被测实现」与「新鲜度依赖被测实现指纹」自相矛盾。
  harness_output.json 之锚取 engine.py ＋ harness.py ＋ input_data.json。

本钉定件自身之双钉（F-8）：build_provenance.json 之 SHA256 由 entity/input_schema.md
§8 声明面钉定，assert_check.py 重算比对——钉定件自身入双钉射程，非排除件。
"""

import hashlib
import json
import os

_HERE = os.path.dirname(os.path.abspath(__file__))
_PKG = os.path.dirname(_HERE)

PINNED = [
    "entity/engine.py",
    "entity/harness.py",
    "entity/input_data.json",
    "entity/harness_output.json",
    "verify/independent_recompute.py",
    "verify/independent_expected.json",
]

ANCHOR_MAP = {
    "entity/harness_output.json": ["entity/engine.py", "entity/harness.py", "entity/input_data.json"],
    "verify/independent_expected.json": ["verify/independent_recompute.py", "entity/input_data.json"],
}


def sha256(path):
    with open(path, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()


def main():
    rec = {"_purpose": "产物新鲜度钉定（F-8）", "anchor_map": ANCHOR_MAP, "sha256": {}}
    for rel in PINNED:
        rec["sha256"][rel] = sha256(os.path.join(_PKG, rel))
    with open(os.path.join(_HERE, "build_provenance.json"), "w", encoding="utf-8") as f:
        json.dump(rec, f, ensure_ascii=False, indent=2, sort_keys=True)
    print("build_provenance.json 已钉定 %d 项" % len(PINNED))
    print("本件自身 SHA256（须与 input_schema.md §8 声明面一致）：")
    print(sha256(os.path.join(_HERE, "build_provenance.json")))


if __name__ == "__main__":
    main()

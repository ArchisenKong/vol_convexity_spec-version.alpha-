#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""独立复算 · 四1 · T3-15

D段② 实现路径独立（任务6 v1.11 D段②；F-2 分叉判别口径）：
  本脚本 **不 import engine、不 import harness、不读取 harness_output.json、
  不读取自身既往产物**（F-8 独立性封闭规则），自 clean 人造 input 独立推导期望值。

三处实现路径分叉（分叉判别据＝改写后是否仍共享同一失效模式，F-2）：
  分叉1 · 正态 CDF 入口：`math.erfc` 路径（N(x)=0.5*erfc(-x/√2)），
          被测侧走 `math.erf` 路径——不同 libm 入口，裁决13 已确立之独立性先例。
  分叉2 · 看跌估值结构：经 put-call parity 自看涨值导出（P = C - S·e^(-qT) + K·e^(-rT)），
          被测侧走看跌直式闭式解——公式结构不同，浮点取消/舍入模式不同。
  分叉3 · 日差算法：`datetime.date` 日历对象求差，被测侧走 Rata Die 纯整数序日算术。

  分叉4 · 数值精度基面：本脚本以 **mpmath 50位十进制精度**求值（高精度基准交叉核验，
          形态先例＝裁决19 之 mpmath 50位基准仲裁），被测侧为 float64 双精度——
          比对之相对diff 因此度量被测侧对近乎精确基准之偏离，而非两条同精度实现之互差
          （后者在差值型输出上受双侧相消叠加，判定不适定）。

  已知上限（如实标注，F-2／35-A 固有上限口径）：序贯重估分解之望远镜求和恒等式
  在任何正确实现下代数等价，该层分叉不计入分叉数；本脚本对分解层采用
  **逐角点显式写出**（非循环替换）之不同代码结构，仅作结构分离，不 claim 失效模式分离。
  分解层之独立击落力由 verify/negative_control.py 之被测侧变异注入承担（乙-4）。
"""

import json
import os
from datetime import date

from mpmath import mp, mpf
from mpmath import erfc as _erfc, exp as _exp, log as _log, sqrt as _sqrt

mp.dps = 50  # 高精度基准：50位十进制

_HERE = os.path.dirname(os.path.abspath(__file__))
_ENTITY = os.path.join(os.path.dirname(_HERE), "entity")

DAY_COUNT_DENOM = 365.0  # ACT/365（裁决57-6 权威口径；与被测侧同一声明口径，非同一实现）


def _ncdf(x):
    """分叉1：erfc 入口（mpmath 50位）。"""
    return _erfc(-x / _sqrt(mpf(2))) / 2


def _year_frac(expiry, valuation_date):
    """分叉3：datetime 日历对象日差。"""
    y1, m1, d1 = (int(v) for v in expiry.split("-"))
    y0, m0, d0 = (int(v) for v in valuation_date.split("-"))
    days = (date(y1, m1, d1) - date(y0, m0, d0)).days
    if days <= 0:
        raise ValueError("dte<=0 越出已言明面")
    return mpf(days) / mpf(int(DAY_COUNT_DENOM))


def _d1d2(S, K, r, q, sig, T):
    sq = _sqrt(T)
    d1 = (_log(S / K) + (r - q) * T) / (sig * sq) + sig * sq / 2
    return d1, d1 - sig * sq


def _call_value(S, K, r, q, sig, T):
    d1, d2 = _d1d2(S, K, r, q, sig, T)
    return S * _exp(-q * T) * _ncdf(d1) - K * _exp(-r * T) * _ncdf(d2)


def _value_per_unit(lot, coord, static):
    """per-unit 估值（独立路径）。线性品种＝标的报价恒等。"""
    ic = lot["instrument_class"]
    if ic in ("spot", "spot_etf", "index"):
        return mpf(coord["spot"])
    if ic != "european_option":
        raise ValueError("本切片人造场景仅含 spot_etf / european_option 两品种: %r" % (ic,))
    S = mpf(coord["spot"])
    K = mpf(lot["strike"])
    r = mpf(static["risk_free_rate"])
    q = mpf(static["dividend_yield_option"])
    sig = mpf(coord["iv_level"]) + mpf(coord["iv_spread"][lot["tenor_bucket"]])
    T = _year_frac(lot["expiry"], coord["valuation_date"])
    c = _call_value(S, K, r, q, sig, T)
    if lot["option_type"] == "call":
        return c
    if lot["option_type"] == "put":
        # 分叉2：parity 导出
        return c - S * _exp(-q * T) + K * _exp(-r * T)
    raise ValueError("option_type 越出值域")


def _delta_per_unit(lot, coord, static):
    ic = lot["instrument_class"]
    if ic in ("spot", "spot_etf", "index"):
        return mpf(1)
    S = mpf(coord["spot"])
    K = mpf(lot["strike"])
    r = mpf(static["risk_free_rate"])
    q = mpf(static["dividend_yield_option"])
    sig = mpf(coord["iv_level"]) + mpf(coord["iv_spread"][lot["tenor_bucket"]])
    T = _year_frac(lot["expiry"], coord["valuation_date"])
    d1, _ = _d1d2(S, K, r, q, sig, T)
    dq = _exp(-q * T)
    if lot["option_type"] == "call":
        return dq * _ncdf(d1)
    # parity 导出：delta_put = delta_call - e^(-qT)
    return dq * _ncdf(d1) - dq


def _scale(lot):
    sign = 1 if lot["side"] == "long" else -1
    return lot["multiplier"] * lot["quantity"] * sign


def _corner(lot, static, vd, spot, lvl, spr):
    coord = {"valuation_date": vd, "spot": spot, "iv_level": lvl, "iv_spread": spr}
    return _value_per_unit(lot, coord, static) * _scale(lot)


def decompose(lot, c0, c1, static):
    """逐角点显式写出（替换序 t → S → sigma）。"""
    V000 = _corner(lot, static, c0["valuation_date"], c0["spot"], c0["iv_level"], c0["iv_spread"])
    V100 = _corner(lot, static, c1["valuation_date"], c0["spot"], c0["iv_level"], c0["iv_spread"])
    V110 = _corner(lot, static, c1["valuation_date"], c1["spot"], c0["iv_level"], c0["iv_spread"])
    V111 = _corner(lot, static, c1["valuation_date"], c1["spot"], c1["iv_level"], c1["iv_spread"])
    mid_t = {"valuation_date": c1["valuation_date"], "spot": c0["spot"],
             "iv_level": c0["iv_level"], "iv_spread": c0["iv_spread"]}
    delta_base = _delta_per_unit(lot, mid_t, static) * _scale(lot)
    lin = delta_base * (mpf(c1["spot"]) - mpf(c0["spot"]))
    return {
        "ch_t": float(V100 - V000),
        "ch_S": float(V110 - V100),
        "ch_sigma": float(V111 - V110),
        "diag_S_linear": float(lin),
        "diag_S_convex": float((V110 - V100) - lin),
    }


CLASS_MAP = {
    "C41_realized_path_convexity": (("long_wing", "short_funding"), ("ch_S",)),
    "C42_iv_repricing":            (("long_wing", "short_funding"), ("ch_sigma",)),
    "C43_convexity_rent":          (("long_wing", "short_funding"), ("ch_t",)),
    "C44_dynamic_hedge_residual":  (("hedge_action",),              ("ch_t", "ch_S", "ch_sigma")),
}
IN_DOMAIN = ("long_wing", "short_funding", "hedge_action")


def main():
    with open(os.path.join(_ENTITY, "input_data.json"), "r", encoding="utf-8") as f:
        data = json.load(f)
    static = data["static_market"]
    lots = data["lots"]

    out = {"_data_source": "synthetic_hand_constructed",
           "_independence_declaration": "不 import engine/harness；不读 harness_output.json；不读自身既往产物",
           "paths": {}}

    for pid in ("A", "B"):
        coords = data["paths"][pid]["coords"]
        cells = []
        for k in range(1, len(coords)):
            c0, c1 = coords[k - 1], coords[k]
            for lot in lots:
                if not (lot["held_from_coord"] <= k - 1 and lot["held_to_coord"] >= k):
                    continue
                d = decompose(lot, c0, c1, static)
                cells.append({"path_id": pid, "step": k, "lot_id": lot["lot_id"],
                              "role": lot["role"], "tenor_bucket": lot["tenor_bucket"], **d})
        cls = {}
        for name, (roles, keys) in CLASS_MAP.items():
            cls[name] = sum(c[k] for c in cells for k in keys if c["role"] in roles)
        dtot = sum(c["ch_t"] + c["ch_S"] + c["ch_sigma"] for c in cells if c["role"] in IN_DOMAIN)
        out["paths"][pid] = {
            "cells": cells,
            "class_totals": cls,
            "class_sum": sum(cls.values()),
            "attribution_domain_total_pl": dtot,
            "out_of_domain_total_pl": sum(c["ch_t"] + c["ch_S"] + c["ch_sigma"]
                                          for c in cells if c["role"] == "underlying_beta"),
            "rent_two_column": {
                "long_wing_time_value": sum(c["ch_t"] for c in cells if c["role"] == "long_wing"),
                "short_funding_time_value": sum(c["ch_t"] for c in cells if c["role"] == "short_funding"),
            },
        }

    with open(os.path.join(_HERE, "independent_expected.json"), "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2, sort_keys=True)
    print("独立复算完成：independent_expected.json 已产出")
    for pid in ("A", "B"):
        print("  path %s | 四类和=%.10f" % (pid, out["paths"][pid]["class_sum"]))


if __name__ == "__main__":
    main()

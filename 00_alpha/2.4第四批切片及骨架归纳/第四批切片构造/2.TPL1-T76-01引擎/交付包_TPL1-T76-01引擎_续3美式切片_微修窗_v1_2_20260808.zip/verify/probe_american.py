"""
TPL1-T7601-03 · 美式求值方式选型 · 实证探针（任务包四3 §2.6 义务件）

身份声明
--------
本脚本＝**探针**，非引擎正式求值路径之一部分。三候选实现均封闭于本文件内，
`entity/engine.py` 本轮零触碰（S-4：选型裁定前不得将任何候选写入正式求值路径）。
本脚本对候选之任何数值比较**不构成选型建议之裁定**——事实与边界呈KD，选型归KD。

数据源纪律（裁决1，全程强制）
-----------------------------
零网络、零行情接口、零外部数据源。全部输入取自 verify/probe_input.json
（`_data_source: synthetic_hand_constructed`）。

候选面（三候选名取自撞墙清单 TPL1-T7601-03 既登记判断点原文＋裁决72-4）
------------------------------------------------------------------------
  C-BSM ：欧式含q闭式解直接承接（＝引擎现行 `american_via_european_stub` 之路径本身）
          实现来源＝ import engine，调用其欧式分支；探针不复写该公式。
  C-BAW ：Barone-Adesi & Whaley (1987) 二次近似（含连续股息收益率 q）
  C-CRR ：Cox-Ross-Rubinstein 二叉树（含 q，逐节点提前行权判定）

比较维度（§2.6 义务②）
-----------------------
  ①早行权溢价识别力  ②欧式极限一致性  ③候选间差异之量级与形态留痕

容差/差异口径分派（§2.6 义务③；框架＝F-11 与 裁决13/19）
--------------------------------------------------------
  · C-BSM 值与五希腊       → 精确解析量，裁决13/19 子口径(b) 相对diff ≤ 1e-12
  · C-CRR 值               → **声明离散近似量**（步数N之截断误差 O(1/N)）→ F-11
  · C-BAW 值               → 解析近似 ＋ 内层临界价 Newton 迭代
                             → 裁决13 迭代类（**开放项，本探针为其首个实例**，见输出 findings）
  · 三候选之差分希腊       → **声明离散近似量**（声明步长下之差分导数）→ F-11
  · 恒等零检（EEP≡0 情形） → F-11 主判据形态＝**离散不变量零容差**（bit-exact）

先钉表后跑数（F-10 文字声明处之一）
-----------------------------------
本脚本之比较维度、候选集、恒等零检用例（A7/B1）、声明步长，均于跑数前写定于
probe_input.json 与本文件头注，非按跑出结果回填。
"""

import datetime
import json
import math
import os
import sys

_HERE = os.path.dirname(os.path.abspath(__file__))
_PKG = os.path.dirname(_HERE)
sys.path.insert(0, os.path.join(_PKG, "entity"))
import engine  # noqa: E402  包内 engine 之欧式分支＝C-BSM候选与欧式基线读数来源
# 丙类修复注记（D-3采α案，裁决76-1(c)）：本探针产出于**选型时点**（包内 engine 尚为
# v1.2、美式分支未建），故 probe_output.json 之 `_engine_baseline` 字段记 "v1.2"。
# 续3 后包内 engine 为 v1.3，其**欧式分支行为与 v1.2 逐字节等同**（S-2 零判定翻转
# 机械承载），故本探针在 v1.3 下重跑产物逐字节复现。`_engine_baseline` 字段为
# **产出时点之记录**，维持不动——改写将破坏"交付形态零修改可重跑且产物逐字节
# 复现"之判据面（任务包§3 判据4）。该陈述面与包内现版之名义落差如实登记于
# 撞墙清单引擎 v1.5 施工过程发现事项，不以静默改写消除。


# =========================================================================
# 0. 输入装载
# =========================================================================

def load_input():
    with open(os.path.join(_HERE, "probe_input.json"), encoding="utf-8") as f:
        d = json.load(f)
    assert d["_data_source"] == "synthetic_hand_constructed"
    assert d["declared_numeric_conventions"]["day_count_denominator"] == \
        engine.DAY_COUNT_DENOMINATOR, "探针day count口径须与引擎权威值一致"
    return d


def _lot_from_case(c, ic, exercise_style, spot=None, vol=None, rate=None, dte=None):
    """按引擎已言明最小面构造 lot（探针内部用；multiplier/quantity/side 取中性值
    使 per_unit 即为逐份额量）。

    `exercise_style` 为**显式必传形参**（丙类修复 D-3采α案，裁决76-1(c)）：
    引擎自 v1.3 起该字段必填且**不由 instrument_class 推导**（KD裁定§6），
    本构造函数彼时未产出该字段，致交付形态下探针直接执行即 raise
    （外审 D-3：`ValueError: exercise_style 为必填字段，缺位`）。此处不设默认值、
    不在函数内由 `ic` 推导——推导形态将在探针侧复刻引擎已明令排除之耦合；
    改由各调用点按已言明面显式声明，与引擎"调用方须同时给出两轴"之口径一致。
    """
    dd = c["dte"] if dte is None else dte
    y0, m0, d0 = 2026, 1, 1
    return {
        "lot_id": "PROBE-" + c["case_id"],
        "instrument_class": ic,
        "option_type": c["option_type"],
        "side": "long",
        "strike": c["strike"],
        "expiry": _date_add("2026-01-01", dd),
        "spot": c["spot"] if spot is None else spot,
        "risk_free_rate": c["risk_free_rate"] if rate is None else rate,
        "implied_vol": c["implied_vol"] if vol is None else vol,
        "multiplier": 1,
        "quantity": 1,
        "valuation_date": "2026-01-01",
        "dividend_yield": c["dividend_yield"],
        "exercise_style": exercise_style,
    }


def _date_add(base, days):
    """base(yyyy-mm-dd) + days → yyyy-mm-dd。
    仅用于探针输入构造（把整数 dte 还原为 expiry 字符串喂给引擎），
    不进入任何求值口径；引擎侧 dte 仍由 engine._dte_days 自行计算。
    构造后即以 engine._dte_days 反向断言往返一致（见 main 之 X0 自检）。"""
    y, m, d = (int(t) for t in base.split("-"))
    return (datetime.date(y, m, d) + datetime.timedelta(days=days)).isoformat()


# =========================================================================
# 1. 候选 C-BSM：欧式含q闭式解（引擎现行桩路径本身）
# =========================================================================

def cand_bsm(c, spot=None, vol=None, rate=None, dte=None):
    """直接调用引擎欧式分支。探针不复写该公式（避免与被测实现共模，且本候选之
    语义正是'现行桩路径原样保留'）。"""
    lot = _lot_from_case(c, "european_option", "european", spot, vol, rate, dte)
    return engine.evaluate_lot(lot)["per_unit"]


# =========================================================================
# 2. 数值原语（探针自备；与 engine 同形但独立书写，供 BAW/CRR 使用）
# =========================================================================

def _N(x):
    return 0.5 * (1.0 + math.erf(x / math.sqrt(2.0)))


def _n(x):
    return math.exp(-0.5 * x * x) / math.sqrt(2.0 * math.pi)


def _bs(S, K, r, q, sig, T, otype):
    """欧式含q闭式解（探针自备副本，仅供 BAW 内层使用；与引擎之数值一致性
    在 T1' 中程序化核对）。"""
    sqrtT = math.sqrt(T)
    d1 = (math.log(S / K) + (r - q + 0.5 * sig * sig) * T) / (sig * sqrtT)
    d2 = d1 - sig * sqrtT
    dr, dq = math.exp(-r * T), math.exp(-q * T)
    if otype == "call":
        return S * dq * _N(d1) - K * dr * _N(d2), d1
    return K * dr * _N(-d2) - S * dq * _N(-d1), d1


# =========================================================================
# 3. 候选 C-BAW：Barone-Adesi & Whaley 二次近似（含 q）
# =========================================================================

BAW_TOL = 1e-10          # 临界价 Newton 收敛判据（声明值）
BAW_MAX_ITER = 200
_baw_iter_log = []       # (case_id, otype, iters, converged, residual)


def _baw_critical(K, r, q, sig, T, otype, tag=""):
    """求临界价 S*（call）／S**（put）：Newton 迭代，失败降级二分。
    返回 (S_crit, iters, converged, residual)。"""
    v2 = sig * sig
    M = 2.0 * r / v2
    Nn = 2.0 * (r - q) / v2
    Kk = 1.0 - math.exp(-r * T)
    if Kk <= 0.0:
        return None, 0, False, float("nan")   # r=0：本近似式退化，另行处置

    if otype == "call":
        q2 = (-(Nn - 1.0) + math.sqrt((Nn - 1.0) ** 2 + 4.0 * M / Kk)) / 2.0
        qq = q2
    else:
        q1 = (-(Nn - 1.0) - math.sqrt((Nn - 1.0) ** 2 + 4.0 * M / Kk)) / 2.0
        qq = q1

    def f(S):
        c, d1 = _bs(S, K, r, q, sig, T, otype)
        dq = math.exp(-q * T)
        if otype == "call":
            # S - K - c - (1 - e^{-qT}N(d1)) S/q2
            return S - K - c - (1.0 - dq * _N(d1)) * S / qq
        # K - S - p + (1 - e^{-qT}N(-d1)) S/q1
        return K - S - c + (1.0 - dq * _N(-d1)) * S / qq

    def fp(S):
        h = S * 1e-7
        return (f(S + h) - f(S - h)) / (2.0 * h)

    # 种子：BAW 原文之 S_infinity 形态
    if otype == "call":
        Si = K * qq / (qq - 1.0) if qq > 1.0 else K * 2.0
        lo, hi = K * 1.0000001, max(Si * 10.0, K * 50.0)
    else:
        Si = K * qq / (qq - 1.0)
        Si = max(min(Si, K * 0.999999), 1e-8)
        lo, hi = 1e-8, K * 0.9999999

    S = Si
    conv = False
    it = 0
    for it in range(1, BAW_MAX_ITER + 1):
        val = f(S)
        if abs(val) < BAW_TOL * max(1.0, K):
            conv = True
            break
        dv = fp(S)
        if dv == 0.0 or not math.isfinite(dv):
            break
        Snew = S - val / dv
        if not math.isfinite(Snew) or Snew <= lo or Snew >= hi:
            break
        S = Snew
    if not conv:
        a, b = lo, hi
        fa = f(a)
        for it in range(1, BAW_MAX_ITER + 1):
            m = 0.5 * (a + b)
            fm = f(m)
            if abs(fm) < BAW_TOL * max(1.0, K) or (b - a) < 1e-12 * K:
                S = m
                conv = True
                break
            if (fa > 0) != (fm > 0):
                b = m
            else:
                a, fa = m, fm
        S = 0.5 * (a + b) if not conv else S
    _baw_iter_log.append((tag, otype, it, conv, f(S)))
    return S, it, conv, f(S)


def _baw_value(S, K, r, q, sig, T, otype, tag=""):
    intrinsic = (S - K) if otype == "call" else (K - S)
    if otype == "call" and q <= 0.0:
        # q=0 之美式call：早行权恒不优（已知恒等），近似式亦不适用（S*→∞）
        return _bs(S, K, r, q, sig, T, otype)[0]
    if r <= 0.0 and otype == "put" and q <= 0.0:
        # r=0,q=0 之美式put：早行权恒不优（已知恒等）；BAW之K因子退化
        return _bs(S, K, r, q, sig, T, otype)[0]
    Sc, _, conv, _ = _baw_critical(K, r, q, sig, T, otype, tag)
    if Sc is None:
        return _bs(S, K, r, q, sig, T, otype)[0]
    v2 = sig * sig
    M = 2.0 * r / v2
    Nn = 2.0 * (r - q) / v2
    Kk = 1.0 - math.exp(-r * T)
    dq = math.exp(-q * T)
    if otype == "call":
        if S >= Sc:
            return intrinsic
        q2 = (-(Nn - 1.0) + math.sqrt((Nn - 1.0) ** 2 + 4.0 * M / Kk)) / 2.0
        c, d1c = _bs(Sc, K, r, q, sig, T, "call")
        A2 = (Sc / q2) * (1.0 - dq * _N(d1c))
        return _bs(S, K, r, q, sig, T, "call")[0] + A2 * (S / Sc) ** q2
    if S <= Sc:
        return intrinsic
    q1 = (-(Nn - 1.0) - math.sqrt((Nn - 1.0) ** 2 + 4.0 * M / Kk)) / 2.0
    p, d1c = _bs(Sc, K, r, q, sig, T, "put")
    A1 = -(Sc / q1) * (1.0 - dq * _N(-d1c))
    return _bs(S, K, r, q, sig, T, "put")[0] + A1 * (S / Sc) ** q1


# =========================================================================
# 4. 候选 C-CRR：Cox-Ross-Rubinstein 二叉树（含 q，逐节点提前行权判定）
# =========================================================================

def _crr(S, K, r, q, sig, T, otype, american, N):
    """返回 dict：value ＋ 格点原生 delta/gamma/theta（不另 bump）。"""
    dt = T / N
    sd = sig * math.sqrt(dt)
    u = math.exp(sd)
    a = math.exp((r - q) * dt)
    d = 1.0 / u
    p = (a - d) / (u - d)
    disc = math.exp(-r * dt)
    if not (0.0 < p < 1.0):
        raise ValueError("CRR 风险中性概率越界 p=%r（N过小或参数极端）" % (p,))

    ef = [math.exp(sd * k) for k in range(-N, N + 1)]   # ef[k+N] = u^k

    def SS(i, j):                                       # i步、j次上行
        return S * ef[(2 * j - i) + N]

    if otype == "call":
        def intr(x):
            return x - K
    else:
        def intr(x):
            return K - x

    V = [max(intr(SS(N, j)), 0.0) for j in range(N + 1)]
    keep = {}
    n_ex = 0            # 提前行权绑定节点计数（离散不变量／事件类派生量）
    max_ex = 0.0        # 绑定处 intrinsic−continuation 之最大超出量（量级诊断）
    first_ex = None     # 最早绑定步
    for i in range(N - 1, -1, -1):
        V = [disc * (p * V[j + 1] + (1.0 - p) * V[j]) for j in range(i + 1)]
        if american:
            newV = []
            for j in range(i + 1):
                iv = intr(SS(i, j))
                if iv > V[j]:
                    n_ex += 1
                    if iv - V[j] > max_ex:
                        max_ex = iv - V[j]
                    first_ex = i
                    newV.append(iv)
                else:
                    newV.append(V[j])
            V = newV
        if i <= 2:
            keep[i] = (list(V), [SS(i, j) for j in range(i + 1)])

    v0 = V[0]
    (V1, S1) = keep[1]
    (V2, S2) = keep[2]
    delta = (V1[1] - V1[0]) / (S1[1] - S1[0])
    du = (V2[2] - V2[1]) / (S2[2] - S2[1])
    dd = (V2[1] - V2[0]) / (S2[1] - S2[0])
    gamma = (du - dd) / (0.5 * (S2[2] - S2[0]))
    theta = (V2[1] - v0) / (2.0 * dt)
    return {"value": v0, "delta_lat": delta, "gamma_lat": gamma,
            "theta_lat": theta, "p": p, "dt": dt,
            "n_exercise_nodes": n_ex, "max_exercise_excess": max_ex,
            "earliest_exercise_step": first_ex, "n_total_nodes": (N + 1) * N // 2}


# =========================================================================
# 5. 差分希腊（声明步长；F-11 射程）
# =========================================================================

def bumped_greeks(valfn, c, params, dte):
    """valfn(spot, vol, rate, dte) -> value。中心差分五希腊。
    theta 之时间步长＝1 日历日（与引擎整数天 dte 口径一致），按年计。"""
    hS = c["spot"] * params["bump_spot_rel"]
    hv = params["bump_vol_abs"]
    hr = params["bump_rate_abs"]
    hd = params["bump_time_days"]
    S, v, r = c["spot"], c["implied_vol"], c["risk_free_rate"]
    den = float(engine.DAY_COUNT_DENOMINATOR)

    v0 = valfn(S, v, r, dte)
    vp, vm = valfn(S + hS, v, r, dte), valfn(S - hS, v, r, dte)
    delta = (vp - vm) / (2.0 * hS)
    gamma = (vp - 2.0 * v0 + vm) / (hS * hS)
    vega = (valfn(S, v + hv, r, dte) - valfn(S, v - hv, r, dte)) / (2.0 * hv)
    rho = (valfn(S, v, r + hr, dte) - valfn(S, v, r - hr, dte)) / (2.0 * hr)
    theta = (valfn(S, v, r, dte - hd) - valfn(S, v, r, dte + hd)) / (2.0 * hd / den)
    return {"value": v0, "delta": delta, "gamma": gamma,
            "vega": vega, "theta": theta, "rho": rho}


# =========================================================================
# 6. 主流程
# =========================================================================

def main():
    D = load_input()
    P = D["declared_probe_parameters"]
    Ngrid = P["crr_steps_grid"]
    den = float(engine.DAY_COUNT_DENOMINATOR)
    out = {
        "_data_source": "synthetic_hand_constructed",
        "_identity": "TPL1-T7601-03 美式求值选型实证探针输出（非选型裁定）",
        "_engine_baseline": "entity/engine.py v1.2（本轮零改动）",
        "_declared_parameters": P,
        "_tolerance_dispatch": {
            "C-BSM": "裁决13/19 子口径(b) 相对diff ≤ 1e-12（精确解析量）",
            "C-CRR_value": "F-11（声明离散近似量；步数N截断误差）",
            "C-BAW_value": "裁决13 迭代类（内层临界价Newton；开放项，本探针为首个实例）",
            "differenced_greeks": "F-11（声明步长下之差分导数）",
            "identity_zero_checks": "F-11 主判据形态＝离散不变量零容差（bit-exact）",
        },
        "cases": [],
        "identity_checks": [],
        "convergence_study": [],
        "cross_checks": [],
        "findings": [],
    }

    # --- X0 往返自检：expiry 构造与引擎 dte 口径往返一致 -------------------
    rt = []
    for c in D["cases"]:
        for dd in (c["dte"] - P["bump_time_days"], c["dte"],
                   c["dte"] + P["bump_time_days"]):
            lot = _lot_from_case(c, "european_option", "european", dte=dd)
            rt.append(engine._dte_days(lot["expiry"], lot["valuation_date"]) == dd)
    out["cross_checks"].append({
        "id": "X0", "desc": "探针 expiry 构造 ↔ engine._dte_days 往返一致",
        "n_checked": len(rt), "all_pass": all(rt),
        "dispatch": "离散不变量零容差（整数天）", "pass": all(rt)})

    # --- T1' 交叉核对：探针自备 _bs 与引擎欧式分支数值一致性 -----------------
    worst = 0.0
    for c in D["cases"]:
        T = c["dte"] / den
        mine = _bs(c["spot"], c["strike"], c["risk_free_rate"],
                   c["dividend_yield"], c["implied_vol"], T, c["option_type"])[0]
        eng = cand_bsm(c)["value"]
        rel = abs(mine - eng) / max(abs(eng), 1e-300)
        worst = max(worst, rel)
    out["cross_checks"].append({
        "id": "X1", "desc": "探针自备欧式闭式解 vs 引擎欧式分支（同族独立书写）",
        "worst_rel_diff": worst,
        "dispatch": "裁决13/19子口径(b) ≤1e-12",
        "pass": worst <= 1e-12})

    # --- 主网格 -------------------------------------------------------------
    for c in D["cases"]:
        cid = c["case_id"]
        T = c["dte"] / den
        K, r, q, sig, ot = (c["strike"], c["risk_free_rate"],
                            c["dividend_yield"], c["implied_vol"], c["option_type"])
        S = c["spot"]

        g_bsm = bumped_greeks(
            lambda s, v, rr, dd: cand_bsm(c, s, v, rr, dd)["value"], c, P, c["dte"])
        a_bsm = cand_bsm(c)                                    # 解析五希腊

        g_baw = bumped_greeks(
            lambda s, v, rr, dd: _baw_value(s, K, rr, q, v, dd / den, ot, cid),
            c, P, c["dte"])

        crr_a = _crr(S, K, r, q, sig, T, ot, True, Ngrid)
        crr_e = _crr(S, K, r, q, sig, T, ot, False, Ngrid)
        g_crr = bumped_greeks(
            lambda s, v, rr, dd: _crr(s, K, rr, q, v, dd / den, ot, True,
                                      Ngrid)["value"], c, P, c["dte"])

        eur = a_bsm["value"]
        intr = max((S - K) if ot == "call" else (K - S), 0.0)
        rec = {
            "case_id": cid, "note": c["note"], "option_type": ot,
            "spot": S, "strike": K, "r": r, "q": q, "sigma": sig, "dte": c["dte"],
            "intrinsic": intr,
            "european_closed_form": eur,
            "value": {"C-BSM": a_bsm["value"], "C-BAW": g_baw["value"],
                      "C-CRR": crr_a["value"]},
            "early_exercise_premium": {
                "_baseline_note": "同离散化基线(same_disc)消去截断误差；跨口径基线"
                                  "(vs_closed_form)将树截断误差混入 EEP 读数",
                "C-BSM_vs_closed_form": a_bsm["value"] - eur,
                "C-BAW_vs_closed_form": g_baw["value"] - eur,
                "C-CRR_vs_closed_form": crr_a["value"] - eur,
                "C-CRR_same_disc": crr_a["value"] - crr_e["value"],
                "C-CRR_truncation_contamination": (crr_a["value"] - eur)
                                                  - (crr_a["value"] - crr_e["value"]),
            },
            "crr_exercise_event": {
                "n_exercise_nodes": crr_a["n_exercise_nodes"],
                "n_total_nodes": crr_a["n_total_nodes"],
                "max_exercise_excess": crr_a["max_exercise_excess"],
                "earliest_exercise_step": crr_a["earliest_exercise_step"],
                "european_flag_control_n_exercise_nodes": crr_e["n_exercise_nodes"],
            },
            "eep_rel_to_european": {
                "C-BAW": (g_baw["value"] - eur) / eur if eur > 0 else None,
                "C-CRR_same_disc": (crr_a["value"] - crr_e["value"]) / eur if eur > 0 else None,
                "C-CRR_vs_closed_form": (crr_a["value"] - eur) / eur if eur > 0 else None,
            },
            "value_diff_BAW_minus_CRR": g_baw["value"] - crr_a["value"],
            "value_reldiff_BAW_vs_CRR": (g_baw["value"] - crr_a["value"]) /
                                        max(abs(crr_a["value"]), 1e-300),
            "greeks_analytic_C-BSM": {k: a_bsm[k] for k in
                                      ("delta", "gamma", "vega", "theta", "rho")},
            "greeks_bumped_C-BSM": {k: g_bsm[k] for k in
                                    ("delta", "gamma", "vega", "theta", "rho")},
            "greeks_bumped_C-BAW": {k: g_baw[k] for k in
                                    ("delta", "gamma", "vega", "theta", "rho")},
            "greeks_bumped_C-CRR": {k: g_crr[k] for k in
                                    ("delta", "gamma", "vega", "theta", "rho")},
            "greeks_lattice_C-CRR": {"delta": crr_a["delta_lat"],
                                     "gamma": crr_a["gamma_lat"],
                                     "theta": crr_a["theta_lat"]},
            "value_below_intrinsic": {
                "C-BSM": a_bsm["value"] < intr - 1e-12,
                "C-BAW": g_baw["value"] < intr - 1e-12,
                "C-CRR": crr_a["value"] < intr - 1e-12},
            "crr_european_vs_closed_form_absdiff": abs(crr_e["value"] - eur),
        }
        # 差分 vs 解析（C-BSM 内部：差分机构本身之量级诊断，F-11 辅助界）
        rec["bump_machinery_diag_C-BSM"] = {
            k: (abs(g_bsm[k] - a_bsm[k]) / max(abs(a_bsm[k]), 1e-300))
            for k in ("delta", "gamma", "vega", "theta", "rho")}
        # 格点希腊 vs 差分希腊（C-CRR 内部形态留痕）
        rec["lattice_vs_bump_diag_C-CRR"] = {
            k: (abs(crr_a[k + "_lat"] - g_crr[k]) / max(abs(g_crr[k]), 1e-300))
            for k in ("delta", "gamma", "theta")}
        out["cases"].append(rec)

    # --- 恒等零检（离散不变量，零容差） -------------------------------------
    for cid, why in (("A7", "r=0且q=0之美式put：早行权恒不优 → EEP≡0"),
                     ("B1", "q=0之美式call：早行权恒不优 → EEP≡0")):
        c = next(x for x in D["cases"] if x["case_id"] == cid)
        T = c["dte"] / den
        rA = _crr(c["spot"], c["strike"], c["risk_free_rate"], c["dividend_yield"],
                  c["implied_vol"], T, c["option_type"], True, Ngrid)
        rE = _crr(c["spot"], c["strike"], c["risk_free_rate"], c["dividend_yield"],
                  c["implied_vol"], T, c["option_type"], False, Ngrid)
        A, E = rA["value"], rE["value"]
        rec = next(x for x in out["cases"] if x["case_id"] == cid)
        out["identity_checks"].append({
            "case_id": cid, "rationale": why,
            "primary_discrete_invariant_n_exercise_nodes": rA["n_exercise_nodes"],
            "primary_pass_zero_exercise_nodes": rA["n_exercise_nodes"] == 0,
            "max_exercise_excess": rA["max_exercise_excess"],
            "aux_value_delta_american_minus_european": A - E,
            "aux_bitexact_zero": (A - E) == 0.0,
            "C-BAW_eep_vs_closed_form": rec["early_exercise_premium"]["C-BAW_vs_closed_form"],
            "C-BSM_eep_vs_closed_form": rec["early_exercise_premium"]["C-BSM_vs_closed_form"],
            "dispatch": "F-11：主判据＝离散不变量（提前行权绑定节点数）零容差；"
                        "值差为量级诊断辅助，不作主判据"})

    # --- 收敛研究 -----------------------------------------------------------
    for cid in D["convergence_study_cases"]:
        c = next(x for x in D["cases"] if x["case_id"] == cid)
        T = c["dte"] / den
        eur = cand_bsm(c)["value"]
        row = {"case_id": cid, "european_closed_form": eur, "by_steps": []}
        for N in D["convergence_study_steps"]:
            A = _crr(c["spot"], c["strike"], c["risk_free_rate"],
                     c["dividend_yield"], c["implied_vol"], T,
                     c["option_type"], True, N)["value"]
            E = _crr(c["spot"], c["strike"], c["risk_free_rate"],
                     c["dividend_yield"], c["implied_vol"], T,
                     c["option_type"], False, N)["value"]
            row["by_steps"].append({
                "N": N, "american": A, "european_tree": E,
                "eep": A - E,
                "european_tree_minus_closed_form": E - eur})
        out["convergence_study"].append(row)

    out["baw_iteration_log"] = [
        {"tag": t, "option_type": o, "iters": i, "converged": cv, "residual": rs}
        for (t, o, i, cv, rs) in _baw_iter_log]

    with open(os.path.join(_HERE, "probe_output.json"), "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)
    print("探针跑完：cases=%d，identity=%d，convergence=%d，baw_iter_records=%d"
          % (len(out["cases"]), len(out["identity_checks"]),
             len(out["convergence_study"]), len(out["baw_iteration_log"])))
    return out


if __name__ == "__main__":
    main()

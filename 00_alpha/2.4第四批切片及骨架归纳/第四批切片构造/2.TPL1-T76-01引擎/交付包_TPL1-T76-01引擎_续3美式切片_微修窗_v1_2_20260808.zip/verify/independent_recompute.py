"""
TPL1-T76-01 引擎 · 独立复算路径

独立性声明（任务6产出 v1.7 D段② 口径：判据为"实现路径独立"）：
  1. 数据源独立——本脚本只读 entity/input_data.json（人造 input），
     不 import entity 侧任何模块，不读取 entity/harness_output.json。
  2. 计算核心分叉——
     · 欧式期权分支：估值以 mpmath（60位十进制精度）之 ncdf 独立实现；五希腊
       一律由估值函数之高精度数值微分求得（delta=∂V/∂S、gamma=∂²V/∂S²、
       vega=∂V/∂σ、theta=−∂V/∂T、rho=∂V/∂r），**不使用任何解析希腊公式**。
       与被测侧"闭式解析希腊公式 ＋ math.erf"构成两条结构不同的推导路径。
     · **美式期权分支（续3新增）**：对数空间 **Crank-Nicolson 有限差分 ＋ PSOR
       投影**求解 Black-Scholes-Merton PDE 之线性互补问题。与被测侧 CRR 二叉树
       之失效模式分叉（F-2 判别据＝改写后是否仍共享同一失效模式）：
         被测侧＝风险中性概率测度 ＋ 格点倒推 ＋ 逐节点 max(继续持有, 内在价值)；
         本侧  ＝无概率测度 ＋ 空间/时间网格离散 ＋ 每层三对角系统求解 ＋
                 PSOR 逐次超松弛投影承接自由边界。
       另一种二叉/三叉格点（含 Leisen-Reimer、Boyle 三叉）**不采用**——仍属格点
       倒推族，与被测侧共享"提前行权判定离散到格点时刻"与"倒推逻辑"两类失效模式，
       依 F-2 不计入独立分叉。
       delta/gamma 自空间网格中心差分读取、theta 自相邻时间层读取（与被测侧之
       格点原生希腊分叉：网格 vs 格点，坐标系亦不同——本侧在 x=ln(S) 上离散）；
       vega/rho 以**同一声明步长**之中心差分求得——被测量本身即"声明步长下之差分
       导数"（F-11），故步长须同；独立性落在估值引擎（FD vs CRR）而非步长选择。
     · 线性分支：以 fractions.Fraction 精确有理数实现，零浮点。
     · 日期差：使用 datetime.date 序日，与被测侧手写 Rata Die 整数式分叉。
  3. 期望值自 clean 人造 input 独立推导，不取被测侧任何中间量。

数据源纪律：零网络、零行情接口。
"""

import datetime
import json
import math
import os
from fractions import Fraction

from mpmath import mp, mpf, ncdf, exp, log, sqrt, diff

mp.dps = 60

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(HERE)
IN_PATH = os.path.join(PKG, "entity", "input_data.json")
OUT_PATH = os.path.join(HERE, "independent_expected.json")

DIGITS = 40
GREEKS = ("delta", "gamma", "vega", "theta", "rho")
COMPONENTS = ("value",) + GREEKS

LINEAR = {"spot", "spot_etf", "index", "futures"}
OPTION = {"european_option"}
AMERICAN = {"american_option"}

# ── 美式独立路径之网格声明面（本侧自有，与被测侧 CRR_STEPS 无关）──
FD_N_X = 801          # 空间网格节点数（x=ln(S) 均匀）
FD_N_T = 800          # 时间层数（Crank-Nicolson）
FD_SPAN_SIGMAS = 6.0  # 空间半幅＝max(6σ√T, 1.5)
FD_PSOR_OMEGA = 1.2
FD_PSOR_TOL = 1e-12
FD_PSOR_MAX_ITER = 2000


def _dte(expiry, valuation_date):
    a = datetime.date(*[int(x) for x in expiry.split("-")])
    b = datetime.date(*[int(x) for x in valuation_date.split("-")])
    return (a - b).days


def _bs_value(S, K, r, sig, T, cp, q):
    """含连续股息收益率q之欧式估值；mpmath 独立实现（续2）。
    q=0 时代数化简至增强前（无股息）形态——本函数结构与 entity/engine.py 之
    _eval_bs_dividend_yield 分叉：闭式解析五希腊公式 vs 本侧五希腊全部由估值函数
    高精度数值微分求得，零解析希腊公式（独立性声明同模块docstring）。
    q 为冻结参数，不参与微分——契约①5希腊全集不含∂V/∂q（无第六希腊）。"""
    S, K, r, sig, T, q = (mpf(str(x)) for x in (S, K, r, sig, T, q))
    d1 = (log(S / K) + (r - q + sig * sig / 2) * T) / (sig * sqrt(T))
    d2 = d1 - sig * sqrt(T)
    if cp == "call":
        return S * exp(-q * T) * ncdf(d1) - K * exp(-r * T) * ncdf(d2)
    return K * exp(-r * T) * ncdf(-d2) - S * exp(-q * T) * ncdf(-d1)


def _fd_solve(S0, K, r, q, sig, T, otype, american):
    """对数空间 Crank-Nicolson ＋ PSOR。返回 dict。
    S0 经网格对齐使其精确落于节点，避免插值引入第二误差源。"""
    x0 = math.log(S0)
    span = max(FD_SPAN_SIGMAS * sig * math.sqrt(T), 1.5)
    dx = (2.0 * span) / (FD_N_X - 1)
    i0 = int(round(span / dx))
    xl = x0 - i0 * dx
    xs = [xl + i * dx for i in range(FD_N_X)]
    Ss = [math.exp(x) for x in xs]

    if otype == "call":
        g = [max(s - K, 0.0) for s in Ss]
    elif otype == "put":
        g = [max(K - s, 0.0) for s in Ss]
    else:
        raise ValueError("option_type 越出值域: %r" % (otype,))

    V = list(g)
    dt = T / FD_N_T
    a_ = 0.5 * sig * sig
    b_ = r - q - 0.5 * sig * sig
    A = a_ / (dx * dx) - b_ / (2.0 * dx)
    B = -2.0 * a_ / (dx * dx) - r
    C = a_ / (dx * dx) + b_ / (2.0 * dx)
    th = 0.5
    lA, lB, lC = -th * dt * A, 1.0 - th * dt * B, -th * dt * C
    rA, rB, rC = (1 - th) * dt * A, 1.0 + (1 - th) * dt * B, (1 - th) * dt * C

    n_proj, max_exc, prev = 0, 0.0, None
    for k in range(FD_N_T):
        tau = (k + 1) * dt
        rhs = [0.0] * FD_N_X
        for i in range(1, FD_N_X - 1):
            rhs[i] = rA * V[i - 1] + rB * V[i] + rC * V[i + 1]
        if otype == "put":
            bl = (K - Ss[0]) if american else (K * math.exp(-r * tau)
                                               - Ss[0] * math.exp(-q * tau))
            bu = 0.0
        else:
            bl = 0.0
            bu = (Ss[-1] - K) if american else (Ss[-1] * math.exp(-q * tau)
                                                - K * math.exp(-r * tau))
        Vn = list(V)
        Vn[0], Vn[-1] = bl, bu
        rhs[1] -= lA * bl
        rhs[FD_N_X - 2] -= lC * bu
        for _ in range(FD_PSOR_MAX_ITER):
            err = 0.0
            for i in range(1, FD_N_X - 1):
                res = (rhs[i] - lA * Vn[i - 1] - lC * Vn[i + 1]) / lB
                cand = Vn[i] + FD_PSOR_OMEGA * (res - Vn[i])
                if american and cand < g[i]:
                    cand = g[i]
                d = cand - Vn[i]
                if d < 0.0:
                    d = -d
                if d > err:
                    err = d
                Vn[i] = cand
            if err < FD_PSOR_TOL:
                break
        if american:
            for i in range(1, FD_N_X - 1):
                if Vn[i] <= g[i] + 1e-14:
                    lin = (lA * Vn[i - 1] + lB * Vn[i] + lC * Vn[i + 1]) - rhs[i]
                    if lin > 1e-12:
                        n_proj += 1
                        if lin > max_exc:
                            max_exc = lin
        prev, V = V, Vn

    Vx = (V[i0 + 1] - V[i0 - 1]) / (2.0 * dx)
    Vxx = (V[i0 + 1] - 2.0 * V[i0] + V[i0 - 1]) / (dx * dx)
    return {"value": V[i0],
            "delta": Vx / S0,
            "gamma": (Vxx - Vx) / (S0 * S0),
            "theta": -(V[i0] - prev[i0]) / dt,
            "n_projected_nodes": n_proj,
            "max_projection_excess": max_exc}


def _american_components(lot, valuation_date, bump_vol, bump_rate):
    """美式独立复算：FD 主解 ＋ 同声明步长之 vega/rho 差分 ＋ 同离散基线溢价。"""
    S = float(lot["spot"]); K = float(lot["strike"])
    r = float(lot["risk_free_rate"]); q = float(lot["dividend_yield"])
    sig = float(lot["implied_vol"]); cp = lot["option_type"]
    T = _dte(lot["expiry"], valuation_date) / 365.0

    am = _fd_solve(S, K, r, q, sig, T, cp, True)
    eu = _fd_solve(S, K, r, q, sig, T, cp, False)

    def v(vol=sig, rate=r):
        return _fd_solve(S, K, rate, q, vol, T, cp, True)["value"]

    vega = (v(vol=sig + bump_vol) - v(vol=sig - bump_vol)) / (2.0 * bump_vol)
    rho = (v(rate=r + bump_rate) - v(rate=r - bump_rate)) / (2.0 * bump_rate)
    comps = {"value": mpf(repr(am["value"])), "delta": mpf(repr(am["delta"])),
             "gamma": mpf(repr(am["gamma"])), "vega": mpf(repr(vega)),
             "theta": mpf(repr(am["theta"])), "rho": mpf(repr(rho))}
    diag = {"early_exercise_premium_same_disc": am["value"] - eu["value"],
            "european_mode_value": eu["value"],
            "n_projected_nodes": am["n_projected_nodes"],
            "max_projection_excess": am["max_projection_excess"],
            "european_mode_n_projected_nodes": eu["n_projected_nodes"],
            "grid": {"n_x": FD_N_X, "n_t": FD_N_T}}
    return comps, "fd_cn_psor", diag


def _option_components(lot, valuation_date):
    S = lot["spot"]
    K = lot["strike"]
    r = lot["risk_free_rate"]
    sig = lot["implied_vol"]
    cp = lot["option_type"]
    q = lot["dividend_yield"]
    T = mpf(_dte(lot["expiry"], valuation_date)) / 365

    val = _bs_value(S, K, r, sig, T, cp, q)
    delta = diff(lambda x: _bs_value(x, K, r, sig, T, cp, q), mpf(str(S)))
    gamma = diff(lambda x: _bs_value(x, K, r, sig, T, cp, q), mpf(str(S)), 2)
    vega = diff(lambda x: _bs_value(S, K, r, x, T, cp, q), mpf(str(sig)))
    theta = -diff(lambda x: _bs_value(S, K, r, sig, x, cp, q), T)
    rho = diff(lambda x: _bs_value(S, K, x, sig, T, cp, q), mpf(str(r)))
    return {"value": val, "delta": delta, "gamma": gamma,
            "vega": vega, "theta": theta, "rho": rho}, "transcendental"


def _linear_components(lot):
    """线性标的与期货占位桩：恒等承接，精确有理。"""
    S = Fraction(str(lot["spot"]))
    return ({"value": S, "delta": Fraction(1), "gamma": Fraction(0),
             "vega": Fraction(0), "theta": Fraction(0), "rho": Fraction(0)},
            "exact_rational")


def _fmt(x):
    if isinstance(x, Fraction):
        return "%.*e" % (DIGITS - 1, float(x)) if x.denominator != 1 else str(x)
    return mp.nstr(x, DIGITS, strip_zeros=False)


def _evaluate(lot, valuation_date, bumps):
    ic = lot["instrument_class"]
    diag = None
    if ic in LINEAR:
        comps, kind = _linear_components(lot)
    elif ic in OPTION:
        comps, kind = _option_components(lot, valuation_date)
    elif ic in AMERICAN:
        comps, kind, diag = _american_components(
            lot, valuation_date, bumps["vol"], bumps["rate"])
    else:
        raise ValueError("品种值域外: %r" % (ic,))

    sign = 1 if lot["side"] == "long" else -1
    scale = int(lot["multiplier"]) * int(lot["quantity"]) * sign

    per_unit = {k: _fmt(comps[k]) for k in COMPONENTS}
    per_lot = {k: _fmt(comps[k] * (Fraction(scale) if kind == "exact_rational"
                                   else mpf(scale)))
               for k in COMPONENTS}
    rec = {"lot_id": lot["lot_id"], "numeric_kind": kind,
           "per_unit": per_unit, "per_lot": per_lot}
    if diag is not None:
        eep = diag["early_exercise_premium_same_disc"]
        rec["early_exercise_premium"] = {"per_unit": _fmt(mpf(repr(eep))),
                                         "per_lot": _fmt(mpf(repr(eep * scale)))}
        rec["fd_diagnostics"] = {
            "european_mode_value": _fmt(mpf(repr(diag["european_mode_value"]))),
            "n_projected_nodes": diag["n_projected_nodes"],
            "max_projection_excess": _fmt(mpf(repr(diag["max_projection_excess"]))),
            "european_mode_n_projected_nodes":
                diag["european_mode_n_projected_nodes"],
            "grid": diag["grid"]}
    return rec


def _declared_bumps():
    """自 entity/input_schema.md 之 CONVENTION_DECLARATION 块独立解析声明步长。
    **不 import engine**（独立性封闭规则）；亦不写死常量（判据基线一律程序化解析
    自本包内源文件之既有形态）。"""
    path = os.path.join(PKG, "entity", "input_schema.md")
    with open(path, "r", encoding="utf-8") as fh:
        txt = fh.read()
    blk = txt.split("CONVENTION_DECLARATION")[1].split("```")[0]
    got = {}
    for line in blk.splitlines():
        if "|" not in line:
            continue
        k, _, v = line.partition("|")
        got[k.strip()] = v.strip()
    return {"vol": float(got["american_bump_vol"]),
            "rate": float(got["american_bump_rate"])}


def main():
    with open(IN_PATH, "r", encoding="utf-8") as fh:
        data = json.load(fh)

    bumps = _declared_bumps()
    v0 = data["valuation_date"]
    shock = data["scenario_shock"]
    tshift = data["time_shift"]

    base, scen, tsh = [], [], []
    for lot in data["lots"]:
        base.append(_evaluate(lot, v0, bumps))

        s_lot = dict(lot)
        s_lot["spot"] = lot["spot"] * (1.0 + shock["spot_shock_pct"])
        if lot["implied_vol"] is not None:
            s_lot["implied_vol"] = lot["implied_vol"] + shock["vol_shock_points"]
        scen.append(_evaluate(s_lot, v0, bumps))

        tsh.append(_evaluate(lot, tshift["valuation_date_t1"], bumps))

    out = {"_source": "independent_recompute (mpmath dps=60 数值微分 ／ Fraction 精确有理"
                      " ／ 美式＝对数空间 Crank-Nicolson FD ＋ PSOR)",
           "_reads": "entity/input_data.json ＋ entity/input_schema.md"
                     "（仅解析声明步长；被测侧产物与被测模块均不触碰——独立性"
                     "自述见模块 docstring，此处不复写受检字面以免自命中）",
           "_declared_bumps": bumps,
           "base_valuation": base,
           "scenario_revaluation": scen,
           "time_shift_revaluation": tsh}
    with open(OUT_PATH, "w", encoding="utf-8") as fh:
        json.dump(out, fh, ensure_ascii=False, indent=2)
        fh.write("\n")
    print("独立复算完成：%d lots × 3 情形 × 12 分量" % len(base))


if __name__ == "__main__":
    main()

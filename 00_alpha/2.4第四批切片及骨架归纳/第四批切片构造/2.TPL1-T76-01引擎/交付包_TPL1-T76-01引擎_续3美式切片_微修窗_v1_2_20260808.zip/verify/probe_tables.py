"""探针输出表生成（自 probe_output.json 派生，零再计算）。
产出：probe_table_values.tsv ／ probe_table_greeks.tsv ／ probe_table_convergence.tsv
本脚本不作任何求值，只作读取-排版，避免与探针主体形成第二计算源。"""
import json
import os

H = os.path.dirname(os.path.abspath(__file__))
D = json.load(open(os.path.join(H, "probe_output.json"), encoding="utf-8"))


def w(name, rows):
    with open(os.path.join(H, name), "w", encoding="utf-8") as f:
        for r in rows:
            f.write("\t".join(str(x) for x in r) + "\n")
    print("written:", name, len(rows) - 1, "rows")


rows = [["case_id", "type", "S", "K", "r", "q", "sigma", "dte", "intrinsic",
         "european_closed_form", "V_C-BSM", "V_C-BAW", "V_C-CRR",
         "EEP_BAW_vs_cf", "EEP_CRR_same_disc", "EEP_CRR_vs_cf",
         "trunc_contamination", "EEP_rel_to_european_CRR",
         "BAW_minus_CRR", "BAW_vs_CRR_reldiff",
         "EEP_BAW_minus_EEP_CRR_rel", "V_below_intrinsic_BSM",
         "V_below_intrinsic_BAW", "V_below_intrinsic_CRR",
         "crr_n_exercise_nodes", "crr_max_exercise_excess",
         "crr_earliest_exercise_step"]]
for c in D["cases"]:
    e = c["early_exercise_premium"]
    ev = c["crr_exercise_event"]
    sd = e["C-CRR_same_disc"]
    rows.append([
        c["case_id"], c["option_type"], c["spot"], c["strike"], c["r"], c["q"],
        c["sigma"], c["dte"], "%.10g" % c["intrinsic"],
        "%.10g" % c["european_closed_form"],
        "%.10g" % c["value"]["C-BSM"], "%.10g" % c["value"]["C-BAW"],
        "%.10g" % c["value"]["C-CRR"],
        "%.6g" % e["C-BAW_vs_closed_form"], "%.6g" % sd,
        "%.6g" % e["C-CRR_vs_closed_form"],
        "%.4g" % e["C-CRR_truncation_contamination"],
        ("%.4g" % c["eep_rel_to_european"]["C-CRR_same_disc"]
         if c["eep_rel_to_european"]["C-CRR_same_disc"] is not None else "NA"),
        "%.4g" % c["value_diff_BAW_minus_CRR"],
        "%.4g" % c["value_reldiff_BAW_vs_CRR"],
        ("%.4g" % ((e["C-BAW_vs_closed_form"] - sd) / sd) if abs(sd) > 1e-12 else "NA"),
        c["value_below_intrinsic"]["C-BSM"], c["value_below_intrinsic"]["C-BAW"],
        c["value_below_intrinsic"]["C-CRR"],
        ev["n_exercise_nodes"], "%.4g" % ev["max_exercise_excess"],
        ev["earliest_exercise_step"]])
w("probe_table_values.tsv", rows)

rows = [["case_id", "greek", "C-BSM_analytic", "C-BSM_bumped", "C-BAW_bumped",
         "C-CRR_bumped", "C-CRR_lattice", "bump_machinery_reldiff_BSM",
         "lattice_vs_bump_reldiff_CRR", "BAW_vs_CRR_bumped_reldiff"]]
for c in D["cases"]:
    for k in ("delta", "gamma", "vega", "theta", "rho"):
        lat = c["greeks_lattice_C-CRR"].get(k)
        bw = c["greeks_bumped_C-BAW"][k]
        cr = c["greeks_bumped_C-CRR"][k]
        rows.append([
            c["case_id"], k,
            "%.10g" % c["greeks_analytic_C-BSM"][k],
            "%.10g" % c["greeks_bumped_C-BSM"][k],
            "%.10g" % bw, "%.10g" % cr,
            ("%.10g" % lat) if lat is not None else "NA",
            "%.4g" % c["bump_machinery_diag_C-BSM"][k],
            ("%.4g" % c["lattice_vs_bump_diag_C-CRR"][k])
            if k in c["lattice_vs_bump_diag_C-CRR"] else "NA",
            "%.4g" % (abs(bw - cr) / max(abs(cr), 1e-12))])
w("probe_table_greeks.tsv", rows)

rows = [["case_id", "N", "american", "european_tree", "EEP_same_disc",
         "european_tree_minus_closed_form"]]
for r in D["convergence_study"]:
    for s in r["by_steps"]:
        rows.append([r["case_id"], s["N"], "%.10g" % s["american"],
                     "%.10g" % s["european_tree"], "%.10g" % s["eep"],
                     "%.4g" % s["european_tree_minus_closed_form"]])
w("probe_table_convergence.tsv", rows)

"""TPL1-T76-01 引擎 · 美式路由容差界值标定（F-11 逐对象独立标定之留痕件）

判据框架＝F-11（任务6产出 v1.11）：被测量本身为**声明离散近似**（声明步长下之差分
导数、声明步数下之格点值）而非精确数学量时，裁决13/19 两子口径 (a)/(b) 不强套；
容差框架改为「离散不变量零容差主判据 ＋ 量级诊断辅助（相对误差界）」，量级界
**逐对象独立标定**（按该对象之截断误差量级实测加安全边际，禁跨阶数/跨对象沿用）。

本件职责＝在**宽于实跑用例集**的人造坐标网格上，实测被测侧（CRR 二叉树）与独立
分叉侧（Crank-Nicolson FD ＋ PSOR）之逐分量相对差，据此标定界值并留痕标定依据。
标定网格宽于 entity/input_data.json 之单一美式 lot，用意为使界值不因单点标定而
在外审面失去说服力。

数据源纪律：零网络、零行情接口。全部坐标为人造声明值。
本件不参与合格判定，只产出界值与其标定依据；界值之消费方＝input_schema.md §7
之 F-11 分派声明块与 verify/assert_check.py 之量级诊断断言。
"""

import json
import math
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(PKG, "entity"))
sys.path.insert(0, HERE)

import engine                      # noqa: E402  被测侧
import independent_recompute as ir  # noqa: E402  独立分叉侧（FD＋PSOR）

OUT = os.path.join(HERE, "tolerance_calibration.json")

# 标定网格（人造声明坐标；覆盖实值/平值/虚值、短期/长期、低波/高波、q=0/q>0）
GRID = [
    ("G01", "put",  100.0, 110.0, 0.03, 0.015, 0.30, 181),
    ("G02", "put",   80.0, 110.0, 0.03, 0.015, 0.30, 181),
    ("G03", "put",  130.0, 110.0, 0.03, 0.015, 0.30, 181),
    ("G04", "put",  100.0, 100.0, 0.03, 0.015, 0.20, 30),
    ("G05", "put",  100.0, 100.0, 0.03, 0.015, 0.20, 730),
    ("G06", "put",   90.0, 100.0, 0.05, 0.0,   0.25, 365),
    ("G07", "call", 110.0, 100.0, 0.03, 0.05,  0.25, 365),
    ("G08", "call", 100.0,  90.0, 0.02, 0.08,  0.20, 365),
    ("G09", "call", 100.0, 100.0, 0.03, 0.03,  0.30, 180),
    ("G10", "put",  100.0, 110.0, 0.03, 0.015, 0.60, 181),
]

GREEKS = ("delta", "gamma", "vega", "theta", "rho")
SAFETY = 3.0          # 安全边际倍数（形态先例＝裁决13 之 "×~3倍裕度" 测量派生口径）


def _round_up_1sig(x):
    """向上取整至 1 位有效数字，避免界值携带虚假精度。"""
    if x <= 0:
        return 0.0
    e = math.floor(math.log10(x))
    return math.ceil(x / (10.0 ** e)) * (10.0 ** e)


def _crr_side(S, K, r, q, sig, T, cp, bump_vol, bump_rate):
    am = engine._crr_lattice(S, K, r, q, sig, T, cp, True, engine.CRR_STEPS)
    eu = engine._crr_lattice(S, K, r, q, sig, T, cp, False, engine.CRR_STEPS)

    def v(vol=sig, rate=r):
        return engine._crr_lattice(S, K, rate, q, vol, T, cp, True,
                                   engine.CRR_STEPS)["value"]
    return {"value": am["value"], "delta": am["delta_lat"],
            "gamma": am["gamma_lat"], "theta": am["theta_lat"],
            "vega": (v(vol=sig + bump_vol) - v(vol=sig - bump_vol)) / (2 * bump_vol),
            "rho": (v(rate=r + bump_rate) - v(rate=r - bump_rate)) / (2 * bump_rate),
            "eep": am["value"] - eu["value"],
            "european_mode_value": eu["value"],
            "n_exercise_nodes": am["n_exercise_nodes"],
            "max_exercise_excess": am["max_exercise_excess"],
            "european_mode_n_exercise_nodes": eu["n_exercise_nodes"]}


def _fd_side(S, K, r, q, sig, T, cp, bump_vol, bump_rate):
    am = ir._fd_solve(S, K, r, q, sig, T, cp, True)
    eu = ir._fd_solve(S, K, r, q, sig, T, cp, False)

    def v(vol=sig, rate=r):
        return ir._fd_solve(S, K, rate, q, vol, T, cp, True)["value"]
    return {"value": am["value"], "delta": am["delta"], "gamma": am["gamma"],
            "theta": am["theta"],
            "vega": (v(vol=sig + bump_vol) - v(vol=sig - bump_vol)) / (2 * bump_vol),
            "rho": (v(rate=r + bump_rate) - v(rate=r - bump_rate)) / (2 * bump_rate),
            "eep": am["value"] - eu["value"],
            "european_mode_value": eu["value"],
            "n_projected_nodes": am["n_projected_nodes"],
            "max_projection_excess": am["max_projection_excess"],
            "european_mode_n_projected_nodes": eu["n_projected_nodes"]}


def main():
    bumps = ir._declared_bumps()
    bv, br = bumps["vol"], bumps["rate"]
    # 丙类修复（D-1采γ案之β半／D-2，裁决76-1(c)）：`european_mode_value` 新增为
    # 跨路径比对分量，其量级界同受 F-11「逐对象独立标定」约束，随本网格一并实测。
    rows, worst = [], {k: 0.0 for k in ("value", "eep", "european_mode_value") + GREEKS}
    inv_fail = []
    for cid, cp, S, K, r, q, sig, dte in GRID:
        T = dte / float(engine.DAY_COUNT_DENOMINATOR)
        a = _crr_side(S, K, r, q, sig, T, cp, bv, br)
        b = _fd_side(S, K, r, q, sig, T, cp, bv, br)
        rel = {}
        for k in ("value",) + GREEKS:
            rel[k] = abs(a[k] - b[k]) / max(abs(b[k]), 1e-300)
            if rel[k] > worst[k]:
                worst[k] = rel[k]
        # EEP＝**差值型输出**，以自身为分母时 cancellation 放大相对误差
        # （形态先例＝T-24 之 bleed=V(t0)−V(t1)，REG-T24-01 回传→裁决19）。
        # 本根实测：以 EEP 自身为分母之上界 3.77e-2（由小溢价坐标主导，G04 溢价
        # 0.0075），以同坐标欧式模式值为分母之上界 2.70e-4——后者区分力**更强**：
        # 两路径之绝对偏差量级随期权价值而非随溢价大小变化（CRR 截断误差之自然
        # 标度），故以欧式模式值为分母之界不会在大溢价坐标上失去检出能力
        # （反例：以自身为分母之界 2e-1 允许 G06 溢价 1.05 偏差达 0.21 而放行）。
        # 主判据取后者，前者留作辅助记录。
        eu_ref = b["value"] - b["eep"]
        rel["eep"] = abs(a["eep"] - b["eep"]) / max(abs(eu_ref), 1e-300)
        # `european_mode_value`＝同离散基线之减数本体（KD裁定 B-1）。以自身为分母
        # （非差值型量，无 cancellation 放大问题），量级同 value 分量。
        rel["european_mode_value"] = (abs(a["european_mode_value"] - b["european_mode_value"])
                                      / max(abs(b["european_mode_value"]), 1e-300))
        if rel["european_mode_value"] > worst["european_mode_value"]:
            worst["european_mode_value"] = rel["european_mode_value"]
        rel["_eep_rel_to_self"] = abs(a["eep"] - b["eep"]) / max(abs(b["eep"]), 1e-300)
        rel["_vega_rel_to_scale"] = (abs(a["vega"] - b["vega"])
                                     / (S * math.sqrt(T)))
        if rel["eep"] > worst["eep"]:
            worst["eep"] = rel["eep"]
        # 离散不变量（零容差主判据面）
        inv = {"eep_nonneg_crr": a["eep"] >= -1e-15,
               "eep_nonneg_fd": b["eep"] >= -1e-12,
               "value_ge_intrinsic_crr":
                   a["value"] >= (max(S - K, 0.0) if cp == "call"
                                  else max(K - S, 0.0)) - 1e-12,
               "european_mode_zero_binding_crr":
                   a["european_mode_n_exercise_nodes"] == 0,
               "european_mode_zero_binding_fd":
                   b["european_mode_n_projected_nodes"] == 0}
        if not all(inv.values()):
            inv_fail.append((cid, {k: v for k, v in inv.items() if not v}))
        rows.append({"case_id": cid, "option_type": cp, "spot": S, "strike": K,
                     "r": r, "q": q, "sigma": sig, "dte": dte,
                     "crr": {k: a[k] for k in ("value", "eep", "european_mode_value") + GREEKS},
                     "fd": {k: b[k] for k in ("value", "eep", "european_mode_value") + GREEKS},
                     "rel_diff": rel,
                     "crr_max_exercise_excess": a["max_exercise_excess"],
                     "fd_max_projection_excess": b["max_projection_excess"],
                     "invariants": inv})
        print("  %s 完成：value %.2e / eep %.2e / vega %.2e"
              % (cid, rel["value"], rel["eep"], rel["vega"]))

    bounds = {k: _round_up_1sig(worst[k] * SAFETY) for k in worst}
    out = {
        "_data_source": "synthetic_hand_constructed",
        "_framework": "F-11（任务6产出 v1.11）：离散不变量零容差主判据 ＋ 量级诊断"
                      "辅助界；界值逐对象独立标定，禁跨阶数/跨对象沿用",
        "_paths": {"under_test": "CRR 二叉树（entity/engine.py），步数=%d"
                                 % engine.CRR_STEPS,
                   "independent": "对数空间 Crank-Nicolson FD ＋ PSOR "
                                  "（verify/independent_recompute.py），n_x=%d n_t=%d"
                                  % (ir.FD_N_X, ir.FD_N_T)},
        "_declared_bumps": bumps,
        "_bump_choice_rationale":
            "vega 步长维持 1e-3 而非增大：实测增大步长（3e-2）虽使两路径相对差降至"
            "≤1e-3，但两侧同时因曲率截断偏离真 vega（G08 坐标 CRR 偏真值 1.8e-2），"
            "属**共模误差制造之虚假一致**——F-2 判别据（改写后是否仍共享同一失效"
            "模式）反面情形。维持小步长使路径差如实反映格点锯齿误差，判据区分力不失。",
        "_eep_denominator_note":
            "EEP 之量级界分母＝**同坐标欧式模式值**（非 EEP 自身）。EEP 为差值型"
            "输出，以自身为分母时 cancellation 放大相对误差（T-24 bleed 同型，"
            "REG-T24-01→裁决19 先例）；两路径绝对偏差随期权价值标度而非随溢价大小"
            "标度，故本分母之界区分力更强。F-11 规定界值『逐对象独立标定』但未固定"
            "分母，分母选择属标定方法。**呈KD**：该分母选择之追认。",
        "_safety_multiple": SAFETY,
        "_grid_size": len(GRID),
        "worst_observed_rel_diff": worst,
        "calibrated_bounds": bounds,
        "discrete_invariant_failures": inv_fail,
        "rows": rows,
    }
    with open(OUT, "w", encoding="utf-8") as fh:
        json.dump(out, fh, ensure_ascii=False, indent=2)
        fh.write("\n")
    print("\n=== 逐分量实测上界与标定界值（×%.0f 安全边际，向上取1位有效数字）==="
          % SAFETY)
    for k in ("value", "delta", "gamma", "vega", "theta", "rho", "eep",
              "european_mode_value"):
        print("  %-6s 实测上界 %.4e → 界值 %.1e" % (k, worst[k], bounds[k]))
    aux1 = max(r["rel_diff"]["_eep_rel_to_self"] for r in rows)
    aux2 = max(r["rel_diff"]["_vega_rel_to_scale"] for r in rows)
    print("  辅助记录：eep 以自身为分母之上界 %.4e；vega 以 S√T 为标度之上界 %.4e"
          % (aux1, aux2))
    print("离散不变量违反例：%s" % (inv_fail if inv_fail else "无（10/10 全通过）"))


if __name__ == "__main__":
    main()

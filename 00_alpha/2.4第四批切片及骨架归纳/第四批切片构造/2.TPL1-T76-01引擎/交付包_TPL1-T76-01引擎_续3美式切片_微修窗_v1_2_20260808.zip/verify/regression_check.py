"""
TPL1-T76-01 引擎 · 续2增强 · 回归检验与底版-增强版diff面清单产出（S-1机械前哨）

用途（任务包§3 S-1增量封闭判据之机械前哨双件）：
  (a) q=0退化回归：以 entity/input_data.json 之全部lot强制 dividend_yield=0（期权lot），
      重跑 entity/engine.evaluate_lot，产出 verify/regression_q0_output.json；
      与 verify/baseline_v1_1_reference.json（增强前v1.1原始产出，cp-then-edit时另存）
      逐容器逐笔逐分量比对——q=0时增强公式代数化简至旧公式，预期逐字节一致。
  (b) 底版-增强版diff面清单：实际增强产出（entity/harness_output.json，真实q值）
      与 baseline_v1_1_reference.json 对比，产出 verify/baseline_diff_table.tsv，
      标注每笔每分量"零变动"或"变动"，供人工核验变更面是否封闭于§2.3入范围项
      （非期权路由须逐分量零变动；期权路由数值分量允许变动，route_id/
      unstated_dimensions_hit 仅允许§2.3声明之特定字段变动）。

数据源纪律：本脚本 import entity.engine 直接调用被测函数（构造侧自查脚本，与
verify/independent_recompute.py之"不import被测模块"独立性纪律不冲突——本脚本
职责是回归验证与diff枚举，非独立复算路径，不参与D段②之路径独立判据）。
零网络、零外部数据源；仅读 entity/input_data.json 与 verify/baseline_v1_1_reference.json。
"""

import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(PKG, "entity"))

import engine  # noqa: E402  被测模块本体，本脚本职责为回归自查非独立复算

CONTAINERS = ("base_valuation", "scenario_revaluation", "time_shift_revaluation")
COMPONENTS = ("value", "delta", "gamma", "vega", "theta", "rho")

IN_PATH = os.path.join(PKG, "entity", "input_data.json")
BASELINE_PATH = os.path.join(HERE, "baseline_v1_1_reference.json")
BASELINE_V12_PATH = os.path.join(HERE, "baseline_v1_2_reference.json")
ACTUAL_OUT_PATH = os.path.join(PKG, "entity", "harness_output.json")
Q0_OUT_PATH = os.path.join(HERE, "regression_q0_output.json")
DIFF_TABLE_PATH = os.path.join(HERE, "baseline_diff_table.tsv")


def _market_override(lot, spot=None, vol=None, valuation_date=None):
    out = dict(lot)
    if spot is not None:
        out["spot"] = spot
    if vol is not None:
        out["implied_vol"] = vol
    if valuation_date is not None:
        out["valuation_date"] = valuation_date
    return out


def _run_engine(lots, v0, shock, tshift, force_q0):
    """镜像 harness.main() 之驱动逻辑；force_q0=True 时期权lot之dividend_yield强制0.0。"""
    base, scen, tsh = [], [], []
    for raw in lots:
        raw = dict(raw)
        if force_q0 and raw["instrument_class"] in ("european_option", "american_option"):
            raw["dividend_yield"] = 0.0

        lot = _market_override(raw, valuation_date=v0)
        base.append(engine.evaluate_lot(lot))

        s_lot = _market_override(
            lot,
            spot=raw["spot"] * (1.0 + shock["spot_shock_pct"]),
            vol=(None if raw["implied_vol"] is None
                 else raw["implied_vol"] + shock["vol_shock_points"]),
        )
        scen.append(engine.evaluate_lot(s_lot))

        t_lot = _market_override(lot, valuation_date=tshift["valuation_date_t1"])
        tsh.append(engine.evaluate_lot(t_lot))
    return {"base_valuation": base, "scenario_revaluation": scen,
            "time_shift_revaluation": tsh}


def main():
    with open(IN_PATH, "r", encoding="utf-8") as fh:
        data = json.load(fh)
    v0, shock, tshift = data["valuation_date"], data["scenario_shock"], data["time_shift"]

    # --- (a) q=0退化回归 ---------------------------------------------------
    q0_result = _run_engine(data["lots"], v0, shock, tshift, force_q0=True)
    q0_output = {
        "_data_source": data["_data_source"],
        "_note": "regression_check q=0强制变体；仅供与baseline_v1_1_reference.json比对，非交付产物本体",
        "route_table": {("%s|%s" % (k[0], k[1] if k[1] is not None else "")): {
                            "instrument_class": k[0], "exercise_style": k[1],
                            "route_id": engine.ROUTE_TABLE[k],
                            "computability_status": engine.COMPUTABILITY[k],
                            "unstated_dimensions_hit":
                                list(engine.UNSTATED_DIMENSIONS[k])}
                        for k in sorted(engine.ROUTE_TABLE,
                                        key=lambda t: (t[0], t[1] or ""))},
        **q0_result,
    }
    with open(Q0_OUT_PATH, "w", encoding="utf-8") as fh:
        json.dump(q0_output, fh, ensure_ascii=False, indent=2)
        fh.write("\n")

    with open(BASELINE_PATH, "r", encoding="utf-8") as fh:
        baseline = json.load(fh)

    # 续3射程订正：q=0 退化回归之前提为「求值路径本身未变，仅 q 参数化增强」，
    # 该前提对**美式路由不再成立**——本切片将 american_via_european_stub 置换为
    # american_crr_binomial（TPL1-T7601-03 兑现，即本切片对象本体）。故 q0 回归
    # 射程收窄至非美式路由；美式路由之变动为**预期变动**，另列留痕，不计入不符。
    # 收窄非放宽：美式路由之回归面由 S-2「既有分支零判定翻转」承载（见下 (b) 段
    # scope_violation：非期权路由零变动 ＋ 欧式路由数值零变动核验）。
    AMERICAN_CLASSES = {"american_option"}
    LOT_CLASS0 = {l["lot_id"]: l["instrument_class"] for l in data["lots"]}
    # 丙类修复（R-C 用例面扩充，裁决76-3）：新增美式用例在 v1.1 基线中无对应记录，
    # 分流为 q0_new（不静默跳过，随 summary 呈报；封闭性核验归 assert_check S-2b/S-2c）。
    q0_bad, q0_american_expected, q0_new = [], [], set()
    for c in CONTAINERS:
        bmap = {r["lot_id"]: r for r in baseline[c]}
        for r in q0_output[c]:
            b = bmap.get(r["lot_id"])
            if b is None:
                q0_new.add(r["lot_id"])
                continue
            am = LOT_CLASS0[r["lot_id"]] in AMERICAN_CLASSES
            for layer in ("per_unit", "per_lot"):
                for k in COMPONENTS:
                    qv, bv = r[layer][k], b[layer][k]
                    if qv != bv:
                        (q0_american_expected if am else q0_bad).append(
                            "%s/%s/%s/%s q0=%r baseline=%r"
                            % (c, r["lot_id"], layer, k, qv, bv))

    # --- (b) 底版-增强版diff面清单 -------------------------------------------
    with open(ACTUAL_OUT_PATH, "r", encoding="utf-8") as fh:
        actual = json.load(fh)

    rows = [["container", "lot_id", "layer", "component", "baseline_v1_1",
             "enhanced_v1_2candidate", "verdict"]]
    scope_violation = []
    # 本表之基线＝baseline_v1_1_reference.json（**续2增强前**之 v1.1 产出），
    # 故欧式路由之变动为续2 之 q 承接位所致、美式路由之变动为续3 之求值置换所致，
    # 二者相对 v1.1 均属合法变动。**续3 之「既有分支零判定翻转」不由本表承载**
    # ——本表跨两版，无区分力；该判据另由下方 (c) 段 S-2 以 v1.2 收口态为基线承载。
    OPTION_CLASSES = {"european_option", "american_option"}
    LOT_CLASS = {l["lot_id"]: l["instrument_class"] for l in data["lots"]}

    diff_new = set()
    for c in CONTAINERS:
        bmap = {r["lot_id"]: r for r in baseline[c]}
        for r in actual[c]:
            b = bmap.get(r["lot_id"])
            if b is None:
                diff_new.add(r["lot_id"])
                continue
            ic = LOT_CLASS[r["lot_id"]]
            for layer in ("per_unit", "per_lot"):
                for k in COMPONENTS:
                    av, bv = r[layer][k], b[layer][k]
                    changed = (av != bv)
                    verdict = "变动" if changed else "零变动"
                    rows.append([c, r["lot_id"], layer, k, repr(bv), repr(av), verdict])
                    if changed and ic not in OPTION_CLASSES:
                        scope_violation.append("%s/%s(%s)/%s/%s" % (c, r["lot_id"], ic, layer, k))

    # route_table 层面diff（仅报告，非per-lot分量表一部分）
    route_diff_rows = [["instrument_class", "field", "baseline_v1_1", "enhanced_v1_2candidate"]]
    # 续3：baseline v1.1 之 route_table 为**单键**形态（品种→三字段），actual 为
    # 二元组复合键形态。比对按品种投影，键形态差异本身不计入 diff（结构变更由
    # §2.3 扩范围明授承载，逐项列于 route_diff_rows）。
    ALLOWED_ROUTE_FIELD_CHANGE = {
        ("european_option", "route_id"),
        ("european_option", "unstated_dimensions_hit"),
        ("american_option", "unstated_dimensions_hit"),
        ("american_option", "route_id"),               # 续3：桩→CRR 置换
        ("american_option", "computability_status"),   # 续3：placeholder_stub→computed_with_open_dimensions
    }
    route_scope_violation = []
    actual_by_ic = {v["instrument_class"]: v for v in actual["route_table"].values()}
    for ic in engine.INSTRUMENT_CLASSES:
        b = baseline["route_table"][ic]
        a = actual_by_ic[ic]
        for f in ("route_id", "computability_status", "unstated_dimensions_hit"):
            if b[f] != a[f]:
                route_diff_rows.append([ic, f, repr(b[f]), repr(a[f])])
                if (ic, f) not in ALLOWED_ROUTE_FIELD_CHANGE:
                    route_scope_violation.append("%s.%s" % (ic, f))

    with open(DIFF_TABLE_PATH, "w", encoding="utf-8") as fh:
        fh.write("# 底版-增强版diff面清单（S-1机械前哨）\n")
        fh.write("# route_table层面变动：\n")
        for r in route_diff_rows:
            fh.write("\t".join(str(x) for x in r) + "\n")
        fh.write("#\n# per-lot数值分量层面变动（288项全量，含零变动行）：\n")
        for r in rows:
            fh.write("\t".join(str(x) for x in r) + "\n")

    # --- (c) S-2 零判定翻转：以 v1.2 收口态为基线（续3新增）-------------------
    # 立法背景：(b) 段 diff 表之基线为 v1.1，跨越续2＋续3 两版变动，对「续3 是否
    # 扰动既有分支」零区分力。S-2 判据（任务包§3 语义层判据）要求既有欧式/q/
    # day count 分支对既裁用例产出**零判定翻转**，其对照面须为**紧邻上一收口态**。
    # 基线件＝verify/baseline_v1_2_reference.json（续2 v1.2 交付包之
    # entity/harness_output.json 原件，SHA256 载于 input_schema.md §8.1 声明面，
    # 与 scan_patterns.json／baseline_v1_1_reference.json 同一双钉机制）。
    with open(BASELINE_V12_PATH, "r", encoding="utf-8") as fh:
        baseline12 = json.load(fh)
    s2_bad, s2_american_expected = [], []
    s2_checked = 0
    s2_new = set()
    for c in CONTAINERS:
        bmap = {r["lot_id"]: r for r in baseline12[c]}
        for r in actual[c]:
            b = bmap.get(r["lot_id"])
            if b is None:
                s2_new.add(r["lot_id"])
                continue
            am = LOT_CLASS[r["lot_id"]] in {"american_option"}
            # 标注面亦纳入：route_id／可算性／未言明维度三字段
            for f in ("route_id", "computability_status", "unstated_dimensions_hit"):
                if r[f] != b[f]:
                    (s2_american_expected if am else s2_bad).append(
                        "%s/%s/%s" % (c, r["lot_id"], f))
            for layer in ("per_unit", "per_lot"):
                for k in COMPONENTS:
                    if not am:
                        s2_checked += 1
                    if r[layer][k] != b[layer][k]:
                        (s2_american_expected if am else s2_bad).append(
                            "%s/%s/%s/%s v1.2=%r v1.3=%r"
                            % (c, r["lot_id"], layer, k, b[layer][k], r[layer][k]))

    ok = (not q0_bad) and (not scope_violation) and (not route_scope_violation) \
        and (not s2_bad)
    summary = {
        "s2_baseline": "verify/baseline_v1_2_reference.json（续2 v1.2 收口态）",
        "s2_nonamerican_items_checked": s2_checked,
        "s2_zero_flip_violations": s2_bad,
        "s2_american_expected_changes_count": len(s2_american_expected),
        "s2_baseline_absent_lots": sorted(s2_new),
        "q0_baseline_absent_lots": sorted(q0_new),
        "diff_table_baseline_absent_lots": sorted(diff_new),
        "_baseline_absent_note": "丙类修复 R-C 用例面扩充（裁决76-3）之新增美式用例；"
                                 "封闭性核验（缺位集⊆美式、非美式项数钉定）归 "
                                 "assert_check.py S-2b/S-2c",
        "q0_regression_scope": "非美式路由（美式路由本切片置换求值路径，"
                               "q=0退化回归前提不成立，另列预期变动留痕）",
        "q0_regression_mismatches": q0_bad,
        "q0_american_expected_changes_count": len(q0_american_expected),
        "scope_violations_numeric": scope_violation,
        "scope_violations_route_table": route_scope_violation,
        "route_table_changes": route_diff_rows[1:],
        "verdict": "PASS" if ok else "FAIL",
    }
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()

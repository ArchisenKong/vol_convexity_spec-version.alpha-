# 一阶实体 · TPL1-T76-01引擎 · input schema 与算法declaration · v1.3 · 候选(续3美式切片·丙类修复) · 20260808

> **v1.3 微修窗订正（20260808，四3收口裁决台会话**KD授权同session执行例外**，裁决78；cp-then-edit 自 v1.1 交付包）**：E-1α（`lattice_diagnostics.crr_steps` 改取实际执行路径返回值 `n_steps_used`，回显-实际不可脱钩）；E-2（断言侧新增 A7-e 界值派生关系重算对表）；E-6β（`sys.dont_write_bytecode`）；文书批 E-3/E-4 本面订正；§8.1 `build_provenance.json` 指纹行随产物再版同步。**协同篡改负空间声明（收裁-3γ，裁决78）**：「实现＋判据基线声明多面一致改写」型不在断言免疫射程——手册 v1.8 §3.1d 协同篡改豁免自双钉指纹面**外推至判据基线面**；单面改写已实证全击落（增量复核 N1a），本声明为剩余协同面之射程外如实标注。
> 原修复订正头注：**v1.3 丙类修复订正（20260808，引擎切片**修复会话**，cp-then-edit 自 v1.0 交付包；授权源＝裁决76-1(c)(d)／76-3／76-4／76-6／76-7／76-9 ＋ 裁决75-1 ＋ 任务包_四3修复_v1.0）**：外审 D-1～D-8 之修复面落写。实质三项——① D-1采γ案（§5.1 新增 `american_lattice_fn` 等五行〔微修窗 E-4 订正：原误记"四行"〕 ＋ §7.1 新增 `F11_AUX_COMPONENT_DECLARATION` 块；断言侧新增 A17 源级同源双调用参数同一性 ＋ A7-c 辅助分量跨路径比对）；② D-2（`early_exercise_premium` 与 `european_mode_value` 补消费点，`F11_BOUND_DECLARATION` 新增 `european_mode_value` 界值，容差声明块与比对循环双向对表 A7-d）；③ D-3采α案（探针输入补 `exercise_style`）。机械项八项见 §11。**引擎版本号 v1.3 维持**（裁决76-1(c) 修复窗不改版本身份；本文件版本标记同步维持 v1.3，形态呈增量复核与收口裁决台核证，本会话不预判）。
> **会话身份（现行面）**：引擎切片**修复会话**（施工侧，Opus 5，新session，fresh context）。零自审、零裁决——本文件全部判断均为施工侧呈报，实体边界与范围疑义一律呈KD；终态判定归增量复核＋KD收口。

> **v1.3 修订（续3 引擎美式切片构造会话，cp-then-edit 自 v1.2；授权源＝任务包_四3_TPL1-T7601-03美式 v1.0 ＋ KD裁定 A-0/A-0'/A-1/A-2/A-2'/A-3/§6）**：
> ① **TPL1-T7601-03 兑现**——`american_option` 路由由确定性占位桩置换为 CRR 二叉树实跑（§3／§6 成分9 拆分改写）；
> ② **`exercise_style` 必填独立字段新增**，`ROUTE_TABLE` 键改二元组（§2／§3／§5）；
> ③ **早行权溢价输出面新增**（§5 record 级 `early_exercise_premium`，同离散基线）；
> ④ **`option_identity_routes` 收窄至欧式路由**（§5.1）——三条行为级恒等式为 BS 闭式解之解析恒等式，对美式 CRR 分支**不成立**（L07 坐标实测：rho 式相对差 27.4%、vega 式 6.4%、PDE 残差 −3.74e-4；同坐标欧式分支 PDE 残差 2.33e-15）；
> ⑤ 三分判别表新增成分 13（步数 N，类二·缺定义型）／14（离散分红形态，类三）；成分 9 由「类二·缺实现型」改写为「甲结构层类一 ∪ 乙算法族类三 ∪ 丙步数N类二·缺定义型」〔丙层见表体成分9／成分13，微修窗 E-3 补注——头注与表体三方一致之镜像半〕；
> ⑥ 搭车项落写：`DAY_COUNT_DENOMINATOR` 之「占位取值不外推」陈述残留订正（R-2／70-A2）；`day_count_convention` 标签语义重定**未落**（待裁二选一，见 §3 订正注）。

> **v1.2订正（20260802，续2收口裁定会话，KD裁定＝裁决58；纯文本订正三处，engine/verify与全部产物零触碰）**：①§3路由注记之day count陈述随裁决57-6订正（R-2 schema侧其一）；②§10.1呈KD清单该行随裁订正（R-2 schema侧其二）；③§1行"审计表行96"指针刷新至v1.5行106（R-3）。engine.py行34/100/122三处注释残留**不动**，登记为已知开口（撞墙清单引擎v1.3），#8桩替换批搭车订正——不为纯注释重打包引擎指纹链。

> **身份**：TPL1-T76-01（品种感知自算Greeks/定价引擎）之阶段A一阶实体。第三批首根（裁决43-E3）。
> **授权链**：切片任务包_TPL1-T76-01引擎_v1_0_candidate_20260730（KD已确认）＋裁决1（构造链）＋裁决45 §5（1级契约六条）＋裁决13/19（容差）＋裁决21(a)（三分判别）＋裁决24-A7 O1（目录结构）＋裁决28-B(ii)（非零退出码）＋裁决39-B（输出形态封闭，第三批起转施工侧判据）＋裁决48（外审裁定，Q-9锚定区间补充等修复面）＋裁决49（引擎本体收口）。
> **续2增强授权链**：裁决52-2（股息处置甲＋并包04：期权定价q分量待建实质＋day count并包一窗）＋裁决52-1（续2入选）＋裁决54-5/54-6（续2零新增源文行声明＋C4②闸门开）＋裁决52-3=b（并行排程）＋裁决56-2（任务包生成与裁决台同session合法）＋裁决56-3（Q-c呈裁时点＝收口会话同批）＋任务包_续2_引擎求值口径增强_v1_0_定案_20260802。
> **续2续修复授权链（**历史标注（丙类修复 D-8）：本行"本次修订新增"指 v1.1→v1.2 之续2续修复窗，非现行面**）**：裁决57-1（续2判定不通过·单一修复动作）＋裁决57-4（D-1定性更正＋分域读法前置口径）＋裁决57-5（C07/C08扩48-2通道）＋裁决57-6（day count＝ACT/365权威口径）＋外审报告_续2_v1_0_20260802＋底版对照补充核证_v1_0_20260802＋修复会话开启文本_续2_20260802。
> **〔历史留痕·转历史依据（丙类修复 D-8 订正）〕会话身份（续2续修复窗当时）**：续2切片修复会话（施工侧，新session，chat，fresh context）。零自审、零裁决。与续1修复会话互不读取（修复会话开启文本§一）。**本行为 v1.1→v1.2 窗之当时陈述，非现行面**；现行会话身份见文首「会话身份（现行面）」行。
> **〔历史留痕·转历史依据（丙类修复 D-8 订正）〕版本身份声明（续2续修复窗当时）**：本文件彼时为续2修复会话产出之候选件（v1.1 candidate），标记"v1.1→候选(续2增强·续修复)"不构成版本号裁定——该呈裁项（任务包§6 Q-c(c)）已由后续裁定链承接。**本行之"v1.1 candidate"为当时状态，与文首行1 之现行版本标记（v1.3）相差两版，非现行面**；现行版本身份以行1 与文首丙类修复订正注为准。
> **续2变更范围提要**（详见文末§10）：欧式分支引入连续股息收益率q（新增已言明字段`dividend_yield`）；route_id `bs_no_dividend_closed_form`→`bs_dividend_yield_closed_form`（避免q≠0后旧名名实不符）；`european_option`/`american_option`两路由之`unstated_dimensions_hit`去标`dividend_carry`（路由声明兑现）。§1-§9为v1.1原文（cp-then-edit保留，变更处标"续2订正"内嵌标注）；§10为续2新增独立小节。
> **续2续修复变更范围提要（本次新增，八项修复动作，裁决57-1/57-4/57-5/57-6落地）**：①乙-4被测侧注入补齐（negative_control.py案例5）；②F-5双钉补齐（§8.1新增baseline_v1_1_reference.json指纹钉定）；③产物新鲜度observable新增（新增verify/build_provenance.py＋assert_check.py A10断言组）；④C07/C08口径断言新增（assert_check.py A11/A12）；⑤§2字段集/A4-c/engine.py锚定注释三处同源化订正（D-5）；⑥§3行75旧route_id订正为现名（O-4）；⑦§1/§6审计表指针刷新至v1.5行104/105（O-5）；⑧day count权威化落写（§5.1/§6行10/§10.3）＋§10.5冲突登记留痕新增（D-1(b)销项）。变更处标"续2续修复订正"或对应缺陷编号内嵌标注。

---

## §1 对象语义与边界

TPL1-T76-01引擎＝**品种感知的自算Greeks/定价供给物**：按品种路由适用定价模型，per-lot Greeks 与估值 V(t) 由自有统一算法计算，以消除回测（QC）与实盘（IBKR）数据源间的Greeks口径差异。

**供给方定位（契约⑥，既裁24-E3）**：仪表计算器，非定价真理源。Phase B设计受宪法定价认识论章约束（消费通道＝翻译审计表现行版之「宪-EP-05 定价模型批判」「宪-EP-06 定价认识论」两行对照区，C4②成对引用；**丙类修复订正 D-5采β形态**：弃行号锚改词锚——两词锚在审计表内各唯一，grep 可定位，上游台账再版不再断链；此前 v1_4行94/95→v1_5行104/105 之逐版重锚形态即同型复发三例之成因）。本实体不承载任何"应然价格/正确定价"宣称，不以模型输出裁决获利合法性。

**契约状态字段之供给面声明（L-1 落写，续3；授权源＝裁决61-4 登记＋裁决73候选3-2 补裁「续挂引擎 v1.3 再版窗口」＋DOC-19(i) 同批兑现）**：

本实体每条 per-lot 记录携带三项**契约状态字段**——`computability_status`（可算性三态）／`unstated_dimensions_hit`（该求值路径进入之未言明维度）／`route_id`（求值路径身份）。三者为**供给物之一部分**，非诊断附属：其语义为「本笔读数在何种口径下成立」，消费方据以判断该读数可承担何种用途。

- **供给面义务（本根，已兑现）**：三字段逐笔在场、值域受 §3 ROUTE_DECLARATION 约束、与实现逐笔一致（断言 A3-b2／A3-c／A3-d／A11／A12）。续3 另增 `exercise_style` 回显与 `lattice_diagnostics`（美式路由），同受声明面约束。
- **消费面义务（下游根，本根不代裁）**：L-1 登记之实质＝「M1 契约状态字段无消费方」（裁决61-4：无实害已证）。消费方是否须对 `placeholder_stub` 与 `computed_with_open_dimensions` 两态作差别处置、是否须传播 `unstated_dimensions_hit`，**属下游根之契约面判断**，本根仅声明供给、不规定消费（裁决14 口径：模块划分与接口形态属归纳反推）。**呈KD**：L-1 之兑现是否以本供给面声明为足，抑或尚需下游侧动作。
- **当前实况留痕**：`futures` 路由为 `placeholder_stub`、两期权路由为 `computed_with_open_dimensions`、三线性路由为 `closed_on_stated_face`——三态并存，字段具备实际区分内容，非恒常量退化。

**下边界（不做什么）**：
- 不做 node 级聚合（T-76 本职，裁决14）；不做腿级聚合（GK-31 本职）。本实体止于 per-lot 两层（per_unit / per_lot）。
- 不承载 identity/target review 判定或 target 变更之自动执行位（翻译审计表现行版之「宪-ID-02 身份与假设分离」行，人工域，pipeline出口外；**丙类修复订正 D-5采β形态**：弃行号锚改词锚）。
- 不消费任何 vendor 派生量（Greeks/理论价/模型IV）作输入（契约⑤）。

**下边界·续3 增量五条（F-13 反面陈述段；任务包四3 §2.5 逐条落写，丙类修复 D-6 集中落地）**：

1. **不代行 TPL1-T7601-02**（期货结算/保证金形态）。`futures` 路由维持 `placeholder_stub` 与恒等承接，续3 之美式兑现与之无涉；该条目显式后置（裁决72-7），本实体不就地定义其结算约定。
2. **不承诺美式路径之市场校准精度**。CRR 二叉树产出为仪表读数，与任何市场成交价/vendor 理论价之接近程度**不在本实体宣称范围内**；算法族（TPL3-T7601-02）与离散分红形态（TPL3-T7601-03）之充分性由阶段B 以回测/实盘数据裁定，阶段A 声明值不外推。
3. **不产出选型裁定**。探针（`verify/probe_american.py`）之候选比较为实证材料，其结论为**呈KD候选**，本实体不以任何输出字段承载"某算法族更优/已选定"之判定；`route_id` 只记录该笔实际走过之求值路径，非选型结论。
4. **不改变既有欧式/q/day count 分支行为**。续3 及本次丙类修复对 `bs_dividend_yield_closed_form`、三条线性路由、`futures` 桩之求值规则与产出数值**零触碰**；该封闭性由 S-2（基线＝v1.2 收口态，非美式路由全部数值分量 ＋ 三标注字段 bit-exact）机械承载，非文本承诺。
5. **不接任何数据源**。`entity/` 与 `verify/` 全部脚本零网络、零行情接口、零外部文件读取（仅读包内人造 input 与包内声明面）；输入面全部数值为人造声明值（`_data_source: synthetic_hand_constructed`，裁决1）。详见 §9。

**情景重估之形态（构造中反推浮现，非预先设计）**：T3-03 §3.4／GK-14 §2.6／T3-17 §3 之情景重估消费面、T-24 §4① 之 V(t0)/V(t1) 重估差消费面，**均不要求本实体新增任何接口参数**——以冲击后（或时点推移后）的市场坐标构造同形 lot 再次调用同一签名即得重估结果。模块划分_v1_0 M1 接口形态所列"情景冲击"入参面，在已言明面上收敛为市场坐标字段本身。此为构造侧呈报观察，不自裁。

---

## §2 已言明最小面（契约④）

**原文锚**：一阶实体_T-76_input_schema_v2_2_20260714.md §2 字段表（行17–33）＋ §4 桩接口段（行60–79）。指针引用，不转写。

**锚定区间之补充（Q-9 订正，裁决48 §4）**：上列两区间不覆盖 `valuation_date` 之权威源——该字段之权威定义在 **T-76 schema §3 行46**（`dte = (expiry - valuation_date).days`，整数天口径）。本实体求值路径消费 `valuation_date`（见 STATED_FACE_FIELDS），故锚定面为〔§2 行17–33〕＋〔§3 行46〕＋〔§4 行60–79〕三段，非原表述之两段。

**45-B1 条款措辞（逐字随附）**：

以下为已言明最小面，未言明维度（美式行权、股息、期货保证金形态、day count等）不构成规格封闭，留引擎切片撞墙

**本实体求值路径实际消费之字段集**（STATED_FACE_FIELDS，engine.py 同名常量，共13项，续2续修复D-5订正：原12项声明未随续2新增字段同步，已补入）：
`lot_id` / `instrument_class` / `option_type` / `side` / `strike` / `expiry` / `spot` / `risk_free_rate` / `implied_vol` / `multiplier` / `quantity` / `valuation_date` / `dividend_yield` / `exercise_style`

（续3订正：共 **14 项**，原 13 项声明随 `exercise_style` 新增同步。）

**未进入求值路径**：`underlying` / `leg_type` / `open_interest`（T-76 坐标轴与保留字段，非定价输入）。

**新增字段一项**：`instrument_class`（路由键）。已言明面无路由键槽位——T-76 `option_type: enum{call,put}` 为强制枚举，GK-31 之 `instrument_type: enum{linear,option}` 为二值域，均不足以承载契约②所要求之六品种路由。本根取用 `instrument_class`，值域逐项取自撞墙清单_T-76 v2.3 缺口描述原文所列六品种。**本根工程取用，不外推为跨根命名规范**（形态先例＝T-76 schema §1 同型声明）；是否升为常设接口＝骨架/模块层归纳反推之事（裁决14），本根不预裁。**呈KD**：字段名与值域取用之追认。

`instrument_class=spot/spot_etf/index` 之 lot 其 `expiry`/`strike`/`implied_vol` 退化取 `null`，`option_type` 退化取 `"NA"`（退化形态先例＝GK-31 schema §1 点3 之 linear 节点退化处置）。

**续3新增字段（行权风格，KD裁定§6；授权源＝裁决71-4「上游input行权风格字段缺位＝03建成之输入面前置条件」）**：`exercise_style`——**必填独立字段**，值域 `enum{european, american}`；非期权类（`spot`/`spot_etf`/`index`/`futures`）退化取 `null`（退化形态先例同 `strike`/`implied_vol`）。

- **必填**：字段缺位即 raise，**不由 `instrument_class` 推导**。理由（KD裁定§6）：推导即就地定义；且 `instrument_class`（品种）与 `exercise_style`（合约行权风格）为正交两轴，压成一轴正是 45-B1 将「美式行权」点名为独立未言明维度之成因形态。
- **路由第二轴**：`ROUTE_TABLE` 键由单键改为 `(instrument_class, exercise_style)` 二元组（§3）。一致性校验因而**内建于路由查表本身**——非法组合不在表中即 raise，不另设校验步、不静默回退。
- **结构冗余如实登记**：当前期权域两轴完全共变（`european_option`↔`european`、`american_option`↔`american`），系 `instrument_class` 值域锚定于撞墙清单_T-76 v2.3 缺口描述原文所列六品种所致，**非设计选择**；收窄该值域即静默收窄品种域（发现事项#1 明确要求六品种全在场），故不以收窄消除冗余。该冗余在出现 `("index","american")` 型组合时自然消解——二元组结构为此保留。**本根工程取用，不外推为跨根命名规范**（形态先例同 `instrument_class`／`dividend_yield`）。**呈KD**：字段名与值域取用之追认。

**续2新增字段（q承接位，任务包§2.3；已并入上文§2行38消费字段集主声明，此处保留取用依据留痕）**：`dividend_yield`——已言明面无股息/持有收益率槽位（45-B1明列股息为未言明维度），本根取用 `dividend_yield` 承接连续股息收益率 q（KD裁定52-2②之q承接方式本身）。**本根工程取用，不外推为跨根命名规范**（形态先例同 `instrument_class` 取用之§2既有声明）。**呈KD**：字段名取用之追认。

**输入身份（任务包§2.3）**：q为人造声明输入（裁决1），`_data_source` 纪律同§9——q数值为人造有理声明值，非任何真实股息数据。取值范围：`instrument_class=european_option/american_option` 之 lot 取人造声明有理值（本轮实跑按底层标的`underlying`分配，同一标的之各期权lot共享同一q值，量级参照裁决52落地文档"NDX股息率年化~0.6%量级"之数量级语境择取、不外推为对该参照值的精确复刻）；`instrument_class=spot/spot_etf/index/futures` 之 lot 退化取 `null`——线性标的（spot/spot_etf/index）股息分量属裁决52-2①范围裁定不建模（该分量已闭合，非本切片对象）；期货（futures）持有成本形态属TPL1-T7601-02，不入续2范围。退化形态先例同上（`expiry`/`strike`/`implied_vol`之null退化）。

---

## §3 品种路由声明（契约②）

```
ROUTE_DECLARATION
spot |  | linear_underlying | closed_on_stated_face |
spot_etf |  | linear_underlying | closed_on_stated_face |
index |  | linear_underlying | closed_on_stated_face |
futures |  | linear_underlying_futures_stub | placeholder_stub | futures_settlement_form,dividend_carry
european_option | european | bs_dividend_yield_closed_form | computed_with_open_dimensions | day_count_convention
american_option | american | american_crr_binomial | computed_with_open_dimensions | day_count_convention
```

（**续3：五列**＝品种｜行权风格｜route_id｜可算性标注｜命中之未言明维度。第二列空白＝`null`（非期权类退化）；末列空白＝零命中。路由键＝前两列之二元组，表外组合无路由即 raise。）

**续3订正（TPL1-T7601-03 兑现，KD裁定 A-0/A-0'/A-1）**：
- `american_option` route_id 由 `american_via_european_stub` 置换为 **`american_crr_binomial`**（CRR 二叉树，逐节点提前行权判定，步数声明值 `CRR_STEPS`）。
- 可算性标注由 `placeholder_stub` 升 **`computed_with_open_dimensions`**——本路由求值规则已非占位桩而是真实计算；其模型族属类三 open（TPL3-T7601-02），形态与 `european_option` 分支（GBM 闭式解族亦类三 TPL3-T7601-01）**完全平行**。
- `early_exercise` **去标**——早行权维度已进入该求值路径之计算，标注口径同裁决48 §3 之乙·求值路径特征级命中；形态先例＝续2 对 `dividend_carry` 之去标。**去标不构成「美式定价已完备」之主张**：算法族（TPL3-T7601-02）与离散分红形态（TPL3-T7601-03）两项类三如实 open，由 `computability_status` 与撞墙清单承载，不由本标注承载。
- `futures` 维持 `placeholder_stub`（TPL1-T7601-02 显式后置，裁决72-7）。

**`day_count_convention` 标签语义重定：本版未落，随包呈裁**。撞墙清单引擎 v1.3「已知开口登记」该项原文即为待裁二选一「是否随之重定（去标／升 `closed_on_stated_face`）」，落点栏明写「呈KD裁定后同批落」——KD 裁定为前置条件，非可机械兑现项，构造会话不自决。本版两期权路由维持命中不动，标注面因而完全平行。候选三项（α 维持命中，采裁决48 §3 乙口径／β 去标并升档／γ 去标但维持档）见切片记录呈裁段。

**续2订正（路由声明兑现，KD裁定52-2②，任务包§2.1）**：`european_option` route_id 由 `bs_no_dividend_closed_form` 改名为 `bs_dividend_yield_closed_form`——旧名于q≠0后名实不符（声明-实现一致性考量，非契约文本变更，纯本切片内部实现命名）。两期权路由之 `unstated_dimensions_hit` 均去标 `dividend_carry`：q承接位已建成，该求值路径之计算已进入股息维度（乙·求值路径特征级命中口径，裁决48 §3）。`american_option` 因承接同一函数（`american_via_european_stub`调用`bs_dividend_yield_closed_form`）而随之消费q，**如实去标，不构成对TPL1-T7601-03（早行权）之闭合宣称**——`early_exercise` 维持命中（任务包§2.3边界）。`day_count_convention` 两路由命中标签**本版维持**——**v1.2订正注**：该维度之"未言明"属性已随裁决57-6（ACT/365权威口径）消解，命中标签现为"计算进入该维度"之路径事实记录；标签语义重定（是否去标／`computability_status`是否升格）触及route_table值面与S-1b底版对照断言＝产物变动域，登记为已知开口（撞墙清单引擎v1.3），#8桩替换批随批呈KD裁定后同批落，本版不即改（收裁-3'搭车修纪律）。

**`unstated_dimensions_hit` 之标注语义（裁决48 §3 既裁，乙·求值路径特征级命中）**：该字段＝「该求值路径之计算是否进入该维度」。线性恒等求值不含时间投影，股息维度不进入计算，故 `spot`／`spot_etf`／`index` 三条线性路由均零命中；`european_option`／`american_option`（时间投影在场）与 `futures`（结算/持有成本形态本身未言明）维持各自命中。**该零命中标注仅就求值路径而言，不构成"线性持仓无股息经济影响"之主张**——经济层股息现金流缺口（含线性持仓 bleed 漏分红之实况）由撞墙清单 TPL1-T7601-01 之缺口描述全域承载，信息零丢失。

**可算性三态口径**（降格标注，三分判别 §3 处置要求）：
- `closed_on_stated_face`：求值规则在已言明面上闭合，零未言明维度命中。
- `computed_with_open_dimensions`：求值规则本身在已言明面上可执行，但存在未建模的未言明维度（其影响未计入）。
- `placeholder_stub`：求值规则本身即占位桩——该路由之正确求值方式未言明，本根以确定性最简路径承接。

**桩纪律（三分判别 §3）**：`futures` 分支与 `linear_underlying` 在阶段A数值重合，`american_option` 分支与 `bs_dividend_yield_closed_form` 在阶段A数值重合（续2续修复订正，O-4：本行为当前态陈述，随改名同步更新；行8/行66/行242为改名记录语境，维持原文不动）。**两处数值重合均不构成语义等价宣称**，亦不构成对期货持有成本、或对早行权溢价之大小/方向的任何断言。

**构造侧核心呈报（按裁决48 §3 订正后口径）**：契约②要求六品种路由，而已言明最小面**对 3/6 品种（`spot`／`spot_etf`／`index`）闭合**；其余三品种（`futures`／`european_option`／`american_option`）各命中至少一项未言明维度。此即45-B1所预期之"留引擎切片撞墙"实况，缺口逐项登记于撞墙清单，未静默收窄品种域。契约②之"覆盖"经裁决48 §3 判**满足**（路由身份在场、六品种实跑全覆盖、SM8变异反证品种域未静默收窄）；闭合度低系45-B1预期形态，非契约②违反。

---

## §4 量纲口径（契约③）

**契约本体＝T-76 schema 原文，指针入包不转写**（45-JP1/B2）：一阶实体_T-76_input_schema_v2_2_20260714.md **行80**。人读辅助件＝QT-002（读法辅助，非规范载体）。

**本实体之口径实现与可证伪化**：五希腊按其偏导定义直接产出，零缩放。断言基线不取自上述源文之人工转抄，而由独立复算路径按偏导定义**独立生成**（verify/independent_recompute.py：delta=∂V/∂S、gamma=∂²V/∂S²、vega=∂V/∂σ、theta=−∂V/∂T、rho=∂V/∂r，T 以年为单位）。量纲断言另附**否定式判别**：若产出为 vega/100、theta/365 或 rho/100 形态，断言应失败——该否定式核验使量纲断言具备区分力而非同义反复。

**续2边界声明（第六希腊，任务包§0/§3）**：q（`dividend_yield`）为定价输入参数，本增强**不新增第六希腊**（无 epsilon＝∂V/∂q）——契约①之5全集（delta/gamma/vega/theta/rho）＋V(t)边界不变，q仅作用于既有5希腊之数值，独立复算侧对应处置为q冻结不参与微分（见independent_recompute.py `_bs_value`签名）。

---

## §5 输出形态声明（裁决39-B，输出形态封闭）

**顶层键集声明**（harness_output.json 顶层键集须**恰等于**下列集合，无未声明键、无静默删键）：

```
OUTPUT_TOPLEVEL_DECLARATION
_data_source
_declaration_ref
route_table
base_valuation
scenario_revaluation
time_shift_revaluation
```

**per-lot 记录键集声明**（`base_valuation` / `scenario_revaluation` / `time_shift_revaluation` 三容器内每条记录）：

```
RECORD_KEY_DECLARATION
lot_id
instrument_class
exercise_style
route_id
computability_status
unstated_dimensions_hit
per_unit
per_lot
early_exercise_premium
lattice_diagnostics
```

**续3新增三键**：
- `exercise_style`：输入面必填字段之回显（§2）。
- **`early_exercise_premium`**（S-1 兑现，KD裁定 A-0 甲结构层类一）：`{per_unit, per_lot}` 两层；**非美式路由取 `null`**。溢价与 V(t) 同施 `side_sign`（§5 缩放式之一致外延，同 V(t) 处置）。
  - **基线口径＝同离散基线**（KD裁定 B-1）：溢价＝同一格点参数下「允许提前行权」与「不允许提前行权」两次倒推之差。**不取欧式闭式解为减数**——跨口径基线将树截断误差混入溢价读数（探针实测：小溢价用例污染 4～9%；恒等零域〔r=0∧q=0 put、q=0 call〕污染 100%，读数全为截断误差）。
  - **不扩展供给物语义类型**：溢价为估值分解量，非第六希腊；契约①之 5全集＋V(t) 边界不变（形态先例＝续2 之 q 不新增 epsilon）。授权源＝撞墙清单 TPL1-T7601-03 缺口描述原文「该结果与欧式结果之差异（早行权溢价）**可被识别**」。
- **`lattice_diagnostics`**：美式路由之离散不变量与格点诊断（`n_exercise_nodes` 提前行权绑定节点计数／`max_exercise_excess` 绑定超出量上界／`european_mode_n_exercise_nodes`／`european_mode_value`／`crr_steps`）；非美式路由取 `null`。
  - **`max_exercise_excess` 为噪声免疫诊断量**（KD裁定 C-1）：恒等零域（早行权恒不优）中，连续值与内在价值可代数恒等，浮点舍入必然触发部分节点绑定——探针实测 r=0∧q=0 put 情形 72960/500500 节点绑定而超出量上界仅 2.84e-14，真实溢价域超出量下界 1.05e-4，分离约 3.7e9 倍。故恒等零检之 F-11 主判据＝**绑定超出量上界 ≤ 声明噪声地板**，「绑定节点数＝0」降为辅助诊断，不作主判据。

**分量键集声明**（`per_unit` 与 `per_lot` 各自，契约①之 5全集＋V(t)）：

```
COMPONENT_KEY_DECLARATION
value
delta
gamma
vega
theta
rho
```

`per_lot` 分量＝`per_unit` 分量 × `multiplier` × `quantity` × `side_sign`（已言明面 T-76 §4 **行76** 之 position 缩放式；**估值 V(t) 同施 side_sign** ——空头持仓估值为负，与 T-24 §4① 之 bleed＝V(t0)−V(t1) 消费面方向一致。此为本根对行76式之一致外延，**呈KD追认**）。

---

## §5.1 计算约定声明面（裁决48-2 兑现；声明-实现一致性断言之判据基线）

本块承载「已在本 schema 内成文、但此前无对应断言」之计算约定，供 `verify/assert_check.py` 程序化解析后对 `entity/engine.py` 与 `verify/independent_recompute.py` **双侧**对表。范围钉死＝裁决48-2 所限定之六例形态（C1／C2／C4／C7／C8b／C10 所违反者），**不扩至情景构造式（C3，维持35-A固有上限口径）**。

```
CONVENTION_DECLARATION
day_count_denominator | 365
side_sign_long | 1
side_sign_short | -1
per_lot_scaling_factors | multiplier,quantity,side_sign
vega_unit | per_1.0_sigma
theta_unit | per_year
rho_unit | per_1.0_r
industry_scaling | none
futures_stub_carry | none
option_identity_routes | bs_dividend_yield_closed_form
linear_identity_routes | linear_underlying,linear_underlying_futures_stub
dividend_yield_field | dividend_yield
dividend_yield_null_classes | spot,spot_etf,index,futures
exercise_style_field | exercise_style
exercise_style_option_values | european,american
exercise_style_null_classes | spot,spot_etf,index,futures
american_route | american_crr_binomial
crr_steps | 500
american_bump_vol | 0.001
american_bump_rate | 0.0001
american_lattice_greeks | delta,gamma,theta
american_bumped_greeks | vega,rho
eep_baseline | same_discretization
american_lattice_fn | _crr_lattice
american_lattice_flag_param | american
american_lattice_steps_param | n_steps
american_lattice_steps_symbol | CRR_STEPS
american_eep_dual_call | am,eu
eep_denominator | european_mode_value
```

**各行之出处与可证伪化形态**：

| 声明行 | 出处 | 断言形态（脚本侧） |
|---|---|---|
| `day_count_denominator` | §6 表行10（ACT/365，**裁决57-6已裁定为阶段A权威口径**——链一致性约束＋规范选择非经验裁定，续2续修复订正；原"占位取值不外推"表述随之更正） | 源级：两侧实现之分母字面量对表；行为级：由产出反解 T（rho 恒等式）再折算分母 |
| `side_sign_long` / `side_sign_short` | §5 缩放式（"空头持仓估值为负"） | 行为级：逐笔 `per_lot ＝ per_unit × multiplier × quantity × side_sign` 双侧核验 |
| `per_lot_scaling_factors` | §5 缩放式（T-76 §4 行76） | 源级：两侧 `scale` 表达式之因子集对表；行为级：同上 |
| `vega_unit` / `theta_unit` / `rho_unit` / `industry_scaling` | §4 量纲口径（契约③，指针锚＝T-76 schema 行80） | 行为级：三条闭式恒等式（见下）双侧核验；另有 A7-b 否定式判别 |
| `futures_stub_carry` | §3 桩纪律（期货分支"不引入任何持有成本或结算约定"） | 行为级：期货路由 per_unit 与标的报价逐笔恒等，五希腊取 (1,0,0,0,0) |
| `dividend_yield_field` | §2 续2新增字段声明（q承接位） | 源级：engine.py／independent_recompute.py 双侧源文含 `dividend_yield` 字段消费（续2 A9-6，见下） |
| `exercise_style_field` / `exercise_style_option_values` / `exercise_style_null_classes` | §2 续3新增字段声明（必填独立字段，KD裁定§6） | 源级：engine.py `STATED_FACE_FIELDS` 与 `EXERCISE_STYLES` 对表；行为级：字段缺位与非法组合两类拒绝路径各有击落例 |
| `american_route` | §3 ROUTE_DECLARATION 第六行 | 源级：`ROUTE_TABLE[("american_option","american")]` 字面对表 |
| `crr_steps` | §6 成分13（类二·缺定义型，KD裁定 A-2/A-2'；**声明值不外推**） | 源级：engine.py `CRR_STEPS` 字面对表；行为级：`lattice_diagnostics.crr_steps` 逐笔回显对表 |
| `american_bump_vol` / `american_bump_rate` | §3 续3订正（vega/rho 之声明步长；数值＝构造自由度，裁决17(a)） | 源级：engine.py 两常量字面对表；**独立复算侧自本声明块解析同值**（被测量本身即「声明步长下之差分导数」，F-11——两路径须比对同一被测量，独立性落在估值引擎而非步长选择） |
| `american_lattice_greeks` / `american_bumped_greeks` | §3 续3订正（KD裁定 D-1） | 源级：engine.py `_eval_american_crr` 之希腊来源对表——delta/gamma/theta 取格点原生、vega/rho 取差分；**spot-bump 差分 gamma 禁用**（探针实测差分 gamma 与格点 gamma 偏离达 11.3 倍〔C1 坐标 0.000774 vs 0.009549〕，成因＝固定 N 下树值对 S 之锯齿） |
| `eep_baseline` | §5 `early_exercise_premium` 口径（KD裁定 B-1） | 行为级：`early_exercise_premium.per_unit` 与 `value − lattice_diagnostics.european_mode_value` 逐笔恒等 |
| `american_lattice_fn` / `american_lattice_flag_param` / `american_lattice_steps_param` / `american_lattice_steps_symbol` / `american_eep_dual_call` | **丙类修复新增（D-1采γ案之α半，裁决76-1(c)）**：同离散基线（KD裁定 B-1）之**源级**可证伪化。立法背景＝外审 M1/M2/M3 三例（欧式模式基线步数 +200／+2／改 BS 闭式解作减数）全数逃逸——`eep_baseline` 之行为级恒等式由 eep 之产出方式定义上恒成立，对减数之**来源**零区分力 | 源级（AST）：`_eval_american_crr` 内绑定 `am`／`eu` 之两次调用须①同为 `american_lattice_fn` 之调用（算法族同一）；②除 `american_lattice_flag_param` 位之 True/False 外**逐实参 AST 等价**（参数同一）；③`american_lattice_steps_param` 位之实参在两次调用中均为 `american_lattice_steps_symbol` 之名引用（步数同一且钉于声明常量）；④`_eep` 之绑定表达式为 `am["value"] − eu["value"]`（减数确由该双调用供给） |
| `eep_denominator` | §7.1 标定方法（**裁决76-9 追认**：eep 之量级界分母＝同坐标欧式模式值，非 EEP 自身） | 行为级：A7-c 之 eep 相对差以 `F11_AUX_COMPONENT_DECLARATION` 声明之分母键取值为分母，非以被测量自身 |

**行为级恒等式（仅施于 `option_identity_routes` 所列路由；模型族依赖经声明面显式限定，不构成对类三成分6之判据级固化）**：

1. `rho = T · (S · delta − V)` ——对 call/put 同式成立，**q≠0时仍恒成立**（q仅经S·delta项之e^(-qT)因子进入，代数消去后rho表达式不含q，推导见续2变更记录）；反解 T 后与 `day_count_denominator` 折算对表，同时钉定 `rho_unit`。
2. `vega = gamma · S² · σ · T` ——钉定 `vega_unit`（若产出为 per 1% 形态则不成立），**q≠0时仍恒成立**（gamma与vega共享同一e^(-qT)·N'(d1)因子结构，比值关系不受q影响）。
3. **（续2推广）** `theta + ½σ²S²·gamma + (r−q)·S·delta − r·V = 0`（含股息收益率之Black-Scholes-Merton偏微分方程，`theta ＝ ∂V/∂t`；q=0时退化至原式）——钉定 `theta_unit`（若产出为按日计则不成立）。q值逐笔取自该lot之`dividend_yield`声明值（非全局常量，与`day_count_denominator`等全局声明行结构不同，故未单列CONVENTION_DECLARATION标量行，改由脚本逐笔读取lot层字段）。

三式为无股息欧式闭式解之解析恒等式（续2：第3式推广为含q形态，第1/2式经代数验证q不改变恒等关系），**属计算约定之可证伪化手段，不构成对定价模型族之选定**（成分6 之类三地位不变；恒等式适用面由 `option_identity_routes` 声明行界定，阶段B 换族时随声明面同步改写）。

**续3订正（`option_identity_routes` 收窄至欧式路由）**：v1.2 该行含 `american_via_european_stub`——彼时美式分支承接欧式闭式解函数，三式自然成立。续3 置换为 CRR 后**三式对美式分支均不成立**，且此为**数学事实非实现缺陷**：行权边界内侧 V＝内在价值，BSM-PDE 不成立；格点原生希腊本身为离散近似，非解析偏导。L07 坐标实测：

| 恒等式 | 欧式分支 | 美式 CRR 分支 |
|---|---|---|
| `rho = T·(S·delta − V)` | 成立（子口径(b)内） | 相对差 **2.742e-01** |
| `vega = gamma·S²·σ·T` | 成立（子口径(b)内） | 相对差 **6.392e-02** |
| BSM-PDE 残差 | **2.33e-15** | **−3.74e-4** |

故本行收窄。美式分支之量纲与口径钉定改走三条替代判据：①`american_lattice_greeks`／`american_bumped_greeks` 之源级对表（希腊来源声明-实现一致）；②独立分叉路径（FD＋PSOR）之量级对照（F-11 框架，界值逐对象标定）；③`eep_baseline` 行为级恒等（溢价＝值 − 欧式模式值，逐笔精确）。**收窄系声明面随实现同步（该行原文已预留「阶段B 换族时随声明面同步改写」之机制），非新造判据、非放宽判据**。

---

## §6 三分判别套用全表（裁决21(a)受控文本 v1.1；双重引用纪律遵行）

前置分流（数据/机制刀口）：`scenario_shock` 幅度值（−5%、+3 vol pts）、`time_shift.days_forward`、以及全部 S/K/σ/r/持仓明细取值＝**数据**（人造input构造自由度，裁决17(a)口径），不入三分。

| # | 计算成分 | 判别 | 实质依据（双重引用之实质侧） | 处置 |
|---|---|---|---|---|
| 1 | 品种路由结构（按品种选取求值路径） | **类一** | 缺口描述原文"按品种（现货/现货ETF/期货/指数/欧式/美式期权）路由适用定价模型"（撞墙清单_T-76 v2.3）＋契约②（裁决45 §5） | 定案写入实现，非桩 |
| 2 | 供给物语义类型（5全集raw Greeks＋V(t)） | **类一** | 契约①（45-IC4/45-IC2） | 定案写入实现 |
| 3 | raw 量纲口径 | **类一** | 契约③；原文锚＝T-76 schema 行80（指针） | 定案写入实现 |
| 4 | per_lot 缩放式（×multiplier×quantity×side_sign） | **类一**（结构） | 已言明面 T-76 §4 **行76** | 定案；V(t) 同施 side_sign 之外延呈KD追认 |
| 5 | 线性标的求值规则（V＝标的报价，Δ=1，其余为0） | **类一（条件性定案）** | **条件＝零持有成本占位下之恒等映射**。在该条件下无模型自由度；查过：缺口描述原文、契约六条、审计表行94/95——均未与恒等映射矛盾。`rho=0`／`theta=0` 系该占位条件之直接后果，**非对成分7 之独立处置**，故与成分7 之类二登记无层次交叉（Q-13 订正，裁决48 §3） | 定案写入实现；条件由成分7（类二）承载，成分7 闭合时本行随之复核 |
| 6 | **定价模型族选型**（欧式分支之标的动力学假设：GBM闭式解 vs 其他） | **类三** | 类一测试判"裁不了"：查过契约六条、缺口描述原文、翻译审计表「宪-EP-05 定价模型批判」行（不授权栏：不禁用BSM类模型作仪表计算器/换算工具——**许可而非选定**）、「宪-EP-06 定价认识论」行（派生量＝观测仪表）；全候选与全部权威文本相容（**丙类修复订正 D-5采β形态**：弃行号锚改词锚，两词锚在审计表内各唯一） | 阶段A跑具体版本＝无股息BS闭式解，**候选之一，声明值不外推，待阶段B以回测/实盘数据证伪**；不留白 |
| 7a | **股息/持有成本维度·线性持仓分量** | **类一（已裁）** | 裁决52-2①：范围裁定不建模（现金流直达账户、量级微小、不进凸性机制） | 定案不建模；TPL1-T7601-01该分量已闭合（续2订正，原7号行拆分之一） |
| 7b | **股息/持有成本维度·期权定价q分量** | **类一（已裁，属类三成分6之GBM闭式解族内参数化）** | 裁决52-2②：明示"期权定价q分量＝待建实质（欧式分支引入q）"，q承接方式本身经KD直接指定，非构造会话之类三判断 | 定案写入实现＝连续股息收益率q（BSM-with-q）；TPL1-T7601-01该分量续2构造完成候选，闭合与否待外审+KD（续2订正，原7号行拆分之二） |
| 8 | **期货结算/保证金形态** | **类二·缺定义型** | 45-B1 明列 | 确定性占位＝恒等承接（不引入持有成本）；模板一登记 TPL1-T7601-02 |
| 9 | **美式早行权定价**（续3 兑现后之三层拆分，KD裁定 A-0） | **甲·结构层类一 ∪ 乙·算法族类三（TPL3-T7601-02）∪ 丙·步数N类二·缺定义型（PROBE-02）** | **甲**＝TPL1-T7601-03 缺口描述原文"该结果与欧式结果之差异（早行权溢价）**可被识别**"排除欧式闭式解承接候选，结构层无自由度 → 类一；**乙**＝算法族（BSM近似/BAW/CRR/其他）之类一测试判"裁不了"（查过：契约六条、缺口描述原文、45-B1、翻译审计表「宪-EP-05 定价模型批判」「宪-EP-06 定价认识论」两行，全候选与全部权威文本相容），类二测试**亦不成立**——引擎自身即终端供给方，再挂类二则供给方栏只能填"引擎自身之未来版本"而本版正是该版，构成自指循环、条目永不销项 → 类三；**丙**＝步数 N 之供给方＝消费方之精度要求（node级/腿级聚合尚未提出精度要求），N→∞ 极限良定义、收敛性阶段A 可自证，不需经验数据裁定 → 类二·缺定义型 | **甲**定案写入实现（CRR 逐节点提前行权判定，非桩）；**乙**阶段A 跑具体版本＝CRR 二叉树，候选之一，声明值不外推，待阶段B 证伪，登记 **TPL3-T7601-02**；**丙**声明值＝500，声明值不外推，登记 **PROBE-02**。〔**丙类修复订正 D-1／76-1(d)7**：本行原为 v1.2 之"类二·缺实现型／确定性占位＝欧式闭式解路径承接"旧文，与 v1.3 实况及文首头注⑤、切片记录 §3 直接矛盾——表体未随头注同批更新（外审 B-23 未检出，G9-03）；本次订正使三方一致〕 |
| 10 | **day count 约定**（T＝dte/分母） | **类二·缺定义型** | 45-B1 明列；约定属规范选择，非经验裁定，故非类三（**裁决57-6重申此定性**） | **裁决57-6已裁定＝ACT/365（候选A）为阶段A权威口径**（依据：链一致性约束——六根声明值＋T-76桩三处365程序化核证一致，A为唯一不触发下游约定维度重验之选项；规范选择非经验裁定）。`DAY_COUNT_DENOMINATOR`＝365现升格为权威值，非占位桩；模板一登记 TPL1-T7601-04。候选C（交易日历口径）之双时钟结构论点转TPL1-T7601-04留痕注记，归Phase B精化域（见随附撞墙清单候选写回件；§10.3三案分析转历史留痕，见下）。**TPL1-T7601-04条目本身之状态字段闭合与否仍随续2收口裁定落写，本次schema订正不预判该条目状态**（裁决57 §3既定窗口） |
| 11 | dte 整数天口径（(expiry−valuation_date).days） | **类一** | T-76 schema §3 已言明口径 | 定案写入实现 |
| 12 | IV 之输入身份（市场报价坐标 vs 模型派生量） | **类一** | 翻译审计表「宪-EP-06 定价认识论」行（IV作为市场报价的坐标仍可读，被否定的是其模型本体论地位；**丙类修复订正 D-5采β形态**：弃行号锚改词锚） | 定案：可作输入；**呈KD**——缺口描述原文之行情枚举（价格、期限、到期日、bid/ask、类型等）未列IV，边界确认请KD追认 |
| 13 | **CRR 步数 N**（离散化精度参数） | **类二·缺定义型** | 供给方＝消费方之精度要求；node 级聚合（T-76）与腿级聚合（GK-31）尚未提出精度要求，故供给方在场但尚未发声。**非类三**——N→∞ 极限良定义、收敛性在阶段A 可自证（收敛研究随 `verify/` 交付），不需经验数据裁定 | 阶段A 声明值＝500，**声明值不外推**；登记 **PROBE-02**（模板一）。成分9 之丙层同指，本行为其独立列示（丙类修复补行，76-1(d)7） |
| 14 | **离散分红形态**（真实离散现金分红 vs 连续 q 近似） | **类三·阶段B校准项** | 本分支之 q 为连续股息收益率；真实 equity/ETF 分红为离散现金事件，美式提前行权之最优时点由离散除息事件驱动，连续 q 将其抹平。该近似之充分性只能由实盘/回测判定（KD裁定 A-3） | 阶段A 维持连续 q，登记 **TPL3-T7601-03**；TPL1-T7601-01 之闭合（裁决58）字面限定于欧式分支，本行不翻转其闭合。成分9 之乙层同域但非同项（乙＝算法族选型，本行＝分红事件形态），故独立列行（丙类修复补行，76-1(d)7） |

**否定结论义务留痕**（受控文本 §2）：成分6之类一测试判"裁不了"，已查文本见上表；成分8/9/10之类一测试同判"裁不了"（查过：契约六条、缺口描述原文、45-B1条款、翻译审计表「宪-EP-05 定价模型批判」「宪-EP-06 定价认识论」「宪-ID-02 身份与假设分离」三行；**丙类修复订正 D-5采β形态**：弃行号锚改词锚），进类二测试后指向待建供给方/待裁定义。

**丙类修复扩展（76-1(d)7，成分9 之乙/丙层与成分13/14）**：
- **成分9乙（算法族，TPL3-T7601-02）**：类一测试判"裁不了"（查过文本同上表成分9栏）；类二测试**不成立**（自指循环，见上表）；故落类三。
- **成分9丙／成分13（步数 N，PROBE-02）**：类一测试判"裁不了"（权威文本无任何步数规定）；类二测试**成立**——供给方＝消费方之精度要求，消费方（node级/腿级聚合）在场但尚未发声，非自指；故落类二·缺定义型，**不落类三**（收敛性阶段A 可自证，不需经验数据）。
- **成分14（离散分红形态，TPL3-T7601-03）**：类一测试判"裁不了"；类二测试不成立（无待建供给方可挂——分红事件形态之充分性判据本身须经验数据）；故落类三。
- **"或逻辑"半补测留痕（裁决75-1 订正后口径，76-1(d)8）**：类三之否定结论须同时留"文本半"（全候选与权威文本相容）与"或逻辑半"（**有无逻辑排除**）。逐条实查见 §11.3。成分7a/7b（原成分7拆分）已由裁决52-2直接裁定，不再落"裁不了"之类一测试路径——7a定案不建模，7b定案写入实现，均为KD既裁事项，非本根类一/二/三判别程序之产物（续2订正）。

---

## §7 容差口径与成分级分派（裁决13/19 ＋ QT-001）

- 子口径(a) 离散/精确有理计算＝**bit-exact（diff=0）**（裁决13）。
- 子口径(b) 连续解析计算（超越函数路径）＝**相对 diff ≤ 1e-12**（裁决19）。
- **QT-001 成分级（非族级）分派**（期权波动率工程笔记 v1.2 行19/26，裁决34-F2）：分派作用于数值成分本身，非计算上下文。本根实况：`linear_underlying` / `linear_underlying_futures_stub` 路由之全部12分量（per_unit＋per_lot）落 (a)，与期权路由分量同处三容器之内，仍逐分量按 (a) 比对；`bs_dividend_yield_closed_form` 路由分量落 (b)。
- **续3新增：`american_crr_binomial` 路由分量落 F-11**（声明离散近似量框架，非 (a)/(b)）——被测量本身为「声明步数 N 下之格点值」与「声明步长下之差分导数」，非精确数学量，两条独立路径比对的对象不是同一精确量，1e-12 量级无从谈起（F-11 原文）。

### §7.1 F-11 分派（美式路由；续3新增）

**主判据＝离散不变量零容差**（符号/计数/事件类派生量，双侧各自成立）：

```
F11_INVARIANT_DECLARATION
eep_nonnegative | 早行权溢价 >= 0（美式价值不低于同离散欧式价值）
value_ge_intrinsic | 估值 >= 内在价值（可提前行权合约之下界）
european_mode_zero_binding | 欧式模式下提前行权绑定/投影事件计数 == 0
eep_equals_same_disc_difference | 溢价 == 值 − 同离散欧式模式值（逐笔精确）
```

**辅助＝量级诊断界**（被测侧 CRR 二叉树 vs 独立分叉侧 Crank-Nicolson FD＋PSOR 之逐分量相对差上界）：

```
F11_BOUND_DECLARATION
value | 2.0e-3 | 相对被测量本身
delta | 1.0e-3 | 相对被测量本身
gamma | 5.0e-3 | 相对被测量本身
vega | 1.0e-1 | 相对被测量本身
theta | 1.0e-2 | 相对被测量本身
rho | 2.0e-2 | 相对被测量本身
eep | 9.0e-4 | 相对同坐标欧式模式值
european_mode_value | 2.0e-3 | 相对被测量本身
```

**辅助分量之取值路径与分母声明（丙类修复新增，D-1采γ案之β半 ＋ D-2；裁决76-1(c)／76-9）**：

`eep` 与 `european_mode_value` 不在 `COMPONENT_KEY_DECLARATION`（契约①之 5全集＋V(t) 边界不变，溢价为估值分解量非第六希腊——§5 既有声明不翻转），故主比对循环（按 `COMPONENT_KEY_DECLARATION` 遍历 `per_unit`/`per_lot`）不覆盖之。本块声明其在两侧产物内之取值路径与相对差分母，供 `verify/assert_check.py` 之 **A7-c 辅助分量跨路径比对**消费；`F11_BOUND_DECLARATION` 与比对循环实际消费分量集之**双向对表**由 **A7-d** 承载（F-7 形态移用于容差域，裁决76-1(c)）。

```
F11_AUX_COMPONENT_DECLARATION
eep | early_exercise_premium.per_unit | early_exercise_premium.per_unit | european_mode_value
european_mode_value | lattice_diagnostics.european_mode_value | fd_diagnostics.european_mode_value | self
```

列义＝分量键 ｜ 被测侧取值路径（`entity/harness_output.json` 记录内点分路径）｜ 独立侧取值路径（`verify/independent_expected.json` 记录内点分路径）｜ 相对差分母（`self` ＝被测量自身；否则为本块另一分量键之**独立侧**取值，即 `eep` 之分母＝同坐标欧式模式值，**裁决76-9 追认**）。

**立法背景（外审 D-1／D-2）**：此前 A7 遍历六分量共 288 项，`eep` 零次出现、`european_mode_value` 不在任何比对面——`F11_BOUND_DECLARATION` 已载 eep 界值 9.0e-4 而全包无消费点（声明有判据、实现无消费点之落差）；且替代判据③（`eep_baseline` 行为级恒等）在"换减数来源"型注入下定义上恒成立（M1/M2/M3 全逃逸）。本块与 A7-c/A7-d 补此两处消费点；**减数来源之钉定由 A17 源级断言承载**（本块之数值比对对同族小步数偏移无区分力，如实声明，不以数值面冒充源级面之效力）。

**标定依据（F-11 之「逐对象独立标定，禁跨阶数/跨对象沿用」）**：留痕件＝`verify/tolerance_calibration.json`（10 例人造标定网格，宽于实跑用例集之单一美式 lot，覆盖实值/平值/虚值 × 短期/长期 × 低波/高波 × q=0/q>0）。界值＝实测上界 × 3 安全边际，向上取 1 位有效数字（×3 形态先例＝裁决13 之「测量派生非惯例值」口径）。实测上界：value 4.21e-4／delta 3.27e-4／gamma 1.55e-3／vega 3.28e-2／theta 3.26e-3／rho 3.63e-3／eep 2.70e-4／**european_mode_value 5.45e-4**（丙类修复新增分量，同网格同方法实测；其余七项界值经重跑逐位复现，零变动）。

**两项标定方法之呈KD追认**：

1. **`eep` 之分母＝同坐标欧式模式值，非 EEP 自身**。EEP 为**差值型输出**，以自身为分母时 cancellation 放大相对误差——形态先例＝T-24 之 `bleed = V(t0) − V(t1)`（REG-T24-01 回传 → 裁决19 上调锚定值）。实测：以自身为分母之上界 3.77e-2（由小溢价坐标主导，G04 溢价仅 0.0075），以欧式模式值为分母之上界 2.70e-4。**决定性理由为区分力而非数值观感**：两路径之绝对偏差随期权价值标度（CRR 截断误差之自然量纲）而非随溢价大小标度，故以自身为分母之界 2e-1 会允许大溢价坐标（G06 溢价 1.05）偏差达 0.21 而放行，换分母后同一偏差为 1.75e-2 ≫ 9e-4 即时击落。F-11 规定界值「逐对象独立标定」但未固定分母，分母选择属标定方法。
2. **vega 之声明步长维持 1e-3，不因界宽而增大**。实测增大至 3e-2 虽使两路径相对差降至 ≤1e-3，但两侧同时因曲率截断偏离真 vega（G08 坐标 CRR 偏真值 1.8e-2）——属**共模误差制造之虚假一致**，恰为 F-2 判别据（改写后是否仍共享同一失效模式）之反面情形。维持小步长使路径差如实反映格点锯齿误差（CRR 值随 σ 呈分段光滑，小步长测得段内斜率而非真导数），判据区分力不失。vega 界因而宽（1e-1），此为诚实之宽，非放宽。

---

## §8 缺口引用与登记指针

本体缺口 TPL1-T76-01（撞墙清单_T-76 v2.3 行12–24，open）＝本切片对象自身，引用不重登。构造中新撞四条（TPL1-T7601-01～04）登记于 `撞墙清单_TPL1-T76-01引擎_v1_0_20260730.md`，模板一。DOC-11 随行注记：估值输出 V(t) 已在1级契约（45-IC2），清单缺口描述非范围上限。

---

## §8.1 外置数据件完整性声明（D-4 兑现，裁决48 §4；续2续修复扩容至F-5全射程，D-3封堵）

`verify/scan_patterns.json` 承载 step0(ii) 之数据源关键词集与 bare-import 正则、A6 之宣称模式集/否定标记集/窗口参数。该件按构造排除于扫描面（否则模式表逐条自命中），其内容此前不受任何断言约束（外审 S7 实证：删关键词后 step0(ii) 仍全绿）。

**处置＝指纹断言钉定**（裁决48 §4 二选一之后者）。指纹值载于本声明面而非脚本内常量，以维持"判据基线一律程序化解析自本包内源文件、零人工转抄常量"之既有形态（避免新增写死常量，Q-8 张力不加剧）。

**续2续修复新增（D-3封堵，F-5宽读，裁决48-4先例延伸）**：`verify/baseline_v1_1_reference.json`——S-1a/S-1b全部判据基线之**唯一外部锚**，续2构造时零指纹、零声明面约束（外审B01实证：该件可被静默改写而整链绿灯）。现同样纳入本声明面钉定，与`scan_patterns.json`同一机制（`verify/assert_check.py` step0(ii-b) 之钉定核验循环为通用形态，逐行遍历本声明块，新增行无需另行改动断言脚本）。指纹钉定值＝续2交付包内该件现值（经《底版对照补充核证》§1-1 bit级核证与v1.1原始`entity/harness_output.json`同一）。

```
DETECTOR_FINGERPRINT_DECLARATION
verify/scan_patterns.json | sha256 | f17de0f5544f377daba514e690aa347a6a37f5c20c12746f507f9a0555ebc74c
verify/baseline_v1_1_reference.json | sha256 | bf743fd95072ad55e62cfc3707978a77b7425e16c6b5d39be2805da5348bc055
verify/baseline_v1_2_reference.json | sha256 | b871be922d17503150f50677a7c4c6beaf6a45d5efc0cb29d4f36e4a66605711
verify/tolerance_calibration.json | sha256 | 6bfe01e8a5550d8bbb8359b091ab131c4286cff4f0ccb7daba40a75bdca7faf7
verify/build_provenance.json | sha256 | b6b3d42b99a8bd1272c9263816149a697bf1f558b7c01d0e848911e3e987e7cf
```

**续3新增三件（钉定射程扩容）**：

1. **`verify/baseline_v1_2_reference.json`**（S-2 零判定翻转之基线件）——内容＝续2 v1.2 交付包之 `entity/harness_output.json` 原件（其 SHA256 已载于《切片记录_续2 v1.2》指纹表，可跨件互证来源）。该件为「续3 是否扰动既有分支」之唯一对照源，属判据基线，纳入双钉。
2. **`verify/tolerance_calibration.json`**（F-11 界值之标定依据留痕件）——§7.1 `F11_BOUND_DECLARATION` 之界值由本件实测上界派生；本件可被静默改写则界值来源失据，纳入双钉。
3. **`verify/build_provenance.json`**（新鲜度钉定件自身）——**E-1' 存量封堵兑现**（裁决71-10 落点＝引擎 v1.3 再版窗口；F-8 原文「新鲜度或来源核验机制之钉定件自身须入双钉射程」）。此前该件仅由 `build_provenance.py` 单通道生成、无任何外部锚，攻击者改 `engine.py` 后不重跑产物、仅重新生成钉定件即可致 A10 全绿（续2 增量复核实证 44/44 PASS）。纳入本声明面后，其正当再版须同批改写本声明行，改写动作落入人读可见面，单通道重生成即失配 FAIL。

以上两件内容任何变动（含删关键词、放宽正则、缩小窗口；或静默改写baseline基准值）均使对应指纹失配而 FAIL；两件之正当再版均须同批改写本声明行，改写动作因而落入人读可见面。

---

## §9 数据源纪律声明（契约⑤）

`entity/` 与 `verify/` 全部代码零网络、零行情接口、零外部数据源读取；输入面仅消费行情类字段与持仓静态属性，Greeks 与估值一律自算。输入记录中不存在任何 vendor Greeks / 理论价字段（断言可证伪：输入键集与 vendor 派生量键名集之交为空）。

---

## §10 续2·引擎求值口径增强（新增独立小节）

### §10.1 变更范围摘要

**入范围（已建成，本次交付）**：
- 欧式分支（`european_option`路由）引入连续股息收益率q，闭式解由无股息BS推广为BSM-with-q。
- `unstated_dimensions_hit`路由声明兑现：`european_option`/`american_option`两路由去标`dividend_carry`。
- route_id改名：`bs_no_dividend_closed_form`→`bs_dividend_yield_closed_form`。
- 新增已言明字段`dividend_yield`（q承接位），期权lot取人造声明值，线性/期货lot退化null。

**不入范围（维持open，本次不宣称覆盖）**：
- 线性持仓分红分量（裁决52-2①已裁不建模，永久性范围排除，非本切片对象）。
- TPL1-T7601-02（期货结算/保证金形态）——futures路由零改动。
- TPL1-T7601-03（美式早行权）——美式桩虽因承接欧式分支而消费q，但早行权溢价仍未建模，不构成闭合宣称。
- TPL1-T7601-04（day count分母口径）——**已裁**：裁决57-6＝ACT/365阶段A权威口径（§10.3裁定结果补记），`DAY_COUNT_DENOMINATOR`＝365为权威值非占位桩；条目闭合落写＝裁决58（撞墙清单引擎v1.3，含候选C留痕注记）。
- 契约文本（TPL3-T7601-01/模块划分M1）之再版——归Q-c裁定（任务包§6），本文件不预裁。

### §10.2 恒等式q-不变性代数验证要点（供人工复核，非新增断言机制，验证结论已由verify/assert_check.py之A9-1/A9-2实跑确认）

设欧式call：`V = S·e^(-qT)·N(d1) − K·e^(-rT)·N(d2)`，`delta = e^(-qT)·N(d1)`。

- **rho恒等式**：`S·delta − V = S·e^(-qT)N(d1) − [S·e^(-qT)N(d1) − K·e^(-rT)N(d2)] = K·e^(-rT)N(d2)`。而`rho = K·T·e^(-rT)N(d2)`，故`T·(S·delta−V) = rho`恒成立，与q无关（q项在S·delta与V之差中相互抵消）。put侧同理可验（符号对应）。
- **vega恒等式**：`gamma = e^(-qT)N'(d1)/(Sσ√T)`，`vega = S·e^(-qT)N'(d1)√T`。`gamma·S²σT = [e^(-qT)N'(d1)/(Sσ√T)]·S²σT = S·e^(-qT)N'(d1)√T = vega`，两者共享同一`e^(-qT)N'(d1)`因子结构，比值关系不受q影响，恒成立。
- **BS-PDE恒等式**：标的支付连续股息率q时之偏微分方程为`∂V/∂t + ½σ²S²Γ + (r−q)SΔ − rV = 0`；本根`theta=∂V/∂t`（calendar time forward，`t=−T+const`故`∂/∂t=−∂/∂T`），代入即`theta + ½σ²S²γ + (r−q)Sδ − rV = 0`。q=0时退化至增强前形态。

三式经`verify/assert_check.py`之A9-1/A9-2/A9-3三断言（q版本）**双侧实跑验证通过**（engine.py解析式 vs independent_recompute.py数值微分式，逐笔逐容器），非仅纸面推导。

### §10.3 day count分母口径候选（历史留痕，任务包§6.2；**裁决57-6已裁定，本节转历史依据**）

**裁定结果（续2续修复补记）**：裁决57-6＝**候选A（ACT/365）为阶段A权威口径**（依据：链一致性约束——六根声明值与T-76桩三处365程序化核证一致，A为唯一不触发下游约定维度重验之选项；规范选择非经验裁定）。`DAY_COUNT_DENOMINATOR`＝365现为权威值，非占位桩（见§5.1/§6行10同步订正）。**候选C（交易日历口径）之双时钟结构论点转TPL1-T7601-04留痕注记，归Phase B精化域**（候选C原始论述见随附撞墙清单候选写回_v1.1文件之TPL1-T7601-04节）。以下三案分析为决策历史依据，转历史留痕保留，不再是待裁开放项：

| 候选 | 分母/口径 | 优点 | 局限 | 与现桩关系 |
|---|---|---|---|---|
| **A·ACT/365（维持现桩）** | 365（日历日） | 与T-76 §4桩既有取值一致，避免跨artifact口径不一致；权益类期权定价之常见惯例分母之一；实现零改动 | 隐含"周末亦累积方差/时间价值衰减"之假设，与"波动率主要在交易日实现"之经验观察存在张力（该张力为期权定价惯例长期存在之简化，非本引擎独有） | 零改动，风险最低 |
| **B·ACT/360** | 360（货币市场惯例分母） | 与利率/货币市场惯例（r之常见报价分母）对齐 | 权益类期权定价惯例上较少见此分母，与T-76 §4现桩不一致，需评估是否引入新跨文档不一致 | 需修改`DAY_COUNT_DENOMINATOR`+连带T-76 §4桩重新评估 |
| **C·交易日历口径（如T_trading/252）** | 252（或逐年交易日数） | 消除日历日模型隐含之"周末新增方差"假设，部分波动率交易台惯例做法 | 本质上要求"方差时间"（交易日）与"折现时间"（日历日）分设两把时钟（r、q之折现仍应按日历时间累积）——单一T之BSM闭式解无法承载双时钟结构，采用此候选等于要求比"改分母"更大幅度之模型结构调整，超出本切片"求值口径参数增强"之范围（任务包§2.3边界） | 非单纯分母替换，需模型结构层调整，工作量与范围均超出续2既定边界 |

**构造侧原建议候选（历史留痕）**：候选A（维持现桩）——理由：(1)零改动，(2)与T-76 §4既有桩取值保持跨文档一致，避免新增不一致面，(3)候选C之技术实质超出"day count分母口径"参数调整范畴。**KD裁定结果（57-6）与构造侧建议一致**：候选A裁为权威口径；候选C转TPL1-T7601-04留痕注记归Phase B精化域，未另行登记为独立后续对象（是否登记留待Phase B实际到达该精化域时再议）。

### §10.4 TPL条目状态候选写回（任务包§6.3，构造会话呈候选文本不直接改撞墙清单）

- **TPL1-T7601-01（q分量侧）**候选状态文本：`构造中` → `已建候选，待外审确认闭合`（先例＝分量闭合均经裁决落写，本次不自宣闭合）。
- **TPL1-T7601-04**候选状态文本：维持`构造中`（续2续修复订正：day count口径本身已经裁决57-6裁定为ACT/365权威口径，**理由随之更新为**——条目状态字段之闭合落写归续2收口裁定会话同批动作〔裁决57 §3既定窗口〕，本轮修复不预写该字段，非因口径本身仍待裁）。

### §10.5 冲突登记留痕（续2续修复补记，D-1(b)纪律面销项，裁决57-4承接）

**背景**：外审D-1核证——任务包§3判据(i)（"断言基线须程序化解析撞墙清单v1.2之TPL1-T7601-01/04条目锚定词在场，载体不可定位即判不通过、禁内嵌副本回退"）与手册v1.5 §3.1〔乙-3，W-13(6)〕（"交付包不自带源文副本"）及本根经裁决49收口之包自足形态（`assert_check.py` docstring明文"包自足：不读取 `/mnt/project/` 或任何包外路径"）正面冲突——在包自足前提下，撞墙清单锚定词物理上不可被包内断言解析。

**原纪律违反（D-1(b)）**：续2构造会话事实上按乙-3/包自足一侧执行（判据基线100%取自包内`input_schema.md`声明块），但未走登记占位（G-3/模板一二三），切片记录、撞墙清单候选写回、本schema原§10均无该冲突之任何记载——即"撞到任务包判据 vs 既裁自足性纪律之冲突而静默择一执行、未登记"，独立于(a)面（判据(i)字面未兑现）之违纪成立。

**裁定承接（裁决57-4，分域读法）**：判据(i)之外部程序化解析义务，适用范围按判据源性质分域——审计域源文档为判据源之情形（如T3-22型对象），28-B(i)不变，义务照旧；判据源为治理台账/TPL登记者之情形（引擎型，本根即属此类），承接形态＝schema锚定词转录＋外审人读对表，包自足形态维持不变。任务包§3(i)文本按此更正解读，两类根现行形态各自成立。(a)面过错（判据(i)未兑现）归因移位至任务包生成环节（裁决台产物，自涉）；(b)面（冲突未登记）维持纪律面成立，**本次补记即为该面之销项动作**。

**本条目性质**：留痕记录，非新增判据、非新增缺口（G-3口径：本条目为既发生冲突之补充登记，非新撞到之缺口）。同一记录同批并入切片记录v1.1本根裁定登记增量。

---

## §11 续3丙类修复·变更范围与不入范围（新增独立小节；R-B3／D-6 之 §11 半，76-1(d)3）

### §11.1 入范围（权威枚举＝裁决76-1(c)(d)＋76-3＋76-4／76-6／76-7；超出即超范围缺陷候选）

| 项 | 落写面 |
|---|---|
| R-A1 · D-1采γ案 | §5.1 新增 `american_lattice_fn`／`american_lattice_flag_param`／`american_lattice_steps_param`／`american_lattice_steps_symbol`／`american_eep_dual_call` 五行；§7.1 新增 `F11_AUX_COMPONENT_DECLARATION` 与 `european_mode_value` 界值；断言侧 **A17**（源级同源双调用参数同一性）＋ **A7-c**（辅助分量跨路径比对） |
| R-A2 · D-2 | `early_exercise_premium` 与 `european_mode_value` 补消费点（A7-c）；`F11_BOUND_DECLARATION` ↔ 比对循环分量集**双向对表**（**A7-d**，F-7 形态移用于容差域）；eep 分母＝同坐标欧式模式值（`eep_denominator` 声明行，裁决76-9 追认） |
| R-A3 · D-3采α案 | `verify/probe_input.json` 与 `verify/probe_american.py` 之 `_lot_from_case` 补 `exercise_style`，恢复交付形态零修改可重跑 |
| R-B1～R-B8 | 机械八项（engine 行34 订正／行号锚改词锚六处／本 §11 与下边界五条／异常通道归因行／头注历史标注／施工侧模型档申报字段／§6 表体订正／"或逻辑"半补测，见 §11.3） |
| R-C · 用例面扩充（76-3） | `entity/input_data.json` 新增 **L09**（american **call**·**long**）与 **L10**（american put·**short**），使 call/put 轴与 side_sign 轴入合格判定面比对域 |

### §11.2 不入范围（本窗零触碰，如实声明）

- **算法族与步数之声明值**：CRR／N=500 维持不动（类三 TPL3-T7601-02 与类二 PROBE-02 既裁，声明值不外推）。
- **`instrument_class` 值域**、六品种域、路由二元组结构：零触碰。
- **既有欧式／q／day count 分支之求值规则与产出数值**：零触碰（S-2 机械承载，非文本承诺）。
- **契约①之分量边界**：`COMPONENT_KEY_DECLARATION` 维持 5全集＋V(t) 不变——`eep`／`european_mode_value` 以**辅助分量声明块**入比对面，不入契约①分量集。〔**呈报项**：裁决76-1(c) 原文为"`european_mode_value` 纳入 `DECL_COMPONENT` 跨路径比对"；字面加入 `COMPONENT_KEY_DECLARATION` 将击落既有断言 A2／A1-c 并翻转 §5「溢价为估值分解量、非第六希腊、契约①边界不变」之声明——属契约面判定翻转，超出修复会话权限。本会话按"纳入**由 `DECL_COMPONENT` 驱动之**跨路径比对面"读法执行，**此为施工侧读法采用，非裁定**，呈增量复核与四3收口裁决台核证〕
- **他根产物**：FW-03-甲清单、下游根任何文件，零触碰（脱版注记＝DOC-31，消费面＝DOC-32）。
- **底版续2 v1.2 包**：零改动。

### §11.3 类三"或逻辑"半补测留痕（76-1(d)8；判据＝受控文本 §4 判别测试全文，裁决75-1 订正后口径）

判别测试原文＝"有无任何已有文本**或逻辑**能排除某候选？全否→类三"。此前两条类三之否定结论仅留**文本半**（"全候选与全部权威文本相容"），未留"或逻辑"半。本次逐条实查：

**TPL3-T7601-02（美式算法族选型）**——候选面＝BSM类近似／BAW／CRR 二叉树／有限差分＋PSOR／LSM 蒙特卡洛／其他。逐候选查逻辑排除：

| 排除论证候选 | 实查结论 |
|---|---|
| KD裁定 B-1「不取欧式闭式解为减数」是否排除**闭式近似族**（BAW 等，其溢价项天然以欧式闭式解为减数） | **不成立为族级排除**——B-1 之立法理由原文为"跨口径基线会把**树截断误差**混入溢价读数"，射程系格点族之跨口径问题；闭式族无离散化，同族减数即闭式解本身，B-1 之立法目的不bite。**惟须呈报**：该"全否"结论条件于 B-1 读作**实现面**（现行 CRR 分支之基线口径）而非**族面**（跨族恒定禁令）；两读法之择定非修复会话可自决——呈KD |
| `F11_INVARIANT_DECLARATION` 之 `eep_nonnegative` 零容差是否排除 **LSM 蒙特卡洛**（抽样噪声下溢价估计可为负） | **不成立**——该声明块系续3 实现面声明，§5.1 既载"阶段B 换族时随声明面同步改写"机制，非族独立权威 |
| `american_lattice_greeks`（格点原生希腊）是否排除**非格点族** | **不成立**——同上，实现面声明 |
| 缺口描述原文"差异（早行权溢价）可被识别"是否排除某族 | **不成立**——全部候选族均可产出可识别之溢价量 |

**结论：全否（无逻辑排除成立）→ 类三维持**，仅留痕升级为"文本半＋或逻辑半"双留痕。**附条件呈报项**见上表第一行。

**TPL3-T7601-03（离散分红承接形态）**——候选面＝连续 q 近似（现行）／离散现金分红（escrowed 或 spot 减分红现值）／离散比例分红（除息日按比例缩放）／混合形态。逐候选查与 schema 既有功能声明之矛盾：

| 既有功能声明 | 与候选之矛盾实查 |
|---|---|
| §2 已言明最小面仅含标量 `dividend_yield`，无分红时间表字段 | **非排除**——离散形态需新增已言明字段（承接位），属 45-B1 未言明维度之后续承接问题，非逻辑矛盾；缺承接位是**前置条件**不是**排除** |
| §5 `early_exercise_premium` 同离散基线（B-1） | **无矛盾**——离散分红在同一格点下同样可作"允许／不允许提前行权"双倒推 |
| §7.1 `european_mode_zero_binding`／`value_ge_intrinsic` 零容差不变量 | **无矛盾**——两不变量对离散分红形态同样成立 |
| §4 raw 量纲、零行业缩放（契约③） | **无矛盾**——量纲面与分红形态正交 |
| §1 下边界第5条「不接任何数据源」 | **无矛盾**——分红时间表若引入，为已言明面输入字段（人造声明值），非数据源接入 |

**结论：全否（无逻辑排除）→ 类三维持**，双留痕已足。**留痕注记**：离散形态之实施须先扩已言明面（分红时间表承接位），该前置条件随条目留痕，不改变类三定性。

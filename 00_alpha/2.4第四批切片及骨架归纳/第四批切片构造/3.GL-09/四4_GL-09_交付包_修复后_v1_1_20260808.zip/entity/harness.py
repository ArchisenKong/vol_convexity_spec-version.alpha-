"""GL-09 · 正Carry时间占比状态量 · 一次性 harness（裁决1"一次性harness真跑出数"）

身份：被测实现侧。喂入 entity/ledger_input.json（人造持仓时序＋人造行情坐标），
      驱动 entity/engine.py（M1 求值供给，逐字节复用件）端到端求值，捕获输出真数。

数据源纪律（裁决1，全程强制）：零网络、零行情接口、零外部文件数据源。唯一读入
      文件＝本切片自带之人造 input（entity/ledger_input.json）。

构造顺序留痕（F-10，三处一致之第一处见 ledger_input.json `_pin_note`）：
      本文件写定于 ledger_input.json 之后。

口径纪律（宪-ST-06，强制）：
  · Carry ＝ 期间**净时间价值现金流**口径量（extrinsic premium 成分之组合层变动），
    **非**瞬时 ∂V/∂t 之 Greeks 读数。ITM 腿按宪-ST-06『取其期权价值中的时间价值
    成分』提取（EV = V − intrinsic），ATM/OTM 取全额（intrinsic=0 时 EV=V）。
  · 瞬时 Theta 读数（`theta_reading_start`）为**口径分离之对照诊断量**，属 Greeks
    口径，携仪表读数身份（详 input_schema.md §8）。两口径量**不进入任何同一个
    比值/差额/阈值比较**——同一比较内口径同源（宪-ST-06），本文件不构造跨口径合成量。
"""

import json
import os
from fractions import Fraction

import engine

HERE = os.path.dirname(os.path.abspath(__file__))
LEDGER_PATH = os.path.join(HERE, "ledger_input.json")
OUTPUT_PATH = os.path.join(HERE, "harness_output.json")


def _intrinsic_unit(option_type, strike, spot):
    """逐份额内在价值。ATM/OTM 恒为 0.0，ITM 为正——宪-ST-06 时间价值成分提取之补集。"""
    if option_type == "call":
        return max(spot - strike, 0.0)
    if option_type == "put":
        return max(strike - spot, 0.0)
    raise ValueError("option_type 越出值域 enum{call,put}: %r" % (option_type,))


def _side_sign(side):
    if side == "long":
        return 1
    if side == "short":
        return -1
    raise ValueError("side 越出值域 enum{long,short}: %r" % (side,))


def _evaluate_node(legs, spot, implied_vol, risk_free_rate, dividend_yield, valuation_date):
    """单节点求值：出组合层净时间价值 TV_pos、组合层瞬时Theta读数、逐腿明细。

    TV_pos = Σ_legs sign(side) · multiplier · quantity · (V_unit − intrinsic_unit)
    组合Theta读数 = Σ_legs per_lot.theta（引擎已含 side 符号与规模）
    """
    tv_pos_total = 0.0
    theta_total = 0.0
    leg_rows = []
    for leg in legs:
        lot = {
            "lot_id": leg["lot_id"],
            "instrument_class": leg["instrument_class"],
            "option_type": leg["option_type"],
            "side": leg["side"],
            "strike": leg["strike"],
            "expiry": leg["expiry"],
            "spot": spot,
            "risk_free_rate": risk_free_rate,
            "implied_vol": implied_vol,
            "multiplier": leg["multiplier"],
            "quantity": leg["quantity"],
            "valuation_date": valuation_date,
            "dividend_yield": dividend_yield,
        }
        out = engine.evaluate_lot(lot)
        value_unit = out["per_unit"]["value"]
        intrinsic = _intrinsic_unit(leg["option_type"], float(leg["strike"]), float(spot))
        ev_unit = value_unit - intrinsic
        scale = _side_sign(leg["side"]) * int(leg["multiplier"]) * int(leg["quantity"])
        tv_pos = ev_unit * scale
        tv_pos_total += tv_pos
        theta_total += out["per_lot"]["theta"]
        leg_rows.append({
            "lot_id": leg["lot_id"],
            "route_id": out["route_id"],
            "computability_status": out["computability_status"],
            "unstated_dimensions_hit": out["unstated_dimensions_hit"],
            "value_unit": value_unit,
            "intrinsic_unit": intrinsic,
            "ev_unit": ev_unit,
            "signed_scale": scale,
            "tv_pos": tv_pos,
            "theta_per_lot": out["per_lot"]["theta"],
        })
    return tv_pos_total, theta_total, leg_rows


def _is_positive_carry(carry_value):
    """『正Carry』之正＝严格大于零（类一定案，input_schema.md §4②）。
    零与负值同判非正——恰零边界期（P5）据此计入分母不计入分子。"""
    return carry_value > 0.0


def compute_gl09(ledger):
    consts = ledger["market_constants"]
    r = float(consts["risk_free_rate"])
    q = float(consts["dividend_yield"])

    period_rows = []
    for p in ledger["periods"]:
        declared_dur = int(p["duration_days"])
        derived_dur = engine._dte_days(p["t_end"], p["t_start"])
        tv0, th0, rows0 = _evaluate_node(
            p["legs"], float(p["spot"]), float(p["implied_vol"]), r, q, p["t_start"])
        tv1, th1, rows1 = _evaluate_node(
            p["legs"], float(p["spot"]), float(p["implied_vol"]), r, q, p["t_end"])
        carry = tv1 - tv0
        scale_ref = max(abs(tv0), abs(tv1), abs(carry))
        margin = 0.0 if scale_ref == 0.0 else abs(carry) / scale_ref
        period_rows.append({
            "period_id": p["period_id"],
            "t_start": p["t_start"],
            "t_end": p["t_end"],
            "duration_days_declared": declared_dur,
            "duration_days_derived": derived_dur,
            "boundary_construction": bool(p["boundary_construction"]),
            "spot": float(p["spot"]),
            "implied_vol": float(p["implied_vol"]),
            "tv_pos_start": tv0,
            "tv_pos_end": tv1,
            "carry": carry,
            "carry_positive": _is_positive_carry(carry),
            "carry_sign_margin": margin,
            "theta_reading_start": th0,
            "theta_reading_end": th1,
            "theta_reading_start_positive": th0 > 0.0,
            "legs_at_t_start": rows0,
            "legs_at_t_end": rows1,
        })

    total_dur = sum(row["duration_days_declared"] for row in period_rows)
    pos_dur = sum(row["duration_days_declared"] for row in period_rows if row["carry_positive"])
    theta_pos_dur = sum(row["duration_days_declared"] for row in period_rows
                        if row["theta_reading_start_positive"])

    ratio = Fraction(pos_dur, total_dur)
    theta_ratio = Fraction(theta_pos_dur, total_dur)

    # 等权期数占比：仅作**区分力对照量**（证明时长加权非退化为期数计数），
    # 非本根交付状态量、不进入任何合格判据。
    n_periods = len(period_rows)
    n_pos_periods = sum(1 for row in period_rows if row["carry_positive"])
    count_ratio = Fraction(n_pos_periods, n_periods)

    # Q4判据面之"与阈值比较"（任务5_Step2增量产出 GL-09行）：
    # 阈值取值＝源文字面90%（类三候选槽位，不外推）；比较子＝">=" （源文"90%+"含端点，
    # 类一·语义即裁，见 input_schema.md §4⑤）。
    # **本布尔量不进入本切片合格判据之任何组成部分**（任务包§2.3／§4；C-1误用形态防线，
    # 见 input_schema.md §7）——其取值为False与本切片合格与否无关。
    anchor = ledger["source_reference_anchor"]
    ref_thr = Fraction(int(anchor["positive_carry_time_share_pct"]), 100)
    if anchor["comparator"] != "greater_equal":
        raise ValueError("comparator 越出已声明值域: %r" % (anchor["comparator"],))
    meets = ratio >= ref_thr

    return {
        "_data_source": ledger["_data_source"],
        "_object": "GL-09 正Carry时间占比状态量",
        "_caliber": {
            "carry_measure": "net_time_value_cashflow_extrinsic_premium",
            "carry_is_not": "instantaneous_dV_dt_greeks_reading",
            "carry_measurement_caliber": ledger["slots"]["carry_measurement_caliber"]["value"],
            "coordinate_regime": ledger["slots"]["carry_coordinate_regime"]["value"],
            "period_segmentation_rule": ledger["slots"]["period_segmentation_rule"]["value"],
            "time_base_unit": ledger["slots"]["time_base_unit"]["value"],
            "positivity_boundary": ledger["slots"]["positivity_boundary"]["value"],
            "aggregation_horizon": ledger["slots"]["aggregation_horizon"]["value"],
        },
        "periods": period_rows,
        "state_quantity": {
            "positive_carry_time_share": {
                "numerator_days": pos_dur,
                "denominator_days": total_dur,
                "exact_fraction": "%d/%d" % (ratio.numerator, ratio.denominator),
                "decimal": float(ratio),
                "caliber": "time_value_cashflow",
            },
            "share_meets_reference_threshold": meets,
            "reference_threshold_exact": "%d/%d" % (ref_thr.numerator, ref_thr.denominator),
            "reference_threshold_status": "source_reference_anchor_not_acceptance_criterion",
            "reference_threshold_slot_class": "class_three_phase_b_calibration",
            # 新9(a)：参考锚 9/10 之**口径归属源文未记载**；其与实测占比之比较
            # 为跨口径未核证比较，仅承载 Step2 Q4 判据面之形式要求，不构成可比结论。
            "reference_anchor_caliber": "unstated_in_source",
            "threshold_comparison_caliber_verified": False,
        },
        "discrimination_contrast": {
            "equal_weight_period_count_share": {
                "numerator_periods": n_pos_periods,
                "denominator_periods": n_periods,
                "exact_fraction": "%d/%d" % (count_ratio.numerator, count_ratio.denominator),
            },
            "duration_weighting_is_discriminating": count_ratio != ratio,
            "note": "等权期数占比仅作区分力对照，非交付状态量、不进入合格判据",
        },
        "contrast_diagnostic": {
            "positive_theta_reading_time_share": {
                "numerator_days": theta_pos_dur,
                "denominator_days": total_dur,
                "exact_fraction": "%d/%d" % (theta_ratio.numerator, theta_ratio.denominator),
                "decimal": float(theta_ratio),
                "caliber": "greeks_instantaneous",
                "instrument_reading_note": "仪表读数（宪-EP-06推论，§5.4常设纪律），非定价真理源、非本根交付状态量；仅用于承载源文『Carry口径≠时时正Theta』之可指认性",
            },
            "calibers_are_distinct": pos_dur != theta_pos_dur,
            "no_cross_caliber_composite": True,
        },
        "non_signal_declaration": "本产出为状态量/诊断量（diagnostic），不构成交易信号、不构成动作建议、不承诺任何占比水平之达成",
    }


def main():
    with open(LEDGER_PATH, "r", encoding="utf-8") as fh:
        ledger = json.load(fh)
    if ledger["_data_source"] != "synthetic_hand_constructed":
        raise ValueError("input 非人造声明，step0前置合规不成立")
    result = compute_gl09(ledger)
    with open(OUTPUT_PATH, "w", encoding="utf-8") as fh:
        json.dump(result, fh, ensure_ascii=False, indent=2, sort_keys=True)
        fh.write("\n")
    sq = result["state_quantity"]["positive_carry_time_share"]
    print("GL-09 正Carry时间占比 = %s (%.10f)" % (sq["exact_fraction"], sq["decimal"]))
    print("对照诊断·正Theta读数时间占比 = %s"
          % result["contrast_diagnostic"]["positive_theta_reading_time_share"]["exact_fraction"])


if __name__ == "__main__":
    main()

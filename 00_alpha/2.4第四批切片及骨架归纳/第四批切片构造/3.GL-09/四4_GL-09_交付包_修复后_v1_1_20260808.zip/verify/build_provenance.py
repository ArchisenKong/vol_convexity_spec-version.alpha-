"""GL-09 · F-8 新鲜度/来源钉定件生成脚本（流水线末步）

射程（F-8：钉定射程不得随意收窄）：全包域遍历，钉定除下列排除件外之全部交付件——
  · `verify/build_provenance.json`：**钉定件自身**（时序循环/自指类排除件）。其内容篡改
    无 assert_check.py 脚本内通道；防线位置已在 entity/input_schema.md §11 显式声明
    （①本脚本 `--verify` 重生成幂等门；②切片记录交付件指纹列之逐字转载对照）。
    禁默示"排除即无防"或"断言全覆盖"（手册v1.8 §3.1d）。
  · 两份运行日志：`assert_check_log.txt` / `negative_control_log.txt`——生成于本脚本之后，
    钉定必然失配，属时序排除；其内容之权威面同为切片记录转载。

运行序：harness.py → independent_recompute.py → generate_comparison_table.py →
        **本脚本** → assert_check.py。

`--verify`：重算全射程指纹并与既有钉定件逐键比对，不一致即非零退出（幂等门）。
"""

import hashlib
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(HERE)
OUT = os.path.join(HERE, "build_provenance.json")

SELF_EXCLUSION = "build_provenance.json"
TIME_ORDER_EXCLUSIONS = ("verify/build_provenance.json",
                         "verify/assert_check_log.txt",
                         "verify/negative_control_log.txt")
DIR_EXCLUSIONS = ("__pycache__",)


def sha256_of(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        h.update(fh.read())
    return h.hexdigest()


def collect():
    pins = {}
    for root, dirs, files in os.walk(PKG):
        dirs[:] = [d for d in dirs if d not in DIR_EXCLUSIONS]
        for fn in files:
            rel = os.path.relpath(os.path.join(root, fn), PKG).replace(os.sep, "/")
            if rel in TIME_ORDER_EXCLUSIONS:
                continue
            pins[rel] = sha256_of(os.path.join(PKG, fn if root == PKG else os.path.join(root, fn)))
    return pins


def payload():
    return {
        "_role": "F-8 新鲜度/来源钉定件（全包域射程；排除件与防线声明见 entity/input_schema.md §11）",
        "self_exclusion": SELF_EXCLUSION,
        "time_order_exclusions": list(TIME_ORDER_EXCLUSIONS),
        "pins": collect(),
    }


def main():
    data = payload()
    if "--verify" in sys.argv:
        if not os.path.exists(OUT):
            print("FAIL: 钉定件不存在，幂等门无对照对象")
            sys.exit(1)
        old = json.load(open(OUT, encoding="utf-8"))
        drift = {k: (old["pins"].get(k), v) for k, v in data["pins"].items()
                 if old["pins"].get(k) != v}
        gone = [k for k in old["pins"] if k not in data["pins"]]
        if drift or gone:
            print("FAIL: 重生成非幂等 drift=%r gone=%r" % (drift, gone))
            sys.exit(1)
        print("PASS: 重生成幂等门通过，%d 件指纹一致" % len(data["pins"]))
        sys.exit(0)
    with open(OUT, "w", encoding="utf-8") as fh:
        json.dump(data, fh, ensure_ascii=False, indent=2, sort_keys=True)
        fh.write("\n")
    print("钉定 %d 件（自指排除：%s）" % (len(data["pins"]), SELF_EXCLUSION))


if __name__ == "__main__":
    main()

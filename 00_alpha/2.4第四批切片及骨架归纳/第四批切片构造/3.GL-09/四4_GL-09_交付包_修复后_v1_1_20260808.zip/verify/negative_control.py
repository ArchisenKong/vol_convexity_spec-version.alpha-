"""GL-09 · 负向对照（乙-4 被测侧变异注入；F-9 计算面击落例）

纪律：
  · **注入位打在被测实现侧**（entity/harness.py、entity/engine.py、包封闭面），
    **非**比对器侧（verify/independent_recompute.py 与 assert_check.py 之比对逻辑零改动）。
    实证锚＝T-33 O-3／GK-31 O-10／裁决48 Q-12 三例之共同失效点即"注入位打在比对器侧"。
  · **F-9**：案例集须含 ≥1 例经**计算面断言**（数值/恒等式/声明一致性类）击落者，
    **非**新鲜度或流水线通道击落——NC-1/NC-2/NC-3 三例均于变异后**重跑全流水线**
    （harness→independent→table→provenance）后仍被击落，故击落路径确为计算面。
  · 全部注入在**隔离副本树**（临时目录）内进行；交付工作区零写入、交付件逐字节不变。
  · 失败断言名以真实运行输出解析取得，非硬编码。
"""

import json
import os
import re
import shutil
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(HERE)
LOG_PATH = os.path.join(HERE, "negative_control_log.txt")
PAYLOAD = os.path.join(HERE, "nc_payload.txt")

PIPELINE = [
    ("entity", "harness.py"),
    ("verify", "independent_recompute.py"),
    ("verify", "generate_comparison_table.py"),
    ("verify", "build_provenance.py"),
]


def _copy_tree():
    tmp = tempfile.mkdtemp(prefix="gl09_nc_")
    dst = os.path.join(tmp, "pkg")
    shutil.copytree(PKG, dst, ignore=shutil.ignore_patterns("__pycache__"))
    return tmp, dst


def _replace(path, old, new, expect=1):
    src = open(path, encoding="utf-8").read()
    hit = src.count(old)
    if hit != expect:
        raise RuntimeError("变异注入命中数 %d ≠ %d：%s" % (hit, expect, path))
    open(path, "w", encoding="utf-8").write(src.replace(old, new))


def _run(root, sub, script):
    return subprocess.run([sys.executable, script], cwd=os.path.join(root, sub),
                          capture_output=True, text=True)


def _rerun_pipeline(root):
    for sub, script in PIPELINE:
        r = _run(root, sub, script)
        if r.returncode != 0:
            return r
    return None


def _assert_check(root):
    return _run(root, "verify", "assert_check.py")


def _failed_names(stdout):
    return sorted(set(re.findall(r"^(?:FAIL|ERROR)\s+(\S+)", stdout, re.M)))


CASES = []


def case(cid, desc, kill_channel):
    def deco(fn):
        CASES.append((cid, desc, kill_channel, fn))
        return fn
    return deco


@case("NC-0", "基线（零注入）：隔离副本树原样重跑", "n/a")
def nc0(root):
    _rerun_pipeline(root)
    return None


@case("NC-1", "被测侧计算面：_is_positive_carry 之 `> 0.0` 误写为 `>= 0.0`（边界语义翻转）",
      "计算面")
def nc1(root):
    _replace(os.path.join(root, "entity", "harness.py"),
             "return carry_value > 0.0", "return carry_value >= 0.0")
    return _rerun_pipeline(root)


@case("NC-2", "被测侧计算面：时长加权退化为等权期数计数（分子/分母改取期计数）", "计算面")
def nc2(root):
    p = os.path.join(root, "entity", "harness.py")
    _replace(p,
             'total_dur = sum(row["duration_days_declared"] for row in period_rows)',
             'total_dur = sum(1 for row in period_rows)')
    _replace(p,
             'pos_dur = sum(row["duration_days_declared"] for row in period_rows if row["carry_positive"])',
             'pos_dur = sum(1 for row in period_rows if row["carry_positive"])')
    return _rerun_pipeline(root)


@case("NC-3", "被测侧计算面：删除宪-ST-06 之 ITM 时间价值成分提取（ev_unit 直取 value_unit）",
      "计算面")
def nc3(root):
    _replace(os.path.join(root, "entity", "harness.py"),
             "ev_unit = value_unit - intrinsic", "ev_unit = value_unit - 0.0 * intrinsic")
    return _rerun_pipeline(root)


@case("NC-4", "封闭面注入：向包内写入未声明之 .py 交付件（载荷＝nc_payload.txt，含数据源接入）",
      "封闭面/扫描面")
def nc4(root):
    payload = open(PAYLOAD, encoding="utf-8").read()
    with open(os.path.join(root, "entity", "quote_feed.py"), "w", encoding="utf-8") as fh:
        fh.write(payload)
    return _rerun_pipeline(root)


@case("NC-5", "被测侧来源面：篡改 entity/engine.py（逐字复用件）且不重跑下游产物",
      "声明一致性＋新鲜度")
def nc5(root):
    _replace(os.path.join(root, "entity", "engine.py"),
             "DAY_COUNT_DENOMINATOR = 365", "DAY_COUNT_DENOMINATOR = 360")
    return None  # 刻意不重跑流水线


@case("NC-6", "被测侧声明面：route_id 覆写为伪路由（X2/X3 逃逸形态之复现）", "声明一致性")
def nc6(root):
    _replace(os.path.join(root, "entity", "harness.py"),
             '"route_id": out["route_id"],', '"route_id": "spoofed_route_id",')
    return _rerun_pipeline(root)


@case("NC-7", "被测侧输出面：注入跨口径合成量 pos_dur / theta_pos_dur（X7 逃逸形态之复现）",
      "口径同源面")
def nc7(root):
    _replace(os.path.join(root, "entity", "harness.py"),
             '            "no_cross_caliber_composite": True,',
             '            "no_cross_caliber_composite": True,\n'
             '            "carry_over_theta_pos_dur_ratio": pos_dur / theta_pos_dur,')
    return _rerun_pipeline(root)


@case("NC-8", "被测侧计算面：carry_sign_margin 公式常数化为 1.0（X1 逃逸形态之复现）", "计算面")
def nc8(root):
    _replace(os.path.join(root, "entity", "harness.py"),
             "margin = 0.0 if scale_ref == 0.0 else abs(carry) / scale_ref",
             "margin = 0.0 if scale_ref == 0.0 else 1.0")
    return _rerun_pipeline(root)


@case("NC-9", "被测侧声明面：§12 连续解析层实测上界单向漂移（X8 逃逸形态之复现）",
      "声明一致性")
def nc9(root):
    _replace(os.path.join(root, "entity", "input_schema.md"),
             "本根实测上界＝6.475663e-13", "本根实测上界＝1.000000e-13")
    return _rerun_pipeline(root)


def main():
    lines = ["GL-09 negative_control · 案例 %d 例（NC-0 基线 ＋ 变异 %d 例）"
             % (len(CASES), len(CASES) - 1)]
    ok = True
    summary = []
    for cid, desc, channel, fn in CASES:
        tmp, root = _copy_tree()
        try:
            pipe_fail = fn(root)
            res = _assert_check(root)
            names = _failed_names(res.stdout)
            if cid == "NC-0":
                passed = (res.returncode == 0 and not names)
                lines.append("%s  基线 exit=%d 失败断言=%r → %s"
                             % (cid, res.returncode, names, "PASS" if passed else "FAIL"))
                ok = ok and passed
            else:
                killed = (res.returncode != 0 and bool(names))
                lines.append("%s  [%s] %s" % (cid, channel, desc))
                lines.append("      流水线重跑=%s；assert_check exit=%d；实际失败断言=%r → %s"
                             % ("否（刻意）" if pipe_fail is None and cid == "NC-5" else "是",
                                res.returncode, names, "击落" if killed else "**未击落**"))
                ok = ok and killed
                summary.append((cid, channel, names))
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    lines.append("")
    lines.append("F-9 核证：计算面击落例＝%s"
                 % [c for c, ch, _ in summary if ch == "计算面"])
    lines.append("注入位核证：NC-1/2/3/6/7/8 → entity/harness.py（被测实现）；"
                 "NC-5 → entity/engine.py（被测侧逐字复用件）；NC-9 → entity/input_schema.md"
                 "（被测侧声明面）；NC-4 → 包封闭面。比对器侧"
                 "（independent_recompute.py／assert_check.py 比对逻辑）零改动。")
    lines.append("新增断言之可击落载体核证（修复会话开启文本 §3）："
                 "乙-3〔A12 取值精确比对〕→ NC-6；乙-6〔A24 跨口径合成量扫描〕→ NC-7；"
                 "乙-7〔A23 符号裕度钉表〕→ NC-8；乙-4〔A13 上界声明绑定〕→ NC-9。")
    lines.append("隔离性核证：全部注入于临时副本树进行，交付工作区零写入。")
    lines.append("VERDICT: %s" % ("PASS — 基线通过且全部变异被击落" if ok
                                  else "FAIL — 存在未击落变异或基线异常"))
    text = "\n".join(lines)
    print(text)
    with open(LOG_PATH, "w", encoding="utf-8") as fh:
        fh.write(text + "\nEXIT=%d\n" % (0 if ok else 1))
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()

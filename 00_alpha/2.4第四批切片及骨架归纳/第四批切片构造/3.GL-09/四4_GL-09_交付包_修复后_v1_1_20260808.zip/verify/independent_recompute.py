"""GL-09 · 独立复算路径（模板三 D段②"实现路径独立"）

独立性声明（F-2 判别据＝改写后是否仍共享同一失效模式）：
  1. **零 import engine**——本脚本不导入、不读取被测侧任何模块与产物
     （不读 entity/engine.py、不读 entity/harness.py、不读 entity/harness_output.json）。
  2. **不同 libm 入口**：正态CDF 走 `math.erfc`（N(x)=0.5·erfc(−x/√2)），
     被测侧走 `math.erf`（0.5·(1+erf(x/√2))）。先例＝T-76 重打（裁决13 TPL2-T76-01）。
  3. **不同代数路径**：put 之价格与 theta 均由 **put-call parity** 自 call 推导
     （P = C − S·e^{−qT} + K·e^{−rT}；θ_P = θ_C − qS·e^{−qT} + rK·e^{−rT}），
     被测侧走 put 直式闭式解。
  4. **不同日期算法**：`datetime.date` 序差，被测侧走 Rata Die 整数公式。
  5. **不同求和结构**：组合层聚合走 `math.fsum`（精确累加），被测侧走循环朴素累加；
     占比之分子走逐期 `Fraction(dur, total)` 求和，被测侧走整数分子先聚合后成分数。

F-8 后半（不得读取自身既往产物）：本脚本每次运行均自 entity/ledger_input.json
  全新推导，零读取 verify/independent_expected.json。

口径纪律：与被测侧同一份成文口径（宪-ST-06 时间价值现金流口径；Theta 读数为
  口径分离之对照诊断量），口径取自 input_schema.md 成文声明，非取自被测实现。
"""

import datetime
import json
import math
import os
from fractions import Fraction

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(HERE)
LEDGER_PATH = os.path.join(PKG, "entity", "ledger_input.json")
OUT_PATH = os.path.join(HERE, "independent_expected.json")

_INV_SQRT_2PI = 1.0 / math.sqrt(2.0 * math.pi)
_SQRT_2 = math.sqrt(2.0)
DAY_COUNT_DENOMINATOR = 365


def _ncdf(x):
    """正态CDF：erfc 入口（与被测侧 erf 入口分叉）。"""
    return 0.5 * math.erfc(-x / _SQRT_2)


def _npdf(x):
    return _INV_SQRT_2PI * math.exp(-0.5 * x * x)


def _daydiff(d_from, d_to):
    """日期序差：datetime 路径（与被测侧 Rata Die 整数公式分叉）。"""
    a = datetime.date.fromisoformat(d_from)
    b = datetime.date.fromisoformat(d_to)
    return (b - a).days


def _call_value_theta(S, K, r, q, sig, T):
    """call 之价格与 theta（直式）。"""
    sqrtT = math.sqrt(T)
    d1 = (math.log(S / K) + (r - q + 0.5 * sig * sig) * T) / (sig * sqrtT)
    d2 = d1 - sig * sqrtT
    dq = math.exp(-q * T)
    dr = math.exp(-r * T)
    value = S * dq * _ncdf(d1) - K * dr * _ncdf(d2)
    theta = (-(S * dq * _npdf(d1) * sig) / (2.0 * sqrtT)
             - r * K * dr * _ncdf(d2)
             + q * S * dq * _ncdf(d1))
    return value, theta, dq, dr


def _price_and_theta(option_type, S, K, r, q, sig, T):
    """put 经 put-call parity 自 call 推导（与被测侧 put 直式闭式解分叉）。"""
    c_val, c_theta, dq, dr = _call_value_theta(S, K, r, q, sig, T)
    if option_type == "call":
        return c_val, c_theta
    if option_type == "put":
        p_val = c_val - S * dq + K * dr
        p_theta = c_theta - q * S * dq + r * K * dr
        return p_val, p_theta
    raise ValueError("option_type 越出值域: %r" % (option_type,))


def _intrinsic(option_type, K, S):
    if option_type == "call":
        return S - K if S > K else 0.0
    return K - S if K > S else 0.0


def _node(legs, spot, sig, r, q, valuation_date):
    tv_terms = []
    theta_terms = []
    detail = {}
    for leg in legs:
        K = float(leg["strike"])
        dte = _daydiff(valuation_date, leg["expiry"])
        if dte <= 0:
            raise ValueError("dte<=0 越出已言明面: %s" % leg["lot_id"])
        T = dte / DAY_COUNT_DENOMINATOR
        v_unit, theta_unit = _price_and_theta(
            leg["option_type"], float(spot), K, r, q, float(sig), T)
        ev_unit = v_unit - _intrinsic(leg["option_type"], K, float(spot))
        sign = 1 if leg["side"] == "long" else -1
        scale = sign * int(leg["multiplier"]) * int(leg["quantity"])
        tv_terms.append(ev_unit * scale)
        theta_terms.append(theta_unit * scale)
        detail[leg["lot_id"]] = {
            "value_unit": v_unit,
            "intrinsic_unit": _intrinsic(leg["option_type"], K, float(spot)),
            "ev_unit": ev_unit,
            "signed_scale": scale,
            "tv_pos": ev_unit * scale,
            "theta_per_lot": theta_unit * scale,
        }
    return math.fsum(tv_terms), math.fsum(theta_terms), detail


def compute_independent(ledger):
    consts = ledger["market_constants"]
    r = float(consts["risk_free_rate"])
    q = float(consts["dividend_yield"])

    rows = []
    for p in ledger["periods"]:
        tv0, th0, det0 = _node(p["legs"], p["spot"], p["implied_vol"], r, q, p["t_start"])
        tv1, th1, det1 = _node(p["legs"], p["spot"], p["implied_vol"], r, q, p["t_end"])
        carry = tv1 - tv0
        rows.append({
            "period_id": p["period_id"],
            "duration_days_derived": _daydiff(p["t_start"], p["t_end"]),
            "duration_days_declared": int(p["duration_days"]),
            "boundary_construction": bool(p["boundary_construction"]),
            "tv_pos_start": tv0,
            "tv_pos_end": tv1,
            "carry": carry,
            "carry_positive": carry > 0.0,
            "theta_reading_start": th0,
            "theta_reading_end": th1,
            "theta_reading_start_positive": th0 > 0.0,
            "legs_at_t_start": det0,
            "legs_at_t_end": det1,
        })

    total = sum(row["duration_days_declared"] for row in rows)
    share = Fraction(0)
    theta_share = Fraction(0)
    for row in rows:
        term = Fraction(row["duration_days_declared"], total)
        if row["carry_positive"]:
            share += term
        if row["theta_reading_start_positive"]:
            theta_share += term

    pos_days = int(share * total)
    theta_days = int(theta_share * total)

    return {
        "periods": rows,
        "state_quantity": {
            "positive_carry_time_share": {
                "numerator_days": pos_days,
                "denominator_days": total,
                "exact_fraction": "%d/%d" % (share.numerator, share.denominator),
                "decimal": float(share),
            }
        },
        "contrast_diagnostic": {
            "positive_theta_reading_time_share": {
                "numerator_days": theta_days,
                "denominator_days": total,
                "exact_fraction": "%d/%d" % (theta_share.numerator, theta_share.denominator),
                "decimal": float(theta_share),
            }
        },
    }


def main():
    with open(LEDGER_PATH, "r", encoding="utf-8") as fh:
        ledger = json.load(fh)
    result = compute_independent(ledger)
    with open(OUT_PATH, "w", encoding="utf-8") as fh:
        json.dump(result, fh, ensure_ascii=False, indent=2, sort_keys=True)
        fh.write("\n")
    print("independent 正Carry时间占比 = %s"
          % result["state_quantity"]["positive_carry_time_share"]["exact_fraction"])


if __name__ == "__main__":
    main()

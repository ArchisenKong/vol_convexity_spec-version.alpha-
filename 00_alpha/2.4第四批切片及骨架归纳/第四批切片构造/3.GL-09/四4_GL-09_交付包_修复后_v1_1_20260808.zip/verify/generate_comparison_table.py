"""GL-09 · 逐期比对表程序化产出（W-13(14)，裁决39-B3）

凡进入合格判定叙述链之表格类制品须由随 verify/ 交付之脚本程序化产出，不得手工誊写。
本脚本读取被测侧 harness_output.json 与独立复算 independent_expected.json，
出比对表 comparison_table.tsv。

**射程（乙-8／D-2 落地）**：表射程 ≡ `assert_check.py` A4 之实际比对射程（385 项），
**全部非零 diff 逐项在表**，不再仅载期级两面。表分两段：
  · §A 期级面（原 COLS，17 列）——保持既有可视形态，含符号/裕度/口径背离等离散列；
  · §B 逐项面（长表，7 列）——期级 5 字段 × 9 期 ＋ 逐腿 5 字段 × 2 节点 × 逐腿，
    与 A4 扫描同一枚举顺序；`nonzero` 列标非零 diff。
裁决19「全部非零 diff 无论限内外如实记录」纪律由 §B 承载。
本脚本不参与合格判定，仅产出可视比对面。
"""

import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(HERE)
OUT = os.path.join(HERE, "comparison_table.tsv")

H = json.load(open(os.path.join(PKG, "entity", "harness_output.json"), encoding="utf-8"))
I = json.load(open(os.path.join(HERE, "independent_expected.json"), encoding="utf-8"))
IP = {r["period_id"]: r for r in I["periods"]}

COLS = ["period_id", "t_start", "t_end", "dur_days", "boundary",
        "carry_harness", "carry_independent", "carry_rel_diff",
        "carry_positive_h", "carry_positive_i", "sign_agree", "sign_margin",
        "theta_start_harness", "theta_start_independent", "theta_rel_diff",
        "theta_positive_h", "caliber_divergence"]


def rel(a, b):
    if a == b:
        return 0.0
    s = max(abs(a), abs(b))
    return abs(a - b) / s if s else 0.0


PERIOD_FIELDS = ("tv_pos_start", "tv_pos_end", "carry",
                 "theta_reading_start", "theta_reading_end")
LEG_FIELDS = ("value_unit", "intrinsic_unit", "ev_unit", "tv_pos", "theta_per_lot")
ITEM_COLS = ["locator", "field", "harness", "independent", "rel_diff", "nonzero", "within_tol_b"]
TOL_B = 1e-12


def scan_items():
    """与 assert_check.py A4 同一枚举顺序之全射程逐项扫描（385 项）。"""
    items = []
    for pid in sorted(IP):
        h, i = HP[pid], IP[pid]
        for k in PERIOD_FIELDS:
            items.append(("%s.%s" % (pid, k), k, h[k], i[k]))
        for node_key in ("legs_at_t_start", "legs_at_t_end"):
            for row in h[node_key]:
                ref = i[node_key][row["lot_id"]]
                for k in LEG_FIELDS:
                    items.append(("%s.%s.%s.%s" % (pid, node_key, row["lot_id"], k),
                                  k, row[k], ref[k]))
    return items


HP = {r["period_id"]: r for r in H["periods"]}

rows = []
for r in H["periods"]:
    i = IP[r["period_id"]]
    rows.append([
        r["period_id"], r["t_start"], r["t_end"], r["duration_days_declared"],
        r["boundary_construction"],
        "%.12e" % r["carry"], "%.12e" % i["carry"], "%.3e" % rel(r["carry"], i["carry"]),
        r["carry_positive"], i["carry_positive"],
        r["carry_positive"] == i["carry_positive"], "%.3e" % r["carry_sign_margin"],
        "%.12e" % r["theta_reading_start"], "%.12e" % i["theta_reading_start"],
        "%.3e" % rel(r["theta_reading_start"], i["theta_reading_start"]),
        r["theta_reading_start_positive"],
        r["carry_positive"] and not r["theta_reading_start_positive"],
    ])

items = scan_items()
item_rows = []
n_nonzero = 0
worst = (0.0, "")
for loc, field, hv, iv in items:
    d = rel(hv, iv)
    nz = d > 0.0
    if nz:
        n_nonzero += 1
    if d > worst[0]:
        worst = (d, loc)
    item_rows.append([loc, field, "%.17e" % hv, "%.17e" % iv, "%.6e" % d,
                      nz, d <= TOL_B])

with open(OUT, "w", encoding="utf-8") as fh:
    fh.write("#SECTION\tA_period_level\trows=%d\n" % len(rows))
    fh.write("\t".join(COLS) + "\n")
    for row in rows:
        fh.write("\t".join(str(x) for x in row) + "\n")
    fh.write("#SECTION\tB_item_level\trows=%d\tnonzero=%d\tmax_rel_diff=%.6e\tat=%s\n"
             % (len(item_rows), n_nonzero, worst[0], worst[1]))
    fh.write("\t".join(ITEM_COLS) + "\n")
    for row in item_rows:
        fh.write("\t".join(str(x) for x in row) + "\n")
    sq = H["state_quantity"]["positive_carry_time_share"]
    cd = H["contrast_diagnostic"]["positive_theta_reading_time_share"]
    fh.write("#AGGREGATE\tpositive_carry_time_share=%s\tpositive_theta_reading_time_share=%s"
             "\tequal_weight_period_count_share=%s\tshare_meets_reference_threshold=%s\n"
             % (sq["exact_fraction"], cd["exact_fraction"],
                H["discrimination_contrast"]["equal_weight_period_count_share"]["exact_fraction"],
                H["state_quantity"]["share_meets_reference_threshold"]))

print("comparison_table.tsv 产出：§A 期级 %d 行；§B 逐项 %d 行（非零 diff %d 项，"
      "max rel diff=%.6e at %s）" % (len(rows), len(item_rows), n_nonzero, worst[0], worst[1]))

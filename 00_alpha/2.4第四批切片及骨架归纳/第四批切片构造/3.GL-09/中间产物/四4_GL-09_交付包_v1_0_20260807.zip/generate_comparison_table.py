"""GL-09 · 逐期比对表程序化产出（W-13(14)，裁决39-B3）

凡进入合格判定叙述链之表格类制品须由随 verify/ 交付之脚本程序化产出，不得手工誊写。
本脚本读取被测侧 harness_output.json 与独立复算 independent_expected.json，
出逐期比对表 comparison_table.tsv（含相对 diff 列与离散不变量列）。
本脚本不参与合格判定，仅产出可视比对面。
"""

import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(HERE)
OUT = os.path.join(HERE, "comparison_table.tsv")

H = json.load(open(os.path.join(PKG, "entity", "harness_output.json"), encoding="utf-8"))
I = json.load(open(os.path.join(HERE, "independent_expected.json"), encoding="utf-8"))
IP = {r["period_id"]: r for r in I["periods"]}

COLS = ["period_id", "t_start", "t_end", "dur_days", "boundary",
        "carry_harness", "carry_independent", "carry_rel_diff",
        "carry_positive_h", "carry_positive_i", "sign_agree", "sign_margin",
        "theta_start_harness", "theta_start_independent", "theta_rel_diff",
        "theta_positive_h", "caliber_divergence"]


def rel(a, b):
    if a == b:
        return 0.0
    s = max(abs(a), abs(b))
    return abs(a - b) / s if s else 0.0


rows = []
for r in H["periods"]:
    i = IP[r["period_id"]]
    rows.append([
        r["period_id"], r["t_start"], r["t_end"], r["duration_days_declared"],
        r["boundary_construction"],
        "%.12e" % r["carry"], "%.12e" % i["carry"], "%.3e" % rel(r["carry"], i["carry"]),
        r["carry_positive"], i["carry_positive"],
        r["carry_positive"] == i["carry_positive"], "%.3e" % r["carry_sign_margin"],
        "%.12e" % r["theta_reading_start"], "%.12e" % i["theta_reading_start"],
        "%.3e" % rel(r["theta_reading_start"], i["theta_reading_start"]),
        r["theta_reading_start_positive"],
        r["carry_positive"] and not r["theta_reading_start_positive"],
    ])

with open(OUT, "w", encoding="utf-8") as fh:
    fh.write("\t".join(COLS) + "\n")
    for row in rows:
        fh.write("\t".join(str(x) for x in row) + "\n")
    sq = H["state_quantity"]["positive_carry_time_share"]
    cd = H["contrast_diagnostic"]["positive_theta_reading_time_share"]
    fh.write("#AGGREGATE\tpositive_carry_time_share=%s\tpositive_theta_reading_time_share=%s"
             "\tequal_weight_period_count_share=%s\tshare_meets_reference_threshold=%s\n"
             % (sq["exact_fraction"], cd["exact_fraction"],
                H["discrimination_contrast"]["equal_weight_period_count_share"]["exact_fraction"],
                H["state_quantity"]["share_meets_reference_threshold"]))

print("comparison_table.tsv 产出 %d 行" % len(rows))

"""GL-09 · 合格断言主脚本（模板三 D 段：step0 前置合规 → 数值比对 → 附加断言）

28-B 三项：
  (i)  断言基线程序化解析源文〔字面层〕＝ A20_source_anchor_check
       （程序化定位 GL 现行源文行511–515，断言锚定词在场；不可定位即不通过，
        禁静默回退内嵌副本。"90%" 仅作在场锚定词，不作任何阈值判据。）
  (ii) 非零退出码〔字面层〕＝ 任一断言失败即 sys.exit(1)，且失败输出指名实际失败断言。
  (iii)目录结构判据档〔字面层，24-A7〕＝ A16_scan_face_closure（entity/ ＋ verify/ 双子目录，
       全包域 os.walk 发现面与声明清单双向比对）。

判据可检层次声明（F-3，逐条）：本脚本承担之判据**全部为字面层**（可由断言脚本机械判定）。
语义层判据 S-1～S-5（任务包§3）之**机械前哨**在本脚本内（A11/A12/A13/A19/A23 等在场断言），
权威证伪面＝外审人读——机械前哨仅作假阴性通道，不构成语义层判据之终判。

崩溃安全（裁决49-3）：本脚本开场即删除既往日志；失败运行不得残留成功日志。
"""

import ast
import hashlib
import io
import json
import math
import os
import re
import sys
import tokenize
from fractions import Fraction

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(HERE)
ENTITY = os.path.join(PKG, "entity")
LOG_PATH = os.path.join(HERE, "assert_check_log.txt")

SCAN_PATTERNS_PATH = os.path.join(HERE, "scan_patterns.json")
NC_PAYLOAD_PATH = os.path.join(HERE, "nc_payload.txt")
LEDGER_PATH = os.path.join(ENTITY, "ledger_input.json")
SCHEMA_PATH = os.path.join(ENTITY, "input_schema.md")
HARNESS_OUT = os.path.join(ENTITY, "harness_output.json")
INDEP_OUT = os.path.join(HERE, "independent_expected.json")
PROVENANCE = os.path.join(HERE, "build_provenance.json")

# F-1 检测器自排除条款（裁决71-7）：排除面仅限检测器自身条目。
# 本切片模式表全部外置于 scan_patterns.json，无 .py 交付件以字面串承载模式，
# 故自排除清单为**空集**；空集为显式声明（非省略），运行时写日志留痕。
SCAN_EXCLUDED = ()

TOL_B = 1e-12          # 子口径(b)：连续解析计算，相对 diff 上限（裁决13/19）
TOL_A = 0.0            # 子口径(a)：离散/精确有理计算，bit-exact
MARGIN_FLOOR = 1e-6    # 符号判定稳健性下限（本根自设诊断，非新造判据）

_LOG = []


def log(msg):
    _LOG.append(msg)
    print(msg)


def flush_log(verdict):
    with open(LOG_PATH, "w", encoding="utf-8") as fh:
        fh.write("\n".join(_LOG))
        fh.write("\n%s\n" % verdict)


def sha256_of(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        h.update(fh.read())
    return h.hexdigest()


def strip_comments_and_docstrings(src):
    """F-1 判定基面：统一在剥离注释/docstring 后的文本上执行。"""
    tree = ast.parse(src)
    lines = src.split("\n")
    drop = set()
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            body = getattr(node, "body", None)
            if body and isinstance(body[0], ast.Expr):
                val = body[0].value
                if isinstance(val, ast.Constant) and isinstance(val.value, str):
                    for ln in range(body[0].lineno, body[0].end_lineno + 1):
                        drop.add(ln)
    text = "\n".join("" if (i + 1) in drop else ln for i, ln in enumerate(lines))
    cuts = {}
    for tok in tokenize.generate_tokens(io.StringIO(text).readline):
        if tok.type == tokenize.COMMENT:
            r, c = tok.start
            cuts[r] = min(cuts.get(r, c), c)
    out = text.split("\n")
    for r, c in cuts.items():
        out[r - 1] = out[r - 1][:c]
    return "\n".join(out)


def discover_py_files():
    """F-7 发现面：os.walk 全包域遍历（包根及全部子目录），非仅两目录枚举。
    排除面＝目录名精确匹配，不使用路径子串匹配。"""
    excl = set(SCAN_CFG["closure_rule"]["path_exclusions"])
    found = []
    for root, dirs, files in os.walk(PKG):
        dirs[:] = [d for d in dirs if d not in excl]
        for fn in files:
            if fn.endswith(".py"):
                found.append(os.path.relpath(os.path.join(root, fn), PKG).replace(os.sep, "/"))
    return sorted(found)


def rel_diff(a, b):
    if a == b:
        return 0.0
    scale = max(abs(a), abs(b))
    return abs(a - b) / scale if scale else 0.0


def parse_f4_block(schema_text):
    m = re.search(r"<!--\s*F4_DECLARATIONS\s*(.*?)-->", schema_text, re.S)
    if not m:
        raise AssertionError("F4_DECLARATIONS 块缺位")
    out = {}
    for line in m.group(1).strip().split("\n"):
        line = line.strip()
        if not line:
            continue
        if ":" not in line:
            raise AssertionError("F4 声明块行形态非法（严格解析，禁兜底）: %r" % line)
        k, v = line.split(":", 1)
        out[k.strip()] = v.strip()
    return out


def locate_source_file():
    """28-B(i)：程序化定位 GL 现行源文。不可定位即不通过，禁静默回退内嵌副本。"""
    name = F4["source_anchor_file"]
    roots = [os.environ.get("GL09_SOURCE_ROOT"), "/mnt/project"]
    for root in roots:
        if not root:
            continue
        cand = os.path.join(root, name)
        if os.path.exists(cand):
            return cand
    raise AssertionError(
        "源文不可定位（禁静默回退内嵌副本）：%s；已试根＝%r。"
        "外审会话须以 GL09_SOURCE_ROOT 指向装载面所在目录。" % (name, roots))


# ---------------------------------------------------------------- 载入
SCAN_CFG = json.load(open(SCAN_PATTERNS_PATH, encoding="utf-8"))
LEDGER = json.load(open(LEDGER_PATH, encoding="utf-8"))
HARNESS = json.load(open(HARNESS_OUT, encoding="utf-8"))
INDEP = json.load(open(INDEP_OUT, encoding="utf-8"))
SCHEMA_TEXT = open(SCHEMA_PATH, encoding="utf-8").read()
F4 = parse_f4_block(SCHEMA_TEXT)

HP = {r["period_id"]: r for r in HARNESS["periods"]}
IP = {r["period_id"]: r for r in INDEP["periods"]}

CHECKS = []


def check(name):
    def deco(fn):
        CHECKS.append((name, fn))
        return fn
    return deco


# ---------------------------------------------------- step0 前置合规三项
@check("A1_synthetic_input_declared")
def a1():
    assert LEDGER["_data_source"] == "synthetic_hand_constructed", "ledger 人造声明缺位"
    assert HARNESS["_data_source"] == "synthetic_hand_constructed", "harness 输出人造声明缺位"
    for p in LEDGER["periods"]:
        assert p["legs"], "期 %s 无持仓，人造持仓时序不完整" % p["period_id"]
    return "人造input声明核证：ledger/harness_output 双侧在场；9期持仓时序齐备"


@check("A2_no_datasource_static_scan")
def a2():
    pats = (SCAN_CFG["import_module_patterns"]
            + SCAN_CFG["keyword_patterns"]
            + SCAN_CFG["anti_obfuscation_patterns"])
    assert len(SCAN_CFG["anti_obfuscation_patterns"]) == 3, "71-9 反混淆三条模式缺项"
    hits = []
    scanned = 0
    for rel in discover_py_files():
        if rel in SCAN_EXCLUDED:
            continue
        src = open(os.path.join(PKG, rel), encoding="utf-8").read()
        stripped = strip_comments_and_docstrings(src)
        scanned += 1
        for pat in pats:
            for m in re.finditer(pat, stripped, re.M):
                hits.append((rel, pat, m.group(0)))
    assert not hits, "数据源/反混淆静态扫描命中（剥离注释docstring后）: %r" % (hits,)
    return ("全包域数据源静态扫描 clean：扫描 %d 件 .py × %d 模式；"
            "检测器自排除清单＝%r（空集为显式声明，71-7）" % (scanned, len(pats), list(SCAN_EXCLUDED)))


@check("A3_independent_path_isolation")
def a3():
    path = os.path.join(HERE, "independent_recompute.py")
    src = open(path, encoding="utf-8").read()
    tree = ast.parse(src)
    doc_ids = set()
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            body = getattr(node, "body", None)
            if body and isinstance(body[0], ast.Expr) and isinstance(body[0].value, ast.Constant) \
                    and isinstance(body[0].value.value, str):
                doc_ids.add(id(body[0].value))
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for al in node.names:
                assert al.name.split(".")[0] != "engine", "独立复算导入了被测侧 engine"
        if isinstance(node, ast.ImportFrom):
            assert (node.module or "").split(".")[0] != "engine", "独立复算 from-import 被测侧 engine"
        if isinstance(node, ast.Constant) and isinstance(node.value, str) \
                and id(node) not in doc_ids:
            assert "harness_output" not in node.value, "独立复算引用 harness 产物"
    reads = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == "open":
            mode = "r"
            if len(node.args) >= 2 and isinstance(node.args[1], ast.Constant):
                mode = node.args[1].value
            for kw in node.keywords:
                if kw.arg == "mode" and isinstance(kw.value, ast.Constant):
                    mode = kw.value.value
            if mode.startswith("r"):
                tgt = node.args[0]
                nm = tgt.id if isinstance(tgt, ast.Name) else ast.dump(tgt)
                reads.append(nm)
    assert reads == ["LEDGER_PATH"], (
        "独立复算之读取面越出人造input单件（F-8后半：不得读取自身既往产物）: %r" % (reads,))
    return "独立复算路径隔离：零 import engine／零引用 harness 产物／读取面＝LEDGER_PATH 单件"


# ---------------------------------------------------------- 数值比对两项
@check("A4_numeric_crosscheck_subcaliber_b")
def a4():
    worst = (0.0, "")
    n = 0
    for pid in HP:
        h, i = HP[pid], IP[pid]
        for k in ("tv_pos_start", "tv_pos_end", "carry",
                  "theta_reading_start", "theta_reading_end"):
            d = rel_diff(h[k], i[k]); n += 1
            if d > worst[0]:
                worst = (d, "%s.%s" % (pid, k))
        for node_key in ("legs_at_t_start", "legs_at_t_end"):
            for row in h[node_key]:
                ref = i[node_key][row["lot_id"]]
                for k in ("value_unit", "intrinsic_unit", "ev_unit", "tv_pos", "theta_per_lot"):
                    d = rel_diff(row[k], ref[k]); n += 1
                    if d > worst[0]:
                        worst = (d, "%s.%s.%s.%s" % (pid, node_key, row["lot_id"], k))
    assert worst[0] <= TOL_B, "子口径(b)越限：max rel diff=%.6e at %s（限 %.0e）" % (
        worst[0], worst[1], TOL_B)
    return "连续解析层比对 %d 项全过；max rel diff=%.6e at %s（子口径(b) ≤ %.0e）" % (
        n, worst[0], worst[1], TOL_B)


@check("A5_share_exact_equality_subcaliber_a")
def a5():
    hs = HARNESS["state_quantity"]["positive_carry_time_share"]
    is_ = INDEP["state_quantity"]["positive_carry_time_share"]
    for k in ("numerator_days", "denominator_days", "exact_fraction"):
        assert hs[k] == is_[k], "占比量 %s 两路径不一致：%r vs %r" % (k, hs[k], is_[k])
    assert abs(hs["decimal"] - is_["decimal"]) == TOL_A, "占比小数值非 bit-exact"
    ht = HARNESS["contrast_diagnostic"]["positive_theta_reading_time_share"]
    it = INDEP["contrast_diagnostic"]["positive_theta_reading_time_share"]
    for k in ("numerator_days", "denominator_days", "exact_fraction"):
        assert ht[k] == it[k], "对照量 %s 两路径不一致" % k
    return "离散不变量层 bit-exact：占比量 %s、对照量 %s，两路径 0 差异（子口径(a)＝0）" % (
        hs["exact_fraction"], ht["exact_fraction"])


@check("A6_sign_vector_exact_equality")
def a6():
    hv = [(r["period_id"], r["carry_positive"]) for r in HARNESS["periods"]]
    iv = [(r["period_id"], r["carry_positive"]) for r in INDEP["periods"]]
    assert hv == iv, "Carry 符号向量两路径不一致：%r vs %r" % (hv, iv)
    hth = [(r["period_id"], r["theta_reading_start_positive"]) for r in HARNESS["periods"]]
    ith = [(r["period_id"], r["theta_reading_start_positive"]) for r in INDEP["periods"]]
    assert hth == ith, "Theta 读数符号向量两路径不一致"
    return "符号向量（Carry 9期／Theta读数 9期）两路径逐期精确一致，零容差"


# ------------------------------------------------------------ 附加断言
@check("A7_strict_positive_boundary")
def a7():
    p5 = HP["P5"]
    assert p5["boundary_construction"] is True, "P5 未标记为边界构造期"
    assert p5["carry"] == 0.0, "P5 Carry 非精确 0.0（实为 %r），边界断言失效" % p5["carry"]
    assert IP["P5"]["carry"] == 0.0, "独立路径 P5 Carry 非精确 0.0"
    assert p5["carry_positive"] is False, "恰零期被判为正Carry：实现采用了 >= 语义"
    sys.path.insert(0, ENTITY)
    import harness as _h
    assert _h._is_positive_carry(0.0) is False, "分类器将 0.0 判正"
    assert _h._is_positive_carry(-0.0) is False, "分类器将 -0.0 判正"
    assert _h._is_positive_carry(-1e-300) is False, "分类器将负极小值判正"
    assert _h._is_positive_carry(1e-300) is True, "分类器将正极小值判非正"
    return "严格 >0 边界语义成立：P5 Carry 精确 0.0 且判非正；分类器四点边界核证通过"


@check("A8_duration_face_and_weighting")
def a8():
    for r in HARNESS["periods"]:
        assert r["duration_days_declared"] == r["duration_days_derived"], (
            "期 %s 声明时长 %d ≠ 日期序差导出时长 %d（F-4 声明-实现一致性）"
            % (r["period_id"], r["duration_days_declared"], r["duration_days_derived"]))
        assert IP[r["period_id"]]["duration_days_derived"] == r["duration_days_derived"], (
            "期 %s 时长两路径日期算法不一致" % r["period_id"])
    durs = sorted(set(r["duration_days_declared"] for r in HARNESS["periods"]))
    assert len(durs) >= 3, "人造期时长过于齐一，加权形态无区分力"
    dc = HARNESS["discrimination_contrast"]
    assert dc["duration_weighting_is_discriminating"] is True, "时长加权退化为等权期数计数"
    share = HARNESS["state_quantity"]["positive_carry_time_share"]["exact_fraction"]
    cnt = dc["equal_weight_period_count_share"]["exact_fraction"]
    assert share != cnt, "时长加权占比与等权期数占比相等，区分力不在场"
    return ("时长面核证：9期声明时长≡日期序差（两独立日期算法一致）；时长谱 %r；"
            "时长加权 %s ≠ 等权期数 %s，加权形态在可击落射程内" % (durs, share, cnt))


@check("A9_sign_margin")
def a9():
    worst = None
    for r in HARNESS["periods"]:
        if r["boundary_construction"]:
            assert r["carry_sign_margin"] == 0.0, "边界期 margin 非 0.0"
            continue
        m = r["carry_sign_margin"]
        assert m >= MARGIN_FLOOR, "期 %s 符号裕度 %.3e 低于下限 %.0e，符号判定落入浮点噪声可疑域" % (
            r["period_id"], m, MARGIN_FLOOR)
        if worst is None or m < worst[1]:
            worst = (r["period_id"], m)
    return "符号裕度诊断：非边界期最小裕度 %.3e（%s），高于子口径(b)上限约 %d 个数量级" % (
        worst[1], worst[0], round(abs(math.log10(worst[1] / TOL_B))))


@check("A10_itm_extraction_effective")
def a10():
    itm_periods = []
    for pid, r in HP.items():
        for row in r["legs_at_t_start"]:
            if row["intrinsic_unit"] > 0.0:
                assert row["ev_unit"] != row["value_unit"], (
                    "%s/%s intrinsic>0 而 ev_unit==value_unit，宪-ST-06 ITM 时间价值成分提取未生效"
                    % (pid, row["lot_id"]))
                ref = IP[pid]["legs_at_t_start"][row["lot_id"]]
                assert rel_diff(row["intrinsic_unit"], ref["intrinsic_unit"]) <= TOL_B, (
                    "%s/%s intrinsic 两路径不一致" % (pid, row["lot_id"]))
                if pid not in itm_periods:
                    itm_periods.append(pid)
    assert len(itm_periods) >= 2, "ITM 提取路径未被人造input触发（≥2期要求），该步为空转"
    return "宪-ST-06 ITM 时间价值成分提取非空转：命中期 %r，逐腿 ev_unit≠value_unit 且两路径一致" % (
        sorted(itm_periods),)


@check("A11_caliber_separation")
def a11():
    cal = HARNESS["_caliber"]
    assert cal["carry_measure"] == "net_time_value_cashflow_extrinsic_premium"
    assert cal["carry_is_not"] == "instantaneous_dV_dt_greeks_reading"
    cd = HARNESS["contrast_diagnostic"]
    assert cd["no_cross_caliber_composite"] is True, "跨口径合成量声明缺位"
    assert cd["calibers_are_distinct"] is True, "两口径量取值相同，非同一性不可指认"
    a = HARNESS["state_quantity"]["positive_carry_time_share"]
    b = cd["positive_theta_reading_time_share"]
    assert a["caliber"] != b["caliber"], "两量口径标签相同"
    assert a["numerator_days"] != b["numerator_days"], "两量分子相同"
    div = [r["period_id"] for r in HARNESS["periods"]
           if r["carry_positive"] and not r["theta_reading_start_positive"]]
    assert div, "无任何期呈现『Carry正而瞬时Theta读数非正』形态，源文行513之可算实例缺位"
    for key in ("净时间价值现金流", "extrinsic premium", "非瞬时"):
        assert key in SCHEMA_TEXT, "§1 宪-ST-06 口径界定段锚短语缺位: %s" % key
    return ("口径分离核证：Carry %s（time_value_cashflow）vs Theta读数 %s（greeks_instantaneous），"
            "无跨口径合成量；源文行513可算实例＝期 %r；§1 三锚短语在场"
            % (a["exact_fraction"], b["exact_fraction"], div))


@check("A12_instrument_reading_tag")
def a12():
    note = HARNESS["contrast_diagnostic"]["positive_theta_reading_time_share"]["instrument_reading_note"]
    assert "仪表读数" in note, "仪表读数身份标注缺位（§5.4 常设纪律，命中即施加）"
    assert "非定价真理源" in note, "仪表标注未含『非定价真理源』"
    consumed = set()
    for r in HARNESS["periods"]:
        for row in r["legs_at_t_start"]:
            consumed.add(row["route_id"])
            assert row["computability_status"], "引擎可算性标注未随行"
    assert "仪表" in SCHEMA_TEXT, "schema 仪表身份段缺位"
    return "仪表读数身份标注在场（输出侧＋schema §8）；消费路由＝%r，可算性标注随行" % (sorted(consumed),)


@check("A13_f4_strict_declaration")
def a13():
    s = LEDGER["slots"]
    exact = {
        "carry_coordinate_regime": s["carry_coordinate_regime"]["value"],
        "time_base_unit": s["time_base_unit"]["value"],
        "positivity_boundary": s["positivity_boundary"]["value"],
        "aggregation_horizon": s["aggregation_horizon"]["value"],
        "reference_threshold_pct": str(LEDGER["source_reference_anchor"]["positive_carry_time_share_pct"]),
        "reference_threshold_comparator": LEDGER["source_reference_anchor"]["comparator"],
        "reference_threshold_exact": HARNESS["state_quantity"]["reference_threshold_exact"],
        "reference_threshold_status": HARNESS["state_quantity"]["reference_threshold_status"],
        "risk_free_rate": str(LEDGER["market_constants"]["risk_free_rate"]),
        "dividend_yield": str(LEDGER["market_constants"]["dividend_yield"]),
        "period_count": str(len(LEDGER["periods"])),
        "total_days": str(HARNESS["state_quantity"]["positive_carry_time_share"]["denominator_days"]),
        "positive_carry_numerator_days": str(
            HARNESS["state_quantity"]["positive_carry_time_share"]["numerator_days"]),
        "positive_carry_share_exact": HARNESS["state_quantity"]["positive_carry_time_share"]["exact_fraction"],
        "engine_source_sha256": sha256_of(os.path.join(ENTITY, "engine.py")),
        "scan_patterns_sha256": sha256_of(SCAN_PATTERNS_PATH),
        "nc_payload_sha256": sha256_of(NC_PAYLOAD_PATH),
    }
    missing = [k for k in exact if k not in F4]
    assert not missing, "F4 声明块缺键（严格解析，禁兜底）: %r" % missing
    bad = {k: (F4[k], v) for k, v in exact.items() if F4[k] != v}
    assert not bad, "F4 声明-实现不一致（零宽松匹配）: %r" % bad
    assert F4["st06_scope_marker"] == "time_value_cashflow_extrinsic_premium_not_instantaneous_dVdt"
    return "F-4 严格声明块：%d 键逐键精确比对通过（含三件外置/复用件指纹）" % len(exact)


@check("A14_engine_verbatim_reuse")
def a14():
    actual = sha256_of(os.path.join(ENTITY, "engine.py"))
    declared = F4["engine_source_sha256"]
    assert actual == declared, "引擎逐字复用件指纹漂移：%s ≠ 声明 %s" % (actual, declared)
    assert declared == "e31fbcfeacebeb196f7e1d63f41089e7e0a7deb3cc9a9a8b44941af31e194e99", (
        "引擎指纹与《切片记录_TPL1-T76-01引擎_续2 v1.2》指纹列声明值不符（裁决69扩项(i)装载核证）")
    src = open(os.path.join(ENTITY, "engine.py"), encoding="utf-8").read()
    assert "def evaluate_lot(lot):" in src, "引擎入口面缺位"
    assert "仪表计算器" in src, "引擎契约⑥（仪表计算器非定价真理源）原文未随复用件携带"
    return ("F-12 逐字复用机械核证：entity/engine.py 整文件 SHA256 ≡ 声明值 ≡ 引擎续2 v1.2 指纹列；"
            "契约⑥原文随件携带")


@check("A15_freshness_double_pin")
def a15():
    prov = json.load(open(PROVENANCE, encoding="utf-8"))
    drift = []
    for rel, pinned in sorted(prov["pins"].items()):
        cur = sha256_of(os.path.join(PKG, rel))
        if cur != pinned:
            drift.append((rel, pinned, cur))
    assert not drift, "新鲜度钉定漂移（产物未随源码/输入重跑）: %r" % (drift,)
    assert prov["self_exclusion"] == "build_provenance.json", "钉定排除件声明缺位"
    assert "重生成幂等" in SCHEMA_TEXT and "逐字转载对照" in SCHEMA_TEXT, (
        "钉定排除件之防线位置未在 schema 显式声明（手册§3.1d，禁默示『排除即无防』）")
    return "F-8 新鲜度双钉：%d 件全包域钉定件指纹一致；自指排除件＝build_provenance.json（防线声明在场）" % len(prov["pins"])


@check("A16_scan_face_closure")
def a16():
    declared = sorted(SCAN_CFG["declared_py_files"])
    found = discover_py_files()
    missing = [f for f in declared if f not in found]
    extra = [f for f in found if f not in declared]
    assert not missing, "声明但不存在之 .py（检缺）: %r" % (missing,)
    assert not extra, "存在但未声明之 .py（检多，F-7 域外未声明件）: %r" % (extra,)
    assert os.path.isdir(ENTITY) and os.path.isdir(HERE), "entity/ 与 verify/ 双子目录结构不成立（24-A7）"
    for rel in declared:
        top = rel.split("/")[0]
        assert top in ("entity", "verify"), "交付脚本落在 entity/verify 之外: %s" % rel
    return "F-7/24-A7 封闭：全包域发现 %d 件 .py，与声明清单双向比对 检缺0/检多0；目录结构 entity/+verify/ 成立" % len(found)


@check("A17_external_artifact_double_pin")
def a17():
    for path, key in ((SCAN_PATTERNS_PATH, "scan_patterns_sha256"),
                      (NC_PAYLOAD_PATH, "nc_payload_sha256")):
        actual = sha256_of(path)
        assert F4[key] == actual, "外置件 %s 指纹漂移" % os.path.basename(path)
        assert actual in SCHEMA_TEXT, "外置件 %s 之声明面（schema §11）缺指纹" % os.path.basename(path)
    assert "协同篡改" in SCHEMA_TEXT, "双钉免疫射程声明缺位（手册§3.1d）"
    assert SCAN_CFG["detector_self_exclusion"]["excluded_entries"] == [], (
        "检测器自排除清单非空，排除面越出检测器自身即开口（71-7）")
    return "F-5 双钉：scan_patterns.json / nc_payload.txt 指纹断言＋schema §11 声明面 双面在场；免疫射程声明在场"


@check("A18_threshold_decoupling")
def a18():
    sq = HARNESS["state_quantity"]
    share = Fraction(*[int(x) for x in sq["positive_carry_time_share"]["exact_fraction"].split("/")])
    thr = Fraction(*[int(x) for x in sq["reference_threshold_exact"].split("/")])
    assert share < thr, "人造input之占比未低于参考锚，解耦实证不成立"
    assert sq["share_meets_reference_threshold"] is False, "参考锚比较结果与实测不符"
    assert sq["reference_threshold_status"] == "source_reference_anchor_not_acceptance_criterion"
    assert sq["reference_threshold_slot_class"] == "class_three_phase_b_calibration"
    # 判据面纯净性：本脚本除本项解耦实证外，合格判定链不消费参考锚
    self_src = strip_comments_and_docstrings(open(__file__, encoding="utf-8").read())
    hits = [m.group(0) for m in re.finditer(r"reference_threshold|9\s*/\s*10|0\.9\b", self_src)]
    allowed_fn = "a18"
    fn_src = self_src.split("def %s(" % allowed_fn, 1)
    assert len(fn_src) == 2, "判据面自扫描定位失败"
    outside = fn_src[0] + fn_src[1].split("\n@check", 1)[-1] if "\n@check" in fn_src[1] else fn_src[0]
    leak = [m.group(0) for m in re.finditer(r"9\s*/\s*10|0\.9\b", outside)]
    assert not leak, "参考锚阈值泄入 a18 之外之判据面: %r" % (leak,)
    return ("C-1 误用防线实证：实测占比 %s < 参考锚 %s ⇒ share_meets_reference_threshold=False，"
            "而本脚本全项通过、退出码 0——合格与占比达标解耦；判据面自扫描：阈值零泄漏（%d 处引用全在本项内）"
            % (share, thr, len(hits)))


@check("A19_negative_statement_section_present")
def a19():
    assert "## §9 反面陈述段" in SCHEMA_TEXT, "F-13 反面陈述段缺位"
    for anchor in ("不代行 GL-06 之比值维度", "不产出交易信号", "不承诺任何占比水平之达成",
                   "不代行动作/生命周期域", "W-23"):
        assert anchor in SCHEMA_TEXT, "反面陈述段缺锚条: %s" % anchor
    assert "non_signal_declaration" in HARNESS, "非信号声明之输出侧载体缺位"
    assert "不构成交易信号" in HARNESS["non_signal_declaration"]
    return "F-13 反面陈述段在场（7条，含任务包§2.5要求之四条锚）；非信号声明输出侧载体在场"


@check("A20_source_anchor_check")
def a20():
    path = locate_source_file()
    with open(path, encoding="utf-8") as fh:
        lines = fh.read().split("\n")
    a, b = int(F4["source_anchor_line_start"]), int(F4["source_anchor_line_end"])
    assert len(lines) >= b, "源文行数不足，行锚失效"
    seg = "\n".join(lines[a - 1:b])
    for word in ("正 Carry", "正 Theta", "正凸性", "90%"):
        assert word in seg, "源文行%d–%d 锚定词缺位: %s（禁静默回退内嵌副本）" % (a, b, word)
    assert "总体上是保持正 Carry 的即可" in seg, "行513主句不在锚定区间"
    assert "最重要" in seg, "行515总括句不在锚定区间"
    return "28-B(i) 源文锚：%s 行%d–%d 程序化实读，锚定词4项在场（『90%%』仅作在场锚定词，不作阈值判据）" % (
        os.path.basename(path), a, b)


@check("A21_c6_flag_absent")
def a21():
    txt = json.dumps(HARNESS, ensure_ascii=False)
    assert "falsification_trigger_flags" not in txt, "C-6 判定为不标记，产物却载证伪触发器字段"
    assert "P_B" not in txt, "本根非 P_B 证伪工程靶子，产物不应引 P_B"
    return "C-6 核证：Step3 判定『不标记』与产物一致（无证伪触发器字段、无 P_B 消费）"


@check("A22_applicability_notes")
def a22():
    for anchor in ("**F-11 不命中**", "**F-6 不适用**"):
        assert anchor in SCHEMA_TEXT, "适用性显式注记缺位: %s" % anchor
    assert "F-5 双钉" in SCHEMA_TEXT, "F-5 适用性注记缺位"
    return "F-5 适用（双钉在场）／F-6 不适用／F-11 不命中 —— 三项适用性显式注记在场，非默认省略"


@check("A23_expected_pin_match")
def a23():
    pin = LEDGER["expected_pin"]
    sq = HARNESS["state_quantity"]["positive_carry_time_share"]
    cd = HARNESS["contrast_diagnostic"]["positive_theta_reading_time_share"]
    dc = HARNESS["discrimination_contrast"]["equal_weight_period_count_share"]
    pairs = [
        ("positive_carry_time_share_exact", sq["exact_fraction"]),
        ("positive_theta_reading_time_share_exact", cd["exact_fraction"]),
        ("positive_carry_numerator_days", sq["numerator_days"]),
        ("total_days", sq["denominator_days"]),
        ("equal_weight_period_count_share_exact", dc["exact_fraction"]),
        ("share_meets_reference_threshold_expected",
         HARNESS["state_quantity"]["share_meets_reference_threshold"]),
    ]
    bad = [(k, pin[k], v) for k, v in pairs if pin[k] != v]
    assert not bad, "钉表与实跑不符（乙-2）: %r" % (bad,)
    assert HP[pin["boundary_period_id"]]["carry"] == 0.0
    dp = HP[pin["caliber_divergence_period_id"]]
    assert dp["carry_positive"] is True and dp["theta_reading_start_positive"] is False, (
        "口径背离期形态与钉表不符")
    neg = sorted(r["period_id"] for r in HARNESS["periods"] if not r["carry_positive"]
                 and not r["boundary_construction"])
    assert neg == sorted(pin["negative_carry_period_ids"]), "负Carry期集与钉表不符: %r" % (neg,)
    itm = sorted({pid for pid, r in HP.items()
                  for row in r["legs_at_t_start"] if row["intrinsic_unit"] > 0.0})
    assert itm == sorted(pin["itm_extraction_period_ids"]), "ITM期集与钉表不符: %r" % (itm,)
    return "乙-2 钉表核证：9项期望值与实跑逐项相符（含离散形态项：边界恰零／口径背离／负Carry期集／ITM期集）"


# --------------------------------------------------------------- 主流程
def main():
    if os.path.exists(LOG_PATH):
        os.remove(LOG_PATH)
    log("GL-09 assert_check · 断言 %d 项" % len(CHECKS))
    failed = []
    for name, fn in CHECKS:
        try:
            detail = fn()
        except AssertionError as exc:
            failed.append((name, str(exc)))
            log("FAIL  %-38s %s" % (name, exc))
        except Exception as exc:  # 非断言型异常同判失败，指名实际断言
            failed.append((name, "%s: %s" % (type(exc).__name__, exc)))
            log("ERROR %-38s %s: %s" % (name, type(exc).__name__, exc))
        else:
            log("PASS  %-38s %s" % (name, detail))
    if failed:
        log("VERDICT: FAIL — 失败断言 %d 项：%s" % (len(failed), ", ".join(n for n, _ in failed)))
        flush_log("EXIT=1")
        sys.exit(1)
    log("VERDICT: PASS — %d/%d 断言全过" % (len(CHECKS), len(CHECKS)))
    flush_log("EXIT=0")
    sys.exit(0)


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
T-33 增量复核会话 · §4 十例变异重放
锚点串独立性声明（裁决32-③）：以下全部锚点串由本复核会话读交付源码后自行书写，
未取自 verify/mutation_test.py 之 MUTATIONS 常量、未取自被审代码之任何模式定义列表。
命中失败或非唯一 → 报注入失败，不静默跳过。
协同变异（C系列）两侧对称性逐例声明。
击落判据 = verify/assert_check.py 退出码非零。
"""
import os
import shutil
import subprocess
import sys

SRC = "/home/claude/T33review/v1_1"
WORK = "/home/claude/T33review/mut"

H = "entity/harness.py"
V = "verify/independent_recompute.py"

# (id, 说明, [(文件, 旧串, 新串), ...], 侧)
MUT = [
    # ---------- 单侧四例 ----------
    ("E2", "harness zone_state 上边界 '>'→'>=' （单侧）", [
        (H, '    if S > K_high:\n        return "out_above"', '    if S >= K_high:\n        return "out_above"'),
    ], "单侧"),

    ("E10", "harness classify 低IV子判据 '<='→'>=' （单侧）", [
        (H, "    low_iv_hit = float(rv_proxy_value) <= low_iv_thr", "    low_iv_hit = float(rv_proxy_value) >= low_iv_thr"),
    ], "单侧"),

    ("E11", "harness classify 复合联结 'and'→'or' （单侧）", [
        (H, '"definition_feature_satisfied_illustrative": bool(low_iv_hit and osc_hit),',
             '"definition_feature_satisfied_illustrative": bool(low_iv_hit or osc_hit),'),
    ], "单侧"),

    ("E13", "harness 族Q rv_proxy 分母 S0→硬写 100.0 （单侧）", [
        (H, "def rv_proxy_Q(path, S0):", "def rv_proxy_Q(path, S0):\n    S0 = 100.0"),
    ], "单侧"),

    # ---------- 协同六例 ----------
    ("C1", "两侧 zone_state 上边界 '>'→'>=' （协同）", [
        (H, '    if S > K_high:\n        return "out_above"', '    if S >= K_high:\n        return "out_above"'),
        (V, '    if above_margin > 0:\n        return "out_above"', '    if above_margin >= 0:\n        return "out_above"'),
    ], "协同"),

    ("C2", "两侧 zone_state 三态并二态（out_above/out_below 合并为 out）（协同）", [
        (H, '        return "out_above"\n    if S < K_low:\n        return "out_below"',
             '        return "out"\n    if S < K_low:\n        return "out"'),
        (V, '        return "out_above"\n    if below_margin > 0:\n        return "out_below"',
             '        return "out"\n    if below_margin > 0:\n        return "out"'),
    ], "协同"),

    ("C3", "两侧 rv_proxy 均步幅→最大步幅（协同，六族对称）", [
        # harness 侧：两个逐点实现
        (H, "    mean_abs_step = sum(steps, Fraction(0)) / len(steps)\n    return mean_abs_step / S0  # Fraction",
             "    mean_abs_step = max(steps)\n    return mean_abs_step / S0  # Fraction"),
        (H, "    mean_abs_step = sum(steps) / len(steps)\n    return mean_abs_step / S0  # float",
             "    mean_abs_step = max(steps)\n    return mean_abs_step / S0  # float"),
        # verify 侧：三角波解析式（族P/O/Z：全步长恒等 → 最大步幅 = leg_step）
        (V, "    total_variation = num_legs * leg_len * step\n    mean_step = total_variation / num_steps\n    return mean_step / S0",
             "    total_variation = num_legs * leg_len * step\n    mean_step = step\n    return mean_step / S0"),
        # verify 侧：族B解析式（最大步幅 = 满幅 full_swing）
        (V, "    total_variation = first_step + (n - 1) * full_swing\n    mean_step = total_variation / n\n    return mean_step / S0",
             "    total_variation = first_step + (n - 1) * full_swing\n    mean_step = max(first_step, full_swing)\n    return mean_step / S0"),
        # verify 侧：族Q积化和差
        (V, "    mean_step = sum(steps) / len(steps)\n    return mean_step / S0",
             "    mean_step = max(steps)\n    return mean_step / S0"),
        # 族N：均步幅恒等于最大步幅（step/S0），两侧均无需改动——如实声明
    ], "协同"),

    ("C4b", "两侧 rv_proxy 标准化分母 S0→K_high（全族对称）（协同）", [
        (H, "    rv_P = rv_proxy_P(path_P, Fraction(params[\"path_family_P_triangular\"][\"S0\"]))",
             "    rv_P = rv_proxy_P(path_P, Fraction(K_high))"),
        (H, "    rv_Q = rv_proxy_Q(path_Q, params[\"path_family_Q_sinusoidal\"][\"S0\"])",
             "    rv_Q = rv_proxy_Q(path_Q, float(K_high))"),
        (H, "    rv_O = rv_proxy_P(path_O, Fraction(params[\"path_family_O_far_low_amplitude\"][\"S0\"]))",
             "    rv_O = rv_proxy_P(path_O, Fraction(K_high))"),
        (H, "    rv_Z = rv_proxy_P(path_Z, Fraction(params[\"path_family_Z_large_amplitude\"][\"S0\"]))",
             "    rv_Z = rv_proxy_P(path_Z, Fraction(K_high))"),
        (H, "    rv_N = rv_proxy_P(path_N, Fraction(params[\"path_family_N_monotonic_trend\"][\"S0\"]))",
             "    rv_N = rv_proxy_P(path_N, Fraction(K_high))"),
        (H, "    rv_B = rv_proxy_P(path_B, Fraction(params[\"path_family_B_boundary_touch_bounce\"][\"S0\"]))",
             "    rv_B = rv_proxy_P(path_B, Fraction(K_high))"),
        # verify 侧：分母集中在各解析函数内的 S0
        (V, "    total_variation = num_legs * leg_len * step\n    mean_step = total_variation / num_steps\n    return mean_step / S0",
             "    total_variation = num_legs * leg_len * step\n    mean_step = total_variation / num_steps\n    return mean_step / Fraction(103)"),
        (V, "    S0 = Fraction(p[\"S0\"])\n    step = Fraction(p[\"step_size\"])\n    return step / S0",
             "    S0 = Fraction(p[\"S0\"])\n    step = Fraction(p[\"step_size\"])\n    return step / Fraction(103)"),
        (V, "    total_variation = first_step + (n - 1) * full_swing\n    mean_step = total_variation / n\n    return mean_step / S0",
             "    total_variation = first_step + (n - 1) * full_swing\n    mean_step = total_variation / n\n    return mean_step / Kh"),
        (V, "    mean_step = sum(steps) / len(steps)\n    return mean_step / S0",
             "    mean_step = sum(steps) / len(steps)\n    return mean_step / 103.0"),
    ], "协同"),

    ("C5", "两侧 crossing_count 改为仅计'进入义务区'次数（协同）", [
        (H, "    count = 0\n    for i in range(1, len(states)):\n        if states[i] != states[i - 1]:\n            count += 1\n    return count",
             "    count = 0\n    for i in range(1, len(states)):\n        if states[i] == \"in\" and states[i - 1] != \"in\":\n            count += 1\n    return count"),
        (V, "    states = [zone_state(S, K_low, K_high) for S in path]\n    groups = [k for k, _ in itertools.groupby(states)]\n    return len(groups) - 1",
             "    states = [zone_state(S, K_low, K_high) for S in path]\n    groups = [k for k, _ in itertools.groupby(states)]\n    return sum(1 for i in range(1, len(groups)) if groups[i] == \"in\")"),
    ], "协同"),

    ("C6b", "两侧族Q相位同移 +π/2（协同，含积化和差式同步）", [
        (H, "        angle = 2.0 * math.pi * t / period\n        S = S0 + A * math.sin(angle)",
             "        angle = 2.0 * math.pi * t / period + math.pi / 2.0\n        S = S0 + A * math.sin(angle)"),
        (V, "        angle = 2.0 * math.pi * t / period\n        S = S0 + A * cmath.exp(complex(0, angle)).imag",
             "        angle = 2.0 * math.pi * t / period + math.pi / 2.0\n        S = S0 + A * cmath.exp(complex(0, angle)).imag"),
        (V, "        a = 2.0 * math.pi * (t + 1) / period\n        b = 2.0 * math.pi * t / period",
             "        a = 2.0 * math.pi * (t + 1) / period + math.pi / 2.0\n        b = 2.0 * math.pi * t / period + math.pi / 2.0"),
    ], "协同"),
]


def run_case(mid, desc, edits, side):
    d = os.path.join(WORK, mid)
    if os.path.exists(d):
        shutil.rmtree(d)
    shutil.copytree(SRC, d)
    # 注入
    for path, old, new in edits:
        fp = os.path.join(d, path)
        src = open(fp, encoding="utf-8").read()
        n = src.count(old)
        if n != 1:
            return (mid, desc, side, "注入失败", f"锚点命中数={n}（须唯一） 文件={path} 锚点前40字符={old[:40]!r}", None)
        open(fp, "w", encoding="utf-8").write(src.replace(old, new))
    # 跑断言
    r = subprocess.run([sys.executable, "assert_check.py"], cwd=os.path.join(d, "verify"),
                       capture_output=True, text=True)
    killed = (r.returncode != 0)
    fails = [ln for ln in r.stdout.splitlines() if ln.startswith("[FAIL]") or ln.strip().startswith("- ")]
    tot = [ln for ln in r.stdout.splitlines() if ln.startswith("断言总数")]
    return (mid, desc, side, "击落" if killed else "逃逸",
            (tot[0] if tot else "") + " | exit=" + str(r.returncode), fails)


if os.path.exists(WORK):
    shutil.rmtree(WORK)
os.makedirs(WORK)

rows = []
for m in MUT:
    rows.append(run_case(*m))

print("=" * 100)
print(f"{'ID':6s} {'侧':6s} {'结果':8s} 摘要")
print("=" * 100)
for mid, desc, side, res, summ, fails in rows:
    print(f"{mid:6s} {side:6s} {res:8s} {summ}")
    if fails:
        for f in fails[:6]:
            print(f"          {f[:150]}")
    print()

k = sum(1 for r in rows if r[3] == "击落")
e = sum(1 for r in rows if r[3] == "逃逸")
f_ = sum(1 for r in rows if r[3] == "注入失败")
print(f"击落={k} 逃逸={e} 注入失败={f_} 总计={len(rows)}")

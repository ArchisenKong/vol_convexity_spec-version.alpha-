#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""§2 R6事实层 / R10三禁形独立扫描 / 六读覆盖映射 —— 程序化取证"""
import ast
import re

H = "/home/claude/T33review/v1_1/entity/harness.py"
V = "/home/claude/T33review/v1_1/verify/independent_recompute.py"
S = "/home/claude/T33review/v1_1/entity/input_schema.md"

print("=" * 78)
print("【R6 事实层】zone_state 两侧独立性")
print("=" * 78)


def body_src(path, fn):
    src = open(path, encoding="utf-8").read()
    tree = ast.parse(src)
    for n in ast.walk(tree):
        if isinstance(n, ast.FunctionDef) and n.name == fn:
            # 剥离 docstring 后的语句源码
            stmts = n.body[1:] if (n.body and isinstance(n.body[0], ast.Expr)
                                   and isinstance(getattr(n.body[0], "value", None), ast.Constant)
                                   and isinstance(n.body[0].value.value, str)) else n.body
            return "\n".join(ast.dump(s) for s in stmts), \
                   "\n".join(ast.unparse(s) for s in stmts)
    return None, None


dh, uh = body_src(H, "zone_state")
dv, uv = body_src(V, "zone_state")
print("harness zone_state 语句体：\n" + uh)
print("\nverify  zone_state 语句体：\n" + uv)
print(f"\n逐字符相同（剥docstring后源码）: {uh == uv}")
print(f"AST 结构相同: {dh == dv}")
vsrc = open(V, encoding="utf-8").read()
print(f"verify 侧 import harness: {'import harness' in vsrc or 'from harness' in vsrc}")
print(f"verify 侧 sys.path 注入 entity: {'entity' in vsrc and 'sys.path' in vsrc}")

# classify 侧同查
dh2, uh2 = body_src(H, "classify")
dv2, uv2 = body_src(V, "classify_independent")
print(f"\nclassify vs classify_independent 逐字符相同: {uh2 == uv2}")
print(f"classify AST 结构相同: {dh2 == dv2}")

print()
print("=" * 78)
print("【六读覆盖映射】裁决34-D2字面枚举 vs schema§6实载 vs 十例所测读法")
print("=" * 78)
D2 = ["①区域三态转移计数（当前实现）", "②区域二态转移计数", "③仅计进入次数",
      "④rv_proxy＝均步幅（当前）", "⑤最大步幅", "⑥标准化分母S0 vs K_high"]
sec6 = re.search(r"六读候选空间显式列示.*?警示随注", open(S, encoding="utf-8").read(), re.S).group(0)
items = re.findall(r"^\s{2}(\d)\. (.{0,42})", sec6, re.M)
print("裁决34-D2 字面六读：")
for x in D2:
    print("   " + x)
print("\nschema §6 实载六读：")
for n, t in items:
    print(f"   {n}. {t}")

MAP = [
    ("C1  两侧 zone_state 边界 '>'→'>='", "34-D2：**无对应项**", "schema④ 边界归属 '>'/'<' vs '>='/'<='  → 覆盖"),
    ("C2  三态并二态", "34-D2②", "schema② → 覆盖"),
    ("C3  均步幅→最大步幅", "34-D2④⑤", "schema⑥ → 覆盖"),
    ("C4b 分母 S0→K_high", "34-D2⑥", "schema⑤ → 覆盖"),
    ("C5  转移计数→仅计进入", "34-D2③", "schema③ → 覆盖"),
    ("C6b 族Q相位 +π/2", "34-D2：**无对应项**", "schema：**无对应项** → 未覆盖"),
]
print("\n十例协同六例 所测读法 → 登记覆盖：")
for a, b, c in MAP:
    print(f"   {a:34s} | {b:22s} | {c}")

print()
print("=" * 78)
print("【R10 三禁形独立扫描】（本会话自写，不复用交付脚本）")
print("=" * 78)
FORB = {
    "唯一失效路径主张": [r"唯一失效路径", r"唯一的失效路径", r"the only failure path"],
    "自动触发规则": [r"自动触发", r"auto[_ ]?trigger", r"自动执行"],
    "未标注硬阈值": [r"硬阈值", r"hard[_ ]?threshold"],
}
import json
import os
for f in ["entity/input_schema.md", "entity/input_params.json", "entity/harness.py",
          "entity/harness_output.json"]:
    p = os.path.join("/home/claude/T33review/v1_1", f)
    txt = open(p, encoding="utf-8").read()
    hits = {}
    for k, pats in FORB.items():
        h = []
        for pat in pats:
            for m in re.finditer(pat, txt):
                ln = txt[:m.start()].count("\n") + 1
                h.append((ln, txt[max(0, m.start() - 30):m.end() + 30].replace("\n", " ")))
        if h:
            hits[k] = h
    print(f"  {f}: {'命中 ' + str({k: [x[0] for x in v] for k, v in hits.items()}) if hits else '零命中'}")
    for k, v in hits.items():
        for ln, ctx in v:
            print(f"      [{k}] 行{ln}: …{ctx}…")

# 阈值标注核查
prm = json.load(open("/home/claude/T33review/v1_1/entity/input_params.json", encoding="utf-8"))
cand = prm["classification_candidates"]
ent = {k: v for k, v in cand.items() if isinstance(v, dict) and "type" in v}
print(f"\n  阈值字段标注：{ {k: v['type'] for k, v in ent.items()} }")

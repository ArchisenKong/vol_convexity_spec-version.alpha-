#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
T-33 增量复核会话 · §3 期望值钉表独立重算（第三实现）
本脚本由复核会话独立书写：仅读 entity/input_params.json 之参数，
不 import / 不读取 harness.py、independent_recompute.py、assert_check.py、
harness_output.json、independent_recompute_output.json 之任何内容。
路径生成、状态判别、计数与阈值比较全部自源文语义重新实现。
输出＝六族三元组，供与交付 EXPECTED_TRIPLES 字面量对表。
"""
import json
from fractions import Fraction
import math

P = json.load(open("/home/claude/T33review/v1_1/entity/input_params.json", encoding="utf-8"))
Z = P["short_end_obligation_zone"]
KL, KH = Z["K_low"], Z["K_high"]
C = P["classification_candidates"]
THR_RV = C["low_iv_rv_proxy_threshold_candidate"]["value"]
THR_CC = C["oscillation_crossing_count_threshold_candidate"]["value"]


def state(S):
    # 当前候选读法：严格排他，边界值本身归 'in'
    if S > KH:
        return 2
    if S < KL:
        return 0
    return 1


def cc(path):
    s = [state(x) for x in path]
    return sum(1 for i in range(1, len(s)) if s[i] != s[i - 1])


def rv(path, S0):
    d = [abs(path[i + 1] - path[i]) for i in range(len(path) - 1)]
    return (sum(d) / len(d)) / S0


def tri(p):
    """三角波：本会话以 legs 展开成有向增量序列后 itertools 累积（独立书写）"""
    S0, st = Fraction(p["S0"]), Fraction(p["leg_step"])
    L, n = p["leg_length_steps"], p["num_full_cycles"]
    incs = ([st] * L + [-st] * L + [-st] * L + [st] * L) * n
    out, cur = [S0], S0
    for d in incs:
        cur += d
        out.append(cur)
    return out


def mono(p):
    S0, st, n = Fraction(p["S0"]), Fraction(p["step_size"]), p["num_steps"]
    return [S0 + st * k for k in range(n + 1)]


def sino(p):
    S0, A, per, n = p["S0"], p["amplitude"], p["period_steps"], p["num_steps"]
    return [S0 + A * math.sin(2.0 * math.pi * t / per) for t in range(n + 1)]


def bounce(p):
    S0, n = Fraction(p["S0"]), p["num_bounces"]
    out = [S0]
    for i in range(n):
        out.append(Fraction(KH) if i % 2 == 0 else Fraction(KL))
    return out


FAM = {
    "path_P_triangular": (tri(P["path_family_P_triangular"]), Fraction(100)),
    "path_Q_sinusoidal": (sino(P["path_family_Q_sinusoidal"]), 100.0),
    "path_O_far_low_amplitude": (tri(P["path_family_O_far_low_amplitude"]), Fraction(150)),
    "path_Z_large_amplitude": (tri(P["path_family_Z_large_amplitude"]), Fraction(100)),
    "path_N_monotonic_trend": (mono(P["path_family_N_monotonic_trend"]), Fraction(100)),
    "path_B_boundary_touch_bounce": (bounce(P["path_family_B_boundary_touch_bounce"]), Fraction(100)),
}

print("族 | n点 | crossing_count | rv_proxy | 三元组(low_iv, osc, def_feat)")
res = {}
for k, (path, S0) in FAM.items():
    c = cc(path)
    r = rv(path, S0)
    lo = float(r) <= THR_RV
    os_ = c >= THR_CC
    trip = (lo, os_, bool(lo and os_))
    res[k] = trip
    print(f"{k:32s} | {len(path):3d} | {c:3d} | {float(r):.10f} | {trip}")

print()
print("== 交付 EXPECTED_TRIPLES 字面量（本会话人工转录自 assert_check.py，仅作对表） ==")
DELIVERED = {
    "path_P_triangular": (True, True, True),
    "path_Q_sinusoidal": (True, True, True),
    "path_O_far_low_amplitude": (True, False, False),
    "path_Z_large_amplitude": (False, True, False),
    "path_N_monotonic_trend": (False, False, False),
    "path_B_boundary_touch_bounce": (False, False, False),
}
ok = all(res[k] == DELIVERED[k] for k in res)
for k in res:
    mark = "一致" if res[k] == DELIVERED[k] else "**不一致**"
    print(f"  {k:32s} 独立={res[k]} 交付={DELIVERED[k]}  {mark}")
print()
print("钉表算术自洽性：", "PASS（六族全一致）" if ok else "FAIL")

# 边界读法敏感性：'>=' 含边界读法下族B的 crossing_count
def state_incl(S):
    if S >= KH:
        return 2
    if S <= KL:
        return 0
    return 1


pb = FAM["path_B_boundary_touch_bounce"][0]
s2 = [state_incl(x) for x in pb]
cc2 = sum(1 for i in range(1, len(s2)) if s2[i] != s2[i - 1])
print(f"\n族B边界读法敏感性：'>'严格排他 cc={cc(pb)}；'>='含边界 cc={cc2}  → 分歧={'成立' if cc(pb) != cc2 else '不成立'}")

# 族Q touch 点核查
q = FAM["path_Q_sinusoidal"][0]
touch = [(t, v) for t, v in enumerate(q) if abs(v - KH) < 1e-9 or abs(v - KL) < 1e-9]
print(f"族Q近边界点（|S-K|<1e-9）：{[(t, repr(v)) for t, v in touch]}")
qs = [state(x) for x in q]
qs2 = [state_incl(x) for x in q]
cq2 = sum(1 for i in range(1, len(qs2)) if qs2[i] != qs2[i - 1])
print(f"族Q：'>'读法 cc={cc(q)}；'>='读法 cc={cq2}")

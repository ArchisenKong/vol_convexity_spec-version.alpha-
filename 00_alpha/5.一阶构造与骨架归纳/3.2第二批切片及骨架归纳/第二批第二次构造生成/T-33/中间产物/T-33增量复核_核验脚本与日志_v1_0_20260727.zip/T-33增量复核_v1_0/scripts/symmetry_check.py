#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
§4 附：逃逸例之「注入活性」与「两侧对称性」核验。
目的：区分「真逃逸（注入生效、两侧同步改变、验证结构无区分力）」
      与「伪逃逸（注入实为no-op，或仅单侧生效被误记为协同）」。
方法：对每个变异副本，比较其 harness_output.json / independent_recompute_output.json
      与基线之 crossing_count、rv_proxy 逐族取值。
"""
import json
import os

BASE = "/home/claude/T33review/v1_1"
WORK = "/home/claude/T33review/mut"
FAMS = ["path_P_triangular", "path_Q_sinusoidal", "path_O_far_low_amplitude",
        "path_Z_large_amplitude", "path_N_monotonic_trend", "path_B_boundary_touch_bounce"]


def load(d):
    h = json.load(open(os.path.join(d, "entity/harness_output.json"), encoding="utf-8"))
    v = json.load(open(os.path.join(d, "verify/independent_recompute_output.json"), encoding="utf-8"))
    return h, v


def sig(h, v):
    o = {}
    for f in FAMS:
        o[f] = (h[f]["crossing_count"], str(h[f]["rv_proxy"]),
                v[f]["crossing_count"], str(v[f]["rv_proxy"]))
    return o


bh, bv = load(BASE)
base = sig(bh, bv)

for mid in ["E13", "C2", "C3", "C4b", "C5", "C6b"]:
    d = os.path.join(WORK, mid)
    h, v = load(d)
    s = sig(h, v)
    print(f"===== {mid} =====")
    live_h, live_v, asym = [], [], []
    for f in FAMS:
        b = base[f]
        c = s[f]
        dh = (b[0] != c[0]) or (b[1] != c[1])
        dv = (b[2] != c[2]) or (b[3] != c[3])
        if dh:
            live_h.append(f)
        if dv:
            live_v.append(f)
        # 对称性：harness 侧与 verify 侧改后取值须一致（bit-exact 或 float 近似）
        same = (str(c[0]) == str(c[2])) and (c[1] == c[3] or abs(float(c[1]) - float(c[3])) / max(abs(float(c[1])), 1e-30) <= 1e-12)
        if not same:
            asym.append(f)
        if dh or dv:
            print(f"  {f:32s} 基线 h=({b[0]},{b[1]}) v=({b[2]},{b[3]})")
            print(f"  {'':32s} 变异 h=({c[0]},{c[1]}) v=({c[2]},{c[3]})  h变={dh} v变={dv}")
    print(f"  → harness侧生效族={live_h or '无'}")
    print(f"  → verify 侧生效族={live_v or '无'}")
    print(f"  → 两侧取值不一致族={asym or '无（对称）'}")
    if mid.startswith("C"):
        verdict = "对称且生效＝真协同逃逸" if (live_h and live_v and not asym) else \
                  ("注入未生效（no-op）" if not live_h and not live_v else "**非对称/单侧生效——须作废重写**")
    else:
        verdict = "生效" if live_h else "注入未改变任何输出（数值等价，符合外审E13定性）"
    print(f"  判定：{verdict}\n")

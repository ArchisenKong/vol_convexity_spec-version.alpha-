"""
verify/negative_control.py — T3-22 负向对照（乙-4 mutation最小形态）

注入对象＝被测实现entity/harness.py之band_position函数（非比对器verify/assert_check.py），
变异＝边界比较符 `moneyness > high` → `moneyness >= high`（典型off-by-one型协同变异，
T3-17外审M7同型：`>`→`>=`协同）。预期：该变异使put wing t4（moneyness恰等于
target_activation_band_high）从"within"误判为"above"，与entity/input_schema.md声明的
含端点口径（low<=m<=high计入within）矛盾，应被band序列钉点断言击落。

本脚本独立运行，产出mutated harness的实跑结果，与未变异的verify/independent_output.json
（正确期望值来源）比对，断言差异确实出现在预期位置（put t4），并显式打印实际失败之
断言名称（不写死单一归因文案，W-9(3)口径）。
"""

import json
import os
import re
import shutil
import subprocess
import sys
from fractions import Fraction as F

MUTATION_DIR = "verify/_mutation_tmp"


def inject_mutation():
    with open("entity/harness.py", encoding="utf-8") as f:
        src = f.read()

    target = "elif moneyness > high:"
    mutated_target = "elif moneyness >= high:"
    if target not in src:
        print(f"FAIL: mutation注入点未找到（预期字符串: {target!r}），负向对照本身失败")
        sys.exit(1)

    mutated_src = src.replace(target, mutated_target, 1)
    if mutated_src.count(mutated_target) != 1:
        print("FAIL: 变异注入命中数异常（预期恰1处）")
        sys.exit(1)

    os.makedirs(f"{MUTATION_DIR}/entity", exist_ok=True)
    with open(f"{MUTATION_DIR}/entity/harness.py", "w", encoding="utf-8") as f:
        f.write(mutated_src)
    return True


def run_mutated_harness():
    # 变异harness需要读取真实input_data.json；在mutation临时目录内建立指向链接（复制，保持只读隔离）
    shutil.copy("entity/input_data.json", f"{MUTATION_DIR}/entity/input_data.json")
    proc = subprocess.run(
        [sys.executable, "entity/harness.py"],
        cwd=MUTATION_DIR,
        capture_output=True,
        text=True,
    )
    if proc.returncode != 0:
        print(f"FAIL: 变异harness运行本身异常退出：{proc.stderr}")
        sys.exit(1)
    with open(f"{MUTATION_DIR}/entity/harness_output.json", encoding="utf-8") as f:
        return json.load(f)


def check_mutation_caught(mutated_output):
    with open("verify/independent_output.json", encoding="utf-8") as f:
        indep = json.load(f)

    put_h = mutated_output["wings"]["put_wing"]["periods"]
    put_i = indep["put_wing_derived"]

    caught_at = []
    for h_rec, i_rec in zip(put_h, put_i):
        assert h_rec["period"] == i_rec["period"]
        if h_rec["tail_coverage_band_position"] != i_rec["tail_coverage_band_position"]:
            caught_at.append((
                h_rec["period"],
                i_rec["tail_coverage_band_position"],
                h_rec["tail_coverage_band_position"],
            ))

    return caught_at


def main():
    print("--- 乙-4 mutation注入：entity/harness.py band_position边界符 > -> >= ---")
    inject_mutation()
    print(f"变异已注入临时目录 {MUTATION_DIR}/entity/harness.py（原entity/harness.py零改动）")

    mutated_output = run_mutated_harness()
    caught = check_mutation_caught(mutated_output)

    if not caught:
        print("FAIL: 变异未被任何比对断言击落（负向对照失效，判据链存在盲区）")
        shutil.rmtree(MUTATION_DIR, ignore_errors=True)
        sys.exit(1)

    expected_flip_period = "t4"
    flipped_periods = [c[0] for c in caught]
    if expected_flip_period not in flipped_periods:
        print(f"FAIL: 变异击落发生但不在预期边界点t4（实际击落于：{flipped_periods}），"
              f"判据链击落点与预期机制不符，需人工复核")
        shutil.rmtree(MUTATION_DIR, ignore_errors=True)
        sys.exit(1)

    for period, expected, mutated in caught:
        print(f"PASS: 变异在{period}被击落 —— 期望band={expected} 变异后band={mutated}"
              f"（断言：put wing band序列逐期钉点，verify/assert_check.py::enum_and_pinned_band_check）")

    shutil.rmtree(MUTATION_DIR, ignore_errors=True)
    print(f"--- 负向对照通过：{len(caught)}处击落，含预期边界点{expected_flip_period}，"
          f"归因指名断言=band序列逐期钉点（非泛化描述） ---")
    print("exit 0")
    sys.exit(0)


if __name__ == "__main__":
    main()

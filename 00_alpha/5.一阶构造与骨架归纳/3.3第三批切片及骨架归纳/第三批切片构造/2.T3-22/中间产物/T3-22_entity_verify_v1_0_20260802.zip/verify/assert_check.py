"""
verify/assert_check.py — T3-22 合格判据断言脚本（模板三D段＋任务6 v1.8 F段）

判据可检层次声明（F-3）：
  step0(i)(ii)(iii)、28-B三项、数值比对、附加断言中的枚举/边界钉点/声明完整性/
  声明-实现一致性/锚定词命中 —— 字面层，本脚本机械判定。
  S-1五问对应、S-2非信号地位、S-3消费面衔接的实质证伪 —— 语义层，本脚本仅提供
  机械前哨（假阴性通道），权威证伪面＝外审人读（task包§3已declared）。

失败运行不得残留成功日志（49-3根治形态）：日志文件在脚本开始时即截断重写，
任一断言失败立即append FAIL行并sys.exit(非零)，全程不写"ALL PASS"字样直至
真正跑完全部断言。
"""

import json
import re
import sys
import os
from fractions import Fraction as F

LOG_PATH = "verify/assert_log.txt"
_log_lines = []


def log(msg):
    _log_lines.append(msg)
    print(msg)


def flush_log():
    with open(LOG_PATH, "w", encoding="utf-8") as f:
        f.write("\n".join(_log_lines) + "\n")


def fail(msg):
    log(f"FAIL: {msg}")
    flush_log()
    sys.exit(1)


def ok(msg):
    log(f"PASS: {msg}")


# ---------------------------------------------------------------------------
# step0 · 前置合规断言
# ---------------------------------------------------------------------------

FORBIDDEN_IMPORT_RE = re.compile(
    r"^\s*(import\s+(requests|urllib|socket|yfinance|ibapi|ib_insync|pandas_datareader)\b"
    r"|from\s+(requests|urllib|socket|yfinance|ibapi|ib_insync|pandas_datareader)\b)",
    re.MULTILINE,
)
# 关键字片段以拼接方式构造（非混淆意图，如实标记）：本脚本自身即F-1扫描对象之一
# （对象集＝全部交付脚本，含assert_check.py自身），若关键字以连续字面量写入本文件，
# 扫描本文件时会对"用于探测的模式字符串本身"产生自指假阳性（探测器包含被探测词，
# 而非实际发起该等网络/数据源访问）。拼接不改变对*其他*文件的探测语义——被扫描对象
# 中这些词以连续自然形态出现时（真实import/URL/调用），join后的正则串仍逐字匹配、
# 命中不变。此处处理方式与判定依据显式留痕于verify/assert_log.txt与切片记录。
_KEYWORD_FRAGMENTS = [
    "IB" + "KR",
    "Quant" + "Connect",
    "http" + "://",
    "https" + "://",
    "urlo" + "pen",
    "requests" + r"\.",
    "socket" + r"\.",
]
FORBIDDEN_KEYWORD_RE = re.compile("|".join(_KEYWORD_FRAGMENTS))


def strip_comments_and_docstrings(src):
    """剥离注释与三引号docstring，供W-8判定基面使用（GK-14/TC-33假阳性教训口径）。"""
    src = re.sub(r'"""(.*?)"""', "", src, flags=re.DOTALL)
    src = re.sub(r"'''(.*?)'''", "", src, flags=re.DOTALL)
    lines = []
    for line in src.split("\n"):
        code = line.split("#", 1)[0]
        lines.append(code)
    return "\n".join(lines)


def w8_scan(path):
    with open(path, encoding="utf-8") as f:
        raw = f.read()
    stripped = strip_comments_and_docstrings(raw)
    import_hits = FORBIDDEN_IMPORT_RE.findall(stripped)
    keyword_hits = FORBIDDEN_KEYWORD_RE.findall(stripped)
    return import_hits, keyword_hits


def step0():
    log("--- step0 前置合规断言 ---")

    # (i) 人造数据源确认
    with open("entity/input_data.json", encoding="utf-8") as f:
        input_data = json.load(f)
    if input_data.get("_data_source") != "synthetic_hand_constructed":
        fail("input_data._data_source != synthetic_hand_constructed")
    ok("(i) input_data._data_source = synthetic_hand_constructed")

    if not os.path.exists("entity/harness_output.json"):
        fail("entity/harness_output.json 不存在，harness未真跑")
    with open("entity/harness_output.json", encoding="utf-8") as f:
        harness_output = json.load(f)
    if harness_output.get("_data_source") != "synthetic_hand_constructed":
        fail("harness_output._data_source != synthetic_hand_constructed")
    ok("(i) harness_output._data_source = synthetic_hand_constructed")

    # (ii) W-8三部分静态扫描（F-1完备性自检对象集：entity/harness.py, verify/independent_recompute.py,
    #      verify/assert_check.py, verify/negative_control.py，剥离注释/docstring后执行）
    scan_targets = [
        "entity/harness.py",
        "verify/independent_recompute.py",
        "verify/assert_check.py",
        "verify/negative_control.py",
    ]
    for path in scan_targets:
        if not os.path.exists(path):
            fail(f"F-1扫描对象缺失：{path}")
        import_hits, keyword_hits = w8_scan(path)
        if import_hits or keyword_hits:
            fail(f"{path} 命中forbidden模式：import={import_hits} keyword={keyword_hits}")
        ok(f"(ii) {path} W-8三部分扫描 0命中")

    # (iii) independent_recompute.py 与 harness 零耦合
    with open("verify/independent_recompute.py", encoding="utf-8") as f:
        recompute_src = f.read()
    stripped_recompute = strip_comments_and_docstrings(recompute_src)
    if re.search(r"import\s+.*harness", stripped_recompute):
        fail("independent_recompute.py 检出 import harness")
    if "harness_output.json" in stripped_recompute:
        fail("independent_recompute.py 检出读取 harness_output.json 字样")
    ok("(iii) independent_recompute.py 零harness耦合（剥离后核验）")

    return input_data, harness_output


# ---------------------------------------------------------------------------
# F-1 · 交付脚本完备性自检（枚举清单 vs 实际交付集）
# ---------------------------------------------------------------------------

EXPECTED_SCRIPTS = {
    "entity/harness.py",
    "verify/independent_recompute.py",
    "verify/assert_check.py",
    "verify/negative_control.py",
}


def f1_completeness_check():
    log("--- F-1 交付脚本完备性自检 ---")
    actual = set()
    for root, _dirs, files in os.walk("."):
        for fn in files:
            if fn.endswith(".py"):
                rel = os.path.normpath(os.path.join(root, fn)).replace(os.sep, "/")
                rel = rel[2:] if rel.startswith("./") else rel
                actual.add(rel)
    missing = EXPECTED_SCRIPTS - actual
    extra = actual - EXPECTED_SCRIPTS
    if missing:
        fail(f"F-1完备性缺项：{missing}")
    ok(f"F-1完备性核验通过：枚举清单={sorted(EXPECTED_SCRIPTS)}；实际交付含={sorted(actual)}"
       + (f"（封闭规则自动纳入：{sorted(extra)}）" if extra else ""))


# ---------------------------------------------------------------------------
# 28-B(i) · 断言基线程序化解析源文
# ---------------------------------------------------------------------------

SOURCE_PATH = "/mnt/project/3_波动率凸性操作方法论主文档_T0_frozen_clean_20260615.md"

REQUIRED_ANCHOR_WORDS = [
    "integrity",
    "左尾",
    "右尾",
    "moneyness drift",
    "time decay",
    "skew change",
    "liquidity deterioration",
    "monetization",
    "roll",
    "premium bleed",
    "diagnostic",
    "candidate input",
    "Phase 4 governance input",
    "交易信号",
]


def source_anchor_check():
    log("--- 28-B(i) 源文程序化定位与锚定词核证 ---")
    if not os.path.exists(SOURCE_PATH):
        fail(f"源文不可定位：{SOURCE_PATH}（拒绝静默回退内嵌副本）")

    with open(SOURCE_PATH, encoding="utf-8") as f:
        content = f.read()

    m = re.search(r"## 13\.4 Long put / long call integrity(.*?)## 13\.5", content, re.DOTALL)
    if not m:
        fail("源文§13.4段落定位失败（正则未命中 '## 13.4 ... ## 13.5' 区间）")
    block = m.group(1)
    ok(f"源文§13.4段落定位成功，区间长度={len(block)}字符")

    missing_words = [w for w in REQUIRED_ANCHOR_WORDS if w not in block]
    if missing_words:
        fail(f"锚定词缺失（功能层必过面，F-6）：{missing_words}")
    ok(f"锚定词表{len(REQUIRED_ANCHOR_WORDS)}项全部在场（F-6功能层必过面；形状层词不设、不作必过）")
    return block


# ---------------------------------------------------------------------------
# 28-B(iii) · 目录结构判据档
# ---------------------------------------------------------------------------

def directory_structure_check():
    log("--- 28-B(iii) 目录结构判据档 ---")
    expected = {
        "entity/input_schema.md",
        "entity/input_data.json",
        "entity/harness.py",
        "entity/harness_output.json",
        "verify/independent_recompute.py",
        "verify/independent_output.json",
        "verify/assert_check.py",
        "verify/assert_log.txt",
        "verify/negative_control.py",
        "verify/comparison_table.tsv",
    }
    actual = set()
    for sub in ("entity", "verify"):
        if not os.path.isdir(sub):
            fail(f"目录缺失：{sub}/")
        for fn in os.listdir(sub):
            actual.add(f"{sub}/{fn}")
    # assert_log.txt 由本脚本自身产出，运行时可能尚不存在于本次核验前——不计入前置阻断
    missing = expected - actual - {"verify/assert_log.txt", "verify/comparison_table.tsv"}
    if missing:
        fail(f"entity/+verify/ 打包结构缺项（不符判据档，24-A7）：{missing}")
    ok("entity/+verify/ 打包结构核验通过（assert_log.txt/comparison_table.tsv为本轮运行产出，随runend核验）")


# ---------------------------------------------------------------------------
# 数值比对（D段②）
# ---------------------------------------------------------------------------

def numeric_comparison(harness_output, comparison_rows):
    log("--- 数值比对（harness_output vs independent_output，容差子口径(a) bit-exact） ---")
    with open("verify/independent_output.json", encoding="utf-8") as f:
        indep = json.load(f)

    put_h = harness_output["wings"]["put_wing"]["periods"]
    call_h = harness_output["wings"]["call_wing"]["periods"]
    put_i = indep["put_wing_derived"]
    call_i = indep["call_wing_derived"]

    put_fields = [
        "tail_coverage_band_position", "moneyness_drift", "time_decay_fraction",
        "skew_change", "liquidity_deterioration", "premium_bleed_integrity_check",
    ]
    call_fields = [
        "tail_coverage_band_position", "upside_convexity_reading",
        "premium_bleed_integrity_check",
    ]

    diff_count = 0
    total = 0
    for wing_name, h_periods, i_periods, fields in (
        ("put_wing", put_h, put_i, put_fields),
        ("call_wing", call_h, call_i, call_fields),
    ):
        for h_rec, i_rec in zip(h_periods, i_periods):
            assert h_rec["period"] == i_rec["period"]
            for field in fields:
                total += 1
                h_val = h_rec[field]
                i_val = i_rec[field]
                match = h_val == i_val
                comparison_rows.append((wing_name, h_rec["period"], field, str(h_val), str(i_val), "0" if match else "DIFF"))
                if not match:
                    diff_count += 1
                    log(f"  DIFF {wing_name} {h_rec['period']} {field}: harness={h_val} indep={i_val}")

    if diff_count > 0:
        fail(f"数值比对越限：{diff_count}/{total} 项不一致（容差(a)=0 bit-exact，裁决13）")
    ok(f"数值比对全部通过：{total}/{total} 项 diff=0（bit-exact，全程fractions.Fraction）")
    return total


def write_comparison_table(rows):
    with open("verify/comparison_table.tsv", "w", encoding="utf-8") as f:
        f.write("wing\tperiod\tfield\tharness_value\tindependent_value\tdiff\n")
        for row in rows:
            f.write("\t".join(row) + "\n")
    ok(f"比对表程序化产出 verify/comparison_table.tsv（{len(rows)}行，W-13(14)禁手工誊写）")


# ---------------------------------------------------------------------------
# 附加断言（D段③ / F-4 / S-1 / S-2 / S-3 机械前哨）
# ---------------------------------------------------------------------------

FIVE_QUESTION_MAP = {
    "Q1_left_tail_coverage": ("put_wing", ["tail_coverage_band_position"]),
    "Q2_put_wing_dulling_four_factors": (
        "put_wing",
        ["moneyness_drift", "time_decay_fraction", "skew_change", "liquidity_deterioration"],
    ),
    "Q3_right_tail_participation_convexity": (
        "call_wing", ["tail_coverage_band_position", "upside_convexity_reading"],
    ),
    "Q4_call_wing_absence_four_forms": ("call_wing", ["wing_presence_status"]),
    "Q5_premium_bleed_booked_not_downgraded": (
        "both", ["premium_bleed_booked", "premium_bleed_downgrade_flag", "premium_bleed_integrity_check"],
    ),
}

VALID_PRESENCE_ENUM = {"present", "deleted", "over_monetized", "covered_call_shipped", "roll_misplaced"}

# 期望band序列逐期钉点（D2式修复先例：不止验枚举合法性，钉住期望值本身）
EXPECTED_PUT_BAND = ["within", "within", "within", "within", "above", "above", "above", "below", "within"]
EXPECTED_CALL_BAND = ["below", "within", "within", "within", "within", "above", "below", "below", "below"]

FORBIDDEN_SIGNAL_WORDS = [
    "signal", "auto_execute", "auto_route", "recommend_order", "place_order",
    "买入", "卖出", "下单", "自动执行", "自动下单", "交易建议",
]


def s1_declaration_completeness(harness_output):
    log("--- S-1 五问对应可指认：声明分量齐备断言（机械前哨） ---")
    put_periods = harness_output["wings"]["put_wing"]["periods"]
    call_periods = harness_output["wings"]["call_wing"]["periods"]

    for qname, (wing, fields) in FIVE_QUESTION_MAP.items():
        targets = []
        if wing in ("put_wing", "both"):
            targets.append(("put_wing", put_periods))
        if wing in ("call_wing", "both"):
            targets.append(("call_wing", call_periods))
        for wname, periods in targets:
            for rec in periods:
                for field in fields:
                    if field not in rec:
                        fail(f"S-1声明分量缺失：{qname} 要求字段 {field} 未见于 {wname}/{rec['period']}")
    ok(f"S-1声明分量齐备核验通过：五问{len(FIVE_QUESTION_MAP)}项映射字段全部在场")


def enum_and_pinned_band_check(harness_output):
    log("--- Q4枚举合规 + band序列逐期钉点（D2式修复口径） ---")
    call_periods = harness_output["wings"]["call_wing"]["periods"]
    for rec in call_periods:
        status = rec["wing_presence_status"]
        if status not in VALID_PRESENCE_ENUM:
            fail(f"wing_presence_status非法值：{status}（合法枚举={VALID_PRESENCE_ENUM}）")
    ok(f"Q4枚举合规核验通过：合法枚举集={sorted(VALID_PRESENCE_ENUM)}")

    put_periods = harness_output["wings"]["put_wing"]["periods"]
    actual_put_band = [r["tail_coverage_band_position"] for r in put_periods]
    if actual_put_band != EXPECTED_PUT_BAND:
        fail(f"put wing band序列钉点不符：期望={EXPECTED_PUT_BAND} 实际={actual_put_band}")
    ok(f"put wing band序列逐期钉点通过：{actual_put_band}")

    actual_call_band = [r["tail_coverage_band_position"] for r in call_periods]
    if actual_call_band != EXPECTED_CALL_BAND:
        fail(f"call wing band序列钉点不符：期望={EXPECTED_CALL_BAND} 实际={actual_call_band}")
    ok(f"call wing band序列逐期钉点通过：{actual_call_band}")


def f4_declaration_implementation_consistency(harness_output):
    log("--- F-4 声明-实现一致性断言（边界口径：low<=m<=high含两端计入within） ---")
    put_periods = harness_output["wings"]["put_wing"]["periods"]
    call_periods = harness_output["wings"]["call_wing"]["periods"]

    # put t4: moneyness=19/20=0.95=target_activation_band_high，边界含端点应判within
    t4 = next(r for r in put_periods if r["period"] == "t4")
    if F(t4["moneyness"]) != F(19, 20):
        fail(f"F-4边界样本漂移：put t4 moneyness期望19/20，实际={t4['moneyness']}")
    if t4["tail_coverage_band_position"] != "within":
        fail(f"F-4边界断言不符：put t4 恰等于band_high，声明口径含端点，实际判定={t4['tail_coverage_band_position']}")
    ok("F-4边界断言通过：put t4（=band_high）判定within，符合schema声明之含端点口径")

    # put t9: moneyness=17/20=0.85=target_activation_band_low
    t9 = next(r for r in put_periods if r["period"] == "t9")
    if F(t9["moneyness"]) != F(17, 20):
        fail(f"F-4边界样本漂移：put t9 moneyness期望17/20，实际={t9['moneyness']}")
    if t9["tail_coverage_band_position"] != "within":
        fail(f"F-4边界断言不符：put t9 恰等于band_low，实际判定={t9['tail_coverage_band_position']}")
    ok("F-4边界断言通过：put t9（=band_low）判定within，符合含端点口径")

    # call t2: moneyness=9/10=0.90=target_activation_band_low
    c2 = next(r for r in call_periods if r["period"] == "t2")
    if c2["tail_coverage_band_position"] != "within":
        fail(f"F-4边界断言不符：call t2（=band_low）实际判定={c2['tail_coverage_band_position']}")
    ok("F-4边界断言通过：call t2（=band_low）判定within")

    # call t5: moneyness=21/20=1.05=target_activation_band_high
    c5 = next(r for r in call_periods if r["period"] == "t5")
    if c5["tail_coverage_band_position"] != "within":
        fail(f"F-4边界断言不符：call t5（=band_high）实际判定={c5['tail_coverage_band_position']}")
    ok("F-4边界断言通过：call t5（=band_high）判定within")


def bleed_monotonic_independent_sanity(input_data):
    log("--- Q5独立最小路径：bleed单调非降直接核验（第三独立路径，直读input） ---")
    for wing_key in ("put_wing", "call_wing"):
        periods = input_data["wings"][wing_key]["periods"]
        booked_seq = [F(r["premium_bleed_booked"]) for r in periods]
        for i in range(1, len(booked_seq)):
            if booked_seq[i] < booked_seq[i - 1]:
                fail(f"{wing_key} premium_bleed_booked 非单调：{periods[i]['period']} 低于前期")
        if any(r["premium_bleed_downgrade_flag"] for r in periods):
            fail(f"{wing_key} 检出premium_bleed_downgrade_flag=True（Q5违反：bleed被降级）")
    ok("bleed单调非降 + downgrade_flag恒False：两翼18期全部核验通过（第三独立路径）")


def s2_non_signal_wording_check():
    log("--- S-2 非信号地位：措辞审计（启发式机械前哨，权威证伪面＝人读） ---")
    # 扫描对象＝状态输出面本体（domain输出：schema/harness/独立复算逻辑），
    # 不含verify/assert_check.py与verify/negative_control.py自身——后两者为
    # 审计/负向对照工具代码，其源码必然以字面量承载禁用词列表本身（探测器含
    # 被探测词，同W-8自指假阳性性质，非"状态输出授予信号地位"）。如实标注于此，
    # 不作静默排除。
    hits = {}
    for path in [
        "entity/harness.py", "entity/input_schema.md",
        "verify/independent_recompute.py",
    ]:
        if not os.path.exists(path):
            continue
        with open(path, encoding="utf-8") as f:
            content = f.read()
        found = [w for w in FORBIDDEN_SIGNAL_WORDS if w in content]
        if found:
            hits[path] = found
    if hits:
        fail(f"S-2启发式命中禁用措辞（需人读复核是否构成违反）：{hits}")
    ok("S-2启发式扫描0命中（machine picket only；权威证伪面仍为外审人读）")


def tpl1_t303_02_pointer_check(harness_output):
    log("--- TPL1-T303-02随行指针核验：本根未产出'钝化判定'布尔量 ---")
    put_periods = harness_output["wings"]["put_wing"]["periods"]
    forbidden_keys = {"put_wing_dulled", "wing_dullness_triggered", "is_dulled", "dulling_verdict"}
    for rec in put_periods:
        present = forbidden_keys & set(rec.keys())
        if present:
            fail(f"检出越权钝化判定字段：{present}（TPL1-T303-02本根不重开不代裁）")
    ok("TPL1-T303-02边界核验通过：本根仅输出四因诊断读数，未合成钝化判定布尔量")


# ---------------------------------------------------------------------------
# 主流程
# ---------------------------------------------------------------------------

def main():
    if os.path.exists(LOG_PATH):
        os.remove(LOG_PATH)

    input_data, harness_output = step0()
    f1_completeness_check()
    source_anchor_check()
    directory_structure_check()

    comparison_rows = []
    total = numeric_comparison(harness_output, comparison_rows)
    write_comparison_table(comparison_rows)

    s1_declaration_completeness(harness_output)
    enum_and_pinned_band_check(harness_output)
    f4_declaration_implementation_consistency(harness_output)
    bleed_monotonic_independent_sanity(input_data)
    s2_non_signal_wording_check()
    tpl1_t303_02_pointer_check(harness_output)

    log(f"--- ALL PASS：{total}项数值比对 + 全部附加断言通过 ---")
    flush_log()
    print("exit 0")
    sys.exit(0)


if __name__ == "__main__":
    main()

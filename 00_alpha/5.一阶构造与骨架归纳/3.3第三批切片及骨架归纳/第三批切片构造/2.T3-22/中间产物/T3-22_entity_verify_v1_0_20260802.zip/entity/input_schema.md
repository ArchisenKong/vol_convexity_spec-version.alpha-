# input_schema · T3-22 wing integrity 状态量 · v1.0 · 施工候选

> **身份**：T3-22（wing integrity状态量）之阶段A一阶实体，第三批续1（断点二闭合位，
> 已建成消费方T3-17之上游）。
> **授权链**：任务包_续1_T3-22_v1.0（裁决52-1＋54-6＋54§3＋52-3=b）＋裁决1（构造链，
> 人造input全程强制）＋裁决13/19（容差）＋裁决21(a)（三分判别）＋裁决24-A7 O1（目录
> 结构）＋裁决28-B（非零退出码＋程序化解析）＋裁决39-B4（锚定词表分层）＋裁决53（W-13
> 判据类并入任务6 v1.8 F段）。
> **会话身份**：切片构造会话。零自审、零裁决——本文件全部判断均为构造侧呈报，实体
> 边界与范围疑义一律呈KD（§13本根裁定登记）。

---

## §1 对象定义与本切片实际计算之要件（C1）

T3-22＝"持仓＋行情→状态向量"（裁决52 §2定位语）：确认长端双翼（long put／long call）
是否仍承担母结构中左尾保护与右尾参与职能之诊断状态量。判据源＝T3§13.4（行1314-1326，
审计表v1.5三态全部**思想锚定**）。

**本切片计算要件**：
1. moneyness相对declared_basis两端边界（`target_activation_band_low/high`）之三分位置
   判定（below/within/above），两翼公用同一机制（Q1/Q3公共结构）。
2. put wing四因诊断读数（moneyness_drift／time_decay_fraction／skew_change／
   liquidity_deterioration），相对本翼t1（entry）基准的差值/比例计算（Q2）。
3. call wing convexity读数（upside_convexity_reading＝raw_gamma直接标注，Q3）。
4. premium bleed账本完整性联合检验（单调非降 ∧ downgrade_flag恒False，Q5，两翼各算）。

**上游输入（本切片不计算、作已声明值/人造行情坐标接收，裁决1强制）**：
- 两翼各9期（t1-t9）moneyness、raw_vega、raw_gamma（人造时序本体）。
- 两翼declared_basis：`target_activation_band_low/high`（构造候选值，见§6）。
- put wing每期：`dte_remaining`、`skew_reading`、`liquidity_reading`。
- call wing每期：`dte_remaining`、`wing_presence_status`（枚举，位置事实，非计算得出——见§4）。
- 两翼每期：`premium_bleed_booked`（累计账本值）、`premium_bleed_downgrade_flag`（布尔）。

**本切片不计算、不供给（越界声明，§8消费面契约边界）**：`target_vega_response_level`／
`target_gamma_response_level`——T3-17 §1"该翼建仓/roll后声明的基准"一并列出的另两项，
但其消费场景专属T3-17自身响应比合成（occupant#1候选规格），非T3-22五问范畴（Q1-Q5
均不涉逐Greek响应水平目标）。本切片不代T3-17声明该两值，避免越界填入下游对象参数
（呈KD追认，见§13#1）。

---

## §2 五问→输出分量映射表（S-1机械前哨基面）

| 判据源问句（T3§13.4） | 输出分量 | 归属翼 |
|---|---|---|
| Q1 long put是否仍覆盖目标左尾路径（T3·1319） | `tail_coverage_band_position` | put_wing |
| Q2 put wing是否因moneyness drift/time decay/skew change/liquidity deterioration而钝化（T3·1320） | `moneyness_drift`／`time_decay_fraction`／`skew_change`／`liquidity_deterioration` | put_wing |
| Q3 long call是否仍提供右尾参与与upside convexity（T3·1321） | `tail_coverage_band_position`／`upside_convexity_reading` | call_wing |
| Q4 call wing是否因删除/过度monetization/covered call出货/roll后位置错误而缺席（T3·1322） | `wing_presence_status` | call_wing |
| Q5 长端双翼premium bleed是否入账未降级（T3·1323） | `premium_bleed_booked`／`premium_bleed_downgrade_flag`／`premium_bleed_integrity_check` | put_wing＋call_wing |

**权限句重申（T3·1326）**：本状态量不是单独交易信号，仅作diagnostic、candidate input
或Phase 4 governance input。本schema与entity/harness.py全程不产出roll/repair/review
执行逻辑、不产出信号字段（S-2机械前哨核验对象，见verify/assert_check.py）。

---

## §3 三分判别套用表（裁决21(a)受控文本v1.1；乙-7回引条款号）

| # | 计算成分 | 判别 | 依据（双重引用） | 处置 |
|---|---|---|---|---|
| 1 | Q1/Q3公共band位置三分机制（below/within/above） | **类一** | 受控文本§2；源文"是否仍覆盖目标左尾路径"/"是否仍提供右尾参与"直接语义支持位置类判定；先例T-76/T3-03/GK-14/T3-17均属同型A1分桶机制，无矛盾候选 | 定案写入实现 |
| 2 | band边界具体数值（`target_activation_band_low/high`） | **类三** | 受控文本§4；数值本身无权威文本/既有裁决可排除任何候选，工程候选待Phase B证伪；同型先例＝T-76阈值H1、T3-17 floor/window | 阶段A候选之一，本根新声明，不外推，见§6 |
| 3 | Q2四因诊断读数差值计算式 | **类二·缺定义型** | 受控文本§3；回引既有登记条目TPL1-T303-02（撞墙清单_T3-03 v1.4：诊断解释规则权威计算定义缺失），引用不重登，本根不重开不代裁 | 确定性占位读数，不claim诊断权威，见§4 |
| 4 | Q5 bleed账本完整性联合检验（单调非降∧未降级） | **类一** | 受控文本§2；宪-CV-05"凸性有成本"（思想锚定，审计表T3·1326行）＋源文"premium bleed 是否被账本记录，但未因此被降级为可删除成本"直接语义支持"记录存在性+非降级"联合布尔机制，无矛盾候选 | 定案写入实现 |
| 5 | Q4 wing_presence_status | 不入三分（数据/机制刀口前置分流） | 受控文本§1："成分只作为值被消费＝数据，不进入三分判别"——存续状态为持仓事实，人造声明值，非本切片计算派生 | 数据层，见§4 |
| 6 | Q3 upside_convexity_reading（raw_gamma直接标注） | 不入三分（数据搬运，非新增机制） | 受控文本§1同上；该字段为已声明raw_gamma之贴标签操作，未引入新计算规则 | 数据搬运 |

---

## §4 Q4 wing_presence_status 与 TPL1-T303-02 随行指针（§5强制携带，本根不重开不闭合）

`wing_presence_status`枚举值域：`present` / `deleted` / `over_monetized` /
`covered_call_shipped` / `roll_misplaced`——逐项对应T3·1322四缺席形态（删除/过度
monetization/covered call出货/roll后位置错误）加一"present"健康态，由人造持仓事实
直接声明（数据层，§3#5），非本切片计算派生。

**TPL1-T303-02随行指针（撞墙清单_T3-03 v1.4，强制携带，裁决54-4）**：wing dullness
分量现状态＝候选级闭合（裁决40-4，经T3-17 v2.0交付候选可算化）；gamma_center／
vega_concentration／theta_burn三标签维持缺定义、open。本切片Q2产出**仅为四因诊断
读数（差值/比例，见entity/harness.py process_put_period），不合成"put wing是否钝化"
之布尔判定**——该判定之权威计算规则仍属TPL1-T303-02范畴（诊断解释规则之权威计算
定义如何从raw字段实际得出），本根不重开、不闭合、不代裁该条目。verify/assert_check.py
之`tpl1_t303_02_pointer_check`断言核证本切片输出中不含任何越权钝化判定字段
（`put_wing_dulled`／`wing_dullness_triggered`／`is_dulled`／`dulling_verdict`等）。

---

## §5 仪表身份标注（对照表§3随行义务③＋§5.4常设纪律，强制）

本切片消费/携带raw_vega、raw_gamma两项模型派生量（Greeks）。依宪-EP-06（价格在先＋
派生量仪表推论：模型派生量＝仪表读数非真理源）＋24-E3引擎范围注记形态：

**raw_vega、raw_gamma、upside_convexity_reading（=raw_gamma标注）三字段，其数值身份＝
仪表读数（instrument reading），非真理源（truth source）；不承载"应然定价/正确Greeks"
宣称，不以此类读数裁决持仓合法性或获利正当性。** 本条注记随§6取值形态裁定同批生效，
适用于本切片全部产出（entity/input_schema.md、harness_output.json、切片记录）。

---

## §6 raw_vega/raw_gamma取值形态（本根裁定登记，呈KD）

**候选路径**：(a) 经TPL1-T76-01（品种感知自算Greeks引擎，v1.1，裁决49终态收口）实际
调用求值；(b) 声明值接收（人造行情坐标直接手工声明，先例＝T3-17 §1/§6同型处置）。

**本根取(b)**。理由：
1. **环境事实**：本构造会话可及文件系统（`/mnt/project/`）核证零`.py`/代码类文件，
   TPL1-T76-01之`entity/engine.py`等实际可导入产物未挂载本会话（`find /mnt/project
   -type f ! -name "*.md"`核证为空）；仅其schema/治理文档（一阶实体_TPL1-T76-01
   引擎_input_schema_v1_1）在场，属"背景件（可选，非必装）"定位（任务包§1）。
2. **分层原则**：TPL1-T76-01已收口（裁决49-7），M1"纯函数+账本"双解耦架构下承担
   Greeks供给之调用权；若本根在无法真实导入调用的情况下自行重新实现BSM闭式解以
   "冒充调用"，将构成对M1已收口产物的越权平行重造，违反downstream消费而非重造之
   分层纪律。
3. **先例一致性**：T3-17（本切片下游消费方）自身即采声明值接收（§1"上游输入，
   本切片不计算，作已声明值接收"；§6"全部数值为本根手工构造，非源自任何真实行情
   或历史样本"），本根与之取同型路径，形态衔接无冲突。

**呈KD**：若KD认为后续切片应实测engine-call路径（例如真实导入TPL1-T76-01产物验证
"调用权"实际可执行性），需先解决"引擎代码产物跨会话持久化/挂载"这一环境层缺口
（非本切片方法论缺口，供KD参考是否另立W/DOC条目）。

---

## §7 B段路线选择与容差子口径

- **B段计算路线**：全程离散有理数算术（`fractions.Fraction`），无sqrt/exp/log等
  超越函数 → 容差子口径**(a) bit-exact**（裁决13/19，骨架C3分派判据＝超越函数在场性）。
- **路径独立（D段②硬要求）**：`entity/harness.py`＝命令式for循环风格；
  `verify/independent_recompute.py`＝函数式/生成器风格，四处表达式级分叉（band位置
  嵌套三元表达式、abs改写为max-min展开式、time_decay改写为1-(dte/entry_dte)恒等式、
  bleed单调检验改写为zip对偶生成器+all()谓词），不复用harness任何代码或计算思路，
  不import harness模块、不读取harness_output.json。

---

## §8 消费面契约（断点二，T3-17 §1衔接核验，S-3）

T3-17 §1声明上游输入需"T3-22状态时序本身（moneyness、raw_vega、raw_gamma，§6未审
引用T3§13.4形态依据）"。本切片输出（`entity/harness_output.json`）两翼×9期均含
`moneyness`／`raw_vega`／`raw_gamma`三字段，形态（两翼×9期）与T3-17 §6"两翼各9期
人造时序"假设严格一致——**衔接核验通过**（字面层，verify/assert_check.py::
s1_declaration_completeness间接核证三字段在场；语义层的"T3-17实际消费兼容性"仍
待外审人读）。

**T3-17"未审引用"注记之解除**：本切片收口时联动兑现（裁决52-1兑现点），本切片
构造会话不执行该解除（§2.3任务包原文）。

**不涉及、不供给**：`target_vega_response_level`／`target_gamma_response_level`
（见§1越界声明）。**不修改**T3-17全部产物／审计表／治理册slot#1档案／骨架（§2.5
范围边界）。

---

## §9 边界口径声明（F-4声明-实现一致性断言基线）

band位置三分判定边界口径（本根声明，须与entity/harness.py::band_position及
verify/independent_recompute.py::band_position_alt两侧实现一致，verify/
assert_check.py::f4_declaration_implementation_consistency核证）：

```
low <= moneyness <= high  → within（含两端边界）
moneyness > high          → above
moneyness < low           → below
```

---

## §10 范围边界重申（§2.5，本切片明确不做之事）

状态输出之下游动作（roll、repair、review执行逻辑）不在本切片范围：T3·1326判据源
即禁其为交易信号；执行逻辑不实现（A7语义标注随行形态，T3-18裁定6先例）。本切片
不裁决、不修改T3-17全部产物／审计表／治理册slot#1档案／骨架。

---

## §11 数据来源声明（C6档二字段规范化，裁决23(f)采纳）

`entity/input_data.json`顶层字段`_data_source: "synthetic_hand_constructed"`；
harness零数据源接入（W-8三部分静态扫描核证，见verify/assert_check.py）。

---

## §12 判据源双层结构标注（裁决28-D措辞读法）

本schema及全部产出中"判据源文位置"字段指T3§13.4（行1314-1326，审计表T3·1316／
T3·1318-1324／T3·1326三行，均**思想锚定**→宪-ST-04/05/07＋宪-ID-01＋宪-CV-05＋
宪-EP-06/07），仅为源文出处定位，不构成档位或效力断言。度量形状层（band边界具体
数值）无冻结判据源，构造自由度候选，见§3#2、§6。判据效力链＝审计表锚定→宪法
（裁决28-D）。

---

## §13 本根裁定登记素材（供切片记录汇总，呈KD）

| # | 裁定语句 | 性质 | 指针 |
|---|---|---|---|
| 1 | 实体边界：Q1/Q3band位置+Q2四因诊断读数+Q3convexity标注+Q5账本完整性联合检验＝要件；两翼时序本体/declared_basis/枚举存续状态/账本值＝上游输入；`target_vega_response_level`/`target_gamma_response_level`不属本切片供给范围 | 本根裁定 | §1、§8 |
| 2 | band边界数值`target_activation_band_low/high`（put: 17/20,19/20；call: 9/10,21/20）＝类三阶段A候选之一，本根新声明，不外推，待Phase B证伪 | 本根裁定 | §3#2、§6、entity/input_data.json |
| 3 | Q2四因诊断读数差值计算式＝类二·缺定义型占位读数，引用TPL1-T303-02既有登记（不重登），不claim诊断权威，不产出钝化判定布尔量 | 引用不重登 | §3#3、§4 |
| 4 | raw_vega/raw_gamma取值形态＝声明值接收（非engine调用），理由见§6三点（环境事实+分层原则+先例一致性） | 本根裁定 | §6 |
| 5 | band位置三分机制、Q5账本完整性联合检验＝类一，定案写入实现 | 本根裁定 | §3#1、§3#4 |
| 6 | 仪表身份标注：raw_vega/raw_gamma/upside_convexity_reading三字段＝仪表读数非真理源（宪-EP-06+24-E3形态） | 强制随行义务履行（对照表§3③+§5.4） | §5 |
